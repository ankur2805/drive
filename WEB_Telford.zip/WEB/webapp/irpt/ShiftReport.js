var projectName = "";
var avail_running;


function populateAvailData(){


	document.getElementById("id_avail_fail").innerHTML="0";
	document.getElementById("id_avail_unsch").innerHTML="0";
	document.getElementById("id_avail_rest").innerHTML="0";
	document.getElementById("id_avail_idle").innerHTML="0";
	document.getElementById("id_avail_rate").innerHTML="0";

	var plant = document.getElementById("id_hid_plant").value;
	var resource = document.getElementById("id_hid_resr").value;
	

	var currenttime = new Date();
	var currentDT = getCurrentDateTime(currenttime);
	var EDate=document.getElementById("id_hid_shiftenddate").value;
	var selectedShiftstatus =document.getElementById("id_shiftrunstatus").value;
	
	
	var sParams = "&Param.1="+plant+"&Param.2="+resource+"&Param.3="+document.getElementById("id_hid_StartDate").value;
		if(EDate <= currentDT || selectedShiftstatus == "2" || selectedShiftstatus == "3")
		{
			
			sParams = sParams + "&Param.4="  + document.getElementById("id_hid_shiftenddate").value;
		}
		else
		{
			sParams = sParams + "&Param.4="  + currentDT;
			
		}
		
		var url = "/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_OEEAvailability&content-type=text/json";
		url = url + sParams;
		jQuery.ajax({
			url: url,
		            type : 'GET',
			async:false,
		      	success : function (jsonData) {
		      		
		      		var i=0;
		      		var tot=0;
		      		var j=0;
		      		var name;
		      		
		      		if (jsonData && jsonData.Rowsets && jsonData.Rowsets.Rowset
		    				&& jsonData.Rowsets.Rowset[0]
		    				&& jsonData.Rowsets.Rowset[0].Row) {
		    			
		    			
		    			var rows = jsonData.Rowsets.Rowset[0].Row;
		    			i = rows.length;
		    			
		    			for(j=0;j<i;j++){
		    				
		    				name = rows[j][Object.keys(rows[j])[0]];
		    				var time = rows[j][Object.keys(rows[j])[1]];
		    				if(time!=""){
	    						
	    						tot=tot+parseInt(time);
	    						
	    					}
		    				
		    				if(name=="Running"){
		    					
		    					
		    					document.getElementById("id_avail_running_shift").value = time;
		    					document.getElementById("id_avail_running_new").value =  avail_running;
		    					
		    				}
		    				else if(name=="Failure" || name=="F"){
		    					document.getElementById("id_avail_fail").innerHTML = time;
		    				}
		    				else if(name=="Line Restraint" || name=="L"){
		    					document.getElementById("id_avail_rest").innerHTML = time;
		    				}
		    				else if(name=="Unscheduled"  || name=="U"){
		    					document.getElementById("id_avail_unsch").innerHTML = time;
		    				}
		    				else if(name=="Idle"  || name=="I"){
		    					document.getElementById("id_avail_idle").innerHTML = time;
		    				}
		    				
		    			}
		    			
		    			// End of for loop
		    			document.getElementById("id_avail_tottime").innerHTML = tot;
		    			
		    			//Change By Sudipta Chakraborty for change order 166136 on 25 Nov.

		    			var selectedShiftstatus =document.getElementById("id_shiftrunstatus").value;
		    			var selectedShiftRunTime = document.getElementById("id_shiftruntime").value;

		    			if(selectedShiftstatus != "1")
		    			{
		    				if((selectedShiftRunTime-document.getElementById("id_avail_running_new").value) > 0)
		    				{
		    					
		    					document.getElementById("id_unaccounted").innerHTML = selectedShiftRunTime - document.getElementById("id_avail_running_new").value;
		    				}	
		    				else
		    				{
		    					document.getElementById("id_unaccounted").innerHTML ="0";
		    				}
		    			}

		    				//Change By Sudipta Chakraborty for change order 166136 on 25 Nov END.
		    			
		    			var js_availability_oee=(parseFloat(document.getElementById("id_avail_running").innerHTML)/parseFloat(parseFloat(document.getElementById("id_avail_tottime").innerHTML) - parseFloat(document.getElementById("id_avail_unsch").innerHTML)))*100;

		    			if(parseInt(document.getElementById("id_avail_unsch").innerHTML)>="479"){
		    				document.getElementById("id_avail_rate").innerHTML= "100.00%";
		    				document.getElementById("AvailBg").innerHTML="100";	
		    			}
		    			else if(isNaN(js_availability_oee)){
		    				document.getElementById("id_avail_rate").innerHTML= "0.00%";
		    				document.getElementById("AvailBg").innerHTML="0";
		    			}
		    			else{
		    				document.getElementById("id_avail_rate").innerHTML=js_availability_oee.toFixed(2) + "%";
		    				document.getElementById("AvailBg").innerHTML=js_availability_oee.toFixed(2);
		    			}


		    			if(document.getElementById("AvailBg").innerHTML >= 80)
		    			{
		    				document.getElementById("AvailBg").style.backgroundColor = "#00FF00";
		    			}
		    			else if(document.getElementById("AvailBg").innerHTML < 80 && document.getElementById("AvailBg").innerHTML >= 60)
		    			{document.getElementById("AvailBg").style.backgroundColor = "yellow";}
		    			else
		    			{document.getElementById("AvailBg").style.backgroundColor = "red";}

		    			
		    	
		    		}
		      		calculateOEE();
            }
		});

}


function populateQualityData(){

	document.getElementById("id_qual_totout").innerHTML="";
	document.getElementById("id_qual_scrap").innerHTML="";
	document.getElementById("id_qual_goodout").innerHTML="";
	document.getElementById("id_qual_rate").innerHTML="";


	var plant = document.getElementById("id_hid_plant").value;
	var resource = document.getElementById("id_hid_resr").value;

	
	var sParams = "&Param.1="+plant+"&Param.2="+resource+"&Param.3="+document.getElementById("id_hid_StartDate").value+"&Param.4="+document.getElementById("id_hid_shiftenddate").value;
	var url = "/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_OEEQuality&content-type=text/json";
	
	url = url +	sParams;
	
	jQuery.ajax({
		url: url,
	            type : 'GET',
		async:false,
	      	success : function (jsonData) {
	      		
	      		var i=0;
	      		var j=0;
	      		var name;
	      		var scrap=0;
	      		var js_quality_oee=0;
	      		
	      		if (jsonData && jsonData.Rowsets && jsonData.Rowsets.Rowset
	    				&& jsonData.Rowsets.Rowset[0]
	    				&& jsonData.Rowsets.Rowset[0].Row) {
	    			
	    			
	    			var rows = jsonData.Rowsets.Rowset[0].Row;
	    			i = rows.length;
	    			
	    			for(j=0;j<i;j++){
	    				
	    				name = rows[j].Type;
	    				var qty = rows[j].Quantity;
	    				if(name=="GoodOutput"){
	    					document.getElementById("id_qual_goodout").innerHTML = qty;
	    				}
	    				else if(name=="TotalOutput"){
	    					document.getElementById("id_qual_totout").innerHTML  = qty;
	    				}
	    				else if(name=="TotalScrap"){
	    					document.getElementById("id_qual_scrap").innerHTML = qty;
	    				}
	    				else if(name=="OEEQuality"){
	    					js_quality_oee= qty;
	    				}
	    			}
	    			// End of for loop
	    			
	    			if(isNaN(js_quality_oee)){
	    				document.getElementById("id_qual_rate").innerHTML= "0.00%";
	    				document.getElementById("QualBg").innerHTML= "0";
	    			}
	    			else{
	    				document.getElementById("id_qual_rate").innerHTML=js_quality_oee + "%";
	    				document.getElementById("QualBg").innerHTML=js_quality_oee;
	    			}

	    			if(document.getElementById("QualBg").innerHTML >= 80)
	    			{
	    				document.getElementById("QualBg").style.backgroundColor = "#00FF00";
	    			}
	    			else if(document.getElementById("QualBg").innerHTML < 80 && document.getElementById("QualBg").innerHTML >= 60)
	    			{document.getElementById("QualBg").style.backgroundColor = "yellow";}
	    			else
	    			{document.getElementById("QualBg").style.backgroundColor = "red";}	


	    		if (document.getElementById("id_qual_rate").innerHTML == "100%")
	    		{
	    		document.getElementById("id_qual_rate").innerHTML = "100.00%";
	    		}
	    		if (document.getElementById("id_qual_rate").innerHTML == "0%")
	    		{
	    		document.getElementById("id_qual_rate").innerHTML = "0.00%";
	    		}
	      		}
	      		
	      		
	      		populateAvailData();
	      		
	      	}
	});
	
}


function populatePerfomData(){
	
	document.getElementById("id_avail_running").innerHTML="0";
	document.getElementById("id_perf_tarout").innerHTML="";
	document.getElementById("id_perf_spdloss").innerHTML="";
	document.getElementById("id_perf_totout").innerHTML="";
	document.getElementById("id_perf_rate").innerHTML="";


	var plant = document.getElementById("id_hid_plant").value;
	var resource = document.getElementById("id_hid_resr").value;

	//dynamically pass project name
	projectName =document.getElementById("id_hid_projectname").value;
	
	var sParams = "&Param.1="+plant+"&Param.2="+resource+"&Param.3="+document.getElementById("id_hid_StartDate").value+"&Param.4="+document.getElementById("id_hid_shiftenddate").value;
	var url = "/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetOEEPerformanceData&content-type=text/json";
	url = url +	sParams;
	
	
	
	jQuery.ajax({
		url: url,
	            type : 'GET',
		async:false,
	      	success : function (jsonData) {
	      		
	      		var i=0;
	      		var j=0;
	      		var name;
	      		var scrap=0;
	      		var js_quality_oee=0;
	      		
	      		if (jsonData && jsonData.Rowsets && jsonData.Rowsets.Rowset
	    				&& jsonData.Rowsets.Rowset[0]
	    				&& jsonData.Rowsets.Rowset[0].Row) {
	      			
	      			var row = jsonData.Rowsets.Rowset[0].Row[0];
	      			//var i=row.PlannedOutput;
	      			
	      			document.getElementById("id_perf_tarout").innerHTML = row.ProdOut;
	      			document.getElementById("id_perf_spdloss").innerHTML = row.SpeedLoss;
	      			document.getElementById("id_perf_totout").innerHTML = row.TotalOutput;
	      			document.getElementById("id_perf_minstop").innerHTML = row.MinorStop;
	      			document.getElementById("id_perf_plnout").innerHTML = row.SetSpeedOutput;
	      			
	      		// added for new avail calc.
	      			document.getElementById("id_avail_running").innerHTML= row.Runtime;
	      			// added for new avail calc.
	      			
	      			// will be used in populateAvailData()
	      			avail_running = row.Runtime;

	      			var js_perf_oee=(eval(document.getElementById("id_perf_totout").innerHTML)/eval(document.getElementById("id_perf_tarout").innerHTML))*100;
	      			if(isNaN(js_perf_oee)){
	      				document.getElementById("id_perf_rate").innerHTML= "0.00%";
	      				document.getElementById("PerfBg").innerHTML= "0";
	      			}
	      			else{
	      				document.getElementById("id_perf_rate").innerHTML=js_perf_oee.toFixed(2) + "%";
	      				document.getElementById("PerfBg").innerHTML=js_perf_oee.toFixed(2);
	      			}

	      			if(document.getElementById("PerfBg").innerHTML >= 80)
	      			{
	      				document.getElementById("PerfBg").style.backgroundColor = "#00FF00";
	      			}
	      			else if(document.getElementById("PerfBg").innerHTML < 80 && document.getElementById("PerfBg").innerHTML >= 60)
	      			{document.getElementById("PerfBg").style.backgroundColor = "yellow";}
	      			else
	      			{document.getElementById("PerfBg").style.backgroundColor = "red";}		

	      			
	      		}
	      		
	      		populateQualityData();
	      	}
	});


}

function calculateOEE(){
	if(document.getElementById("AvailBg").innerHTML != "" && document.getElementById("QualBg").innerHTML != "" && document.getElementById("PerfBg").innerHTML != "")
	{
		var js_oee=parseFloat(parseFloat(document.getElementById("QualBg").innerHTML)*parseFloat(document.getElementById("PerfBg").innerHTML)*parseFloat(document.getElementById("AvailBg").innerHTML))/10000;
		document.getElementById("OEEBg").innerHTML=js_oee.toFixed(2);

		if(document.getElementById("OEEBg").innerHTML >= 80)
		{
		document.getElementById("OEEBg").style.backgroundColor = "#00FF00";
		}
		else if(document.getElementById("OEEBg").innerHTML < 80 && document.getElementById("OEEBg").innerHTML >= 60)
		{document.getElementById("OEEBg").style.backgroundColor = "yellow";}
		else
		{document.getElementById("OEEBg").style.backgroundColor = "red";}	


		if (document.getElementById("PerfBg").innerHTML == "0")
		{
		document.getElementById("PerfBg").innerHTML = "0.00";
		}
		if (document.getElementById("PerfBg").innerHTML == "100")
		{
		document.getElementById("PerfBg").innerHTML = "100.00";
		}
		
		if (document.getElementById("QualBg").innerHTML == "0")
		{
		document.getElementById("QualBg").innerHTML = "0.00";
		}
		if (document.getElementById("QualBg").innerHTML == "100")
		{
		document.getElementById("QualBg").innerHTML = "100.00";
		}
		
		if (document.getElementById("AvailBg").innerHTML == "0")
		{
		document.getElementById("AvailBg").innerHTML = "0.00";
		}
		if (document.getElementById("AvailBg").innerHTML == "100")
		{
		document.getElementById("AvailBg").innerHTML = "100.00";
		}
		
		
		// Add % to all 
		document.getElementById("AvailBg").innerHTML = document.getElementById("AvailBg").innerHTML + "%";
		document.getElementById("QualBg").innerHTML = document.getElementById("QualBg").innerHTML + "%";
		document.getElementById("PerfBg").innerHTML = document.getElementById("PerfBg").innerHTML + "%";
		document.getElementById("OEEBg").innerHTML = document.getElementById("OEEBg").innerHTML + "%";
	}
	
}