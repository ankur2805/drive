var global ="";
var username="";
var plantid="";
var plantresr="";
var bScaleIntegration = false;
	sap.ui.define(["sap/ui/core/mvc/Controller",
		"com/khc/rephub/utils/UI_utilities",
		"com/khc/common/Script/CommonUtility", "com/khc/rephub/model/models"], 
	function(Controller,UI_utilities,CommonUtility, models) {
	"use strict";
	return Controller.extend("com.khc.rephub.controller.SessionSetting", {
		
		/**
		 * Called when a controller is instantiated and its View
		 * controls (if available) are already created. Can be used to
		 * modify the View before it is displayed, to bind event
		 * handlers and do other one-time initialization.
		 */
		onInit : function() {

			// Register the _oRoutePatternMatched methos, init will be
			// called only once
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// RepHome is your Route name and set the menu key as the
			// same name
			this._oRouter.getRoute("sessionSetting").attachPatternMatched(
					this._oRoutePatternMatched, this);

		},

		/**
		 * Called when the Routing is matched, 'RepHome'
		 * 
		 */

		_oRoutePatternMatched : function(oEvent) {
			
			//Hide the messages and set busy to false
			UI_utilities.nonProductionPageOpened(this);
			
			this.setInitialValues();
			this.getPlantData();
			this.setOldValues();
		},

		/**
		 * Called when the View has been rendered (so its HTML is part
		 * of the document). Post-rendering manipulations of the HTML
		 * could be done here. This hook is the same one that SAPUI5
		 * controls get after being rendered.
		 */
		onAfterRendering : function() {

			// To set the menu as selected, hide message ad remove busy
			//UI_utilities.menuOpened(this,"RepHome");

		},



		onSave:function(){

			var obj = this;
			var xmlHttp;
			var plant = this.getView().byId("PlantLoc").getSelectedKey();
			var resource = this.getView().byId("ResourceT").getSelectedKey();
			var workstation = this.getView().byId("WorkSt").getSelectedKey();
			var planttext = this.getView().byId("PlantLoc")._getSelectedItemText();
			var resrtext = this.getView().byId("ResourceT")._getSelectedItemText();
			var worksttext = this.getView().byId("WorkSt")._getSelectedItemText();
			//var scale = this.getView().byId("ScaleNm").getSelectedKey();
			//var printer = this.getView().byId("PrinterNm").getSelectedKey();
			var username = sap.ui.getCore().getModel("session").getData().CA_IllumLoginName;
			let attrName = "CA_Plant~CA_Resource~CA_CRDest~CA_PlantText~CA_ResrText~CA_CRDestText";
			let attrValue = plant+"~"+resource+"~"+workstation+"~"+planttext+"~"+resrtext+"~"+worksttext;
			var fetchData ="";
			var sScaleName = "";



/*xmlHttp=new XMLHttpRequest();  
alert("Plant : "+plant+", Resource : "+resource+", Work Station : "+workstation+", Scale : "+scale+", Printer : "+printer);*/


if (plant!="" && resource!="" && workstation!="" )
{

	var that = this;
	
	 if(bScaleIntegration)	{
    	 
	    	var oScaleCombo = this.getView().byId("scaleName");
	    	sScaleName = oScaleCombo.getSelectedKey();
	    	//to do add the scale name validation
	    	if(!sScaleName){
	    		
	    		
	    	}
	    	
	    	 attrName = "CA_Plant~CA_Resource~CA_CRDest~CA_PlantText~CA_ResrText~CA_CRDestText~CA_ScaleName";
	    	 attrValue = attrValue+"~"+sScaleName;
	     }
	 
	 CommonUtility.setCustomAttributeValue(attrName,attrValue,username).then(function (sResult) {

		 
		 if(sResult==="success")	{

				sap.ui.getCore().getModel("session").setProperty("/CA_Plant", plant);
				sap.ui.getCore().getModel("session").setProperty("/CA_Resource", resource);
				sap.ui.getCore().getModel("session").setProperty("/CA_CRDest", workstation);
				sap.ui.getCore().getModel("session").setProperty("/CA_PlantText", planttext);
				sap.ui.getCore().getModel("session").setProperty("/CA_ResrText", resrtext);
				sap.ui.getCore().getModel("session").setProperty("/CA_CRDestText", worksttext);
				sap.ui.getCore().getModel("session").setProperty("/CA_CRDestText", worksttext);

			
				// Update Local storage
				
					
					var oUserSessionData = JSON.parse(sessionStorage[username]);
					oUserSessionData["CA_Plant"] = plant;
					oUserSessionData["CA_Resource"] = resource;
					oUserSessionData["CA_CRDest"] = workstation;
					oUserSessionData["CA_PlantText"] = planttext;
					oUserSessionData["CA_ResrText"] = resrtext;
					oUserSessionData["CA_CRDestText"] = worksttext;
					
					 if(bScaleIntegration)	{
						 
						 sap.ui.getCore().getModel("session").setProperty("/CA_ScaleName", sScaleName);
						 oUserSessionData["CA_ScaleName"] = sScaleName;
					 }
					
					sessionStorage.setItem(username,JSON.stringify(oUserSessionData));
					
					// Show Success Message in the screen
					sap.ui.getCore().getModel("oMessage").setProperty("/message","Values updated");
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
					
					// to navigate back to home screen
					setTimeout(function(){ that.onBack(); 
					}, 2000);
				
				}
			 else{
				 
				 	sap.ui.getCore().getModel("oMessage").setProperty("/message","Error while updating the values");
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Error")
			 }


	 
	 
	 });;
	 
	 

	}

else
{
//alert("Select values for Plant, Resource and Work Station");
	// Show Success Message in the screen
	sap.ui.getCore().getModel("oMessage").setProperty("/message","Select values for Plant, Resource and Work Station");
	sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
	sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
} 
//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
	//oRouter.navTo("RepHome");
},

/**
 * to open the help document
 */

onHelp:function(){

	
	UI_utilities.OpenHelpFileSingle("Changesettings");
},

onBack:function(){

	
	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
	oRouter.navTo("RepHome");
	//window.location.replace("/XMII/CM/NL_ELS_HUB_SAPUi5/webapp/index.irpt#/RepHome");
	//location.reload();
},


getPlantData:function(oEvent){

	this.getView().byId("PlantLoc").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Plant);
         var oModel1 = models.createNewJSONModel("com.khc.rephub.controller.SessionSetting-->getPlantData-->XACQ_GetPlant");
		oModel1.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetPlant&content-type=text/xml", "", false);
      	var oTable = this.getView().byId("PlantLoc");
      	 oTable.setModel(oModel1, "DropDown");
},

onPlantChange:function(){
	plantid = this.getView().byId("PlantLoc").getSelectedKey();
         var oModel2 = models.createNewJSONModel("com.khc.rephub.controller.SessionSetting-->onPlantChange-->XACQ_GetResrByPlantCRD");
        	oModel2.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetResrByPlantCRD&Param.1=" + plantid + "&content-type=text/xml", "", false);
      	var oTable = this.getView().byId("ResourceT");
      	 oTable.setModel(oModel2, "DropDownResource");
	//this.onWorkStationChange();
},

onResourceChange:function(oEvent3){
	plantid = this.getView().byId("PlantLoc").getSelectedKey();
	plantresr = this.getView().byId("ResourceT").getSelectedKey();
	
         var oModel3 = models.createNewJSONModel("com.khc.rephub.controller.SessionSetting-->onResourceChange-->XACQ_GetCRDestByResr");
        	oModel3.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetCRDestByResr&Param.1=" + plantid + "&Param.2=" + plantresr + "&content-type=text/xml", "", false);
      	var oTable = this.getView().byId("WorkSt");
      	 oTable.setModel(oModel3, "DropDownWortSt");
},

setInitialValues:function(){
	
	this.getView().byId("PlantLoc").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Plant);
	this.getView().byId("ResourceT").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Resource);
	this.getView().byId("WorkSt").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_CRDest);
	plantid = this.getView().byId("PlantLoc").getSelectedKey();
	plantresr = this.getView().byId("ResourceT").getSelectedKey();	

},

setOldValues:function(){
	
         var oModel2 = models.createNewJSONModel("com.khc.rephub.controller.SessionSetting-->setOldValues-->XACQ_GetResrByPlantCRD");
        	oModel2.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetResrByPlantCRD&Param.1=" + plantid + "&content-type=text/xml", "", false);
      	var oTable = this.getView().byId("ResourceT");
      	 oTable.setModel(oModel2, "DropDownResource");

         var oModel3 = models.createNewJSONModel("com.khc.rephub.controller.SessionSetting-->setOldValues-->XACQ_GetCRDestByResr");
        	oModel3.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetCRDestByResr&Param.1=" + plantid + "&Param.2=" + plantresr + "&content-type=text/xml", "", false);
      	var oTable = this.getView().byId("WorkSt");
      	 oTable.setModel(oModel3, "DropDownWortSt");
     // if CA_RepHubScaleIntegration === 'Y' weigh scale is integrated, show the scale name and add functionality
     if(sap.ui.getCore().getModel("session").getData().CA_RepHubScaleIntegration === 'Y')	{
    	 
    	 bScaleIntegration = true;
      	this.getView().byId("scaleName").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_ScaleName);
         var oModel4 = models.createNewJSONModel("com.khc.rephub.controller.SessionSetting-->setOldValues-->XACQ_GetWeighScaleList");
    	oModel4.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighScaleList&content-type=text/xml", "", false);
    	var oScaleCombo = this.getView().byId("scaleName");
    	oScaleCombo.setModel(oModel4, "oScale");
     }
     else{
    	 bScaleIntegration = false;
     }
  	 
}
	

});

});