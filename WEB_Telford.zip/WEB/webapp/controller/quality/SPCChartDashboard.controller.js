sap.ui
  .define(
    [ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox", "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/DateTimeInput", "com/khc/rephub/model/formatter" ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, DateTimeInput, formatter) {
      "use strict";

      var crid;
      var plant = '';
      var resource = ''; 
      var projectName = '';
      var projectNameNLELSHUB = '';
      var userName;
      var crDest = '';
      var insplot = '';
      var order = '';
      var orderId = '';
      var material = '';
      var insplot;
      var Rowcount;
      var matnum;
      var InspMethod;
      var resetChartType;
      var MasterChar;
      var ChartParam1;
      var SubgroupSize;
      var UpperCL;
      var UpperUCL;
      var UpperLCL;
      var inspectionPointModel;
      var updateData;
      var flag_Alert = 0;
      var hide_Table = 0;
      var oController;

      return Controller
        .extend(
          "com.khc.rephub.controller.quality.SPCChartDashboard",
          {
            formatter : formatter,
            onInit : function() {
              this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
              this._oRouter.getRoute("SPCChartDashboard").attachPatternMatched(this._oRoutePatternMatched, this);
              oController = this;
            },
            /** *********************************************************************************************************************************************************************************** */
            _oRoutePatternMatched : function(oEvent) {
              UI_utilities.qualityPageOpened(this, "SPCChartDashboard");

              plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
              resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
              projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
              projectNameNLELSHUB = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
              userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
              crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
              var oDisplayData = {
                selectedOption : "showMICList"
              };
              var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
              this.getView().setModel(oDisplayOptionModel, "displayOption");

              this.onLoad();
              // this.setFirstRowSelectedSPCPhasedAggregateResultWOAlerts();

            },
            /** *********************************************************************************************************************************************************************************** */
            menuSelected : function(oEvent) {

              // Navigate the the selected menu page

              var sKey = oEvent.getParameters().key;
              UI_utilities.openMenu(this._oRouter, this, sKey);
            },
            /** *********************************************************************************************************************************************************************************** */
            onHelp : function() {

              UI_utilities.OpenHelpFileSingle("Resultentry");
            },
            /** *********************************************************************************************************************************************************************************** */

            onLoad : function() {
              var oModelGetResourceList = CommonUtility.getResourceListByPlant(projectName, plant);
              this.getView().setModel(oModelGetResourceList, "oResourceList");
              if (CommonUtility.getJsonModelRowCount(oModelGetResourceList.getData()) > 0) {
                this.getView().byId("id_resource_dropdown").setSelectedKey(resource);
              }

              this.getRunningOrder();

              this.getView().getModel("displayOption").setProperty("/selectedOption", "showMICList");
            },
            /** *********************************************************************************************************************************************************************************** */

            setFirstRowSelectedSPCPhasedAggregateResultWOAlerts : function() {
              var phaseMICObj = this.getView().byId("id_phaseMIC");
              var phaseMICItems = phaseMICObj.getItems();
              if (phaseMICItems && phaseMICItems.length > 0) {
                phaseMICItems[0].setSelected(true);
                this.getInspectionPoint();
              } else {
                this.showChart();
              }
            },
            /** *********************************************************************************************************************************************************************************** */

            setFirstRowSelectedSPCPhasedAggregateResults : function() {
              var phaseMICObj = this.getView().byId("id_phaseMICLights");
              var phaseMICItems = phaseMICObj.getItems();
              if (phaseMICItems && phaseMICItems.length > 0) {
                phaseMICItems[0].setSelected(true);
                this.getDataFromSelectedGridRow();
              } else {
                this.showChart();
              }
            },
            /** *********************************************************************************************************************************************************************************** */

            fetchPhaseData : function() {
              var oModelSPCOperByOrder = new sap.ui.model.json.JSONModel();
              insplot = this.getView().byId("id_txt_insplot").getValue();
              var sParams = "Param.1=" + plant + "&Param.2=" + insplot + "&Param.3=" + orderId;
              oModelSPCOperByOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/SQLQ_SPCGetOperByOrderForQuantMIC&" + sParams + "&Content-Type=text/json", "", false);
              this.getView().setModel(oModelSPCOperByOrder, "oSPCOperByOrder");
              this.getView().byId("id_phase_dropdown").insertItem(new sap.ui.core.Item({
                key : "All",
                text : "All"
              }), 0);
              this.getView().byId("id_phase_dropdown").setSelectedKey("All");
            },
            /** *********************************************************************************************************************************************************************************** */

            getRunningOrder : function() {
              var oModelRunningOderList = new sap.ui.model.json.JSONModel();
              var resrValue = this.getView().byId("id_resource_dropdown").getSelectedKey();
              var sParams = '';
              if (resrValue != undefined || resrValue != '') {
                sParams = "Param.1=" + plant + "&Param.2=" + resrValue + "&Param.3=" + crDest;
              } else {
                sParams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crDest;
              }

              oModelRunningOderList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/XACQ_GetRunningOrderOpenInsp&" + sParams + "&Content-Type=text/json", "", false);
              this.getView().setModel(oModelRunningOderList, "oRunningOderList");
              if (CommonUtility.getJsonModelRowCount(oModelRunningOderList.getData()) > 0) {
                if (oModelRunningOderList.getData().Rowsets.Rowset[0].Row != undefined) {
                  var oRunningOrder = oModelRunningOderList.getData().Rowsets.Rowset[0].Row[0];
                  this.getView().byId("id_txt_ordstrip").setValue(oRunningOrder.MODORDERID);
                  orderId = oRunningOrder.ORDERID;
                  crid = oRunningOrder.CRID;
                  material = oRunningOrder.MATNR;
                  this.getView().byId("id_txt_matstrip").setValue(oRunningOrder.MODMATNR);
                  this.getView().byId("id_txt_mattext").setValue(oRunningOrder.MATTEXT);
                  this.getView().byId("id_txt_insplot").setValue(oRunningOrder.INSPLOT);
                  insplot = this.getView().byId("id_txt_insplot").getValue();
                  this.fetchPhaseData();

                  if (flag_Alert == 1) {
                    this.getSPCPhasedAggregateResults();
                    this.setFirstRowSelectedSPCPhasedAggregateResults();
                  } else {
                    this.getSPCPhasedAggregateResultWOAlerts();
                    this.setFirstRowSelectedSPCPhasedAggregateResultWOAlerts();
                  }
                }
              } else {
                this.getView().byId("id_txt_ordstrip").setValue('');
                this.getView().byId("id_txt_matstrip").setValue('');
                this.getView().byId("id_txt_mattext").setValue('');
                this.getView().byId("id_txt_insplot").setValue('');
              }

            },
            /** *********************************************************************************************************************************************************************************** */

            onResourceSelect : function() {
              this.getRunningOrder();
              // /QueryTemplate/XACQ_GetRunningOrder"
              var oModelRunningOrderList = new sap.ui.model.json.JSONModel();

              // /QueryTemplate/SQLQ_SPCGetOperByOrderForQuantMIC
              this.fetchPhaseData();

              // /QueryTemplate/SQLQ_GetSPCAlertsforInspLot
              var oModelSPCAlertsForInsplot = new sap.ui.model.json.JSONModel();
              var sParams = "Param.1=" + insplot;
              oModelSPCAlertsForInsplot.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/SQLQ_GetSPCAlertsforInspLot&" + sParams + "&Content-Type=text/json", "", false);
              this.getView().setModel(oModelSPCAlertsForInsplot, "oSPCAlertsForInsplot");
              if (flag_Alert == 1) {
                this.getSPCPhasedAggregateResults();
                this.setFirstRowSelectedSPCPhasedAggregateResults();
              } else {
                this.getSPCPhasedAggregateResultWOAlerts();
                this.setFirstRowSelectedSPCPhasedAggregateResultWOAlerts();
              }

            },

            /** *********************************************************************************************************************************************************************************** */

            // /QueryTemplate/XACQ_SPCPhasedAggregatedResultWithoutAlerts
            getSPCPhasedAggregateResultWOAlerts : function() {
              var oModelGetPhaseInsp = new sap.ui.model.json.JSONModel();
              var sParams = '';
              var phaseValue = '';
              var phaseTxt = '';
              var that = this;
              phaseTxt = that.getView().byId("id_phase_dropdown").getSelectedKey();
              phaseValue = '';
              if (phaseTxt == '' || phaseTxt == undefined || phaseTxt == "All") {
                phaseValue = '';
              } else {
                phaseValue = phaseTxt;
              }
              sParams = "Param.1=" + insplot + "&Param.2=" + phaseValue;
              oModelGetPhaseInsp.attachRequestCompleted(function() {
                // var phaseDropDownKey =
                // this.getView().byId("id_phase_dropdown").getSelectedKey();

                // oModelGetPhaseInsp.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_SPCPhasedAggregatedResultWithoutAlerts&"+sParams+"&Content-Type=text/json",
                // "", false);
                that.getView().setModel(oModelGetPhaseInsp, "oSPCPhasedAggregateResultWOAlerts");
              });
              oModelGetPhaseInsp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/XACQ_SPCPhasedAggregatedResultWithoutAlerts&" + sParams + "&Content-Type=text/json", "", false);

              // this.setFirstRowSelectedSPCPhasedAggregateResultWOAlerts();
            },
            /** *********************************************************************************************************************************************************************************** */

            // /QueryTemplate/XACQ_SPCPhasedAggregateResults
            getSPCPhasedAggregateResults : function() {
              this.getView().getModel("displayOption").setProperty("/selectedOption", "showPhaseMICLightsVbox");
              var oModelGetPhaseInsp = new sap.ui.model.json.JSONModel();
              var phaseTxt = this.getView().byId("id_phase_dropdown").getSelectedKey();
              var phaseValue = '';
              if (phaseTxt == '' || phaseTxt == undefined || phaseTxt == "All") {
                phaseValue = '';
              } else {
                phaseValue = phaseTxt;
              }
              var sParams = "Param.1=" + insplot + "&Param.2=" + phaseValue;
              oModelGetPhaseInsp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/XACQ_SPCPhasedAggregateResults&" + sParams + "&Content-Type=text/json", "", false);
              this.getView().setModel(oModelGetPhaseInsp, "oSPCPhasedAggregateResults");
              flag_Alert = 1;
            },

            /** *********************************************************************************************************************************************************************************** */

            hideListTable : function() {
              
              if(flag_Alert == 1){
                this.getView().byId("id_phaseMICLights").setVisible(false);
                this.getView().byId("id_tbl_hdr_with_alerts_phaseMICLights").setVisible(false);
              } else {
                this.getView().byId("id_phaseMIC").setVisible(false);
                this.getView().byId("id_tbl_hdr_WO_alerts_phaseMIC").setVisible(false);
              }
              this.getView().byId("id_btn_showList").setVisible(true);
              this.getView().byId("id_btn_hideList").setVisible(false);
              hide_Table = 1;
            },
            /** *********************************************************************************************************************************************************************************** */

            showListTable : function() {
              if (flag_Alert == 1) {
                this.getView().byId("id_tbl_hdr_with_alerts_phaseMICLights").setVisible(true);
                this.getView().byId("id_phaseMICLights").setVisible(true);
              } else {
                this.getView().byId("id_tbl_hdr_WO_alerts_phaseMIC").setVisible(true);
                this.getView().byId("id_phaseMIC").setVisible(true);
              }
              this.getView().byId("id_btn_hideList").setVisible(true);
              this.getView().byId("id_btn_showList").setVisible(false);
              hide_Table = 2;
            },

            /** *********************************************************************************************************************************************************************************** */

            getDetails : function() {
              UI_utilities.setContainerBusyState(this, true);
              this.getView().getModel("displayOption").setProperty("/selectedOption", "showPhaseMICLightsVbox");
              this.getView().byId("id_tbl_hdr_with_alerts_phaseMICLights").setVisible(true);
              this.getView().byId("id_phaseMICLights").setVisible(true);
              this.getSPCPhasedAggregateResults();
              this.getView().byId("id_btn_hideAlerts").setVisible(true);
              this.getView().byId("id_btn_getDetails").setVisible(false);
              this.setFirstRowSelectedSPCPhasedAggregateResults();
             if (hide_Table == 1) {
                this.getView().byId("id_btn_showList").setVisible(false);
                this.getView().byId("id_btn_hideList").setVisible(true);
              } else if (hide_Table == 2) {
                this.getView().byId("id_btn_hideList").setVisible(false);
                this.getView().byId("id_btn_showList").setVisible(true);
              } 
              UI_utilities.setContainerBusyState(this, false);
            },
            /** *********************************************************************************************************************************************************************************** */

            hideAlerts : function() {
              UI_utilities.setContainerBusyState(this, true);
              this.getView().getModel("displayOption").setProperty("/selectedOption", "showMICList");
              this.getView().byId("id_tbl_hdr_WO_alerts_phaseMIC").setVisible(true);
              this.getView().byId("id_phaseMIC").setVisible(true);
              this.getSPCPhasedAggregateResultWOAlerts();
              this.getView().byId("id_btn_getDetails").setVisible(true);
              this.getView().byId("id_btn_hideAlerts").setVisible(false);
              this.setFirstRowSelectedSPCPhasedAggregateResultWOAlerts();
              if (hide_Table == 1) {
                this.getView().byId("id_btn_showList").setVisible(false);
                this.getView().byId("id_btn_hideList").setVisible(true);
              } else if (hide_Table == 2) {
                this.getView().byId("id_btn_hideList").setVisible(false);
                this.getView().byId("id_btn_showList").setVisible(true);
              } 
              UI_utilities.setContainerBusyState(this, false);
            },
            /** *********************************************************************************************************************************************************************************** */

            getInspectionPoint : function() {

              var oTable = this.getView().byId("id_phaseMIC");
              var SelRow = oTable.getSelectedContextPaths().length;

              if (SelRow != 0) {
                UI_utilities.setContainerBusyState(this, true);
                var QnSelRow = oTable.getSelectedContextPaths()[0];
                var QnSelectedRow = this.getView().getModel("oSPCPhasedAggregateResultWOAlerts").getProperty(QnSelRow);
                var InspOpe = QnSelectedRow.InspectionOperation;
                var Phase = QnSelectedRow.PhaseNo;
                MasterChar = QnSelectedRow.MasterChar;
                var DataPoints = QnSelectedRow.SamplingPoints;
                this.getView().byId("id_txt_dataPoint").setValue(DataPoints);
                var ThisOrderOnly = QnSelectedRow.ThisOrderOnly;
                InspMethod = QnSelectedRow.InspMethod;
                var InspReq = QnSelectedRow.InspReq;
                var ResultType = QnSelectedRow.ResultType;
                var UpperCalculateControlLimits = QnSelectedRow.UpperCalculateControlLimits;
                var DynamicCL = "" + QnSelectedRow.Dynamic_CL;
                var DynamicLCL = "" + QnSelectedRow.Dynamic_LCL;
                var DynamicUCL = "" + QnSelectedRow.Dynamic_UCL;
                insplot = this.getView().byId("id_txt_insplot").getValue();

                var ucl = '';
                var cl = '';
                var lcl = '';
                if (DynamicUCL.indexOf(",") != -1) {
                  ucl = DynamicUCL.split(",");
                  DynamicUCL = ucl[0] + "." + ucl[1];
                }
                if (DynamicCL.indexOf(",") != -1) {
                  cl = DynamicCL.split(",");
                  DynamicCL = cl[0] + "." + cl[1];
                }
                if (DynamicLCL.indexOf(",") != -1) {
                  lcl = DynamicLCL.split(",");
                  DynamicLCL = lcl[0] + "." + lcl[1];
                }
                if (ThisOrderOnly == "0") {
                  ChartParam1 = "%";
                  this.getView().byId("id_txt_ThisOrderOnly").setSelected(false);
                } else {
                  ChartParam1 = insplot;
                  this.getView().byId("id_txt_ThisOrderOnly").setSelected(true);
                }

                if (ResultType == "SINGLE" && InspReq > 0) {

                  Rowcount = DataPoints * InspReq;
                  resetChartType = "XBAR-RANGE";
                  SubgroupSize = InspReq;
                } else {
                  Rowcount = DataPoints;
                  resetChartType = "XBAR-MR";
                  SubgroupSize = "1";
                }
                if (UpperCalculateControlLimits == "1") {

                  UpperCL = DynamicCL;
                  UpperUCL = DynamicUCL;
                  UpperLCL = DynamicLCL;
                } else {
                  UpperCL = "CL";
                  UpperUCL = "UCL";
                  UpperLCL = "LCL";

                }
                var ichartDataModel = new sap.ui.model.json.JSONModel();
                let chartData = {
                  InspectionLot : ChartParam1,
                  Masterchar : MasterChar,
                  Method : InspMethod,
                  Material : material,
                  Resource : resource,
                  Plant : plant,
                  Rowcount : DataPoints,
                  parent_page : "SPCChartDashboard"
                };
                ichartDataModel.setData(chartData);
                sap.ui.getCore().setModel(ichartDataModel, "ichartDataModelDisplay");
                this.showChart();
              } else {
                UI_utilities.setContainerBusyState(this, false);
                var sNoInspData = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
                sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoInspData);
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
              }

            },
            /** *********************************************************************************************************************************************************************************** */

            filterDataAsPerPhase : function(oEvent) {
              var sType = oEvent.getSource().getSelectedItem().getProperty("text");
              if (sType == undefined || sType == '' || sType == 'All') {
                sType = '';
              }
              // Get the table Binding to apply filters
              var oTable = '';
              if (flag_Alert == 1) {
                oTable = this.getView().byId("id_phaseMICLights");
              } else {
                oTable = this.getView().byId("id_phaseMIC");
              }
              var oBinding = oTable.getBinding("items");
              // Array to combine filters
              var aFilters = [];
              // STATUS is the json property, EQ is filter operator,
              // "statuscode" is the value to Filter
              if (sType) {
                aFilters.push(new Filter([ new Filter("Phase", "EQ", sType) ]));
              }
              oBinding.filter(aFilters);
              // Call chart method
              if (flag_Alert == 1) {
                this.setFirstRowSelectedSPCPhasedAggregateResults();
              } else {
                this.setFirstRowSelectedSPCPhasedAggregateResultWOAlerts();
              }
            },

            /** *********************************************************************************************************************************************************************************** */

            showChart : function() {
             // var c = new com.sap.xmii.chart.hchart.i5SPCChart("RepHubUI5/DisplayTemplate/i5SPC_QueryOutputV1", projectName
            //    + "/QueryTemplate/XACQ_SPCQueryOutput_V1");
    	  var c = new com.sap.xmii.chart.hchart.i5SPCChart("RepHubUI5/DisplayTemplate/i5SPC_QueryOutputV1_SPC_ChartDashboard", projectName
               + "/QueryTemplate/XACQ_SPCQueryOutput_V1");
              c.getQueryObject().setParameter("Param.1", ChartParam1);
              c.getQueryObject().setParameter("Param.2", MasterChar);
              c.getQueryObject().setParameter("Param.3", InspMethod);
              c.getQueryObject().setParameter("Param.4", material);
              c.getQueryObject().setParameter("Param.5", resource);
              c.getQueryObject().setParameter("Param.6", plant);
              c.getQueryObject().setParameter("Param.7", Rowcount);
              c.getChartObject().setChartType(resetChartType);
              c.getChartObject().setSubgroupSize(parseInt(SubgroupSize));
              c.getChartObject().setUpperCL(parseFloat(UpperCL));
              c.getChartObject().setUpperUCL(parseFloat(UpperUCL));
              c.getChartObject().setUpperLCL(parseFloat(UpperLCL));

              // Destroy the existing content
              // this.getView().byId("id_spc_div").destroy();
              let that = this;
              c.registerCreationEventHandler(this.spcLoaded);

              var oHtml = new sap.ui.core.HTML({
                content : "<div id='spc_content'>"
              });
              this.getView().byId("id_spcCharts_div").addItem(oHtml);
              // this.getView().byId("spc_content").setVisible(true);
              UI_utilities.setContainerBusyState(this, true);
              setTimeout(function() {
                c.draw("spc_content");
              }, 1000);

            },

            /** *********************************************************************************************************************************************************************************** */
            spcLoaded : function() {

              console.log("created");
              UI_utilities.setContainerBusyState(oController, false);

            },

            /** *********************************************************************************************************************************************************************************** */

            getDataFromSelectedGridRow : function() {

              var oTable = this.getView().byId("id_phaseMICLights");
              var SelRow = oTable.getSelectedContextPaths().length;

              if (SelRow != 0) {
                UI_utilities.setContainerBusyState(this, true);
                var QnSelRow = oTable.getSelectedContextPaths()[0];
                var QnSelectedRow = this.getView().getModel("oSPCPhasedAggregateResults").getProperty(QnSelRow);
                var InspOpe = QnSelectedRow.InspectionOperation;
                var Phase = QnSelectedRow.PhaseNo;
                MasterChar = QnSelectedRow.MasterChar;
                var DataPoints = QnSelectedRow.SamplingPoints;
                this.getView().byId("id_txt_dataPoint").setValue(DataPoints);
                var ThisOrderOnly = QnSelectedRow.ThisOrderOnly;
                InspMethod = QnSelectedRow.InspMethod;
                var InspReq = QnSelectedRow.InspReq;
                var ResultType = QnSelectedRow.ResultType;
                var UpperCalculateControlLimits = QnSelectedRow.UpperCalculateControlLimits;
                var DynamicCL = QnSelectedRow.Dynamic_CL;
                var DynamicLCL = QnSelectedRow.Dynamic_LCL;
                var DynamicUCL = QnSelectedRow.Dynamic_UCL;
                insplot = this.getView().byId("id_txt_insplot").getValue();

                if (ThisOrderOnly == "0") {
                  ChartParam1 = "%";
                  this.getView().byId("id_txt_ThisOrderOnly").setSelected(false);
                } else {
                  ChartParam1 = insplot;
                  this.getView().byId("id_txt_ThisOrderOnly").setSelected(true);
                }

                if (ResultType == "SINGLE" && InspReq > 0) {
                  Rowcount = DataPoints * InspReq;
                  resetChartType = "XBAR-RANGE";
                  SubgroupSize = InspReq;
                } else {

                  Rowcount = DataPoints;
                  resetChartType = "XBAR-MR";
                  SubgroupSize = "1";
                }

                if (UpperCalculateControlLimits == "1") {
                  UpperCL = DynamicCL;
                  UpperUCL = DynamicUCL;
                  UpperLCL = DynamicLCL;

                } else {
                  UpperCL = "CL";
                  UpperUCL = "UCL";
                  UpperLCL = "LCL";

                }
                var ichartDataModel = new sap.ui.model.json.JSONModel();
                let chartData = {
                  InspectionLot : ChartParam1,
                  Masterchar : MasterChar,
                  Method : InspMethod,
                  Material : material,
                  Resource : resource,
                  Plant : plant,
                  Rowcount : DataPoints,
                  parent_page : "SPCChartDashboard"
                };
                ichartDataModel.setData(chartData);
                sap.ui.getCore().setModel(ichartDataModel, "ichartDataModelDisplay");
                this.showChart();
              } else {
                UI_utilities.setContainerBusyState(this, false);
                var sNoInspData = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
                sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoInspData);
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
              }
            },
            /** *********************************************************************************************************************************************************************************** */

            updateChartSettings : function() {
              var aSelectedRowPath = '';
              var SelRow = '';
              var NtSelectedRow = '';
              var sPath = '';
              var sPhaseNo = '';
              var sInspectionLot = '';
              var sInspOperation = '';
              UI_utilities.setContainerBusyState(this, true);
              if (flag_Alert == 1) {
                aSelectedRowPath = this.getView().byId("id_phaseMICLights").getSelectedContextPaths()[0];

                NtSelectedRow = this.getView().getModel("oSPCPhasedAggregateResults").getProperty(aSelectedRowPath);
              } else {
                aSelectedRowPath = this.getView().byId("id_phaseMIC").getSelectedContextPaths()[0];

                NtSelectedRow = this.getView().getModel("oSPCPhasedAggregateResultWOAlerts").getProperty(aSelectedRowPath);
              }

              var dataP = this.getView().byId("id_txt_dataPoint").getValue();
              var thisOrder;

              if (NtSelectedRow.PhaseNo != undefined || NtSelectedRow.PhaseNo != null) {
                sPhaseNo = NtSelectedRow.PhaseNo;
              }
              if (NtSelectedRow.InspectionLot != undefined || NtSelectedRow.InspectionLot != null) {
                sInspectionLot = NtSelectedRow.InspectionLot;
              }
              if (NtSelectedRow.InspectionOperation != undefined || NtSelectedRow.InspectionOperation != null) {
                sInspOperation = NtSelectedRow.InspectionOperation;
              }

              var txt = '';
              if (NtSelectedRow.PhaseNo != undefined || NtSelectedRow.PhaseNo != null) {
                txt = NtSelectedRow.PhaseNo;
              } else {
                txt = '';
              }
              if (this.getView().byId("id_txt_ThisOrderOnly").getSelected()) {
                thisOrder = "1";
              } else {
                thisOrder = "0";
              }

              var updateChartModel = new sap.ui.model.json.JSONModel();
              updateChartModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/SQLQ_UpdateInspChar&Param.1=" + dataP + "&Param.2=" + thisOrder + "&Param.3=" + plant
                + "&Param.4=" + resource + "&Param.5=" + sInspectionLot + "&Param.6=" + sInspOperation + "&Param.7=" + sPhaseNo
                + "&Content-Type=text/json", "", false);

              var phaseTxt = this.getView().byId("id_phase_dropdown").getSelectedKey();
              var phaseValue = '';
              if (phaseTxt != '' || phaseTxt != undefined || phaseTxt != "All") {
                phaseValue = phaseTxt;
              } else {
                phaseValue = '';
              }
              var params = "Param.1=" + insplot + "&Param.2=" + phaseValue;
              var inspectionPointModel = new sap.ui.model.json.JSONModel();
              if (flag_Alert == 1) {
                this.getSPCPhasedAggregateResults();

                var ChkCount = this.getView().getModel("oSPCPhasedAggregateResults").getData().Rowsets.Rowset[0].Row.length;

                for (var i = 0; i < ChkCount; i++) {
                  var oSPCPhasedAggResult = this.getView().getModel("oSPCPhasedAggregateResults").getData().Rowsets.Rowset[0].Row;
                  if (oSPCPhasedAggResult[i].PhaseNo == txt) {
                    this.getSPCPhasedAggregateResults();
                    this.getView().byId("id_phaseMICLights").setSelectedItem(this.getView().byId("id_phaseMICLights").getItems()[i]);
                    break;
                  }
                }
       this.getDataFromSelectedGridRow();
              } else {
                this.getSPCPhasedAggregateResultWOAlerts();

                var ChkCount = this.getView().getModel("oSPCPhasedAggregateResultWOAlerts").getData().Rowsets.Rowset[0].Row.length;

                for (var i = 0; i < ChkCount; i++) {
                  var oSPCPhasedAggResultWOAlerts = this.getView().getModel("oSPCPhasedAggregateResultWOAlerts").getData().Rowsets.Rowset[0].Row;
                  if (oSPCPhasedAggResultWOAlerts[i].PhaseNo == txt) {
                    this.getSPCPhasedAggregateResultWOAlerts();
                    this.getView().byId("id_phaseMIC").setSelectedItem(this.getView().byId("id_phaseMIC").getItems()[i]);
                    break;
                  }
                }
       this.getInspectionPoint();
              }
              UI_utilities.setContainerBusyState(this, false);

            },

          });
    });