sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput","com/khc/rephub/model/models", "com/khc/rephub/model/formatter"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput,models, formatter) {
        "use strict";
        var plant;
        var resource;
        var projectName;
        var shiftname = '';
        var shiftId = '';
        var teamId = '';
        var shiftStartTime = '';
        var shiftEndTime = '';
        var oDownTimeData;
        var sDTStartDateFormatted;
        var userName;
        var crdest;

        var xmiiCommand;

        var that;
        return Controller.extend("com.khc.rephub.controller.quality.InspectResultHaccpSubmit_NC", {
            formatter: formatter,
            onInit: function() {
                that = this;
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("InspectResultHACCP_NC").attachPatternMatched(this._oRoutePatternMatched, this);


            },
            _oRoutePatternMatched: function(oEvent) {

              
                 //UI_utilities.qualityPageOpened(this, "InspectResultHACCP_NC");
  	    UI_utilities.qualityPageOpened(this, "InspectionPoint_NC");
                UI_utilities.qualityMenuBar();
 
 

                if (sap.ui.getCore().getModel("oViewHACCPParam") == null) {
                    this._oRouter.navTo("InspectResultSubmit_NC");
                }
                var oViewHaccpModel = new sap.ui.model.json.JSONModel();
                let sID = {
                    "qs_matstrip": "70002305",
                    "qs_matdesc": "NP OM 2 PERA NR e NP GR 80 OLD",
                    "qs_ordstrip": "1003844",
                    "qs_phstxt": "Quality Checks during Prod",
                    "qs_ccpsign": "---",
                    "qs_insplot": "030000002406",
                    "qs_currenttime": "2023-02-09 17:33:25",
                    "qs_char": "GRASSI",
                    "qs_lower": "0",
                    "qs_upper": "10",
                    "qs_result": "4",
                    "qs_eval": "R",
                    "qs_restxt": "Rejected",
                    "qs_phs": "0311",
                    "qs_inspChar": "0010",
                    "qs_inspcount": "---"
                }

                oViewHaccpModel.setData(sID)
                // sap.ui.getCore().setModel(oViewHaccpModel, "oViewHACCPParam")



                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                this.getView().byId("id_btn_Save").setEnabled(true);

                this.getRunningShift();
                this.getInspChar();

            },

            // on Load get the running shift details
            getRunningShift: function() {

              
                var oModelRunningShiftDetails =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit_NC-->getRunningShift-->XACQ_GetRunningShift");
                var that = this;
                oModelRunningShiftDetails.attachRequestCompleted(
                    function() {

                        that.getView().setModel(oModelRunningShiftDetails, "oRunningShiftList");
                        if (CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData()) > 0) {
                            var oRunningShiftData = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
                            shiftname = oRunningShiftData.SHIFTNAME;
                            shiftStartTime = oRunningShiftData.STARTTIME;
                            shiftEndTime = oRunningShiftData.ENDTIME;
                            shiftId = oRunningShiftData.SHIFTID;
                            teamId = oRunningShiftData.TEAMID;
                        } else {
                         /*   var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                            sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");*/
                        }
                    });

                oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningShift&Param.1=" + plant + "&Param.2=" + resource + "&Content-Type=text/json", "", false);


            },


            goBack: function() {
                this._oRouter.navTo("InspectResultSubmit_NC");
            },

            Save: function() {
               // new ccheck command
                var ccpsign = this.getView().byId("id_txt_ccpsign").getValue();
               
               xmiiCommand = new com.sap.xmii.chart.hchart.i5Command("NL_ELS_HUB/QueryTemplate/SQLQ_GetPlant", projectName + "/DisplayTemplate/CMD_VerifyDigitalSignature");
         
                if (ccpsign.indexOf("CCP") == "0")
                    xmiiCommand.setCommandAudit(true)
                else
                    xmiiCommand.setCommandAudit(false)

                if (ccpsign == "CCP2") {
                    var role = sap.ui.getCore().getModel("session").getProperty("/HACCPSign2Role");
                    xmiiCommand.getCommandObject().setCommandRole2(role)
                }

                xmiiCommand.executeCommand();
                xmiiCommand.registerCommandCompletionEventHandler(this.UpdInspPointDataStatus);
                
                
               // end
               /*
                 * var longtext =
                 * this.getView().byId("id_ta_longtext").getValue(); var inslot =
                 * this.getView().byId("id_txt_inslot").getValue(); var txt_phs =
                 * sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_phs");
                 * var char =
                 * sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_inspChar");
                 * var insdate =
                 * this.getView().byId("id_txt_insdate").getValue();
                 * 
                 * var ccpsign =
                 * this.getView().byId("id_txt_ccpsign").getValue(); //new
                 * command APLT_CMD_UpdInspPointData xmiiCommand = new
                 * com.sap.xmii.chart.hchart.i5Command(projectName +
                 * "/QueryTemplate/XACQ_UpdInspectPointLongTextandSignV1HACCP",
                 * projectName + "/DisplayTemplate/CMD_VerifyDigitalSignature");
                 * xmiiCommand.getQueryObject().setParameter("Param.1",
                 * longtext);
                 * xmiiCommand.getQueryObject().setParameter("Param.2", plant);
                 * xmiiCommand.getQueryObject().setParameter("Param.3",
                 * resource);
                 * xmiiCommand.getQueryObject().setParameter("Param.4", inslot);
                 * xmiiCommand.getQueryObject().setParameter("Param.5",
                 * txt_phs);
                 * xmiiCommand.getQueryObject().setParameter("Param.6", char);
                 * xmiiCommand.getQueryObject().setParameter("Param.7",
                 * insdate);
                 * 
                 * if (ccpsign.indexOf("CCP") == "0")
                 * xmiiCommand.setCommandAudit(true) else
                 * xmiiCommand.setCommandAudit(false)
                 * 
                 * if (ccpsign == "CCP2") { var role =
                 * sap.ui.getCore().getModel("session").getProperty("/HACCPSign2Role");
                 * xmiiCommand.getCommandObject().setCommandRole2(role) }
                 * 
                 * xmiiCommand.executeCommand();
                 * xmiiCommand.registerCommandCompletionEventHandler(this.UpdInspPointDataStatus);
                 */
                // new command end
            },

            UpdInspPointDataStatus: function() {
             
               
               var longtext = that.getView().byId("id_ta_longtext").getValue();
                var inslot = that.getView().byId("id_txt_inslot").getValue();
                var txt_phs = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_phs");
                var char = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_inspChar");
                var insdate = that.getView().byId("id_txt_insdate").getValue();
                var ccpsign = that.getView().byId("id_txt_ccpsign").getValue();
 

                var currentDT = CommonUtility.getCurrentDateTime(new Date());
               // APLT_CMD_UpdInspPointData
              
                var oUpdInspPointData =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit_NC-->UpdInspPointDataStatus-->XACQ_UpdInspectPointLongTextandSignV1HACCP");

                var params = "Param.1=" + longtext + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" +
                inslot + "&Param.5=" + txt_phs + "&Param.6=" + char+ "&Param.7=" + insdate+ 
                "&Param.9=" + currentDT+ "&Param.10=" + xmiiCommand.commandUserID1+ "&Param.11=" + xmiiCommand.commandUserID2;
                oUpdInspPointData.loadData("/XMII/Illuminator?QueryTemplate=RepHubUI5/Query/XACQ_UpdInspectPointLongTextandSignV1HACCP&" + params + "&Content-Type=text/json", "", false);
             
                if (oUpdInspPointData.getData().Rowsets.Rowset[0].Row != null) { 
                    var rowCount = oUpdInspPointData.getData().Rowsets.Rowset[0].Row.length;
                    if (rowCount != 0) {
                       // APLT_CMD_GetInspPoint
                      
                        var oGetInspPointModel =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit_NC-->UpdInspPointDataStatus-->SQLQ_GetInspectionPointListHACCP");

                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + inslot + "&Param.4=" +
                            txt_phs + "&Param.5=" + char + "&Param.6=" + insdate;
                        oGetInspPointModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetInspectionPointListHACCP&" + params + "&Content-Type=text/json", "", false);
                        if (oGetInspPointModel.getData().Rowsets.Rowset[0].Row != null) {
                            var getInspData = oGetInspPointModel.getData().Rowsets.Rowset[0].Row[0];
                            var getInspDataLen = oGetInspPointModel.getData().Rowsets.Rowset[0].Row.length;
                            if (getInspDataLen != 0) {

                                var signstatus = getInspData.SIGNSTATUS;
                                if (signstatus == "1") {
                                    that.getView().byId("id_ta_longtext").setValue(getInspData.LONGTEXT);
                                    that.getView().byId("id_txt_acknow").setValue(getInspData.CORRSIGN1USER);
                                    if (ccpsign == "CCP1")
                                        that.getView().byId("id_txt_verified").setValue(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0166"));
                                    else
                                        that.getView().byId("id_txt_verified").setValue(getInspData.CORRSIGN2USER);

                                    that.getView().byId("id_txt_datetime").setValue(getInspData.CORRSIGN1DATE);
                                    that.getView().byId("id_btn_Save").setEnabled(false)

                                }
                            }
                        }
                    }
                }

            },
 
            getInspChar: function() {
                // APLT_CMD_GetInspChar
   // Clear Input
       this.getView().byId("id_ta_longtext").setValue("");
         this.getView().byId("id_txt_acknow").setValue("");
                                this.getView().byId("id_txt_verified").setValue("");
                            this.getView().byId("id_txt_datetime").setValue("");
                var inslot = this.getView().byId("id_txt_inslot").getValue();
                var txt_phs = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_phs");

               
                var oGetInspCharModel =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit_NC-->getInspChar-->SQLQ_GetInspChar");

                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + inslot + "&Param.4=" + txt_phs;
                oGetInspCharModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetInspChar&" + params + "&Content-Type=text/json", "", false);
                if (oGetInspCharModel.getData().Rowsets != null) {
                    var getInspCharData = oGetInspCharModel.getData().Rowsets.Rowset[0].Row[0];
                    var getInspCharLen = oGetInspCharModel.getData().Rowsets.Rowset[0].Row.length;
                    if (getInspCharLen != 0) {

                        var corract = getInspCharData.CORRACTION;
                        var urls = getInspCharData.URLLINKS;
                        var ccpind = getInspCharData.CCPIND;
                        var urls1 = urls.split("\r\n");

                        var urllinks = "";
                        for (var i = 0; i < urls1.length; i++) {
                            if (urls1[i].indexOf("www.") == "0") {
                                urls1[i] = "http://" + urls1[i];
                            } 
		//if no  url then main menu is opening, to fix that added about:blank
                            if(!urls1[i]){
                            	 urls1[i] = "about:blank";
                            }
                            var docno = i + 1;
                            urllinks = urllinks + "\n" + "<a target=\"_blank\" href=\"" + urls1[i].replace("\n", "\"") + "\">" + "Document-" + docno + "<\/a>";

                        }
                        this.getView().byId("id_ta_corract").setValue(corract);
                       
                        this.getView().byId("textURL").setContent(urllinks)
                        /*
                         * document.getElementById("textURL").innerHTML =
                         * urllinks;
                         */
                    }
                }

                var inslot = this.getView().byId("id_txt_inslot").getValue();
                var txt_phs = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_phs");
                var char = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_inspChar");
                var insdate = this.getView().byId("id_txt_insdate").getValue();
                var inspcount = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_inspcount");
                var ccpsign = that.getView().byId("id_txt_ccpsign").getValue();

                // APLT_CMD_GetInspPoint
               
                var oGetInspCharModel =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit_NC-->getInspChar-->SQLQ_GetInspectionPointListHACCP");

                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + inslot + "&Param.4=" +
                    txt_phs + "&Param.5=" + char + "&Param.6=" + insdate + "&Param.7=" + inspcount;
                oGetInspCharModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetInspectionPointListHACCP&" + params + "&Content-Type=text/json", "", false);

                if (oGetInspCharModel.getData().Rowsets.Rowset[0].Row != null) {
                    var getGetInspPointData = oGetInspCharModel.getData().Rowsets.Rowset[0].Row[0];
                    var InspPointLen = oGetInspCharModel.getData().Rowsets.Rowset[0].Row.length;
                    if (InspPointLen != 0) {

                        var signstatus = getGetInspPointData.SIGNSTATUS;
                        if (signstatus == "1") {
                            this.getView().byId("id_ta_longtext").setValue(getGetInspPointData.LONGTEXT);
                            this.getView().byId("id_txt_acknow").setValue(getGetInspPointData.CORRSIGN1USER);
                            if (ccpsign == "CCP1")
                                this.getView().byId("id_txt_verified").setValue(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0166"));
                            else
                                this.getView().byId("id_txt_verified").setValue(getGetInspPointData.CORRSIGN2USER);

                            this.getView().byId("id_txt_datetime").setValue(getGetInspPointData.CORRSIGN1DATE);
                            this.getView().byId("id_btn_Save").setEnabled(false)



                        }
                    }
                }




            },
            GetInspectPoints1: function() {

            },


        });
    });