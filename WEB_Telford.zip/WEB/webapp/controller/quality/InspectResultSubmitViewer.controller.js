sap.ui
    .define(
        [ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox",
            "com/khc/rephub/utils/UI_utilities", "com/khc/common/Script/CommonUtility",
            "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput",
            "com/khc/rephub/model/formatter", "com/khc/rephub/model/models" ],
        function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button,
            DateTimeInput, formatter, models) {
          "use strict";
          var plant = '';
          var resource = '';
          var projectName;
          var shiftname = '';
          var shiftId = '';
          var teamId = '';
          var shiftStartTime = '';
          var shiftEndTime = '';
          var oDownTimeData;
          var sDTStartDateFormatted;
          var userName;
          var crdest = '';

          // from session
          var count = 0;
          var colorDark = "";
          var colorLight = "";
          var warning = "";
          var warning = "";
          var js_FlagPhasesNextTime = 0;
          var js_FlagInspectPoint = 0;
          var js_FlagOrderList = 0;

          var js_LoopCount = 0;

          // for hidden Variable
          var InspectPoint;
          var txt_Mat;
          var crid;
          var txt_Ord;
          var insplot;
          var oModelGetPhaseInsp;
          var ChartParam1;
          var SubgroupSize;
          var UpperCL;
          var UpperUCL;
          var UpperLCL;
          var Rowcount;
          var resetChartType;
          var matnum;
          var oController;

          return Controller
              .extend(
                  "com.khc.rephub.controller.quality.InspectResultSubmitViewer",
                  {
                    formatter : formatter,
/** ******************************************************************************************************************************************************* */
                    onInit : function() {
                      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                      this._oRouter.getRoute("InspectResultSubmitViewer").attachPatternMatched(
                          this._oRoutePatternMatched, this);

                      var oInscPointRoute = {
                        qs_phs : '',
                        qs_currenttime : ""
                      };
                      var oInscPointRouteModel = new sap.ui.model.json.JSONModel(oInscPointRoute);
                      sap.ui.getCore().setModel(oInscPointRouteModel,
                          "RepInspectionPointViewerRoute");
                      oController = this;
                    },

/** ******************************************************************************************************************************************************* */
                    _oRoutePatternMatched : function(oEvent) {

                      console.log("_oRoutePatternMatched");
                      // if parent page condition
                      if (sap.ui.getCore().getModel("InspectResultSubmitViewerModel") != undefined) {
                        if (sap.ui.getCore().getModel("InspectResultSubmitViewerModel").oData.parent_page == "RepInspectPointViewer") {
                          UI_utilities.qualityPageOpened(this, "InspectResultSubmitViewer");
                        } else if (sap.ui.getCore().getModel("InspectResultSubmitViewerModel").oData.parent_page == "InspPointOrderViewer") {
                          UI_utilities.qualityPageOpened(this, "InspectResultSubmitViewer");
                        }
                      }
                      plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                      resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                      projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                      userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                      crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

                      this.onLoad();
                    },
/** ******************************************************************************************************************************************************* */
                    menuSelected : function(oEvent) {

                      // Navigate the the selected menu page

                      var sKey = oEvent.getParameters().key;
                      UI_utilities.openMenu(this._oRouter, this, sKey);

                    },
/** ******************************************************************************************************************************************************* */
                    onHelp : function() {

                      UI_utilities.OpenHelpFileSingle("Resultentry");
                    },
/** ******************************************************************************************************************************************************* */
                    onLoad : function() {

                      if (sap.ui.getCore().getModel("InspectResultSubmitViewerModel") != undefined) {

                        var oInspectResultSubmitViewerModel = sap.ui.getCore().getModel(
                            "InspectResultSubmitViewerModel").oData;
                        // this.getView().setModel(oInspectResultSubmitViewerModel,
                        // "oInspectResultSubmitViewerModel");
                        this.getView().byId("id_txt_matstrip").setValue(
                            oInspectResultSubmitViewerModel.qs_matstrip);
                        this.getView().byId("id_txt_desc").setValue(
                            oInspectResultSubmitViewerModel.qs_matdesc);
                        this.getView().byId("id_txt_ordstrip").setValue(
                            oInspectResultSubmitViewerModel.qs_ordstrip);
                        this.getView().byId("id_txt_phstxt").setValue(
                            oInspectResultSubmitViewerModel.qs_phstxt);
                        matnum = oInspectResultSubmitViewerModel.qs_mat;
                        insplot = oInspectResultSubmitViewerModel.qs_insplot;
                        var inspopr = oInspectResultSubmitViewerModel.qs_phs;
                        var currenttime = oInspectResultSubmitViewerModel.qs_currenttime;

                        this.getView().byId("id_txt_inslot").setValue(insplot);
                        this.getView().byId("id_txt_insdate").setValue(
                            oInspectResultSubmitViewerModel.qs_date);
                        this.getView().byId("id_txt_instime").setValue(
                            oInspectResultSubmitViewerModel.qs_time);

                        var oGetInspCharac = models
                            .createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmitViewer-->onLoad-->XACQ_GetInspCharac");
                        var sParams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3="
                            + insplot + "&Param.4=" + inspopr + "&Param.5=" + currenttime;
                        oGetInspCharac.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                            + "/QueryTemplate/XACQ_GetInspCharac&" + sParams
                            + "&Content-Type=text/json", "", false);
                        this.getView().setModel(oGetInspCharac, "oGetInspCharacData");

                      } else {

                        // Navigate to Rep Inspection Point viewer page
                        UI_utilities.openMenu(this._oRouter, this, "RepInspectPointViewer");
                        return;
                      }

                       

                    },
 /**********************************************************************************************************************************************************/

                    GoBack : function() {
                      var js_phs = sap.ui.getCore().getModel("InspectResultSubmitViewerModel").oData.qs_phs;
                      var js_currenttime = sap.ui.getCore().getModel(
                          "InspectResultSubmitViewerModel").oData.qs_currenttime;

                      sap.ui.getCore().getModel("RepInspectionPointViewerRoute").setProperty(
                          "/qs_phs", js_phs);
                      sap.ui.getCore().getModel("RepInspectionPointViewerRoute").setProperty(
                          "/qs_currenttime", js_currenttime);

                      if (sap.ui.getCore().getModel("InspectResultSubmitViewerModel") != undefined) {
                        if (sap.ui.getCore().getModel("InspectResultSubmitViewerModel").oData.parent_page == "RepInspectPointViewer") {
                          this._oRouter.navTo("RepInspectPointViewer");
                        } else if (sap.ui.getCore().getModel("InspectResultSubmitViewerModel").oData.parent_page == "InspPointOrderViewer") {
                          this._oRouter.navTo("InspPointOrderViewer");
                          sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty(
                              "/Parent_Page", true)
                        }
                      }
                    },

/**View spc chart button functionality*************************************************************************************************************************************************/
                    // RepInspPointSPC
                    ShowSPCChart : function() {
                      var sCharType = '';
                      var sInspChar = '';
                      var oTable = this.getView().byId("id_table_GetInspCharac");
                      var SelRow = oTable.getSelectedContextPaths().length;

                      if (SelRow != 0) {
                        var QnSelRow = oTable.getSelectedContextPaths()[0];
                        var QnSelectedRow = this.getView().getModel("oGetInspCharacData")
                            .getProperty(QnSelRow);
                        sCharType = QnSelectedRow.CHARTYPE;
                        sInspChar = QnSelectedRow.INSPCHAR;
                      }
                      if (sCharType == "QUAN") {

                        this.getSPCPhasedAggregateResults();
                        if (CommonUtility.getJsonModelRowCount(oModelGetPhaseInsp.getData()) > 0) {
                          sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                          var count = oModelGetPhaseInsp.getData().Rowsets.Rowset[0].Row.length;
                       // For loop by taking the rowcount and comparing the selected charDesc from above table and the same chartype from this phased Agg results
                          for (var x = 0; x <= count; x++) {
                            if (oModelGetPhaseInsp.getData().Rowsets.Rowset[0].Row[x].PhaseNo == sInspChar) {
                              
                              var oPhaseData = oModelGetPhaseInsp.getData().Rowsets.Rowset[0].Row[x];

                              var InspLot = oPhaseData.InspectionLot;
                              var InspOpe = oPhaseData.InspectionOperation;
                              var InspChar = oPhaseData.PhaseNo;
                              var ResultType = oPhaseData.ResultType;
                              var InspReq = oPhaseData.InspReq;
                              var MasterChar = oPhaseData.MasterChar;
                              var InspMethod = oPhaseData.InspMethod;
                              var DataPoints = oPhaseData.SamplingPoints;
                              var ThisOrderOnly = oPhaseData.ThisOrderOnly;
                              var UpperCalculateControlLimits = oPhaseData.UpperCalculateControlLimits;
                              var DynamicUCL = "" + oPhaseData.Dynamic_UCL;
                              var DynamicCL = "" + oPhaseData.Dynamic_CL;
                              var DynamicLCL = "" + oPhaseData.Dynamic_LCL;
                              var ChartParam1 = '';
                              var ucl = '';
                              var cl = '';
                              var lcl = '';
                              if (DynamicUCL.indexOf(",") != -1) {
                                ucl = DynamicUCL.split(",");
                                DynamicUCL = ucl[0] + "." + ucl[1];
                              }
                              if (DynamicCL.indexOf(",") != -1) {
                                cl = DynamicCL.split(",");
                                DynamicCL = cl[0] + "." + cl[1];
                              }
                              if (DynamicLCL.indexOf(",") != -1) {
                                lcl = DynamicLCL.split(",");
                                DynamicLCL = lcl[0] + "." + lcl[1];
                              }
                              if (ThisOrderOnly == "0") {
                                ChartParam1 = "%";
                              } else {
                                ChartParam1 = InspLot;
                              }

                              if (ResultType == "SINGLE" && InspReq > 0) {

                                Rowcount = DataPoints * InspReq;
                                resetChartType = "XBAR-RANGE";
                                SubgroupSize = InspReq;
                              } else {
                                Rowcount = DataPoints;
                                resetChartType = "XBAR-MR";
                                SubgroupSize = "1";
                              }
                              if (UpperCalculateControlLimits == "1") {

                                UpperCL = DynamicCL;
                                UpperUCL = DynamicUCL;
                                UpperLCL = DynamicLCL;
                              } else {
                                UpperCL = "CL";
                                UpperUCL = "UCL";
                                UpperLCL = "LCL";

                              }

                            
                            var c = new com.sap.xmii.chart.hchart.i5SPCChart(
                                "RepHubUI5/DisplayTemplate/SPC_InspAnalysisMRChart", projectName
                                    + "/QueryTemplate/XACQ_InspPointSPC");
                            c.getQueryObject().setParameter("Param.1", insplot);
                            c.getQueryObject().setParameter("Param.2", MasterChar);
                            c.getQueryObject().setParameter("Param.3", InspMethod);
                            c.getQueryObject().setParameter("Param.4", matnum);
                            c.getQueryObject().setParameter("Param.5", resource);
                            c.getQueryObject().setParameter("Param.6", plant);
                            c.getQueryObject().setParameter("Param.7", Rowcount);
                            c.getChartObject().setChartType(resetChartType);
                            c.getChartObject().setSubgroupSize(parseInt(SubgroupSize));
                            c.getChartObject().setUpperCL(parseFloat(UpperCL));
                            c.getChartObject().setUpperUCL(parseFloat(UpperUCL));
                            c.getChartObject().setUpperLCL(parseFloat(UpperLCL));
                            c.registerCreationEventHandler(this.spcLoaded);
                            var oHtml = new sap.ui.core.HTML({
                              content : "<div id='spc_chart_content'>"
                            });
                            //this.getView().byId("id_spcCharts_div").addItem(oHtml);
                            //UI_utilities.setContainerBusyState(this, true);
                            //setTimeout(function() {
                              //c.draw("spc_chart_content");
                            //}, 1000);
                            
                            
                            var that = this;
                            if (!this.oEscapePreventDialog) {
                                var dialogInput = new sap.m.VBox({
                                  width : "60%",
                                  height: "450px",
                                  id : "id_spcCharts_div"
                                });
                            
                            
                            this.oEscapePreventDialog = new Dialog({
                              title: "SPC Chart",
                              content: dialogInput,
                              buttons: [
                                new Button({
                                    text: "Close",
                                    press: function(event) {
                                        that.oEscapePreventDialog.close();
                                    }.bind(that)
                                  })
                                ]
                            });
                            sap.ui.getCore().byId("id_spcCharts_div").addItem(oHtml);
                            }
                            
                            UI_utilities.setContainerBusyState(this, true);
                            this.oEscapePreventDialog.open();
                            setTimeout(function() {
                              c.draw("spc_chart_content");
                            }, 1000);
                            
                           } else {
                             var sNoInspData = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
                             sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoInspData);
                             sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                             sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                           }
                           break;
                          }
                        } else {
                            var sNoInspData = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
                            sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoInspData);
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                        }
                      } else {
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty(
                            "HUB_MSG_0068"));
                      }

                    },
/**********Fetch SPC Phased Aggregated Results list**************************************************************************************************************************************************************************** */

                    getSPCPhasedAggregateResults : function() {
                      oModelGetPhaseInsp = new sap.ui.model.json.JSONModel();
                      var sParams = "Param.1=" + insplot + "&Param.2=";
                      oModelGetPhaseInsp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/XACQ_SPCPhasedAggregateResults&" + sParams
                          + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelGetPhaseInsp, "oSPCPhasedAggregateResults");
                    },
/** *********SPC Loaded method*************************************************************************************************************************************************************************** */
                    spcLoaded : function() {
                      UI_utilities.setContainerBusyState(oController, false);

                    },

                  });
        });