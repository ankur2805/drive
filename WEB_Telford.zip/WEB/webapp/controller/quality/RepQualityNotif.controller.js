sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button",
        "sap/m/DateTimeInput", "com/khc/rephub/model/formatter", "com/khc/rephub/model/models"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput, formatter, models) {
        "use strict";
        var plant;
        var resource;
        var projectName;
        var shiftname = '';
        var shiftId = '';
        var teamId = '';
        var shiftStartTime = '';
        var shiftEndTime = '';
        var oDownTimeData;
        var sDTStartDateFormatted;
        var userName;
        var crdest;

        var js_ShiftDetails = 0;
        var js_QualNot = 0;
        var SelNotifType;
        var js_gbl_type_flag = 0;

        //from session
        var CA_GRBlockFlag = 1;
        var eccId;
        var that;
        return Controller.extend("com.khc.rephub.controller.quality.RepQualityNotif", {
            formatter: formatter,
            onInit: function() {
                that = this;
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("RepQualityNotification").attachPatternMatched(this._oRoutePatternMatched, this);

                var oDurationData = {
                    showDuration: false,
                    duration: "00:00"
                };
                var oDurationModel = new sap.ui.model.json.JSONModel(oDurationData);
                sap.ui.getCore().setModel(oDurationModel, "duration");
            },
            _oRoutePatternMatched: function(oEvent) {

                UI_utilities.qualityPageOpened(this, "RepQualityNotification");
                UI_utilities.qualityMenuBar();
                var oQualityNotData = {
                    orderId: '',
                    crid: '',
                    MatNo: '',
                    vendMatnr: false,
                    ReceiveMatnr: false,
                    msgid: '',
                    addButton: true,
                    updateButton: true,
                    closeButton: true,
                    matnr: '',
                    ordNo: ''
                };
                var oQualityNotifyModel = new sap.ui.model.json.JSONModel(oQualityNotData);
                this.getView().setModel(oQualityNotifyModel, "qualityNotifDetails");
                sap.ui.getCore().setModel(oQualityNotifyModel, "qualityNotifDetails")

                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                CA_GRBlockFlag = sap.ui.getCore().getModel("session").oData.CA_GRBlockFlag;

                this.getView().byId("template").setContent('')
                this.getView().byId("txt_funcdesc").setValue("");

                this.getRunningShift();
                this.getRunningOrder()
                this.getNotificationTypeList();
                UI_utilities.DisableDatePickerInput(this.getView().byId("txt_date"));
            },

            ClearAll: function() {
                var that = this;
                var currentDT = CommonUtility.getCurrentDateTime(new Date());
                that.byId("NotifType").setSelectedKey("")
                that.getView().byId("txt_date").setValue(currentDT);
                that.getView().byId("vendMatnr").setModel("");
                this.getView().byId("template").setContent('')
                this.getView().byId("txt_funcdesc").setValue("");
                this.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", false)
                this.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
            },
            messageStrip: function(message, type) {
                sap.ui.getCore().getModel("oMessage").setProperty("/message", message);
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                sap.ui.getCore().getModel("oMessage").setProperty("/type", type);
            },
            //on Load get the running shift details 
            getRunningShift: function() {


                var oModelRunningShiftDetails = models.createNewJSONModel(
                    "com.khc.rephub.controller.quality.RepQualityNotif-->getRunningShift-->XACQ_GetRunningShift");
                var that = this;
                oModelRunningShiftDetails.attachRequestCompleted(
                    function() {

                        that.getView().setModel(oModelRunningShiftDetails, "oRunningShiftList");
                        if (CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData()) > 0) {

                            that.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", false)
                            that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
                            var oRunningShiftData = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
                            shiftname = oRunningShiftData.SHIFTNAME;
                            shiftStartTime = oRunningShiftData.STARTTIME;
                            shiftEndTime = oRunningShiftData.ENDTIME;

                            js_ShiftDetails = 1;
                            shiftId = oRunningShiftData.SHIFTID;
                            teamId = oRunningShiftData.TEAMID;

                        } else {
                            var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                            sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                        }

                    });

                oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetRunningShift&Param.1=" + plant + "&Param.2=" + resource + "&Content-Type=text/json", "", false);

            },

            // ****Check if APLT_CMD_ShiftDetails and APLT_GRI_QualNot are loaded or not. if not then recall it after 500 milisecond.
            // check for running order. if found then populate the running order details.
            // Get the running shift details from hnz_shift table.

            getRunningOrder: function() {

                var that = this;

                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrder&" +
                    "Content-Type=text/json&" + params

                $.ajax({
                    url: url,
                    type: "POST",
                    async: false,
                    success: function(data, txt, jqXHR) {

                        if (CommonUtility.getJsonModelRowCount(data) > 0) {
                            var runningOrder = data.Rowsets.Rowset[0].Row[0];

                            that.getView().byId("txt_OrdNoStrip").setValue(runningOrder.ORDERSTRIP);
                            that.getView().byId("txt_MatNoStrip").setValue(runningOrder.MATNRSTRIP);
                            that.getView().byId("txt_GoodDesc").setValue(runningOrder.MATTEXT);
                            that.getView().byId("txt_PannedQty").setValue(runningOrder.MATQTY);
                            that.getView().byId("txt_UOM").setValue(runningOrder.UOM);
                            that.getView().byId("txt_shift").setValue(shiftname);

                            that.getView().getModel("qualityNotifDetails").setProperty("/orderId", runningOrder.ORDERID)
                            that.getView().getModel("qualityNotifDetails").setProperty("/ordNo", runningOrder.ORDERID)
                            that.getView().getModel("qualityNotifDetails").setProperty("/msgid", runningOrder.MSGID)
                            that.getView().getModel("qualityNotifDetails").setProperty("/matnr", runningOrder.MATNR)
                            that.getView().getModel("qualityNotifDetails").setProperty("/crid", runningOrder.CRID)

                            var currentDT = CommonUtility.getCurrentDateTime(new Date());
                            that.getView().byId("txt_date").setValue(currentDT);

                            that.getQualNotDetails()

                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        alert(jqXHR.responseText);
                    }
                });

            },

            //**** Get the quality notification fro hnz_qualnot table for a particular material. 
            getQualNotDetails: function() {

                var matnum = this.getView().getModel("qualityNotifDetails").getProperty("/MatNo")
                var ordid = this.getView().getModel("qualityNotifDetails").getProperty("/orderId");

                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + ordid + "&Param.4=" + matnum;


                var oModelShiftNoteList = models.createNewJSONModel(
                    "com.khc.rephub.controller.quality.RepQualityNotif-->getQualNotDetails-->XACQ_GetQualNotListV2");
                oModelShiftNoteList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetQualNotListV2&" + params +
                    "&Content-Type=text/json", "", false);

                sap.ui.getCore().setModel(oModelShiftNoteList, "QualityNotifyResrList");
                js_QualNot = 1;
            },

            //on Load get the notif Type 
            getNotificationTypeList: function() {
                var that = this;
                var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetQNTypeV2&Content-Type=text/json"

                $.ajax({
                    url: url,
                    type: "POST",
                    async: false,
                    success: function(data, txt, jqXHR) {
                        var notifType = data.Rowsets.Rowset[0].Row;
                        var oModel = new sap.ui.model.json.JSONModel(notifType);
                        that.getView().byId("NotifType").setModel(oModel);
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        alert(jqXHR.responseText);
                    }
                });

            },
            //on Select on notif Type 
            getVenMatList: function(event) {
                var that = this;

                var SelItem = event.getSource().getSelectedKey();
                //get Ecc Quantity type ID

                var oModelEcctypeList = models.createNewJSONModel(
                    "com.khc.rephub.controller.quality.RepQualityNotif-->getVenMatList-->SQLQ_GetECCIdfromQNType");
                var params = "Param.1=" + SelItem;
                oModelEcctypeList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetECCIdfromQNType&" + params +
                    "&Content-Type=text/json", "", false);

                if (oModelEcctypeList.getData().Rowsets.Rowset[0].Row != undefined) {
                    eccId = oModelEcctypeList.getData().Rowsets.Rowset[0].Row[0].ECCQNTYPEID;

                }

                //getOrder Details count

                var oModelRuningOrder = models.createNewJSONModel(
                    "com.khc.rephub.controller.quality.RepQualityNotif-->getVenMatList-->XACQ_GetRunningOrder");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                oModelRuningOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrder&" + params +
                    "&Content-Type=text/json", "", false);
                var orderDetailCount;
                if (oModelRuningOrder.getData().Rowsets.Rowset[0].Row != undefined) {
                    var orderDetailCount = oModelRuningOrder.getData().Rowsets.Rowset[0].Row.length;
                }

                if (orderDetailCount != 0) {
                    if (eccId == "ZV") {
                        that.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", true)

                        //Bind Material combo box
                        var msgid = that.getView().getModel("qualityNotifDetails").getProperty("/msgid")
                        var crid = that.getView().getModel("qualityNotifDetails").getProperty("/crid")


                        var oModelVendMatList = models.createNewJSONModel(
                            "com.khc.rephub.controller.quality.RepQualityNotif-->getVenMatList-->XACQ_GetMaterialList");
                        var params = "Param.1=" + crid + "&Param.2=" + msgid;
                        oModelVendMatList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMaterialList&" + params +
                            "&Content-Type=text/json", "", false);

                        if (oModelVendMatList.getData().Rowsets.Rowset[0].Row != undefined) {
                            var vendMatmodel = new sap.ui.model.json.JSONModel(oModelVendMatList.getData().Rowsets.Rowset[0].Row)

                            that.getView().byId("vendMatnr").setModel(vendMatmodel);
                            that.getView().byId("vendMatnr").setModel(vendMatmodel);
                        }
                    } else {
                        that.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", false)

                        //  that.getView().byId("vendMatnr").removeAllItems()
                        that.getView().byId("vendMatnr").setModel("");
                    }

                    // Begin Code for HU assign
                    if (CA_GRBlockFlag == "1") {
                        if (eccId == "ZT") {
                            that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", true)
                        } else if (eccId == "ZH") {
                            that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", true)
                        } else {
                            that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
                        }
                    } else {
                        that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
                    }
                    // End code for HU assign

                    if (SelItem != "") {
                        var oModelList = models.createNewJSONModel(
                            "com.khc.rephub.controller.quality.RepQualityNotif-->getVenMatList-->XACQ_GenerateQNTextElement");
                        var params = "Param.1=" + SelItem;
                        oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNTextElement&" + params +
                            "&Content-Type=text/json", "", false);
                        var template = "";
                        if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                            template = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;
                            that.getView().byId("template").setContent(template)
                        }


                        var oModelList = models.createNewJSONModel(
                            "com.khc.rephub.controller.quality.RepQualityNotif-->getVenMatList-->XACQ_GenerateQNHiddenElementID");
                        var params = "Param.1=" + SelItem;
                        oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNHiddenElementID&" + params +
                            "&Content-Type=text/json", "", false);
                        var hidfieldid = "";
                        if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                            hidfieldid = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;

                        }
                    } else {
                        that.getView().byId("template").setContent('')
                        that.getView().byId("hidfieldid").setContent('')
                    }


                }

                // Code for QN raise with No running Order starts here
                else {

                    var currentDT = CommonUtility.getCurrentDateTime(new Date());
                    that.getView().byId("txt_date").setValue(currentDT);

                    if (shiftname != "") {
                        if (eccId == "ZI") {
                            var oModelList = models.createNewJSONModel(
                                "com.khc.rephub.controller.quality.RepQualityNotif-->getVenMatList-->XACQ_GenerateQNTextElement");
                            var params = "Param.1=" + SelItem;
                            oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNTextElement&" + params +
                                "&Content-Type=text/json", "", false);
                            var template = "";
                            if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                template = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;
                                that.getView().byId("template").setContent(template)
                            }

                            var oModelList = models.createNewJSONModel(
                                "com.khc.rephub.controller.quality.RepQualityNotif-->getVenMatList-->XACQ_GenerateQNHiddenElementID");
                            var params = "Param.1=" + SelItem;
                            oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNHiddenElementID&" + params +
                                "&Content-Type=text/json", "", false);
                            var hidfieldid = "";
                            if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                hidfieldid = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;

                            }

                            that.getView().getModel("qualityNotifDetails").setProperty("/addButton", true)
                            that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", true)
                        } else {
                            that.getView().byId("template").setContent('')
                            that.getView().getModel("qualityNotifDetails").setProperty("/addButton", false)
                            that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", false)

                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                        this.messageStrip(msg, "Error");
                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019"))
                        that.getView().getModel("qualityNotifDetails").setProperty("/addButton", false)
                        that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", false)
                        that.getView().getModel("qualityNotifDetails").setProperty("/closeButton", false)
                    }
                }

                // Code for QN raise with No running Order ends here
                js_gbl_type_flag = 0;
            },

            // **** Called from create notification button. Determine the material before createing the notification.
            // for ventor material ZV type select the material from bo list.
            // for other aterial select the header material.
            GetMatNrVal: function() {
                var that = this;
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                var notiftype = eccId;
                var matnr = "";
                if (that.getView().byId("vendMatnr").getSelectedItem() != null)
                    matnr = that.getView().byId("vendMatnr").getSelectedItem().getKey()
                //that.getView().byId("vendMatnr").getSelectedText();
                //alert(notiftype);
                if (notiftype == "ZV") {
                    if (matnr == "") {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0099");
                        this.messageStrip(msg, "Error");
                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0099"));
                    } else {

                        var matnr = that.getView().byId("vendMatnr").getSelectedItem().getText()
                        // that.getView().byId("vendMatnr").getSelectedText();

                        that.CreateQualNotif(matnr);
                    }
                } else {

                    var matnr = that.getView().getModel("qualityNotifDetails").getProperty("/matnr")

                    that.CreateQualNotif(matnr);
                }
            },

            //**** create quality notification.in ecc by calling BAPI_QUALNOT_CREATE and BAPI_QUALNOT_SAVE 
            // save the created notification in hnz_qualnot table
            CreateQualNotif: function(matnum) {
                var that = this;
                that.getView().getModel("qualityNotifDetails").setProperty("/addButton", false)
                that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", false)
                that.getView().getModel("qualityNotifDetails").setProperty("/closeButton", false)

                // 
                var notiftype = eccId;

                var qntypeid = that.getView().byId("NotifType").getSelectedKey();
                var desc = that.getView().byId("txt_funcdesc").getValue();
                var repby = userName;
                var resr = resource;

                var notifdate = that.getView().byId("txt_date").getValue();

                var GRType = "";
                var GRMsg = "";

                //Holding

                var longtext = "";
                var elementtext = "";

                // check for the mandatory eleent value having * at the end. If epty the not allow to create.as well as prepare the longtext and element text.

                var oHtmlTable = this.getView().byId('template').getDomRef();
                var BlankFlag = 0;
                var missingField;

                $(oHtmlTable).find('tr').each(function() {

                    var oTextArea = $(this).find('textarea');
                    var sId = oTextArea[0].id;
                    var Mandfieldobj = sId.indexOf("*");

                    var ObjVal = document.getElementById(sId).value;
                    if (Mandfieldobj != "-1") {
                        if (ObjVal == "") {
                            BlankFlag = 1;
                            missingField = sId;
                        }
                    }
                    elementtext = elementtext + "|" + ObjVal;
                    longtext = longtext + " " + sId + " : " + ObjVal + "|";

                });
                //Holding

                if (notifdate >= shiftStartTime && notifdate <= shiftEndTime) {
                    if (desc != "") {
                        if (BlankFlag != 1) {
                            if (this.getView().byId("NotifType").getSelectedKey() != '') {

                                var QNType;
                                var QNMsg;
                                var oModelList = models.createNewJSONModel(
                                    "com.khc.rephub.controller.quality.RepQualityNotif-->CreateQualNotif-->XACQ_CreateQualNotifV2");
                                var params = "Param.1=" + plant + "&Param.2=" + notiftype + "&Param.4=" + desc +
                                    "&Param.5=" + repby + "&Param.6=" + resr + "&Param.7=" + longtext + "&Param.9=" + notifdate + "&Param.10=" + qntypeid +
                                    "&Param.11=" + elementtext;

                                var ordid = that.getView().getModel("qualityNotifDetails").getProperty("/ordNo");
                                // This condition is added to remove Material number and OrderID in the case when an incident rised Type "ZI". Reference Defect # 27223 Date 3013-02-20
                                if (notiftype != "ZI") {
                                    params += "&Param.3=" + matnum + "&Param.8=" + ordid;
                                } else {
                                    params += "&Param.3=" + "" + "&Param.8=" + ordid;

                                }

                                oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CreateQualNotifV2&" + params +
                                    "&Content-Type=text/json", "", false);

                                if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                    QNType = oModelList.getData().Rowsets.Rowset[0].Row[0].Type;
                                    QNMsg = oModelList.getData().Rowsets.Rowset[0].Row[0].Message;
                                }

                                if (QNType == "S") {
                                    // Begin code for HU assign
                                    if (that.getView().byId("MatnrRadioButton").getSelectedIndex() == 1) {
                                        var block = 1;

                                        var orderId = that.getView().getModel("qualityNotifDetails").getProperty("/ordNo");
                                        var oModelBlockGRList = models.createNewJSONModel(
                                            "com.khc.rephub.controller.quality.RepQualityNotif-->CreateQualNotif-->XACQ_BlockGR");
                                        var params = "Param.1=" + orderId + "&Param.2=" + QNMsg + "&Param.3=" + notiftype + "&Param.4=" + block +
                                            "&Param.5=" + plant + "&Param.6=" + resr + "&Param.7=" + repby;

                                        oModelBlockGRList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_BlockGR&" + params +
                                            "&Content-Type=text/json", "", false);

                                        if (oModelBlockGRList.getData().Rowsets.Rowset[0].Row != undefined) {
                                            GRType = oModelBlockGRList.getData().Rowsets.Rowset[0].Row[0].Type;
                                            GRMsg = oModelBlockGRList.getData().Rowsets.Rowset[0].Row[0].Message;
                                        }

                                    }
                                    // End code for HU assign 

                                    var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0045");
                                    this.messageStrip(msg, "Success");
                                    //MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0045"));
                                    if (GRType == "E11") {
                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0134");
                                        this.messageStrip(msg, "Error");
                                        // MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0134"));
                                    }
                                    if (GRType == "E01") {

                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0136");
                                        this.messageStrip(msg, "Error");
                                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0136"));
                                    }

                                    that.getView().byId("txt_funcdesc").setValue('');
                                    that.getQualNotDetails();
                                    that.ClearAll();
                                } else if (QNType == "E") {

                                    var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0090");
                                    this.messageStrip(msg, "Error");
                                    //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0090"));
                                } else if (QNType == "B") {

                                    var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0091");
                                    this.messageStrip(msg, "Error");
                                    //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0091"));
                                    that.getView().byId("txt_funcdesc").setValue('');
                                    that.getQualNotDetails();
                                    this.ClearAll();
                                }
                            } else {

                                var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0103");
                                this.messageStrip(msg, "Error");
                                //    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0103"));
                            }
                        } else {

                            var msg = "Enter value in the Mandatory Field(*)";
                            this.messageStrip(msg, "Error");
                            //MessageBox.error("Enter value in the Mandatory Field(*)");
                        }
                    } else {

                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0109");
                        this.messageStrip(msg, "Error");
                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0109"));
                    }
                } else {

                    var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0106");
                    this.messageStrip(msg, "Error");
                    // MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0106"));
                }

                that.getView().getModel("qualityNotifDetails").setProperty("/addButton", true)
                that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", true)
                that.getView().getModel("qualityNotifDetails").setProperty("/closeButton", true)
            },

            // **** Update the qualitynotification longtext in ECC and update it in HNZ_QUALNOT table.
            UpdateQualNotif: function() {
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                var SelRow = this.getView().byId("APLT_GRI_QualNot").getSelectedContextPaths().length;
                var that = this;

                var repby = userName;
                var resr = resource;
                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("APLT_GRI_QualNot").getSelectedContextPaths()[0];
                    var QnSelectedRow = this.getView().getModel("QualityNotifyResrList").getProperty(QnSelRow);

                    var qnotno = QnSelectedRow.QNOTIF;
                    var qntypeid = that.getView().byId("NotifType").getSelectedKey();
                    var GRType = "";
                    var GRMsg = "";

                    // 
                    var longtext = "";
                    var elementtext = "";
                    var BlankFlag;
                    // check for the mandatory eleent value having * at the end. If empty the not allow to create. as well as prepare the longtext and element text.

                    var oHtmlTable = this.getView().byId('template').getDomRef();
                    var BlankFlag = 0;
                    var missingField;

                    $(oHtmlTable).find('tr').each(function() {

                        var oTextArea = $(this).find('textarea');
                        var sId = oTextArea[0].id;
                        var Mandfieldobj = sId.indexOf("*");

                        var ObjVal = document.getElementById(sId).value;
                        if (Mandfieldobj != "-1") {
                            if (ObjVal == "") {
                                BlankFlag = 1;
                                missingField = sId;
                            }
                        }
                        elementtext = elementtext + "|" + ObjVal;
                        longtext = longtext + " " + sId + " : " + ObjVal + "|";

                    });
                    //

                    if (longtext != "") {
                        if (BlankFlag != 1) {
                            var notiftype = eccId;
                            if (qnotno != "Buffered" || !isNaN(qnotno)) {
                                var oModelList = models.createNewJSONModel(
                                    "com.khc.rephub.controller.quality.RepQualityNotif-->UpdateQualNotif-->XACQ_UpdateQualNotifV2");
                                var params = "Param.1=" + qnotno + "&Param.2=" + longtext + "&Param.3=" + plant + "&Param.4=" + resr +
                                    "&Param.5=" + repby + "&Param.6=" + elementtext;
                                oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_UpdateQualNotifV2&" + params +
                                    "&Content-Type=text/json", "", false);
                                var QNType;
                                var QNMsg;
                                if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                    QNType = oModelList.getData().Rowsets.Rowset[0].Row[0].Type;
                                    QNMsg = oModelList.getData().Rowsets.Rowset[0].Row[0].Message;

                                }

                                if (QNType == "S") {
                                    var ordid = this.getView().getModel("qualityNotifDetails").getProperty("/orderId");
                                    // Begin code HU assign
                                    if (this.getView().byId("MatnrRadioButton").getSelectedIndex() == 0) {
                                        if (QnSelectedRow.GRBLOCK == "Yes") {
                                            var block = 0;
                                            var oModelList = models.createNewJSONModel(
                                                "com.khc.rephub.controller.quality.RepQualityNotif-->UpdateQualNotif-->XACQ_BlockGR");
                                            var params = "Param.1=" + ordid + "&Param.2=" + qnotno + "&Param.3=" + notiftype + "&Param.4=" + block +
                                                "&Param.5=" + plant + "&Param.6=" + resr + "&Param.7=" + repby;
                                            oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_BlockGR&" + params +
                                                "&Content-Type=text/json", "", false);

                                            if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                                GRType = oModelList.getData().Rowsets.Rowset[0].Row[0].Type;
                                                GRMsg = oModelList.getData().Rowsets.Rowset[0].Row[0].Message;

                                            }
                                        }
                                    }
                                    if (this.getView().byId("MatnrRadioButton").getSelectedIndex() == 1) {
                                        if (QnSelectedRow.GRBLOCK != "Yes") {
                                            var block = 1;
                                            var oModelList = models.createNewJSONModel(
                                                "com.khc.rephub.controller.quality.RepQualityNotif-->UpdateQualNotif-->XACQ_BlockGR");
                                            var params = "Param.1=" + ordid + "&Param.2=" + qnotno + "&Param.3=" + notiftype + "&Param.4=" + block +
                                                "&Param.5=" + plant + "&Param.6=" + resr + "&Param.7=" + repby;
                                            oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_BlockGR&" + params +
                                                "&Content-Type=text/json", "", false);

                                            if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                                GRType = oModelList.getData().Rowsets.Rowset[0].Row[0].Type;
                                                GRMsg = oModelList.getData().Rowsets.Rowset[0].Row[0].Message;

                                            }
                                        }
                                    }
                                    // End code HU assign 	
                                    this.messageStrip(QNMsg, "Success");
                                    // MessageBox.success(QNMsg);
                                    if (GRType == "E11") {
                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0134");
                                        this.messageStrip(msg, "Error");
                                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0134"));
                                    }
                                    if (GRType == "E01") {
                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0136");
                                        this.messageStrip(msg, "Error");
                                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0136"));
                                    }
                                    if (GRType == "E12") {
                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0135");
                                        this.messageStrip(msg, "Error");
                                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0135"));
                                    }
                                    if (GRType == "E02") {
                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0137");
                                        this.messageStrip(msg, "Error");
                                        //MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0137"));
                                    }

                                    this.getView().byId("template").setContent('')
                                    this.getView().byId("txt_funcdesc").setValue("");
                                    this.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", false)
                                    this.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
                                    this.ClearAll()

                                } else if (QNType == "E") {
                                    this.messageStrip(" Error: " + QNMsg, "Error");
                                    // MessageBox.error(" Error: " + QNMsg);
                                }

                                this.getQualNotDetails();
                            } else {
                                var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0107");
                                this.messageStrip(msg, "Error");
                                // MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0107"));
                            }
                        } else {
                            var msg = "Enter value in the Mandatory Field(*)";
                            this.messageStrip(msg, "Error");
                            // MessageBox.error("Enter value in the Mandatory Field(*)");
                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0098");
                        this.messageStrip(msg, "Error");
                        //  MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0098"));
                    }

                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096");
                    this.messageStrip(msg, "Error");
                    // MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
                }

            },
            //***** Update status=2 and Closetime in table  HNZ_QUALNOT
            CloseQualNotif: function() {

                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                var SelRow = this.getView().byId("APLT_GRI_QualNot").getSelectedContextPaths().length;

                var currentDT = CommonUtility.getCurrentDateTime(new Date());

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("APLT_GRI_QualNot").getSelectedContextPaths()[0];
                    var QnSelectedRow = this.getView().getModel("QualityNotifyResrList").getProperty(QnSelRow);

                    var qnotno = QnSelectedRow.QNOTIF;
                    var notiftime = QnSelectedRow.NOTIFTIME;
                    //
                    var that = this;
                    if (!this.oEscapePreventDialog) {
                        var dialogInput = new sap.m.Text({
                            text: sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0105")
                        })
                        this.oEscapePreventDialog = new Dialog({
                            title: "Enter Split time",
                            content: dialogInput,
                            buttons: [
                                new Button({
                                    text: "Yes",
                                    press: function(event) {

                                        that.confirmCloseQualNotif(qnotno, currentDT, notiftime)

                                        that.oEscapePreventDialog.close();
                                    }.bind(that)
                                }),

                                new Button({
                                    text: "No",
                                    press: function(event) {
                                        that.oEscapePreventDialog.close();
                                    }.bind(that)
                                })

                            ]
                        });
                    }

                    this.oEscapePreventDialog.open();

                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096");
                    this.messageStrip(msg, "Error");
                    // MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
                }

            },
            confirmCloseQualNotif: function(qnotno, currentDT, notiftime) {
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                var that = this;
                var oModelList = models.createNewJSONModel(
                    "com.khc.rephub.controller.quality.RepQualityNotif-->confirmCloseQualNotif-->XACQ_CloseQualityNotif");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + qnotno + "&Param.4=" + currentDT + "&Param.5=" + notiftime;
                oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CloseQualityNotif&" + params +
                    "&Content-Type=text/json", "", false);

                if (oModelList.getData().Rowsets.Rowset != undefined) {
                    var QNType = oModelList.getData().Rowsets.Rowset[0].Row[0].Type;
                    var QNMsg = oModelList.getData().Rowsets.Rowset[0].Row[0].Message;

                    if (QNType == "S") {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0070");
                        this.messageStrip(msg, "Success");
                        // MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0070"));	 
                        this.ClearAll()
                        this.getQualNotDetails();
                    } else if (QNType == "E") {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0047") + " Error: " + QNMsg;
                        this.messageStrip(msg, "Error");
                        //  MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0047") + " Error: " + QNMsg);
                    }

                    that.getQualNotDetails();
                }
                 
						this.ClearAll()
						this.getQualNotDetails();
						//var msg = "Quality Notification Closed Successfully";
                        				//this.messageStrip(msg, "Success");
	
				 

            },
            // QualityNotifyListSelected Table selection event
            getLongText: function() {
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                this.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", false)
                this.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
                this.getView().byId("template").setContent("")

                var SelRow = this.getView().byId("APLT_GRI_QualNot").getSelectedContextPaths().length;

                var currentDT = CommonUtility.getCurrentDateTime(new Date());

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("APLT_GRI_QualNot").getSelectedContextPaths()[0];
                    var QnSelectedRow = this.getView().getModel("QualityNotifyResrList").getProperty(QnSelRow);

                    SelNotifType = QnSelectedRow.QNTYPEID;
                    js_gbl_type_flag = 1;
                    //Set type combo Box
                    this.getView().byId("NotifType").setSelectedKey(SelNotifType)

                    var qnDesc = QnSelectedRow.QNDESC;
                    this.getView().byId("txt_funcdesc").setValue(qnDesc)
                    this.getNotifType_Selection();

                    //Holding

                    var dblongtext = QnSelectedRow.ELEMENTTXT;
                    var longtextarray = dblongtext.split("|");
                    var i = 1;
                    this.getView().byId("template").setDOMContent(this.getView().byId("template").getContent())
                    var oHtmlTable = this.getView().byId('template').getDomRef();

                    $(oHtmlTable).find('tr').each(function() {

                        var oTextArea = $(this).find('textarea');
                        var sId = oTextArea[0].id;
                        var longText = longtextarray[i++];
                        if (longText != null)
                            document.getElementById(sId).value = longText;

                    });
                    //Holding

                    if (QnSelectedRow.QNTYPE == "Vendor Material") {
                        this.getView().byId("vendMatnr").setSelectedKey(QnSelectedRow.MATNR)
                    }

                    // Begin cod for HU assign
                    if (QnSelectedRow.GRBLOCK == "Yes") {
                        this.getView().byId("MatnrRadioButton").setSelectedIndex(1)
                    } else {
                        this.getView().byId("MatnrRadioButton").setSelectedIndex(0)
                    }
                    // end code for HU assign
                    //

                }

            },
            getNotifType_Selection: function() {
                var that = this;
                var SelItem = SelNotifType;
                //get Ecc Quantity type ID
                var oModelEcctypeList = models.createNewJSONModel(
                    "com.khc.rephub.controller.quality.RepQualityNotif-->getNotifType_Selection-->SQLQ_GetECCIdfromQNType");
                var params = "Param.1=" + SelItem;
                oModelEcctypeList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetECCIdfromQNType&" + params +
                    "&Content-Type=text/json", "", false);

                if (oModelEcctypeList.getData().Rowsets.Rowset[0].Row != undefined) {
                    eccId = oModelEcctypeList.getData().Rowsets.Rowset[0].Row[0].ECCQNTYPEID;
                }

                //getOrder Details count
                var oModelRuningOrder = models.createNewJSONModel(
                    "com.khc.rephub.controller.quality.RepQualityNotif-->getNotifType_Selection-->XACQ_GetRunningOrder");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                oModelRuningOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrder&" + params +
                    "&Content-Type=text/json", "", false);
                var orderDetailCount;
                if (oModelRuningOrder.getData().Rowsets.Rowset[0].Row != undefined) {
                    var orderDetailCount = oModelRuningOrder.getData().Rowsets.Rowset[0].Row.length;
                }

                if (orderDetailCount != 0) {
                    if (eccId == "ZV") {
                        that.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", true)

                        //Bind Material combo box
                        var msgid = that.getView().getModel("qualityNotifDetails").getProperty("/msgid")
                        var crid = that.getView().getModel("qualityNotifDetails").getProperty("/crid")

                        var oModelVendMatList = models.createNewJSONModel(
                            "com.khc.rephub.controller.quality.RepQualityNotif-->getNotifType_Selection-->XACQ_GetMaterialList");
                        var params = "Param.1=" + crid + "&Param.2=" + msgid;
                        oModelVendMatList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMaterialList&" + params +
                            "&Content-Type=text/json", "", false);

                        if (oModelVendMatList.getData().Rowsets.Rowset[0].Row != undefined) {
                            var vendMatmodel = new sap.ui.model.json.JSONModel(oModelVendMatList.getData().Rowsets.Rowset[0].Row)
                            that.getView().byId("vendMatnr").setModel(vendMatmodel);
                            that.getView().byId("vendMatnr").setModel(vendMatmodel);
                        }
                    } else {
                        that.getView().getModel("qualityNotifDetails").setProperty("/vendMatnr", false)

                        //  that.getView().byId("vendMatnr").removeAllItems()
                        that.getView().byId("vendMatnr").setModel("");
                    }

                    // Begin Code for HU assign
                    if (CA_GRBlockFlag == "1") {
                        if (eccId == "ZT") {
                            that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", true)
                        } else if (eccId == "ZH") {
                            that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", true)
                        } else {
                            that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
                        }
                    } else {
                        that.getView().getModel("qualityNotifDetails").setProperty("/ReceiveMatnr", false)
                    }
                    // End code for HU assign

                    if (SelItem != "") {
                        var oModelList = models.createNewJSONModel(
                            "com.khc.rephub.controller.quality.RepQualityNotif-->getNotifType_Selection-->XACQ_GenerateQNTextElement");
                        var params = "Param.1=" + SelItem;
                        oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNTextElement&" + params +
                            "&Content-Type=text/json", "", false);
                        var template = "";
                        if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                            template = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;
                            that.getView().byId("template").setContent(template)
                        }

                        var oModelList = models.createNewJSONModel(
                            "com.khc.rephub.controller.quality.RepQualityNotif-->getNotifType_Selection-->XACQ_GenerateQNHiddenElementID");
                        var params = "Param.1=" + SelItem;
                        oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNHiddenElementID&" + params +
                            "&Content-Type=text/json", "", false);
                        var hidfieldid = "";
                        if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                            hidfieldid = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;

                        }
                    } else {
                        that.getView().byId("template").setContent('')
                        that.getView().byId("hidfieldid").setContent('')
                    }
                }

                // Code for QN raise with No running Order starts here
                else {

                    var currentDT = CommonUtility.getCurrentDateTime(new Date());
                    that.getView().byId("txt_date").setValue(currentDT);

                    if (shiftname != "") {
                        if (eccId == "ZI") {
                            var oModelList = models.createNewJSONModel(
                                "com.khc.rephub.controller.quality.RepQualityNotif-->getNotifType_Selection-->XACQ_GenerateQNTextElement");
                            var params = "Param.1=" + SelItem;
                            oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNTextElement&" + params +
                                "&Content-Type=text/json", "", false);
                            var template = "";
                            if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                template = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;
                                that.getView().byId("template").setContent(template)
                            }

                            var oModelList = models.createNewJSONModel(
                                "com.khc.rephub.controller.quality.RepQualityNotif-->getNotifType_Selection-->XACQ_GenerateQNHiddenElementID");
                            var params = "Param.1=" + SelItem;
                            oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateQNHiddenElementID&" + params +
                                "&Content-Type=text/json", "", false);
                            var hidfieldid = "";
                            if (oModelList.getData().Rowsets.Rowset[0].Row != undefined) {
                                hidfieldid = oModelList.getData().Rowsets.Rowset[0].Row[0].O_Return;

                            }

                            that.getView().getModel("qualityNotifDetails").setProperty("/addButton", true)
                            that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", true)
                        } else {
                            that.getView().byId("template").setContent('')
                            that.getView().byId("hidfieldid").setContent('')
                            that.getView().getModel("qualityNotifDetails").setProperty("/addButton", false)
                            that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", false)

                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                        this.messageStrip(msg, "Error");
                        //   MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019"))
                        that.getView().getModel("qualityNotifDetails").setProperty("/addButton", false)
                        that.getView().getModel("qualityNotifDetails").setProperty("/updateButton", false)
                        that.getView().getModel("qualityNotifDetails").setProperty("/closeButton", false)
                    }
                }
            },
            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },
            onHelp: function() {

                UI_utilities.OpenHelpFileSingle("Qn");
            }
        });
    });