sap.ui
.define(
		[ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox", "com/khc/rephub/utils/UI_utilities",
			"com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput",
			"com/khc/rephub/model/models", "com/khc/rephub/model/formatter" ],
			function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput, models, formatter) {
			"use strict";
			var plant;
			var resource;
			var projectName;
			var shiftname = '';
			var shiftId = '';
			var teamId = '';
			var shiftStartTime = '';
			var shiftEndTime = '';
			var oDownTimeData;
			var sDTStartDateFormatted;
			var userName;
			var crdest;

			// for page
			var resultflag = 0;
			var currentfocus_textid;

			// for hidden Variable
			var InspectPoint;
			var txt_Mat;
			var crid;
			var txt_Ord;

			//
			var currenttime;
			var currentDate = "";
			var xmiiCommand;
			var TareWeightID;
			var that;
			var isPrevQualInspView;
			var js_resr;
			var js_resrtxt
			//
			var fromManualmenu = false;

			return Controller
			.extend(
					"com.khc.rephub.controller.quality.InspectResultSubmit",
					{
						formatter : formatter,
						onInit : function() {
							that = this;
							this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
							this._oRouter.getRoute("InspectResultSubmit").attachPatternMatched(this._oRoutePatternMatched, this);

						},

						menuSelected : function(oEvent) {

							// Navigate the the selected menu page

							var sKey = oEvent.getParameters().key;
							UI_utilities.openMenu(this._oRouter, this, sKey);

						},

						_oRoutePatternMatched : function(oEvent) {

							plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
							resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
							projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
							userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
							crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
							js_resr = sap.ui.getCore().getModel("session").oData.CA_Resource;
							js_resrtxt = sap.ui.getCore().getModel("session").oData.CA_ResrText;

							// Check if model null return to previous pae
							if (sap.ui.getCore().getModel("IncResSubmitModel") == null) {
								this._oRouter.navTo("InspectionPoint");
								return;
							}
							else{
								resource = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/js_resr");
	  						}

							isPrevQualInspView = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/isQualityInspectionView");

							UI_utilities.qualityPageOpened(this, "InspectResultSubmit");
							UI_utilities.qualityMenuBar();
							// Model For button & Grid Control
							var oData = {
									GridAreaRS : false,
									GridArea1 : false,
									GridArea : false,
									GridAreaAR : false,
									GridAreaTW : false,
									btn_Result_Manual : true,
									btn_ViewSPC : true,
									btn_ViewHACCP : true,
									btn_Submit : true,
									btn_Back : true,
									btn_Save : false,
									btn_ReadScale : false,
									btn_Update : false,
									btn_TW_Check : false,

									InspectionScreen : true,
									ManualScreen : false,
									manualBtn_Save : true,
									manualBtn_Back : true,
									Quan_QualRemark : '',
							};

							var oModel = new sap.ui.model.json.JSONModel(oData);
							sap.ui.getCore().setModel(oModel, "InspectionSubmitResult");
							this.getView().setModel(oModel, "InspectionSubmitResult");

							this.getRunningShift();

							// this.getRunningOrder();
							this.setInitialLoadData();
							this.getInspCharac();

							if (sap.ui.getCore().getModel("oRedirectFromChildPage").getProperty("/Parent_Page") == true) {
								sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty("/Parent_Page", false)
								// alert("dont clear values");
							} else {
								// this.clearValue();
								// alert("Clear the value");

							}
						},

						// on Load get the running shift details
						getRunningShift : function() {

							var oModelRunningShiftDetails = models
							.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->getRunningShift-->XACQ_GetRunningShift");
							var that = this;
							oModelRunningShiftDetails.attachRequestCompleted(function() {

								that.getView().setModel(oModelRunningShiftDetails, "oRunningShiftList");
								if (CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData()) > 0) {
									var oRunningShiftData = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
									shiftname = oRunningShiftData.SHIFTNAME;
									shiftStartTime = oRunningShiftData.STARTTIME;
									shiftEndTime = oRunningShiftData.ENDTIME;
									shiftId = oRunningShiftData.SHIFTID;
									teamId = oRunningShiftData.TEAMID;
								} else {
									/*
									 * Commented by Praveen 28/2/23 var sNoShiftMsg =
									 * sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
									 * sap.ui.getCore().getModel("oMessage").setProperty("/message",
									 * sNoShiftMsg);
									 * sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",
									 * true);
									 * sap.ui.getCore().getModel("oMessage").setProperty("/type",
									 * "Error");
									 */
								}
							});

							oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
									+ "/QueryTemplate/XACQ_GetRunningShift&Param.1=" + plant + "&Param.2=" + resource + "&Content-Type=text/json",
									"", false);

						},

						getRunningOrder : function() {

							var that = this;

							// getOrder Details count

							var oModelRuningOrder = models
							.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->getRunningOrder-->XACQ_GetRunningOrderOpenInsp");

							var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
							oModelRuningOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
									+ "/QueryTemplate/XACQ_GetRunningOrderOpenInsp&" + params + "&Content-Type=text/json", "", false);
							var orderCount;
							if (oModelRuningOrder.getData().Rowsets.Rowset[0].Row != undefined) {
								var OrerForInsp = oModelRuningOrder.getData().Rowsets.Rowset[0].Row[0];
								var orderCount = oModelRuningOrder.getData().Rowsets.Rowset[0].Row.length;

								that.getView().byId("id_txt_ordstrip").setValue(OrerForInsp.MODORDERID);
								var runningorder = OrerForInsp.ORDERID;
								this.CheckOrder(runningorder)
							}

						},
						CheckOrder : function() {
							var insporder = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_ord");

							if (runningorder != "" && runningorder != "---") {
								if (runningorder != insporder) {
									if (!isPrevQualInspView) {

										MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0122"));
									}
								}
							}

						},
						setInitialLoadData : function() {
							var that = this;
							// Layout1
							  var CA_ResrText = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/js_resrtxt");
            						that.getView().byId("txt_ResourceText").setValue(CA_ResrText);
							var qs_matstrip = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_matstrip")
							that.getView().byId("id_txt_matstrip").setValue(qs_matstrip);
							var qs_matdesc = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_matdesc")
							that.getView().byId("id_txt_desc").setValue(qs_matdesc);
							var qs_ordstrip = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_ordstrip")
							that.getView().byId("id_txt_ordstrip").setValue(qs_ordstrip);
							var qs_phstxt = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phstxt")
							that.getView().byId("id_txt_phstxt").setValue(qs_phstxt);
							var qs_ccpsign = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_ccpsign")
							that.getView().byId("id_txt_ccpsign").setValue(qs_ccpsign);
							// Layout 2

							var qs_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot")
							that.getView().byId("id_txt_inslot").setValue(qs_insplot);
							var qs_date = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_date")
							that.getView().byId("id_txt_insdate").setValue(qs_date);
							var qs_time = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_time")
							that.getView().byId("id_txt_instime").setValue(qs_time);

							currenttime = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_currenttime")
						},
						getInspCharac : function() {
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty(false, "/GridAreaTW");
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty(false, "/GridAreaAR");
							var RecordedChar = 0;

							// getOrder Details count
							var qs_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot")
							var qs_phs = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs")
							var qs_currenttime = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_currenttime")

							var oModel = models
							.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->getInspCharac-->XACQ_GetInspCharac");

							var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + qs_insplot + "&Param.4=" + qs_phs
							+ "&Param.5=" + qs_currenttime;
							oModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetInspCharac&" + params
									+ "&Content-Type=text/json", "", false);

							if (oModel.getData().Rowsets.Rowset[0].Row != undefined) {
								sap.ui.getCore().setModel(oModel, "CharList");
								var CharList = oModel.getData().Rowsets.Rowset[0].Row;
								var rowcount = oModel.getData().Rowsets.Rowset[0].Row.length;
								for (var i = 0; i < rowcount; i++) {
									if (CharList[i].STATUS == "2") {
										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", false);
										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Result_Manual", false);
										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", false);
										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update", false);
										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_ViewHACCP", false);
									}
									if (CharList[i].STATUS == "1") {
										RecordedChar = RecordedChar + 1;
									}
								}

								if (RecordedChar == rowcount) {
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Result_Manual", false);
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", false);
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_ViewHACCP", false);
									// commented by Praveen
									// sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update",
									// true);
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", true);

								}

							}

						},
						getResults : function() {
							// Clear Input BG
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/Quan_QualRemark", "");

							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							var that = this;
							that.getView().byId("id_txt_qual_remark").setValue("");

							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var qnotno = ClSelectedRow.QNOTIF;

								var count = ClSelectedRow.INSPREQ;
								var type = ClSelectedRow.CHARTYPE;
								var codegrp = ClSelectedRow.SEL_SET1;
								var status = ClSelectedRow.STATUS;
								var InspChar = ClSelectedRow.INSPCHAR;
								var restype = ClSelectedRow.RESULTTYPE;
								var chardesc = ClSelectedRow.CHARDESC;
								var lowlmt = parseFloat(ClSelectedRow.LW_TOL_LMT);
								var uplmt = parseFloat(ClSelectedRow.UP_TOL_LMT);
								var rtrweight = ClSelectedRow.RTRWEIGHT;
								// alert(rtrweight);

								// GCHHATRI - START OF CHANGE
								var evaluation = ClSelectedRow.EVAL;
								var methodtxt = ClSelectedRow.METHODTXT;
								sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridAreaTW", false);
								sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridAreaAR", false);
								sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_TW_Check", false);

								// getOrder Details count
								var qs_matstrip = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_matstrip")

								var oModel = models
								.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->getResults-->XACQ_TWCheck");

								var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + qs_matstrip + "&Param.4=" + chardesc;
								oModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_TWCheck&" + params
										+ "&Content-Type=text/json", "", false);

								if (oModel.getData().Rowsets.Rowset[0].Row != undefined) {
									var tareWeightCheck = oModel.getData().Rowsets.Rowset[0].Row[0];
									var tareWeightCheckLen = oModel.getData().Rowsets.Rowset[0].Row.length;
									if (tareWeightCheckLen > 0) {

										TareWeightID = tareWeightCheck.TareWeightID;
										var TareWeightDesc = tareWeightCheck.TareWeightDesc;
										var Life = tareWeightCheck.Life;
										var Unit = tareWeightCheck.Unit;
										var Method = tareWeightCheck.Method;
										var SampleSize = tareWeightCheck.SampleSize;
										var UpperPausibleLimit = tareWeightCheck.UpperPausibleLimit;
										var LowerPausibleLimit = tareWeightCheck.LowerPausibleLimit;
										var PausibleUnit = tareWeightCheck.PausibleUnit;
										var ExpiryStatus = tareWeightCheck.ExpiryStatus;
										var TW_LastRecdValue = tareWeightCheck.TW_LastRecdValue;

										var material_noleadingzero = this.trimNumber(qs_matstrip);

										// RANGA - START OF CHANGE - Average Result Display

										if (status == "2" || status == "1") {
											if (count > 1 && restype == "SINGLE" && type == "QUAN") {

												var qs_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot")
												var qs_phs = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs")
												var qs_currenttime = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_currenttime")

												var oAvgResultModel = models
												.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->getResults-->SQLQ_GetInspPointAvgResult");

												var params = "Param.1=" + qs_insplot + "&Param.2=" + qs_phs + "&Param.3=" + InspChar + "&Param.4="
												+ qs_currenttime;
												oAvgResultModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
														+ "/QueryTemplate/SQLQ_GetInspPointAvgResult&" + params + "&Content-Type=text/json", "", false);

												if (oAvgResultModel.getData().Rowsets.Rowset[0].Row != undefined) {
													var oAvgResultList = oAvgResultModel.getData().Rowsets.Rowset[0].Row;

													var oAvgResultListLen = oAvgResultModel.getData().Rowsets.Rowset[0].Row.length;

													if (oAvgResultListLen != 0) {
														var avgresult = oAvgResultList[0].AVG;// oAvgResultList[0]['AVG(HNZ_INSPPOINT.RESULT)']
														// alert(avgresult);
														sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridAreaAR", true);
														that.getView().byId("id_txt_AvgResult").setValue(avgresult);

														if (avgresult >= lowlmt && avgresult <= uplmt) {
															// document.getElementById("id_txt_AvgResult").style.backgroundColor
															// = '#00FF00';
															this.getView().byId("id_txt_AvgResult").removeStyleClass("InspectionAvgResultRejected")
														} else if (avgresult < lowlmt) {
															// document.getElementById("id_txt_AvgResult").style.backgroundColor
															// = '#FF0000';
															this.getView().byId("id_txt_AvgResult").addStyleClass("InspectionAvgResultRejected")
														} else if (avgresult > uplmt) {
															// document.getElementById("id_txt_AvgResult").style.backgroundColor
															// = '#FF0000';
															this.getView().byId("id_txt_AvgResult").addStyleClass("InspectionAvgResultRejected")
														}

													}
												}

											}
										}
										// RANGA - START OF CHANGE - Average Result Display
										var uiCore = sap.ui.getCore().getModel("i18n");

										if (ExpiryStatus == "Please link Material with Tare Weight") {
											var material_noleadingzero = that.trimNumber(qs_matstrip);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_TW_Check", true);
											var errorMsg = uiCore.getProperty("HUB_MSG_0047") + " " + material_noleadingzero + " "
											+ uiCore.getProperty("HUB_MSG_0180") + " " + TareWeightID + " " + uiCore.getProperty("HUB_MSG_0181")
											MessageBox.error(errorMsg);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", false);
											var status = 2;
										}

										if (ExpiryStatus == "Tare Wt exist for MIC but never recorded") {
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_TW_Check", true);
											var errorMsg = uiCore.getProperty("HUB_MSG_0182") + " " + chardesc + " "
											+ uiCore.getProperty("HUB_MSG_0183")
											MessageBox.error(errorMsg);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", false);
											var status = 2;
										}

										if (ExpiryStatus == "Tare Wt Result got Expired for MIC") {
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_TW_Check", true);
											var errorMsg = uiCore.getProperty("HUB_MSG_0184") + " " + chardesc + " "
											+ uiCore.getProperty("HUB_MSG_0185")
											MessageBox.error(errorMsg);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", false);
											var status = 2;
										}
										if (TareWeightID != "" && TareWeightID != "---" && ExpiryStatus == "Tare Wt is active for MIC") {
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridAreaTW", true);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_TW_Check", true);
											if (isPrevQualInspView)
												that.getView().byId("id_txt_TareWt").setValue(TW_LastRecdValue);

										} else {
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridAreaTW", false);
											that.getView().byId("id_txt_TareWt").setValue("0");
										}

										if (status == "0" && type == "QUAN") {
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridAreaRS", true);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1", false);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea", true);
											if (!isPrevQualInspView)
												that.getView().byId("id_txt_TareWt").setValue(TW_LastRecdValue);

											if (restype == "SINGLE") {
												//
												// this.getView().byId("gridAreaItems").removeAllItems();

												var result = sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0105");
												this.getView().byId("ResultTxtLabel").setText(result + "   1 - " + count)

												var oresultData = [];
												for (var i = 1; i <= count; i++) {
													var oDynamicData = {
															value : "",
															remarks : "",
															resulteval : "A"

													};
													oresultData.push(oDynamicData);
												}
												var oResultModel = new sap.ui.model.json.JSONModel(oresultData);
												that.getView().setModel(oResultModel, "resultFeild")

												setTimeout(function() {
													that.getView().byId("resultBox").getItems()[0].focus();
												}, 1000);

												// 
												/*
												 * setTimeout(function() {
												 * document.getElementById("id_quan_val_1").focus(); },
												 * 10);
												 */
											} else {
												// this.getView().byId("gridAreaItems").removeAllItems();
												var result = sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0105");
												this.getView().byId("ResultTxtLabel").setText(result)
												var oresultData = [];
												var oDynamicData = {
														value : "",
														remarks : "",
														resulteval : "A"
												};
												oresultData.push(oDynamicData);
												var oResultModel = new sap.ui.model.json.JSONModel(oresultData);
												that.getView().setModel(oResultModel, "resultFeild")

												setTimeout(function() {
													that.getView().byId("resultBox").getItems()[0].focus();
												}, 1000);
												//
												/*
												 * setTimeout(function() {
												 * document.getElementById("id_quan_val_1").focus(); },
												 * 10);
												 */
											}
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update", false);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", true);
										} else if (status == "0" && type == "QUAL") {
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridAreaRS", true);
											that.getSelectedSet();
											// document.getElementById("GridArea").innerHTML =
											// "";
											// this.getView().byId("gridAreaItems").removeAllItems();
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea", false);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1", true);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update", false);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", true);

											if (!isPrevQualInspView)
												that.getView().byId("id_txt_TareWt").setValue("0");
											that.selectPass();
										} else if (status == "1" && type == "QUAN") {
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1", false);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea", true);

											var result = sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0105");
											this.getView().byId("ResultTxtLabel").setText(result)
											var oresultData = [];
											// Muthu - set resulteval based on ClSelectedRow
											var oDynamicData = {
													value : ClSelectedRow.RESULT,
													remarks : ClSelectedRow.REMARK,
													resulteval : "A"
											};
											oresultData.push(oDynamicData);
											var oResultModel = new sap.ui.model.json.JSONModel(oresultData);
											that.getView().setModel(oResultModel, "resultFeild")

											setTimeout(function() {
												that.getView().byId("resultBox").getItems()[0].focus();
											}, 1000);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update", true);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", false);
											if (!isPrevQualInspView)
												that.getView().byId("id_txt_TareWt").setValue(TW_LastRecdValue);
										} else if (status == "1" && type == "QUAL") {
											that.getSelectedSet();
											// document.getElementById("GridArea").innerHTML =
											// "";
											// this.getView().byId("gridAreaItems").removeAllItems();
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea", false);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1", true);

											that.setSelectedSet();
											that.getView().byId("id_txt_qual_remark").setValue(ClSelectedRow.REMARK);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Save", false);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update", true);
											if (!isPrevQualInspView)
												that.getView().byId("id_txt_TareWt").setValue("0");
										} else {

											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1", false);
											// document.getElementById("GridArea").innerHTML =
											// "";
											// this.getView().byId("gridAreaItems").removeAllItems();
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea", false);
											if (!isPrevQualInspView)
												that.getView().byId("id_txt_TareWt").setValue(rtrweight);

										}

										// GCHHATRI - START OF CHANGE
										if (methodtxt.substring(0, 3) == "CCP" && evaluation == "Rejected")
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_ViewHACCP", true);
										else
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_ViewHACCP", false);
										// GCHHATRI - END OF CHANGE

									}

								}

							}

						},

						trimNumber : function(s) {
							while (s.substring(0, 1) == '0' && s.length > 1) {
								s = s.substring(1, 9999);
							}
							return s;
						},

						getTodayDate : function() {
							var that = this;
							var phase = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");

							if (phase != "") {
								var currenttime = new Date();
								var currentDT = CommonUtility.getCurrentDateTime(new Date());
								var currentDate = currentDT.split(" ");
								currentDate = currentDT;
								var resr = resource;
								var inslot = that.getView().byId("id_txt_inslot").getValue();

								var oModel = models
								.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->getTodayDate-->SQLQ_InsInspectPoint");

								var params = "Param.2=" + "NA" + "&Param.3=" + inslot + "&Param.4=" + phase + "&Param.6=" + currentDT
								+ "&Param.10=" + "0" + "&Param.11=" + plant + "&Param.12=" + resr + "&Param.13=" + "0";
								oModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsInspectPoint&"
										+ params + "&Content-Type=text/json", "", false);

								that.NewInspDatetime(currentDT);

							} else {
								MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0205"));
							}

						},
						NewInspDatetime : function(currentDT) {
							var that = this;
							var splitdatetime = currentDT.split(" ");
							that.getView().byId("id_txt_insdate").setValue(splitdatetime[0]);
							that.getView().byId("id_txt_instime").setValue(splitdatetime[1]);
							currenttime = currentDT;
							sap.ui.getCore().getModel("IncResSubmitModel").setProperty("/qs_currenttime", currenttime)
							if (!isPrevQualInspView)
								sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", true);
							that.getInspCharac();
							sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
						},
						ManualGoBack : function() {
							fromManualmenu = true;
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/ManualScreen", false)
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/InspectionScreen", true)
							sap.ui.getCore().getModel("session").setProperty("/Parent_Page", true)
							this.getView().byId("id_txt_qual_remark").setValue("");
							this.getInspCharac();
							this.getResults();
						},
						OpenManualResult : function() {
							//
							//
							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;

							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var charDesc = ClSelectedRow.CHARDESC;
								this.getView().byId("id_txt_char").setValue(charDesc);

								var methodTxt = ClSelectedRow.METHODTXT;
								this.getView().byId("id_txt_method").setValue(methodTxt);

								var lowLmt = ClSelectedRow.LW_TOL_LMT;
								this.getView().byId("id_txt_lowlim").setValue(lowLmt);

								var uprLmt = ClSelectedRow.UP_TOL_LMT;
								this.getView().byId("id_txt_uplim").setValue(uprLmt);

								var uom = ClSelectedRow.UOM;
								this.getView().byId("id_txt_uom").setValue(uom);

								var phase = ClSelectedRow.Phase;

								if (ClSelectedRow.STATUS == '0') {

									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/ManualScreen", true)
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/InspectionScreen", false)


								} else {
									MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0205"));
								}

							} else {
								MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0205"));
							}

						},
						ShowSPCChart : function() {
							var LotNo = this.getView().byId("id_txt_inslot").getValue();
							var Phase = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
							// var Url = 'SPCChartDashboard.irpt?qs_phs=' + Phase;
							UI_utilities.setContainerBusyState(this, true);
							this._oRouter.navTo("SPCChartDashboard");

							// setMenu(document.APLT_MenuSetting, "id_td_spc"),
							// window.location.href =
							// '../IRPT/SPCChartDashboard.irpt?qs_phs=' + Phase;

						},
						ViewHACCP : function() {

							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;

							var resr = resource;
							if (SelRow != 0) {
								// clear Model
								if (sap.ui.getCore().getModel("oViewHACCPParam") != null)
									sap.ui.getCore().getModel("oViewHACCPParam").setData("")

									var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
								var js_matdesc = this.getView().byId("id_txt_desc").getValue();
								var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();
								var js_phstxt = this.getView().byId("id_txt_phstxt").getValue();
								var js_ccpsign = this.getView().byId("id_txt_ccpsign").getValue();
								var js_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot");

								var js_currenttime = currenttime;
								var inspCharDesc = ClSelectedRow.CHARDESC;
								var uplmt1 = ClSelectedRow.UP_TOL_LMT;
								var lowlmt1 = ClSelectedRow.LW_TOL_LMT;
								var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
								var inspChar = ClSelectedRow.INSPCHAR;
								var inspcount = ClSelectedRow.INSPCOUNT;
								var lowlmt = "0";
								var uplmt = "10";
								var result = "4";
								var resulteval = "R";
								var resulttxt = "Rejected";
		var resourceTxt = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/js_resrtxt");

								var oViewHaccpModel = new sap.ui.model.json.JSONModel();
								let sID = {
										qs_matstrip : js_matstrip,
										qs_matdesc : js_matdesc,
										qs_ordstrip : js_ordstrip,
										qs_phstxt : js_phstxt,
										qs_ccpsign : js_ccpsign,
										qs_insplot : js_insplot,
										qs_currenttime : js_currenttime,
										qs_char : inspCharDesc,
										qs_lower : lowlmt,
										qs_upper : uplmt,
										qs_result : result,
										qs_eval : resulteval,
										qs_restxt : resulttxt,
										qs_phs : inspOper,
										qs_inspChar : inspChar,
										qs_inspcount : inspcount,
										js_resr : resource,
										js_resrtxt:resourceTxt
								}

								oViewHaccpModel.setData(sID)
								sap.ui.getCore().setModel(oViewHaccpModel, "oViewHACCPParam")

								this._oRouter.navTo("InspectResultHACCP");

							}

							/*
							 * window.location.href =
							 * "/XMII/CM/NL_ELS_HUB/IRPT/InspectResultHACCPSubmitV1.irpt?qs_matstrip=" +
							 * js_matstrip + "&qs_matdesc=" + js_matdesc + "&qs_ordstrip=" +
							 * js_ordstrip + "&qs_phstxt=" + js_phstxt + "&qs_ccpsign=" +
							 * js_ccpsign + "&qs_insplot=" + js_insplot + "&qs_currenttime=" +
							 * js_currenttime + "&qs_char=" + inspCharDesc + "&qs_lower=" +
							 * lowlmt + "&qs_upper=" + uplmt + "&qs_result=" + result +
							 * "&qs_eval=" + resulteval + "&qs_restxt=" + resulttxt +
							 * "&qs_phs=" + inspOper + "&qs_inspChar=" + inspChar +
							 * "&qs_inspcount=" + inspcount; // &qs_restxt="+resulttxt+" Added
							 * by gchhatri
							 */

						},
						setSelectedSet : function() {

							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var selcode = ClSelectedRow.RESULT;

								if (this.getView().getModel("SelectedSet").getData() != null)
									var selectSetmodel = this.getView().getModel("SelectedSet").getData().Rowsets.Rowset[0].Row
									for (var i = 0; i < selectSetmodel.length; i++) {
										var code = selectSetmodel[i]["CODE"]
										if (code == selcode) {
											this.getView().byId("APLT_GRI_SelectedSet").setSelectedItem(
													this.getView().byId("APLT_GRI_SelectedSet").getItems()[i])
													this.getTxtFocus();
											break;
										}
									}
							}
						},
						getSelectedSet : function() {
							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;

							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var codegrp = ClSelectedRow.SEL_SET1;
								var cattype = ClSelectedRow.CATTYPE;

								var pselset = ClSelectedRow.PSELSET1;

								// getOrder Details count

								var SelectedSetModel = models
								.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->getSelectedSet-->SQLQ_GetSelectedSet");

								var params = "Param.1=" + cattype + "&Param.2=" + pselset + "&Param.3=" + codegrp;
								SelectedSetModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
										+ "/QueryTemplate/SQLQ_GetSelectedSet&" + params + "&Content-Type=text/json", "", false);
								sap.ui.getCore().setModel(SelectedSetModel, "SelectedSet");

							}

						},
						selectPass : function() {

							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var status = ClSelectedRow.STATUS;

								if (status == "0") {
									if (this.getView().getModel("SelectedSet").getData() != null)
										var selectSetmodel = this.getView().getModel("SelectedSet").getData().Rowsets.Rowset[0].Row
										for (var i = 0; i < selectSetmodel.length; i++) {
											var valuation = selectSetmodel[i]["VALUATION"]
											if (valuation == "A") {
												this.getView().byId("APLT_GRI_SelectedSet").setSelectedItem(
														this.getView().byId("APLT_GRI_SelectedSet").getItems()[i]);
												this.getTxtFocus();
												break;
											}
										}
								}
							}
						},

						sendMail : function(plant, planttxt, resr, resrtxt, js_mat, js_matdesc, uname, inspLot, inspPoint, inspCharDesc,
								lowaccplmt1, lowlmt1, upaccplmt1, uplmt1, result4, js_ord) {

							// sendMail

							var oSendMailOrder = models
							.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->selectPass-->XACQ_SendMailHACCP");

							var params = "Param.1=" + plant + "&Param.2=" + planttxt + "&Param.3=" + resr + "&Param.4=" + resrtxt + "&Param.5="
							+ js_mat + "&Param.6=" + js_matdesc + "&Param.7=" + uname + "&Param.8=" + inspLot + "&Param.9=" + inspPoint
							+ "&Param.10=" + inspCharDesc + "&Param.11=" + lowaccplmt1 + "&Param.12=" + lowlmt1 + "&Param.13=" + upaccplmt1
							+ "&Param.14=" + uplmt1 + "&Param.15=" + result4 + "&Param.16=" + js_ord;
							oSendMailOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_SendMailHACCP&"
									+ params + "&Content-Type=text/json", "", false);

						},
						closePopUp : function() {
							alert("Close popup is selected")
						},
						SaveInspResultData : function() {

							var resr = resource;

							var charreject = 0;
							var charblank = 0;
							var characcept = 0;
							var corract = 0;
							var pointEval = "";

							// var SelRow =
							// this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							var rowcount = CommonUtility.getJsonModelRowCount(this.getView().getModel("CharList").getData());
							if (rowcount != 0) {

								// var ClSelRow =
								// this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];

								// var status = ClSelectedRow.STATUS;
								var aRows = this.getView().getModel("CharList").getProperty("/Rowsets/Rowset/0/Row")

								for (var i = 0; i < rowcount; i++) {

									var ClSelectedRow = aRows[i];

									var evalstatus = ClSelectedRow.EVAL;
									if (evalstatus == "Rejected") {
										charreject = charreject + 1;
									} else if (evalstatus == "" || evalstatus == "---") {
										charblank = charblank + 1;
									} else if (evalstatus == "Accepted") {
										characcept = characcept + 1;
									}
									var signstatus = ClSelectedRow.SIGNSTATUS;
									if (signstatus == "0") {
										corract = corract + 1;
									}
								}
								if (characcept == rowcount) {
									pointEval = "A";
								} else if (charreject == rowcount) {
									pointEval = "R";
								} else {

								}

								if (charblank == rowcount) {
									var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0067");
									sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
									sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
									sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

									/* MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0067")); */
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", true);
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);

									/* document.getElementById("id_msg_delayLoad").style.display='none'; */
								} else if (corract > 0) {
									var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0164");
									sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
									sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
									sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", true);
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);

									/*
									 * MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0117"));
									 * document.getElementById("id_msg_delayLoad").style.display='none';
									 */
								} else {
									// goes here

									/* MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0117")); */

									/*
									 * var sNoShiftMsg =
									 * sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0117");
									 * sap.ui.getCore().getModel("oMessage").setProperty("/message",
									 * sNoShiftMsg);
									 * sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",
									 * true);
									 * sap.ui.getCore().getModel("oMessage").setProperty("/type",
									 * "Error");
									 */

									var inspLot = this.getView().byId("id_txt_inslot").getValue();
									var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
									var inspTime = currenttime;

									// new ccheck command
									var ccpsign = this.getView().byId("id_txt_ccpsign").getValue();

									xmiiCommand = new com.sap.xmii.chart.hchart.i5Command("NL_ELS_HUB/QueryTemplate/SQLQ_GetPlant", projectName
											+ "/DisplayTemplate/CMD_VerifyDigitalSignature");
									if (ccpsign.indexOf("CCP") == "0")
										xmiiCommand.setCommandAudit(true)
										else
											xmiiCommand.setCommandAudit(false)

											if (ccpsign == "CCP2") {
												var role = sap.ui.getCore().getModel("session").getProperty("/HACCPSign2Role");
												xmiiCommand.getCommandObject().setCommandRole2(role)
											}

									if (xmiiCommand.getCommandAudit()) {

										xmiiCommand.executeCommand();
										xmiiCommand.registerCommandCompletionEventHandler(this.saveInspPointStatus);

									}

									else {

										this.saveInspPointStatus();
									}

									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_ViewSPC", true);
									sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);
									/* MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0117")); */

								}

							}
						},
						saveInspPointStatus : function() {

							var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0117");
							sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
							sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
							sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

							// 31.03.23
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Result_Manual", false);
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", false);
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_ViewSPC", false);
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_ViewSPC", false);
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", false);

							var inspLot = that.getView().byId("id_txt_inslot").getValue();
							var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
							var inspTime = currenttime;
							var ccpsign = that.getView().byId("id_txt_ccpsign").getValue();

							var currentDT = CommonUtility.getCurrentDateTime(new Date()).replace(" ", "T");

							// APLT_CMD_SaveInspPoint

							var oSaveInspPointData = models
							.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->saveInspPointStatus-->XACQ_CreateInspPointHACCP");

							var params = "Param.1=" + inspLot + "&Param.2=" + inspOper + "&Param.3=" + inspTime + "&Param.4=" + plant
							+ "&Param.5=" + resource + "&Param.6=" + userName + "&Param.7=" + ccpsign + "&Param.8=" + currentDT
							+ "&Param.9=" + xmiiCommand.commandUserID1 + "&Param.10=" + xmiiCommand.commandUserID2;
							// Changed Path : /QueryTemplate/XACQ_CreateInspPointHACCP
							oSaveInspPointData.loadData("/XMII/Illuminator?QueryTemplate=RepHubUI5/Query/XACQ_CreateInspPointHACCP&" + params
									+ "&Content-Type=text/json", "", false);

							if (oSaveInspPointData.getData().Rowsets.Rowset != null) {
								var rowCount = oSaveInspPointData.getData().Rowsets.Rowset[0].Row.length;
								if (rowCount != 0) {
									var oSaveInspModel = oSaveInspPointData.getData().Rowsets.Rowset[0].Row;
									var type = oSaveInspModel[0].Type;

									if (rowCount != 0) {
										if (type == "S") {
											that.getInspCharac();
											var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0052")
											sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
											sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
											sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);
										} else if (type == "B") {
											that.getInspCharac();
											var sNoShiftMsg = "Created Successfully. Buffered as network is down.Will Update SAP Automatically"
												sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
											sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
											sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);
										} else if (type == "L") {
											var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0053")
											sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
											sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
											sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", true);

											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);
										} else {

											var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0097")
											sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
											sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
											sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", true);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Result_Manual", true);
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);
										}
									} else {
										var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0097")
										sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
										sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
										sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Submit", true);
										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Result_Manual", true);
										sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Back", true);

									}
								}
							}
						},
						GoBack : function() {
							var js_phs = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
							sap.ui.getCore().getModel("InspectionPointRoute").setProperty("/qs_phs", js_phs)
							var qs_currenttime = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_currenttime");
							sap.ui.getCore().getModel("InspectionPointRoute").setProperty("/qs_currenttime", qs_currenttime)
							sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty("/Parent_Page", true)
							if (isPrevQualInspView) {
								this._oRouter.navTo("InspectPointView");
							} else {
								this._oRouter.navTo("InspectionPoint");
								/*
								 * window.location.href =
								 * "InspectionPointNewV3HACCP.irpt?qs_phs="+js_phs;
								 */
							}
						},
						checkResult : function(event) {

							var enteredId = event.getSource();
							var value = enteredId.getValue();
							var that = this;
							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var lowlmt = parseFloat(ClSelectedRow.LW_TOL_LMT);
								var uplmt = parseFloat(ClSelectedRow.UP_TOL_LMT);
								var ResultType = ClSelectedRow.CHARTYPE;
								var TrWt1 = that.getView().byId("id_txt_TareWt").getValue();
								var resulteval;

								if (ResultType == "QUAN") {
									if (parseFloat(TrWt1) < parseFloat(value))
										value = parseFloat(value) - parseFloat(TrWt1);
									else
										value = parseFloat(value);

									if (isNaN(lowlmt) || isNaN(uplmt)) {
										if (isNaN(lowlmt) && isNaN(uplmt)) {
											resulteval = "A";
										} else if (isNaN(uplmt) && value >= lowlmt) {
											resulteval = "A";
										} else if (isNaN(lowlmt) && value <= uplmt) {
											resulteval = "A";
										} else {
											resulteval = "R";
										}
									} else {
										if (value >= lowlmt && value <= uplmt) {
											resulteval = "A";
										} else if (value < lowlmt) {
											resulteval = "R";
										} else if (value > uplmt) {
											resulteval = "R";
										}
									}
									var SPath = enteredId.oBindingContexts.resultFeild.sPath + "/resulteval";

									if (resulteval == "R") {

										this.getView().getModel("resultFeild").setProperty(SPath, "R");
									} else {
										this.getView().getModel("resultFeild").setProperty(SPath, "A");
									}
								}
							}

						},
						readWtscale : function() {
							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							var that = this;

							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var lowerpl = ClSelectedRow.LW_TOL_LMT;
								var upperpl = ClSelectedRow.UP_TOL_LMT;
								var unit = ClSelectedRow.UOM;
								var scale = sap.ui.getCore().getModel("session").getProperty("/CA_ScaleName");
								var samplesize = ClSelectedRow.INSPREQ;

								// APLT_CMD_ReadWeight

								var oReadWeight = models
								.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->readWtscale-->XACQ_ReadTareWeight");

								var params = "Param.1=" + scale + "&Param.2=" + lowerpl + "&Param.3=" + upperpl + "&Param.5=" + plant;
								oReadWeight.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_ReadTareWeight&"
										+ params + "&Content-Type=text/json", "", false);

								if (oReadWeight.getData().Rowsets != null) {
									var readWightModel = oReadWeight.getData().Rowsets.Rowset[0].Row;

									if (isNaN(readWightModel.O_Weight) || readWightModel.O_Weight == 0) {

										MessageBox.error("Read scale again");

										/* document.getElementById(currentfocus_textid).focus(); */

									} else {

										/*
										 * document.getElementById(currentfocus_textid).value =
										 * readWightModel.O_Weight;
										 */

										var nextresultentry = parseInt(currentfocus_textid.substring(currentfocus_textid.length,
												currentfocus_textid.length - 1)) + 1;

										if (nextresultentry <= samplesize) {
											currentfocus_textid = "id_quan_val_" + nextresultentry;

											/* document.getElementById(currentfocus_textid).focus(); */
										}

									}

								}
							}

						},
						updateTWExpiry : function() {

							if (TareWeightID != "" && TareWeightID != "---") {

								var oTareWtModel = new sap.ui.model.json.JSONModel();
								let sID = {
										qs_TareWeightID : TareWeightID

								}
								oTareWtModel.setData(sID)
								sap.ui.getCore().setModel(oTareWtModel, "oTareWtParam")

								this._oRouter.navTo("RepTareWtcheck_1");
								if (!isPrevQualInspView) {

									setTimeout(function() {
										that.getView().byId("resultBox").getItems()[0].focus();
									}, 1000);
								}

								/*
								 * window.location.href =
								 * "RepTareWtcheck_1.irpt?qs_TareWeightID=" + TareWeightID +
								 * "&qs_TareWeightDesc=" + TareWeightDesc + "&qs_Life=" + Life +
								 * "&qs_Unit=" + Unit + "&qs_Method=" + Method +
								 * "&qs_SampleSize=" + SampleSize + "&qs_UpperPausibleLimit=" +
								 * UpperPausibleLimit + "&qs_LowerPausibleLimit=" +
								 * LowerPausibleLimit + "&qs_PausibleUnitLife=" + "'" +
								 * PausibleUnit + "'" + "&qs_LastRecordedDate=" +
								 * LastRecordedDate + "&qs_TW_LastRecdValue=" + TW_LastRecdValue +
								 * "&qs_ExpiryDate=" + ExpiryDate;
								 * ajaxFunction("/XMII/Runner?Transaction=NL_ELS_HUB/BLS/BLS_GenerateInspResHTMLV3&I_Count=SampleSize&OutputParameter=O_Return&Content-Type=text/html",
								 * "GridArea")
								 * 
								 */
							} else {
								var txt_mat = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_matstrip");
								var material_noleadingzero = trimNumber(txt_mat);
								var errMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0170") + material_noleadingzero
								+ sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0171")
								MessageBox.error(errMsg);
							}
						},
						getTxtFocus : function() {
							var that = this;

							setTimeout(function() {
								that.getView().byId("id_txt_qual_remark").focus()
							}, 1000);
						},
						updateResults : function() {
							var validationFlag = 0;
							var getFlag = 1;
							var ccpFlag = "0";
							var l_ccpFlag;
							var TrWt1="";
							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var resr = resource;
								var ResultType = ClSelectedRow.CHARTYPE;
								var restype = ClSelectedRow.RESULTTYPE;
								var inspcount = ClSelectedRow.INSPCOUNT;
								// For HACCP Page Param
								var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
								var js_matdesc = this.getView().byId("id_txt_desc").getValue();
								var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();
								var js_phstxt = this.getView().byId("id_txt_phstxt").getValue();
								var js_ccpsign = this.getView().byId("id_txt_ccpsign").getValue();
								var js_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot");

								var js_currenttime = currenttime;
								var inspCharDesc = ClSelectedRow.CHARDESC;
								var uplmt1 = ClSelectedRow.UP_TOL_LMT;
								var lowlmt1 = ClSelectedRow.LW_TOL_LMT;
								var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
								var inspChar = ClSelectedRow.INSPCHAR;
								var inspcount = ClSelectedRow.INSPCOUNT;
								var lowlmt = "0";
								var uplmt = "10";
								var result = "4";
								var resulteval = "R";
								var resulttxt = "Rejected";
								// For HACCP Page Param
								if (ResultType == "QUAN") {
									var itemcount = 1;
									for (var i = 0; i < itemcount; i++) {
										//

										var inspChar = ClSelectedRow.INSPCHAR;

										var uplmt1 = ClSelectedRow.UP_TOL_LMT;

										var lowlmt1 = ClSelectedRow.LW_TOL_LMT;

										var upaccplmt1 = ClSelectedRow.UP_LMT_1;

										var lowaccplmt1 = ClSelectedRow.LW_LMT_1;

										var inspLot = this.getView().byId("id_txt_inslot").getValue();
										var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
										var inspPoint = "";
										var inspTime = currenttime;

										var insResultFeildModel = this.getView().getModel("resultFeild").getData()[i];

										var remark = insResultFeildModel.remarks;
										var result1 = insResultFeildModel.value;

										var TrWt1 = this.getView().byId("id_txt_TareWt").getValue();

										result1 = result1.split(" ").join("");

										if (result1 != "") {
											if (!isNaN(result1)) {
												var res = result1.split(",");
												if (res.length > 1) {
													var result4 = res[0] + "." + res[1];
												} else {
													var result4 = result1;
												}

												var upl = uplmt1.split(",");
												if (upl.length > 1) {
													var uplmt4 = upl[0] + "." + upl[1];
												} else {
													var uplmt4 = uplmt1;
												}

												var lwl = lowlmt1.split(",");
												if (lwl.length > 1) {
													var lowlmt4 = lwl[0] + "." + lwl[1];
												} else {
													var lowlmt4 = lowlmt1;
												}

												if (parseFloat(TrWt1) < parseFloat(result4))
													var result4 = parseFloat(result4) - parseFloat(TrWt1);
												else
													var result4 = parseFloat(result4);

												var result = parseFloat(result4);
												var lowlmt = parseFloat(lowlmt4);
												var uplmt = parseFloat(uplmt4);

												var upper = upaccplmt1.split(",");
												if (upper.length > 1) {
													var upper4 = upper[0] + "." + upper[1];
												} else {
													var upper4 = upaccplmt1;
												}

												var lower = lowaccplmt1.split(",");
												if (lower.length > 1) {
													var lower4 = lower[0] + "." + lower[1];
												} else {
													var lower4 = lowaccplmt1;
												}

												var lowaccp = parseFloat(lower4);
												var upaccp = parseFloat(upper4);

												var resulteval;
												var resulttxt;
												var resultaccp;
												if (isNaN(lowlmt) || isNaN(uplmt)) {
													if (isNaN(lowlmt) && isNaN(uplmt)) {
														resulteval = "A";
														resulttxt = "Accepted";
													} else if (isNaN(uplmt) && result >= lowlmt) {
														resulteval = "A";
														resulttxt = "Accepted";
													} else if (isNaN(lowlmt) && result <= uplmt) {
														resulteval = "A";
														resulttxt = "Accepted";
													} else {
														resulteval = "R";
														resulttxt = "Rejected"; // Added by gchhatri
													}
												} else {
													if (result >= lowlmt && result <= uplmt) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else if (result < lowlmt) {
														resulteval = "R";
														resulttxt = "Rejected"; // Added by gchhatri
													} else if (result > uplmt) {
														resulteval = "R";
														resulttxt = "Rejected"; // Added by gchhatri
													} else {
													}
												}

												/* Added by gchhatri */
												if (result >= lowaccp && result <= upaccp) {
													resultaccp = "A";
												} else if (result < lowaccp) {
													resultaccp = "R";
												} else if (result > upaccp) {
													resultaccp = "R";
												} else {
												}
												/* Added by gchhatri */

												if ((resulteval == "R" && remark == "") || (resulteval == "R" && remark == "---" && !isPrevQualInspView)) {
													MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065"));

													/*
													 * document.getElementById(inspFreetxt_name).style.backgroundColor='#FF6666';
													 * document.getElementById(inspFreetxt_name).focus();
													 */

													validationFlag = 1;
													break;
												} else {

													/* document.getElementById(inspFreetxt_name).style.backgroundColor='#FFFFFF'; */

												}
											} // end of isNAN checks
											else {
												// alert("Please enter a Neumeric Value for
												// result field");
												MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0202"));
												validationFlag = 1;
												break;
											}
										} else {
											// alert("Please fill all result fields");
											MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0203"));
											validationFlag = 1;
											break;
										}

									}
									// for loop end

									if (validationFlag == 0) {
										for (var j = 0; j < itemcount; j++) {

											var inspChar = ClSelectedRow.INSPCHAR;
											var inspCharDesc = ClSelectedRow.CHARDESC;
											var methodText = ClSelectedRow.METHODTXT;

											var js_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot");
											var js_mat = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_mat");
											var js_matdesc = this.getView().byId("id_txt_desc").getValue();
											var js_ord = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_ord");
											var js_phs = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
											var js_date = this.getView().byId("id_txt_insdate").getValue();
											var js_time = this.getView().byId("id_txt_instime").getValue();
											var js_currenttime = currenttime;
											var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
											var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();
											var js_phstxt = this.getView().byId("id_txt_phstxt").getValue();
											var js_ccpsign = this.getView().byId("id_txt_ccpsign").getValue();

											var uplmt1 = ClSelectedRow.UP_TOL_LMT;
											var lowlmt1 = ClSelectedRow.LW_TOL_LMT;
											var upaccplmt1 = ClSelectedRow.UP_LMT_1;
											var lowaccplmt1 = ClSelectedRow.LW_LMT_1;

											var inspLot = this.getView().byId("id_txt_inslot").getValue()
											var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
											var inspPoint = "";
											var inspTime = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_currenttime");

											var insResultFeildModel = this.getView().getModel("resultFeild").getData()[j]
											var remark = insResultFeildModel.remarks;
											var result1 = insResultFeildModel.value;

											var TrWt1 = this.getView().byId("id_txt_TareWt").getValue()

											var res = result1.split(",");
											if (res.length > 1) {
												var result4 = res[0] + "." + res[1];
											} else {
												var result4 = result1;
											}

											var upl = uplmt1.split(",");
											if (upl.length > 1) {
												var uplmt4 = upl[0] + "." + upl[1];
											} else {
												var uplmt4 = uplmt1;
											}

											var lwl = lowlmt1.split(",");
											if (lwl.length > 1) {
												var lowlmt4 = lwl[0] + "." + lwl[1];
											} else {
												var lowlmt4 = lowlmt1;
											}

											if (parseFloat(TrWt1) < parseFloat(result4))
												var result4 = parseFloat(result4) - parseFloat(TrWt1);
											else
												var result4 = parseFloat(result4);
											var result = parseFloat(result4);
											var lowlmt = parseFloat(lowlmt4);
											var uplmt = parseFloat(uplmt4);

											// /* Added by gchhatri
											var upper = upaccplmt1.split(",");
											if (upper.length > 1) {
												var upper4 = upper[0] + "." + upper[1];
											} else {
												var upper4 = upaccplmt1;
											}

											var lower = lowaccplmt1.split(",");
											if (lower.length > 1) {
												var lower4 = lower[0] + "." + lower[1];
											} else {
												var lower4 = lowaccplmt1;
											}

											var lowaccp = parseFloat(lower4);
											var upaccp = parseFloat(upper4);

											var resulteval;
											var resulttxt;
											var resultaccp = "";

											if (isNaN(lowlmt) || isNaN(uplmt)) {
												if (isNaN(lowlmt) && isNaN(uplmt)) {
													resulteval = "A";
													resulttxt = "Accepted"; // Added by gchhatri
												} else if (isNaN(uplmt) && result >= lowlmt) {
													resulteval = "A";
													resulttxt = "Accepted"; // Added by gchhatri
												} else if (isNaN(lowlmt) && result <= uplmt) {
													resulteval = "A";
													resulttxt = "Accepted"; // Added by gchhatri
												} else {
													resulteval = "R";
													resulttxt = "Rejected";
													if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
														ccpFlag = "1";
													}
												}
											} else {
												if (result >= lowlmt && result <= uplmt) {
													resulteval = "A";
													resulttxt = "Accepted";
												} else if (result < lowlmt) {
													resulteval = "R";
													resulttxt = "Rejected";
													if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
														ccpFlag = "1";
													}
												} else if (result > uplmt) {
													resulteval = "R";
													resulttxt = "Rejected";
													if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
														ccpFlag = "1";
													}
												} else {
												}
											}
											/* Added by gchhatri */
											if (result >= lowaccp && result <= upaccp) {
												resultaccp = "A";
											} else if (result < lowaccp) {
												if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
													resultaccp = "R";
												}
											} else if (result > upaccp) {
												if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
													resultaccp = "R";
												}
											} else {
											}

											if (!isPrevQualInspView )
												result4 = parseFloat(result4).toFixed("3");//result4.toFixed(3);

											var TrWt1 = this.getView().byId("id_txt_TareWt").getValue();
											// document.getElementById("id_btn_Update").disabled
											// = false;
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update", true);

											var oUpdInspPointDataModel = models
											.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->updateResults-->SQLQ_UpdInspectPointV1HACCP");

											var params = "Param.1=" + result4.toString() + "&Param.2=" + resulteval + "&Param.3=" + remark
											+ "&Param.4=" + plant + "&Param.5=" + resr + "&Param.6=" + inspLot + "&Param.7=" + inspTime + "&Param.8="
											+ inspChar + "&Param.9=" + inspOper + "&Param.10=" + inspcount + "&Param.12=" + parseFloat(TrWt1);

											if (ccpFlag == "1") {
												params += "&Param.11=" + "0";
											} else {
												params += "&Param.11=" + "";

											}

											oUpdInspPointDataModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
													+ "/QueryTemplate/SQLQ_UpdInspectPointV1HACCP&" + params + "&Content-Type=text/json", "", false);

										}
										// alert(resultaccp);
										/* Added by gchhatri */
										if (resultaccp == "R") {
											var planttxt = sap.ui.getCore().getModel("session").getProperty("/CA_PlantText");
											var resrtxt = sap.ui.getCore().getModel("session").getProperty("/CA_ResrText");

											this.sendMail(plant, planttxt, resr, resrtxt, js_mat, js_matdesc, userName, inspLot, inspPoint,
													inspCharDesc, lowaccplmt1, lowlmt1, upaccplmt1, uplmt1, result4.toString(), js_ord)
										}
										/* Added by gchhatri */

										if (ccpFlag == "1") {

var resourceTxt = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/js_resrtxt");
											var oViewHaccpModel = new sap.ui.model.json.JSONModel();
											let sID = {
													qs_matstrip : js_matstrip,
													qs_matdesc : js_matdesc,
													qs_ordstrip : js_ordstrip,
													qs_phstxt : js_phstxt,
													qs_ccpsign : js_ccpsign,
													qs_insplot : js_insplot,
													qs_currenttime : js_currenttime,
													qs_char : inspCharDesc,
													qs_lower : lowlmt,
													qs_upper : uplmt,
													qs_result : result,
													qs_eval : resulteval,
													qs_restxt : resulttxt,
													qs_phs : inspOper,
													qs_inspChar : inspChar,
													qs_inspcount : inspcount,
													CA_Resource : js_resr,
													CA_ResrText : js_resrtxt,
										js_resr:resource,
										js_resrtxt:resourceTxt
											}
											oViewHaccpModel.setData(sID);
											sap.ui.getCore().setModel(oViewHaccpModel, "oViewHACCPParam");
											this._oRouter.navTo("InspectResultHACCP");
											/*
											 * window.location.href =
											 * "/XMII/CM/NL_ELS_HUB/IRPT/InspectResultHACCPSubmitV1.irpt?qs_matstrip="+js_matstrip+"&qs_matdesc="+js_matdesc+"&qs_ordstrip="+js_ordstrip+
											 * "&qs_phstxt="+js_phstxt+"&qs_ccpsign="+js_ccpsign+"&qs_insplot="+js_insplot+"&qs_currenttime="+js_currenttime+"&qs_char="+inspCharDesc+
											 * "&qs_lower="+lowlmt+"&qs_upper="+uplmt+"&qs_result="+result+"&qs_eval="+resulteval+"&qs_restxt="+resulttxt+"&qs_phs="+inspOper+"&qs_inspChar="+
											 * inspChar+ "&qs_inspcount="+inspcount;
											 */

										} else {

											// document.getElementById("GridArea").innerHTML="";

											this.getInspCharac();
										}
									}

								} else if (ResultType == "QUAL") {
									var SelectedSetRow = this.getView().byId("APLT_GRI_SelectedSet").getSelectedContextPaths().length;

									if (SelectedSetRow != 0) {
										var oSelcSetRow = this.getView().byId("APLT_GRI_SelectedSet").getSelectedContextPaths()[0];
										var oSelcSetRow = this.getView().getModel("SelectedSet").getProperty(oSelcSetRow);

										var itemcount = ClSelectedRow.INSPREQ;
										var inspChar = ClSelectedRow.INSPCHAR;
										var inspCharDesc = ClSelectedRow.CHARDESC;
										var inspLot = this.getView().byId("id_txt_inslot").getValue();
										var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
										var inspPoint = "";
										var inspTime = currenttime;
										var remark = this.getView().byId("id_txt_qual_remark").getValue();
										var result = oSelcSetRow.CODE;
										var Eval = oSelcSetRow.VALUATION;

										// Begin HACCP change
										var methodText = ClSelectedRow.METHODTXT;
										var js_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot");
										var js_mat = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_mat");
										var js_matdesc = this.getView().byId("id_txt_desc").getValue();
										var js_ord = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_ord");
										var js_phs = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
										var js_date = this.getView().byId("id_txt_insdate").getValue();
										var js_time = this.getView().byId("id_txt_instime").getValue();
										var js_currenttime = currenttime;

										var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
										var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();
										var js_phstxt = this.getView().byId("id_txt_phstxt").getValue();
										var js_ccpsign = this.getView().byId("id_txt_ccpsign").getValue();
										// End HACCP Change

										if ((Eval == "R" && remark == "") || (Eval == "R" && remark == "---" && !isPrevQualInspView)) {
											MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065"));
											// Set Input Bg Color
											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/Quan_QualRemark", "R");
										} else {

											// APLT_CMD_UpdInspPointData

											var oUpdInspPointDataModel = models
											.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->updateResults-->SQLQ_UpdInspectPointV1HACCP");

											var params = "Param.1=" + result + "&Param.2=" + Eval + "&Param.3=" + remark + "&Param.4=" + plant
											+ "&Param.5=" + resr + "&Param.6=" + inspLot + "&Param.7=" + inspTime + "&Param.8=" + inspChar
											+ "&Param.9=" + inspOper + "&Param.10=" + inspcount + "&Param.12=" + TrWt1;

											if (methodText.indexOf("CCP") == "0" && Eval == "R" && js_ccpsign.indexOf("CCP") == "0") {
												params += "&Param.11=" + "0";
											} else {
												params += "&Param.11=" + "";

											}

											oUpdInspPointDataModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
													+ "/QueryTemplate/SQLQ_UpdInspectPointV1HACCP&" + params + "&Content-Type=text/json", "", false);

											if (methodText.indexOf("CCP") == "0" && Eval == "R" && js_ccpsign.indexOf("CCP") == "0") {
												if (Eval = "R")
													resulttxt = "Rejected";
												else if (Eval = "A")
													resulttxt = "Accepted";
var resourceTxt = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/js_resrtxt");

												var oViewHaccpModel = new sap.ui.model.json.JSONModel();
												let sID = {
														qs_matstrip : js_matstrip,
														qs_matdesc : js_matdesc,
														qs_ordstrip : js_ordstrip,
														qs_phstxt : js_phstxt,
														qs_ccpsign : js_ccpsign,
														qs_insplot : js_insplot,
														qs_currenttime : js_currenttime,
														qs_char : inspCharDesc,
														qs_lower : lowlmt,
														qs_upper : uplmt,
														qs_result : result,
														qs_eval : resulteval,
														qs_restxt : resulttxt,
														qs_phs : inspOper,
														qs_inspChar : inspChar,
														qs_inspcount : inspcount,
														CA_Resource : js_resr,
														CA_ResrText : js_resrtxt,
										js_resr:resource,
										js_resrtxt:resourceTxt
												}
												oViewHaccpModel.setData(sID);
												sap.ui.getCore().setModel(oViewHaccpModel, "oViewHACCPParam");
												this._oRouter.navTo("InspectResultHACCP");
												/*
												 * window.location.href =
												 * "/XMII/CM/NL_ELS_HUB/IRPT/InspectResultHACCPSubmitV1.irpt?qs_matstrip="+js_matstrip+"&qs_matdesc="+js_matdesc+"&qs_ordstrip="+js_ordstrip+
												 * "&qs_phstxt="+js_phstxt+"&qs_ccpsign="+js_ccpsign+"&qs_insplot="+js_insplot+"&qs_currenttime="+js_currenttime+"&qs_char="+inspCharDesc+
												 * "&qs_lower=NA"+"&qs_upper=NA"+"&qs_result="+result+"&qs_eval="+resulteval+"&qs_restxt="+resulttxt+"&qs_phs="+inspOper+"&qs_inspChar="+
												 * inspChar+ "&qs_inspcount="+inspcount;
												 */
											} else {
												sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1", false);
												this.getView().byId("id_txt_qual_remark").setValue("")
												// document.getElementById("id_btn_Update").disabled
												// = true;
												sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/btn_Update", false);

												this.getInspCharac();
											}

										}
									} else {
										MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0066"));

									}
								}

							} else {
								MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0066"));

							}

						},

						/**
						 * set the first row as selected row
						 */
						setFirstRowSelected : function() {
							var that = this;
							/*
							 * var oResultModel = new sap.ui.model.json.JSONModel();
							 * that.getView().setModel(oResultModel, "resultFeild")
							 * sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea",false);
							 * sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1",false);
							 */

							// if(!fromManualmenu){
							var charTable = this.getView().byId("APLT_GRI_CharList");
							if (charTable.getItems().length > 0) {
								charTable.setSelectedItem(charTable.getItems()[0]);
								this.getResults();
							}
							// }
							fromManualmenu = false;
						},

						AutoInsertResult : function(type) {
							var isManual = sap.ui.getCore().getModel("InspectionSubmitResult").getProperty("/ManualScreen");
							var InsertType = "";

							this.InsceptionInspect(isManual);
						},
						ManualInsertResult : function(type) {
							var isManual = sap.ui.getCore().getModel("InspectionSubmitResult").getProperty("/ManualScreen");
							var InsertType = "";

							this.InsceptionInspect(isManual);
						},
						checkDecimalPoint : function(value) {
							var result;
							var res = value;
							if (res.length > 1) {
								result = res[0] + "." + res[1];
							} else {
								result = value[0];
							}
							return result;
						},
						InsceptionInspect : function(isManualType) {

							var validationFlag = 0;
							var getFlag = 1;
							var TrWt1="";
							if (isManualType) {
								// var getFlag =
								// document.getElementById("id_hid_flag").value;
								// //qs_flag
							}
							var ccpFlag = 0;
							var l_ccpFlag;

							// document.getElementById("id_txt_qual_remark").style.backgroundColor='#FFFFFF';
							sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/Quan_QualRemark", "");

							var SelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths().length;
							if (SelRow != 0) {
								var ClSelRow = this.getView().byId("APLT_GRI_CharList").getSelectedContextPaths()[0];
								var ClSelectedRow = this.getView().getModel("CharList").getProperty(ClSelRow);

								var status = ClSelectedRow.STATUS;

								var resr = resource;
								var ResultType = ClSelectedRow.CHARTYPE;
								var restype = ClSelectedRow.RESULTTYPE;
								// For HACCP Page Param
								var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
								var js_matdesc = this.getView().byId("id_txt_desc").getValue();
								var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();
								var js_phstxt = this.getView().byId("id_txt_phstxt").getValue();
								var js_ccpsign = this.getView().byId("id_txt_ccpsign").getValue();
								var js_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot");

								var js_currenttime = currenttime;
								var inspCharDesc = ClSelectedRow.CHARDESC;
								var uplmt1 = ClSelectedRow.UP_TOL_LMT;
								var lowlmt1 = ClSelectedRow.LW_TOL_LMT;
								var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
								var inspChar = ClSelectedRow.INSPCHAR;
								var inspcount = ClSelectedRow.INSPCOUNT;
								var lowlmt = "0";
								var uplmt = "10";
								var result = "4";
								var resulteval = "R";
								var resulttxt = "Rejected";
								// For HACCP Page Param
								if (ResultType == "QUAN") {
									if (restype == "SINGLE") {
										var itemcount = ClSelectedRow.INSPREQ;
									} else {
										var itemcount = 1;
									}

									for (var i = 0; i < itemcount; i++) {
										var insResultFeildModel = this.getView().getModel("resultFeild").getData()[i];
										var inspChar = ClSelectedRow.INSPCHAR;

										var uplmt1 = ClSelectedRow.UP_TOL_LMT;

										var lowlmt1 = ClSelectedRow.LW_TOL_LMT;
										var upaccplmt1 = ClSelectedRow.UP_LMT_1;
										var lowaccplmt1 = ClSelectedRow.LW_LMT_1;

										var inspLot = this.getView().byId("id_txt_inslot").getValue()
										var TrWt1 = this.getView().byId("id_txt_TareWt").getValue()
										var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
										var inspPoint = "";
										var inspTime = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_currenttime");
										;

										var remark = insResultFeildModel.remarks;
										var result1 = insResultFeildModel.value;
										result1 = result1.split(" ").join("");

										if (result1 != "") {
											if (!isNaN(result1)) {
												// new

												var result4 = this.checkDecimalPoint(result1.split(","));

												var uplmt4 = this.checkDecimalPoint(uplmt1.split(","));

												var lowlmt4 = this.checkDecimalPoint(lowlmt1.split(","));

												if (!isManualType) {
													if (parseFloat(TrWt1) < parseFloat(result4))
														var result4 = parseFloat(result4) - parseFloat(TrWt1);
													else
														var result4 = parseFloat(result4);
												}

												var result = parseFloat(result4);
												var lowlmt = parseFloat(lowlmt4);
												var uplmt = parseFloat(uplmt4);

												if (!isManualType) {
													var upper4 = this.checkDecimalPoint(upaccplmt1.split(","));

													var lower4 = this.checkDecimalPoint(lowaccplmt1.split(","));

													var lowaccp = parseFloat(lower4);
													var upaccp = parseFloat(upper4);
												}
												// */

												var resulteval;
												var resulttxt; // Added by gchhatri
												var resultaccp = ""; // Added by gchhatri

												if (isNaN(lowlmt) || isNaN(uplmt) && !isManualType) {
													if (isNaN(lowlmt) && isNaN(uplmt)) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else if (isNaN(uplmt) && result >= lowlmt) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else if (isNaN(lowlmt) && result <= uplmt) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else {
														resulteval = "R";
														resulttxt = "Rejected"; // Added by gchhatri
													}
												} else {
													if (result >= lowlmt && result <= uplmt) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else if (result < lowlmt) {
														resulteval = "R";
														resulttxt = "Rejected"; // Added by gchhatri
													} else if (result > uplmt) {
														resulteval = "R";
														resulttxt = "Rejected"; // Added by gchhatri
													} else {
													}
												}

												if (!isManualType) { // if auto type only
													/* Added by gchhatri */
													if (result >= lowaccp && result <= upaccp) {
														resultaccp = "A";
													} else if (result < lowaccp) {
														resultaccp = "R";
													} else if (result > upaccp) {
														resultaccp = "R";
													} else {
													}

													if ((resulteval == "R" && remark == "")
															|| (resulteval == "R" && remark == "---" && !isPrevQualInspView)) {

														MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065"));

														// document.getElementById(inspFreetxt_name).style.backgroundColor='#FF6666';
														// document.getElementById(inspFreetxt_name).focus();
														this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "R")

														validationFlag = 1;
														break;
													} else {

														this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "A")

														// document.getElementById(inspFreetxt_name).style.backgroundColor='#FFFFFF';

													}
												} else { // if manual only
													if (resulteval == "R" && remark == "") {
														MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065"));
														validationFlag = 1;
														break;
													}
												}
											} // end of isNAN checks
											else {
												// alert("Please enter a Neumeric Value for
												// result field");
												MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0202"));
												validationFlag = 1;
												break;
											}
										} // end of blank check
										else {
											// alert("Please fill all result fields");
											MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0203"));
											validationFlag = 1;
											break;
										}

									}
									// end of for
									var g_ccpFlag = "0";
									var g_resulttxt = "Accepted";
									if (validationFlag == 0) {

										// for loop start
										for (var j = 1; j <= itemcount; j++) {
											l_ccpFlag = "0";

											var inspChar = ClSelectedRow.INSPCHAR;
											var inspCharDesc = ClSelectedRow.CHARDESC;
											var methodText = ClSelectedRow.METHODTXT;
											var js_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot");
											var js_mat = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_mat");
											var js_matdesc = this.getView().byId("id_txt_desc").getValue();
											var js_ord = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_ord");
											var js_phs = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
											var js_date = this.getView().byId("id_txt_insdate").getValue();
											var js_time = this.getView().byId("id_txt_instime").getValue();
											var js_currenttime = currenttime;
											var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
											var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();
											var js_phstxt = this.getView().byId("id_txt_phstxt").getValue();
											var js_ccpsign = this.getView().byId("id_txt_ccpsign").getValue();

											var uplmt1 = ClSelectedRow.UP_TOL_LMT;
											var lowlmt1 = ClSelectedRow.LW_TOL_LMT;
											var upaccplmt1 = ClSelectedRow.UP_LMT_1;
											var lowaccplmt1 = ClSelectedRow.LW_LMT_1;
											var inspcount = ClSelectedRow.INSPCOUNT;

											var inspLot = this.getView().byId("id_txt_inslot").getValue()
											var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
											var inspPoint = "";
											var inspTime = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_currenttime");

											var insResultFeildModel = this.getView().getModel("resultFeild").getData()[j-1]
											var remark = insResultFeildModel.remarks;
											var result1 = insResultFeildModel.value;

											var TrWt1 = this.getView().byId("id_txt_TareWt").getValue()

											var result4 = this.checkDecimalPoint(result1.split(","));

											var uplmt4 = this.checkDecimalPoint(uplmt1.split(","));

											var lowlmt4 = this.checkDecimalPoint(lowlmt1.split(","));

											if (!isManualType) {
												if (parseFloat(TrWt1) < parseFloat(result4))
													var result4 = parseFloat(result4) - parseFloat(TrWt1);
												else
													var result4 = parseFloat(result4);
											}

											var result = parseFloat(result4);
											var lowlmt = parseFloat(lowlmt4);
											var uplmt = parseFloat(uplmt4);

											// /* Added by gchhatri
											if (!isManualType) {
												var upper4 = this.checkDecimalPoint(upaccplmt1.split(","));

												var lower4 = this.checkDecimalPoint(lowaccplmt1.split(","));

												var lowaccp = parseFloat(lower4);
												var upaccp = parseFloat(upper4);
											}

											var resulteval;
											// var g_resulttxt; // Added by gchhatri
											var l_resulttxt; // Added by gchhatri
											var resultaccp; // Added by gchhatri
											if (!isManualType) {
												if (isNaN(lowlmt) || isNaN(uplmt)) {
													if (isNaN(lowlmt) && isNaN(uplmt)) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else if (isNaN(uplmt) && result >= lowlmt) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else if (isNaN(lowlmt) && result <= uplmt) {
														resulteval = "A";
														resulttxt = "Accepted"; // Added by gchhatri
													} else {
														resulteval = "R";
														resulttxt = "Rejected"; // Added by gchhatri
														if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
															l_ccpFlag = "1";
															g_ccpFlag = "1";
														}
													}
												} else {
													if (result >= lowlmt && result <= uplmt) {
														resulteval = "A";
														l_resulttxt = "Accepted"; // Added by
														// gchhatri
														// g_resulttxt = "Accepted"; // Added by
														// gchhatri
													} else if (result < lowlmt) {
														resulteval = "R";
														l_resulttxt = "Rejected"; // Added by
														// gchhatri
														g_resulttxt = "Rejected"; // Added by
														// gchhatri
														if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
															l_ccpFlag = "1";
															g_ccpFlag = "1";
														}
													} else if (result > uplmt) {
														resulteval = "R";
														l_resulttxt = "Rejected"; // Added by
														// gchhatri
														g_resulttxt = "Rejected"; // Added by
														// gchhatri
														if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
															l_ccpFlag = "1";
															g_ccpFlag = "1";
														}
													} else {
													}
												}

												/* Added by gchhatri */
												if (result >= lowaccp && result <= upaccp) {
													resultaccp = "A";
												} else if (result < lowaccp) {
													if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
														resultaccp = "R";
													}
												} else if (result > upaccp) {
													if (methodText.indexOf("CCP") == "0" && js_ccpsign.indexOf("CCP") == "0") {
														resultaccp = "R";
													}
												} else {
												}
												/* Added by gchhatri */

											} else {
												if (result >= lowlmt && result <= uplmt) {
													resulteval = "A";
												} else if (result < lowlmt) {
													resulteval = "R";
												} else if (result > uplmt) {
													resulteval = "R";
												} else {
												}
											}

											if (!isPrevQualInspView&& !isManualType)
												result4 = parseFloat(result4).toFixed("3");// result4.toFixed(3);
											// APLT_CMD_InsInspPointData

											var oInspPointDataModel = models
											.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->InsceptionInspect-->SQLQ_UpdInspectPointV1HACCP");

											var params = "Param.1=" + ResultType + "&Param.2=" + inspChar + "&Param.3=" + inspLot + "&Param.4="
											+ inspOper + "&Param.5=" + inspPoint + "&Param.6=" + inspTime + "&Param.7=" + remark + "&Param.8="
											+ result4.toString() + "&Param.9=" + resulteval + "&Param.10=" + "1" + "&Param.11=" + plant
											+ "&Param.12=" + resr + "&Param.13=" + j;
											if (!isManualType) {
												params += "&Param.15=" + TrWt1;

												if (l_ccpFlag == "1") {
													params += "&Param.14=" + "0";
												} else {
													params += "&Param.14=" + "";
												}
											}

											oInspPointDataModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
													+ "/QueryTemplate/SQLQ_InsInspectPointV1HACCP&" + params + "&Content-Type=text/json", "", false);

											// APLT_CMD_DelDueInspPoint

											var oDelDueInspPoint = models
											.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->InsceptionInspect-->SQLQ_DeleteDueInspPoint");

											var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + inspLot + "&Param.4=" + inspOper
											+ "&Param.5=" + inspTime + "&Param.6=" + "0";
											oDelDueInspPoint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
													+ "/QueryTemplate/SQLQ_DeleteDueInspPoint&" + params + "&Content-Type=text/json", "", false);

										}
										// for loop end

										if (!isManualType) {
											if (resultaccp == "R") {
												var planttxt = sap.ui.getCore().getModel("session").getProperty("/CA_PlantText");
												var resrtxt = sap.ui.getCore().getModel("session").getProperty("/CA_ResrText");

												this.sendMail(plant, planttxt, resr, resrtxt, js_mat, js_matdesc, userName, inspLot, inspPoint,
														inspCharDesc, lowaccplmt1, lowlmt1, upaccplmt1, uplmt1, result4.toString(), js_ord)

											}
											if (g_ccpFlag == "1") {

												/*
												 * window.location.href =
												 * "/XMII/CM/NL_ELS_HUB/IRPT/InspectResultHACCPSubmitV1.irpt?qs_matstrip=" +
												 * js_matstrip + "&qs_matdesc=" + js_matdesc +
												 * "&qs_ordstrip=" + js_ordstrip + "&qs_phstxt=" +
												 * js_phstxt + "&qs_ccpsign=" + js_ccpsign +
												 * "&qs_insplot=" + js_insplot + "&qs_currenttime=" +
												 * js_currenttime + "&qs_char=" + inspCharDesc +
												 * "&qs_lower=" + lowlmt + "&qs_upper=" + uplmt +
												 * "&qs_result=" + result + "&qs_eval=" + resulteval +
												 * "&qs_restxt=" + g_resulttxt + "&qs_phs=" + inspOper +
												 * "&qs_inspChar=" + inspChar + "&qs_inspcount=" +
												 * inspcount; // &qs_restxt="+resulttxt+" Added by
												 * gchhatri
												 */
										var resourceTxt = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/js_resrtxt");
												var oViewHaccpModel = new sap.ui.model.json.JSONModel();
												let sID = {
														qs_matstrip : js_matstrip,
														qs_matdesc : js_matdesc,
														qs_ordstrip : js_ordstrip,
														qs_phstxt : js_phstxt,
														qs_ccpsign : js_ccpsign,
														qs_insplot : js_insplot,
														qs_currenttime : js_currenttime,
														qs_char : inspCharDesc,
														qs_lower : lowlmt,
														qs_upper : uplmt,
														qs_result : result,
														qs_eval : resulteval,
														qs_restxt : resulttxt,
														qs_phs : inspOper,
														qs_inspChar : inspChar,
														qs_inspcount : inspcount,
											js_resr : resource,
											js_resrtxt:resourceTxt
												}
												oViewHaccpModel.setData(sID);
												sap.ui.getCore().setModel(oViewHaccpModel, "oViewHACCPParam");
												this._oRouter.navTo("InspectResultHACCP");

											} else {

												// document.getElementById("GridArea").innerHTML="";

												this.getInspCharac();
											}
										} else {

											// document.getElementById("GridArea").innerHTML="";
											if (getFlag == 1) {
												this.ManualGoBack();
											} else {
												this.getInspCharac();
											}
										}
									}

								} else if (ResultType == "QUAL") {
									// Big function to be here

									var SelectedSetRow = this.getView().byId("APLT_GRI_SelectedSet").getSelectedContextPaths().length;

									if (SelectedSetRow != 0) {
										var oSelcSetRow = this.getView().byId("APLT_GRI_SelectedSet").getSelectedContextPaths()[0];
										var oSelcSetRow = this.getView().getModel("SelectedSet").getProperty(oSelcSetRow);

										var itemcount = ClSelectedRow.INSPREQ;
										var inspChar = ClSelectedRow.INSPCHAR;
										var inspCharDesc = ClSelectedRow.CHARDESC;
										var inspLot = this.getView().byId("id_txt_inslot").getValue();
										var inspOper = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
										var inspPoint = "";
										var inspTime = currenttime;
										var remark = this.getView().byId("id_txt_qual_remark").getValue();
										var result = oSelcSetRow.CODE;
										var Eval = oSelcSetRow.VALUATION;

										// Begin HACCP change
										var methodText = ClSelectedRow.METHODTXT;
										var js_insplot = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_insplot");
										var js_mat = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_mat");
										var js_matdesc = this.getView().byId("id_txt_desc").getValue();
										var js_ord = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_ord");
										var js_phs = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/qs_phs");
										var js_date = this.getView().byId("id_txt_insdate").getValue();
										var js_time = this.getView().byId("id_txt_instime").getValue();
										var js_currenttime = currenttime;

										var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
										var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();
										var js_phstxt = this.getView().byId("id_txt_phstxt").getValue();
										var js_ccpsign = this.getView().byId("id_txt_ccpsign").getValue();
										// End HACCP Change

										if (eval == "R" && remark == "" && isManualType) {
											MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065"));
										} else if ((Eval == "R" && remark == "") || (Eval == "R" && remark == "---" && !isPrevQualInspView)
												&& !isManualType) {
											MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065"));

											sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/Quan_QualRemark", "R");
											setTimeout(function() {
												that.getView().byId("id_txt_qual_remark").focus();
											}, 1000);
											/*
											 * document.getElementById("id_txt_qual_remark").style.backgroundColor='#FF6666';
											 * document.getElementById("id_txt_qual_remark").focus();
											 */
										} else {

											// APLT_CMD_InsInspPointData

											var oInspPointDataModel = models
											.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->InsceptionInspect-->SQLQ_InsInspectPointV1HACCP");

											var params = "Param.1=" + ResultType + "&Param.2=" + inspChar + "&Param.3=" + inspLot + "&Param.4="
											+ inspOper + "&Param.5=" + inspPoint + "&Param.6=" + inspTime + "&Param.7=" + remark + "&Param.8="
											+ result + "&Param.9=" + Eval + "&Param.10=" + "1" + "&Param.11=" + plant + "&Param.12=" + resr
											+ "&Param.13=" + "1";

											if (!isManualType) {
												params += "&Param.15=" + TrWt1;
												if (methodText.indexOf("CCP") == "0" && Eval == "R" && js_ccpsign.indexOf("CCP") == "0") {
													params += "&Param.14=" + "0";
												} else {
													params += "&Param.14=" + "";

												}
											}

											oInspPointDataModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
													+ "/QueryTemplate/SQLQ_InsInspectPointV1HACCP&" + params + "&Content-Type=text/json", "", false);

											// APLT_CMD_DelDueInspPoint

											var oDelDueInspPoint = models
											.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultSubmit-->InsceptionInspect-->SQLQ_DeleteDueInspPoint");

											var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + inspLot + "&Param.4=" + inspOper
											+ "&Param.5=" + inspTime + "&Param.6=" + "0";
											oDelDueInspPoint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
													+ "/QueryTemplate/SQLQ_DeleteDueInspPoint&" + params + "&Content-Type=text/json", "", false);

											if (!isManualType) {

												if (methodText.indexOf("CCP") == "0" && Eval == "R" && js_ccpsign.indexOf("CCP") == "0") {
													if (Eval = "R")
														resulttxt = "Rejected";
													else if (Eval = "A")
														resulttxt = "Accepted";

var resourceTxt = sap.ui.getCore().getModel("IncResSubmitModel").getProperty("/js_resrtxt");
													var oViewHaccpModel = new sap.ui.model.json.JSONModel();
													let sID = {
															qs_matstrip : js_matstrip,
															qs_matdesc : js_matdesc,
															qs_ordstrip : js_ordstrip,
															qs_phstxt : js_phstxt,
															qs_ccpsign : js_ccpsign,
															qs_insplot : js_insplot,
															qs_currenttime : js_currenttime,
															qs_char : inspCharDesc,
															qs_lower : lowlmt,
															qs_upper : uplmt,
															qs_result : result,
															qs_eval : resulteval,
															qs_restxt : resulttxt,
															qs_phs : inspOper,
															qs_inspChar : inspChar,
															qs_inspcount : inspcount,
															CA_Resource : js_resr,
															CA_ResrText : js_resrtxt,
											js_resr : resource,
											js_resrtxt:resourceTxt
													}
													oViewHaccpModel.setData(sID);
													sap.ui.getCore().setModel(oViewHaccpModel, "oViewHACCPParam");
													this._oRouter.navTo("InspectResultHACCP");
													/*
													 * window.location.href =
													 * "/XMII/CM/NL_ELS_HUB/IRPT/InspectResultHACCPSubmitV1.irpt?qs_matstrip=" +
													 * js_matstrip + "&qs_matdesc=" + js_matdesc +
													 * "&qs_ordstrip=" + js_ordstrip + "&qs_phstxt=" +
													 * js_phstxt + "&qs_ccpsign=" + js_ccpsign +
													 * "&qs_insplot=" + js_insplot + "&qs_currenttime=" +
													 * js_currenttime + "&qs_char=" + inspCharDesc +
													 * "&qs_lower=NA" + "&qs_upper=NA" + "&qs_result=" +
													 * result + "&qs_eval=" + resulteval + "&qs_restxt=" +
													 * resulttxt + "&qs_phs=" + inspOper + "&qs_inspChar=" +
													 * inspChar + "&qs_inspcount=" + inspcount;
													 */
												} else {
													sap.ui.getCore().getModel("InspectionSubmitResult").setProperty("/GridArea1", false);
													this.getView().byId("id_txt_qual_remark").setValue("")
													this.getInspCharac();
												}
											} else {
												if (getFlag == 1) {
													this.ManualGoBack();
												} else {
													this.getInspCharac();
												}
											}
										}

										// inside if end here
									} else {
										MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
									}

								}

							} else {
								MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0066"));
							}

						},
						keyPressEvent : function() {
							var isSaveBtn =sap.ui.getCore().getModel("InspectionSubmitResult").getProperty("/btn_Save");
							var isUpdateBtn =sap.ui.getCore().getModel("InspectionSubmitResult").getProperty("/btn_Update");
							var isManual = sap.ui.getCore().getModel("InspectionSubmitResult").getProperty("/ManualScreen");
							if(isSaveBtn){
								if(!isManual)
											this.AutoInsertResult();
										else
											this.ManualInsertResult();
							}
							if(isUpdateBtn){
								this.updateResults();
							}	
						},
/*****
						onAfterRendering: function() {

							var that = this;
							var isManual = sap.ui.getCore().getModel("InspectionSubmitResult").getProperty("/ManualScreen");
							
							var input = this.getView().byId("id_txt_qual_remark");
							input.addEventListener("keypress", function(event) {

								if (event.key === "Enter") {
									if(!isManual)
										that.AutoInsertResult();
									else
										that.ManualInsertResult();
									
								}


							}
							);

						},
*****/

					});
		});
//#
//sourceURL=http://khuscsapgib00.mykft.net:50000/XMII/CM/RepHubUI5/webapp/controller/quality/InspectResultSubmit.controller.jss
