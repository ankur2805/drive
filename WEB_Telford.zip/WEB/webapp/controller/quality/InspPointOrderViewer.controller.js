sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
		"sap/m/MessageBox",
		"com/khc/rephub/utils/UI_utilities",
		"com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput",
		"com/khc/rephub/model/formatter", "com/khc/rephub/model/models"
	],
	function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput, formatter, models) {
		"use strict";
		var plant;
		var resource;
		var projectName;
		var userName;
		var crDest;

		//from session
		var count = 0;
		var colorDark = "";
		var colorLight = "";
		var warning = "";
		var warning = "";
		var js_FlagPhasesNextTime = 0;
		var js_FlagInspectPoint = 0;
		var js_FlagOrderList = 0;

		var js_LoopCount = 0;

		//for hidden Variable
		var InspectPoint;
		var txt_Mat;
		var crid;
		var txt_Ord;
		return Controller.extend("com.khc.rephub.controller.quality.InspPointOrderViewer", {
			formatter: formatter,
			onInit: function() {
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this._oRouter.getRoute("InspPointOrderViewer").attachPatternMatched(this._oRoutePatternMatched, this);

			},
			menuSelected: function(oEvent) {

				// Navigate the the selected menu page

				var sKey = oEvent.getParameters().key;
				UI_utilities.openMenu(this._oRouter, this, sKey);

			},

			_oRoutePatternMatched: function(oEvent) {

				//Hide the messages and set busy to false
				UI_utilities.qualityPageOpened(this, "InspPointOrderViewer");
				UI_utilities.qualityMenuBar();

				UI_utilities.DisableDatePickerInput(this.getView().byId("FromTime"));
				UI_utilities.DisableDatePickerInput(this.getView().byId("ToTime"));

				plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
				resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
				projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
				userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
				crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

				var oModelGetResourceList = CommonUtility.getResourceListByPlant(projectName, plant);
				this.getView().setModel(oModelGetResourceList, "oResourceList");
				this.getView().byId("id_dropdown_resource").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Resource);

				if (sap.ui.getCore().getModel("oRedirectFromChildPage").getProperty("/Parent_Page") == true) {
					sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty("/Parent_Page", false)
						//alert("dont clear values");
				} else {
					//alert("Clear the value");
					this.getView().byId("FromTime").setValue("");
					this.getView().byId("ToTime").setValue("");
					this.getView().byId("OrderID").setValue("");
					this.clearAll();
				}

			},

			clearAll: function() {
				this.getView().byId("id_txt_insplot").setValue("");
				this.getView().byId("id_txt_ordstrip").setValue("");
				this.getView().byId("id_txt_matstrip").setValue("");
				this.getView().byId("id_txt_mattext").setValue("");

				var oEmptyModel = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oEmptyModel, "oOrderList");
				this.getView().setModel(oEmptyModel, "PhasesNextTime");
				this.getView().setModel(oEmptyModel, "InspectPointList");
			},

			GetOldOrderDetails: function() {
				this.clearAll();

				var oEmptyModel = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oEmptyModel, "oOrderList");
				this.getView().setModel(oEmptyModel, "PhasesNextTime");
				this.getView().setModel(oEmptyModel, "InspectPointList");

				var SelStartDate = this.getView().byId("FromTime").getValue();
				var SelEndDate = this.getView().byId("ToTime").getValue();
				var OrderID = this.getView().byId("OrderID").getValue();
				var sParams;

				var xParams = "&Param.1=" + SelStartDate + "&Param.2=" + SelEndDate + "&Param.3=" + resource + "&Param.4=" + OrderID;
				var bDateRange = false;
				var bOrder = false;
				if (SelStartDate == "" || SelEndDate == "") {
					if (OrderID != "") {

						sParams = "&Param.1=" + "" + "&Param.2=" + "" + "&Param.3=" + resource + "&Param.4=" + OrderID;
						bOrder = true;
					}

				} else {

					sParams = "&Param.1=" + SelStartDate + "&Param.2=" + SelEndDate + "&Param.3=" + resource + "&Param.4=" + OrderID;
					bDateRange = true;
				}

				if (bDateRange || bOrder) {

					var oModelOrderList = models.createNewJSONModel(
						"com.khc.rephub.controller.quality.InspPointOrderViewer-->GetOldOrderDetails-->XACQ_GetOldOrderDetails");
					oModelOrderList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOldOrderDetails" + sParams +
						"&d=" + new Date() + "&Content-Type=text/json", "", false);
					this.getView().setModel(oModelOrderList, "oOrderList");

					if (CommonUtility.getJsonModelRowCount(oModelOrderList.getData()) <= 0) {

						if (bDateRange)
							MessageBox.alert("No orders selected");
						else
							MessageBox.alert("Order not found");
					}

				} else {
					//alert("Please Select Date Range or Order Number");
					sap.m.MessageBox.alert("Please Select Date Range or Order Number");
				}
			},
			orderList: function() {

				var aSelectedRowPath = this.getView().byId("tbl_Orderlist").getSelectedContextPaths();
				var aSelectedRowPhasePath = aSelectedRowPath;

				var oModelOrderList = this.getView().getModel("oOrderList");
				if (aSelectedRowPath.length > 0) {
					let sPath = aSelectedRowPath[0];

					var INSPLOT = oModelOrderList.getProperty(sPath).INSPLOT;

					var ORDERIDStrip = oModelOrderList.getProperty(sPath).ORDERIDStrip;

					var MATNRStrip = oModelOrderList.getProperty(sPath).MATNRStrip;

					var MATTEXT = oModelOrderList.getProperty(sPath).MATTEXT;

					var CRID = oModelOrderList.getProperty(sPath).CRID;
					this.getView().byId("id_txt_ordstrip").setValue(ORDERIDStrip);

					this.getView().byId("id_txt_matstrip").setValue(MATNRStrip);

					this.getView().byId("id_txt_mattext").setValue(MATTEXT);

					this.getView().byId("id_txt_insplot").setValue(INSPLOT);

					var oPhasesNextTime = models.createNewJSONModel(
						"com.khc.rephub.controller.quality.InspPointOrderViewer-->orderList-->XACQ_GetPhaseNextTime");
					var date = CommonUtility.getCurrentDateTime(new Date());
					var insporder = oModelOrderList.getProperty(sPath).ORDERID;
					var params = "Param.1=" + INSPLOT + "&Param.2=" + insporder + "&Param.3=" + plant + "&Param.4=" + resource + "&Param.5=" + date +
						"&Param.6=" + CRID;
					oPhasesNextTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetPhaseNextTime&" + params +
						"&Content-Type=text/json", "", false);

					if (oPhasesNextTime.getData().Rowsets.Rowset[0].Row != undefined) {
						var OrerForInsp = oPhasesNextTime.getData().Rowsets.Rowset[0].Row[0];

						this.getView().setModel(oPhasesNextTime, "PhasesNextTime");
					}

				}

			},

			GetInspectPoints: function() {

				var that = this;
				var SelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths().length;

				if (SelRow != 0) {
					var QnSelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths()[0];
					var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

					var phase = NtSelectedRow.Phase;
					var insStatus = '';

					//getOrder Details count
					var InspectPointList = models.createNewJSONModel(
						"com.khc.rephub.controller.quality.InspPointOrderViewer-->GetInspectPoints-->XACQ_GetInspectionPoints");
					var insplot = that.getView().byId("id_txt_insplot").getValue();
					var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource;
					InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetInspectionPoints&" + params +
						"&Content-Type=text/json", "", false);
					this.getView().setModel(InspectPointList, "InspectPointList");

					if (InspectPointList.getData().Rowsets.Rowset[0].Row != undefined) {

						InspectPoint = InspectPointList.getData().Rowsets.Rowset[0].Row;
						this.getView().setModel(InspectPointList, "InspectPointList");
						//var runningorder = InspectPoint.ORDERID;
						var rowcount = InspectPointList.getData().Rowsets.Rowset[0].Row.length;
						var complete = 0;
						for (var i = 1; i <= rowcount; i++) {
							//insStatus =  
						}

					}

				}

			},

			// **** Redirect to InspectResultSubmitViewer page for selected inspection point and pass required value via query string

			openSPCCharts: function() {

				var PhasesNTSelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths().length;
				var InspectPointSelRow = this.getView().byId("id_table_InspectPoint").getSelectedContextPaths().length;

				if (InspectPointSelRow != 0) {

					var IpSelRow = this.getView().byId("id_table_InspectPoint").getSelectedContextPaths()[0];
					var IpSelectedRow = this.getView().getModel("InspectPointList").getProperty(IpSelRow);

					var NTSelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths()[0];
					var NTSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(NTSelRow);

					var InsDateTime = IpSelectedRow.Time;

					if (InsDateTime != "") {
						var currentDT = CommonUtility.getCurrentDateTime(new Date());

						var js_date = IpSelectedRow.InsDate;
						var js_time = IpSelectedRow.InsTime;
						var js_currenttime = IpSelectedRow.InsDateTime;

						var js_phs = NTSelectedRow.Phase;
						var js_phstxt = NTSelectedRow.PhaseText;
						//var js_currenttime = NTSelectedRow.Time;

						var js_stdkey = NTSelectedRow.StdTextKey;

						var js_mat = txt_Mat;
						var js_ord = txt_Ord;

						var js_matdesc = this.getView().byId("id_txt_mattext").getValue();
						var js_insplot = this.getView().byId("id_txt_insplot").getValue();
						var js_matstrip = this.getView().byId("id_txt_matstrip").getValue();
						var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();

						var incResSubmitModel = new sap.ui.model.json.JSONModel();
						let sID = {
							qs_insplot: js_insplot,
							qs_mat: js_mat,
							qs_matdesc: js_matdesc,
							qs_ord: js_ord,
							qs_phs: js_phs,
							qs_date: js_date,

							qs_time: js_time,
							qs_currenttime: js_currenttime,
							qs_matstrip: js_matstrip,
							qs_ordstrip: js_ordstrip,
							qs_phstxt: js_phstxt,
							qs_ccpsign: js_stdkey,
							parent_page: "InspPointOrderViewer",
						};
						incResSubmitModel.setData(sID);
						sap.ui.getCore().setModel(incResSubmitModel, "InspectResultSubmitViewerModel");

						UI_utilities.setContainerBusyState(this, true);
						//ID is Mandatory parameter in the routing, to find the model path in start phase screen
						// this._oRouter.navTo("InspectResultSubmitViewer", {
						//      ID: "InspectResultSubmitViewer"
						//  });
						this._oRouter.navTo("InspectResultSubmitViewer");

						/*   window.location.href = "InspectResultSubmitViewer.irpt?qs_insplot="+
						 * js_insplot+"&qs_mat="+js_mat+"&qs_matdesc="+js_matdesc+"&qs_ord="+
						 * js_ord+"&qs_phs="+js_phs+"&qs_date="+js_date+"&qs_time="+js_time+
						 * "&qs_currenttime="+js_currenttime+"&qs_matstrip="+js_matstrip+
						 * "&qs_ordstrip="+js_ordstrip+"&qs_phstxt="+js_phstxt;
						 */

					} else {
						MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0051"));
					}

				} else {
					MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0050"));

				}
			},

			openExport: function() {

				var SelStartDate = this.getView().byId("FromTime").getValue();
				var SelEndDate = this.getView().byId("ToTime").getValue();
				var OrderID = this.getView().byId("OrderID").getValue();
				var SelResr = this.getView().byId("id_dropdown_resource").getSelectedKey();

				if (SelStartDate == "" || SelEndDate == "") {
					if (this.getView().byId("OrderID").getValue()) {

						var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_DownloadArchivedILData&IsTesting=T&Param.1=" +
							SelResr +

							"&Param.2=" + OrderID + "&Param.3=" + SelStartDate + "&Param.4=" + SelEndDate + "&Param.5=" + plant + "&Content-Type=text/csv";
						window.open(url);
					} else {
						sap.m.MessageBox.alert("Please Select Date Range or Order Number");
						//alert("Please Select Date Range or Order Number");
					}

				} else {
					var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_DownloadArchivedILData&IsTesting=T&Param.1=" +
						SelResr + "&Param.2=" + OrderID + "&Param.3=" + SelStartDate + "&Param.4=" + SelEndDate + "&Param.5=" + plant +
						"&Content-Type=text/csv";
					window.open(url);
				}
			},
			onHelp: function() {

				UI_utilities.OpenHelpFileSingle("Resultentry");
			}
		});
	});