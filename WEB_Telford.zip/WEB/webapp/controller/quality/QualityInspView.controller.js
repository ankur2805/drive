sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput", "com/khc/rephub/model/formatter", "com/khc/rephub/model/models"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput, formatter, models) {
        "use strict";
        var plant;
        var resource;
        var projectName;
        var dt;

        return Controller.extend("com.khc.rephub.controller.quality.QualityInspView", {
            formatter: formatter,
            onInit: function() {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("QualityInspView").attachPatternMatched(this._oRoutePatternMatched, this);

            },
            _oRoutePatternMatched: function(oEvent) {

                UI_utilities.qualityPageOpened(this, "QualityInspView");
                UI_utilities.qualityMenuBar();
                UI_utilities.DisableDatePickerInput(this.getView().byId("id_txt_from"));
                UI_utilities.DisableDatePickerInput(this.getView().byId("id_txt_to"));

                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;

                dt = new Date();
                this.getResource();

                if (sap.ui.getCore().getModel("oRedirectFromChildPage").getProperty("/Parent_Page") == true) {
                    sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty("/Parent_Page", false)
                } else {
                    this.clearValue();
                }

            },
            clearValue: function() {
                this.getView().byId("material").setSelectedKey("");
                this.getView().byId("resource").setSelectedKey("");
                this.getView().byId("id_resctext").setValue("");
                this.getView().byId("id_btn_Result").setEnabled(false);
                var oEmptyModel = new sap.ui.model.json.JSONModel();
                this.getView().setModel(oEmptyModel, "oInspView");
            },
            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },

            getResource: function() {
                let resourceModel = CommonUtility.getResourceListByPlant(projectName, plant);
                if (CommonUtility.getJsonModelRowCount(resourceModel.getData())) {
                    this.getView().setModel(resourceModel, "oresource");
                    //resourceModel.getData().Rowsets.Rowset[0].Row[0].RESR
                }

                let oModelInspViewDetails = sap.ui.getCore().getModel("oInspDetails");
                if (!oModelInspViewDetails || !oModelInspViewDetails.getData() || !CommonUtility.getJsonModelRowCount(oModelInspViewDetails.getData())) {
                    let todayDate = CommonUtility.formatDate(dt);
                    this.getView().byId("id_txt_from").setValue(todayDate);
                    this.getView().byId("id_txt_to").setValue(todayDate);
                } else {
                    let spath = sap.ui.getCore().getModel("oInspDetails").getData()

                    this.getView().byId("material").setSelectedKey(spath.SelMATNR);
                    this.getView().byId("resource").setSelectedKey(spath.qs_resource);
                    this.getView().byId("id_resctext").setSelectedKey(spath.SelMATDesc);
                    this.getView().byId("id_txt_from").setSelectedKey(spath.FromDate);
                    this.getView().byId("id_txt_to").setSelectedKey(spath.ToDate);
                    this.getresourceText();
                    this.getResults();


                }
            },

            getresourceText: function(oEvent) {
                this.getView().byId("id_resctext").setValue(this.getView().byId("resource").getSelectedKey());
                var getMatListModel = models.createNewJSONModel("com.khc.rephub.controller.quality.QualityInspView-->getresourceText-->XACQ_GetMaterialforResource");
               resource = this.getView().byId("resource").getSelectedItem().mProperties.text;
	   
	 let getMatListParam = "Param.1=" + plant + "&Param.2=" + this.getView().byId("resource").getSelectedItem().mProperties.text + "&d=" + dt;
                var that = this;
                getMatListModel.attachRequestCompleted(
                    function() {
                        if (CommonUtility.getJsonModelRowCount(getMatListModel.getData())) {
                            that.getView().setModel(getMatListModel, "oMaterial")
                        }
                    });
                getMatListModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMaterialforResource&" + getMatListParam + "&Content-Type=text/json", "", false);
            },

            getResults: function() {
                let SelectedResr =this.getView().byId("resource").getProperty("value");
                let SelectedMat = this.getView().byId("material").getSelectedKey();
                let from = this.getView().byId("id_txt_from").getValue();
                let to = this.getView().byId("id_txt_to").getValue();

                if (SelectedResr == "" || SelectedMat == "") {
                    let msg = "Please select the required input";
                    MessageBox.error(msg, {
                        title: "Error",
                    });
                    return;
                }


                if (from > to) {
                    let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0191");
                    MessageBox.error(msg, {
                        title: "Error",
                    });

                } else {

                    var getQualityInspViewModel = models.createNewJSONModel("com.khc.rephub.controller.quality.QualityInspView-->getResults-->XACQ_QualityInspView");
                    let getQualityInspViewParam = "Param.1=" + SelectedResr + "&Param.2=0000000000" + SelectedMat + "&Param.3=" + from + "&Param.4=" + to + "&d=" + dt;
                    var that = this;
                    getQualityInspViewModel.attachRequestCompleted(
                        function() {
                            if (CommonUtility.getJsonModelRowCount(getQualityInspViewModel.getData())) {
                                that.getView().setModel(getQualityInspViewModel, "oInspView")
                            }
                        });
                    getQualityInspViewModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_QualityInspView&" + getQualityInspViewParam + "&Content-Type=text/json", "", false);

                }

            },

            enableResult: function() {
                this.getView().byId("id_btn_Result").setEnabled(true);
            },

            getInspection: function() {
                let selectedRow = this.getView().byId("inspList").getSelectedContextPaths();
                let sPath = selectedRow[0];
                let oModelInspDetails = this.getView().getModel("oInspView");
                let js_mat = oModelInspDetails.getProperty(sPath + "/MATNR");
                let js_ord = oModelInspDetails.getProperty(sPath + "/ORDERID");
                let js_matdesc = oModelInspDetails.getProperty(sPath + "/MATTEXT");
                let js_insplot = oModelInspDetails.getProperty(sPath + "/INSPLOT");
                let js_plant = oModelInspDetails.getProperty(sPath + "/PLANT");
                let js_resr = oModelInspDetails.getProperty(sPath + "/RESR");
                let js_crid = oModelInspDetails.getProperty(sPath + "/CRID");
                let js_matstrip = Math.abs(js_mat);
                let js_ordstrip = Math.abs(js_ord);
                let SelectedResr = this.getView().byId("resource").getProperty("value");
                let js_resrtxt = this.getView().byId("resource").getSelectedKey();
                let SelectedMat = this.getView().byId("material").getSelectedKey();
                let from = this.getView().byId("id_txt_from").getValue();
                let to = this.getView().byId("id_txt_to").getValue();


                var oInspDetailsModel = new sap.ui.model.json.JSONModel();
                let sID = {
                    qs_matstrip: js_matstrip,
                    qs_matdesc: js_matdesc,
                    qs_ordstrip: js_ordstrip,
                    qs_insplot: js_insplot,
                    CA_Plant: js_plant,
                    qs_resource: js_resr,
                    qs_crid: js_crid,
                    qs_mat: js_mat,
                    qs_ord: js_ord,
                    SelMATDesc: js_resrtxt,
                    FromDate: from,
                    ToDate: to,
                    SelMATNR: SelectedMat,
		js_resr:SelectedResr


                }
                oInspDetailsModel.setData(sID)
                sap.ui.getCore().setModel(oInspDetailsModel, "oInspDetails")

                this._oRouter.navTo("InspectPointView");

            }
        });
    });