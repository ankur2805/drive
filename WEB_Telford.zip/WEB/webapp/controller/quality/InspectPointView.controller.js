sap.ui
  .define(
    [ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox", "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput",
        "com/khc/rephub/model/models", "com/khc/rephub/model/formatter" ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput, models,formatter) {
      "use strict";
      var plant;
      var resource;
      var projectName;
      var shiftname = '';
      var shiftId = '';
      var teamId = '';
      var shiftStartTime = '';
      var shiftEndTime = '';
      var oDownTimeData;
      var sDTStartDateFormatted;
      var userName;
      var crdest;
     var autoRefresh;     

      return Controller
        .extend(
          "com.khc.rephub.controller.quality.InspectPointView",
          {
            formatter : formatter,
            onInit : function() {
              this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
              this._oRouter.getRoute("InspectPointView").attachPatternMatched(this._oRoutePatternMatched, this);
           
              var oInscPointRoute = {
                qs_phs : '',
                qs_currenttime : ""
              };
              var oInscPointRouteModel = new sap.ui.model.json.JSONModel(oInscPointRoute);
              sap.ui.getCore().setModel(oInscPointRouteModel, "InspectionPointRoute")
            },
            _oRoutePatternMatched : function(oEvent) {

              UI_utilities.qualityPageOpened(this, "InspectPointView");

              

              resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
	if (sap.ui.getCore().getModel("oInspDetails") == null){
               	this._oRouter.navTo("qualityInspView");
		return;
	}
	else{
		resource = sap.ui.getCore().getModel("oInspDetails").getProperty("/js_resr");
	}

		
              plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
              projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
              userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
              crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

              this.getRunningShift();
              if (sap.ui.getCore().getModel("PhasesNextTime") != null)
                sap.ui.getCore().getModel("PhasesNextTime").setData("")
              if (sap.ui.getCore().getModel("InspectPointList") != null)
                sap.ui.getCore().getModel("InspectPointList").setData("")
              this.getRunningOrder();

              // Set session row from route
              this.selectSessionPhase();
              if (sap.ui.getCore().getModel("oRedirectFromChildPage").getProperty("/Parent_Page") == true) {
                // sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty("/Parent_Page",false)

              } else {
                // this.clearValue();

              }

            },
         
            // on Load get the running shift details
            getRunningShift : function() {

              var oModelRunningShiftDetails = new sap.ui.model.json.JSONModel();
              var that = this;
              oModelRunningShiftDetails.attachRequestCompleted(function() {

                that.getView().setModel(oModelRunningShiftDetails, "oRunningShiftList");
                if (CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData()) > 0) {
                  var oRunningShiftData = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
                  shiftname = oRunningShiftData.SHIFTNAME;
                  shiftStartTime = oRunningShiftData.STARTTIME;
                  shiftEndTime = oRunningShiftData.ENDTIME;
                  shiftId = oRunningShiftData.SHIFTID;
                  teamId = oRunningShiftData.TEAMID;
                } else {
                  var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                  sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                  sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                  sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                }
              });

              oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/XACQ_GetRunningShift&Param.1=" + plant + "&Param.2=" + resource + "&Content-Type=text/json",
                "", false);

            },

	autoRefreshTable:function(){
		if(autoRefresh==true){
			var that = this;
				let dur= sap.ui.getCore().getModel("session").oData.CA_AutoRefreshQualityPhase;
				if(isNaN(dur)){dur=3;}	
				dur=dur*60000;
				setTimeout(function(){that.getRunningOrder(); }, dur);
				this.getView().byId("APLT_CMD_GetPhasesNextTime").removeSelections(true);
				let oEmptyModel = new sap.ui.model.json.JSONModel();
             			 sap.ui.getCore().setModel(oEmptyModel, "InspectPointList");
				     //sap.ui.getCore().getModel("InspectPointList").setData("")
		}

	},

            getRunningOrder : function() {
		autoRefresh=true;
              var that = this;

              // Maquee Text

              /*
               * var sNoShiftMsg =
               * sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0122");
               * sap.ui.getCore().getModel("oMessage").setProperty("/message",
               * sNoShiftMsg);
               * sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",
               * true);
               * sap.ui.getCore().getModel("oMessage").setProperty("/type",
               * "Warning");
               */
              // Marquee Text End
              var inspOrder = sap.ui.getCore().getModel("oInspDetails").getProperty("/qs_ord");
              var inSplot = sap.ui.getCore().getModel("oInspDetails").getProperty("/qs_insplot");
              var date = CommonUtility.getCurrentDateTime(new Date());

              var oPhasesNextTime = models
                .createNewJSONModel("com.khc.rephub.controller.quality.InspectPointView-->getRunningOrder-->XACQ_GetPhaseNextTime");
              var params = "Param.1=" + inSplot + "&Param.2=" + inspOrder + "&Param.3=" + plant + "&Param.4=" + resource
                + "&Param.5=" + date + "&Param.6=" + crdest;
              oPhasesNextTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetPhaseNextTime&"
                + params + "&Content-Type=text/json", "", false);

              sap.ui.getCore().setModel(oPhasesNextTime, "PhasesNextTime");
		this.autoRefreshTable();
            },

            GetInspectPoints : function() {

              var that = this;
              var SelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;

              if (SelRow != 0) {
                var QnSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                var phase = NtSelectedRow.Phase;

                // APLT_GRI_InspectPoint

                var InspectPointList = models
                  .createNewJSONModel("com.khc.rephub.controller.quality.InspectPointView-->GetInspectPoints-->XACQ_GetInspectionPoints");

                var insplot = that.getView().byId("id_txt_insplot").getValue();
                var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource;
            /*    /* Commented 27-06-23 
		InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                  + "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
	*/

	
	  	InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=RepHubUI5/Query/SQLQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
	
	  	sap.ui.getCore().setModel(null, "InspectPointList");
                  	sap.ui.getCore().setModel(InspectPointList, "InspectPointList");
           /*     if (InspectPointList.getData().Rowsets.Rowset[0].Row != undefined) {

                  var rowcount = InspectPointList.getData().Rowsets.Rowset[0].Row.length
                  // this.getView().byId("APLT_GRI_InspectPoint").setSelectedItem(this.getView().byId("APLT_GRI_InspectPoint").getItems()[rowcount
                  // - 1])

                }*/
              }

            },

            getTodayDate : function() {
	autoRefresh=false;
              var that = this;
              var SelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;

              if (SelRow != 0) {
                var QnSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                var phase = NtSelectedRow.Phase;
                if (phase != "") {

                  // APLT_CMD_AddInspPoint

                  var currentDT = CommonUtility.getCurrentDateTime(new Date());
                  var js_insplot = that.getView().byId("id_txt_insplot").getValue();

                  var AddInspPoint = models
                    .createNewJSONModel("com.khc.rephub.controller.quality.InspectPointView-->getTodayDate-->SQLQ_InsInspectPoint");

                  var params = "Param.2=" + "NA" + "&Param.3=" + js_insplot + "&Param.4=" + phase + "&Param.6=" + currentDT
                    + "&Param.10=0&Param.11=" + plant + "&Param.12=" + resource + "&Param.13=" + "0";

                  AddInspPoint.attcheReques
                  AddInspPoint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsInspectPoint&"
                    + params + "&Content-Type=text/json", "", false);

                  // APLT_GRI_InspectPoint

                  var InspectPointList = models
                    .createNewJSONModel("com.khc.rephub.controller.quality.InspectPointView-->getTodayDate-->XACQ_GetInspectionPoints");

                  var params = "Param.1=" + js_insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource;
                  InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                    + "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
	  	sap.ui.getCore().setModel(null, "InspectPointList");
                  sap.ui.getCore().setModel(InspectPointList, "InspectPointList");

                  // document.APLT_GRI_InspectPoint.getGridObject().setSelectedRow(1);
                  this.getView().byId("APLT_GRI_InspectPoint").setSelectedItem(
                    this.getView().byId("APLT_GRI_InspectPoint").getItems()[0])

                  this.openSPCCharts();

                } else {
                  MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0049"));
                }
              } else {
                MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0049"));
              }

            },

            // **** Redirect to InspectResultSubmitNewV2 page for
            // selected inspection point and pass required value via
            // query string

            openSPCCharts : function() {
	autoRefresh=false;
              var that = this;
              var PhasesNTSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;
              var InspectPointSelRow = this.getView().byId("APLT_GRI_InspectPoint").getSelectedContextPaths().length;

              if (InspectPointSelRow != 0) {

                var IpSelRow = this.getView().byId("APLT_GRI_InspectPoint").getSelectedContextPaths()[0];
                var IpSelectedRow = this.getView().getModel("InspectPointList").getProperty(IpSelRow);

                var NTSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                var NTSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(NTSelRow);

               // var InsDateTime = IpSelectedRow.Time;
                var InsDateTime = IpSelectedRow.InsDateTime;

                if (InsDateTime != "") {
                  var currentDT = CommonUtility.getCurrentDateTime(new Date());
 
                  	var js_currenttime = IpSelectedRow.InsDateTime;
		var js_time = InsDateTime.split(" ")[1];

		var date = new Date(InsDateTime);
    	   	let yyyy = date.getFullYear();
    	   	let mm = date.getMonth() + 1; // Months start at 0!
    	   	let dd = date.getDate();
    	   	if (dd < 10) dd = '0' + dd;
    	   	if (mm < 10) mm = '0' + mm;
    		var   js_date =   dd + '-' + mm + '-' + yyyy	

                 	/* Commented 27-06-23 
		var js_date = IpSelectedRow.InsDate;
                  	var js_time = IpSelectedRow.InsTime;
                  	var js_currenttime = IpSelectedRow.InsDateTime;
		*/
		
                  var js_phs = NTSelectedRow.Phase;
                  var js_phstxt = NTSelectedRow.PhaseText;
                  // var js_currenttime = NTSelectedRow.Time;

                  // Default CCP Change by Praveen 16.02.2022
                  var js_stdkey = "CCP1"; // NTSelectedRow.StdTextKey;

                  var js_mat = sap.ui.getCore().getModel("oInspDetails").getProperty("/qs_matstrip");
                  var js_ord = sap.ui.getCore().getModel("oInspDetails").getProperty("/qs_ordstrip");

                  var js_matdesc = that.getView().byId("id_txt_mattext").getValue();
                  var js_insplot = that.getView().byId("id_txt_insplot").getValue();
                  var js_matstrip = that.getView().byId("id_txt_matstrip").getValue();
                  var js_ordstrip = that.getView().byId("id_txt_ordstrip").getValue();

                  var js_resr = resource;
                  //var js_resrtxt = sap.ui.getCore().getModel("session").oData.CA_ResrText;
	      var js_resrtxt =sap.ui.getCore().getModel("oInspDetails").getProperty("/SelMATDesc")
	
                  var js_crid = sap.ui.getCore().getModel("oInspDetails").getProperty("/qs_crid");

                  var val_fromdate = sap.ui.getCore().getModel("oInspDetails").getProperty("/FromDate")
                  var val_todate = sap.ui.getCore().getModel("oInspDetails").getProperty("/ToDate");

                  var incResSubmitModel = new sap.ui.model.json.JSONModel();
                  let sID = {
                    qs_insplot : js_insplot,
                    qs_mat : js_mat,
                    qs_matdesc : js_matdesc,
                    qs_ord : js_ord,
                    qs_phs : js_phs,
                    qs_date : js_date,
                    qs_time : js_time,
                    qs_currenttime : js_currenttime,
                    qs_matstrip : js_matstrip,
                    qs_ordstrip : js_ordstrip,
                    qs_phstxt : js_phstxt,
                    qs_ccpsign : js_stdkey,

                    js_resr : js_resr,
                    js_resrtxt : js_resrtxt,
                    js_crid : js_crid,
                    FromDate : val_fromdate,
                    ToDate : val_todate,
                    isQualityInspectionView : true,
		
                  }
                  incResSubmitModel.setData(sID)
                  sap.ui.getCore().setModel(incResSubmitModel, "IncResSubmitModel")

                  this._oRouter.navTo("InspectResultSubmit");
		autoRefresh=false;
                } else {
                  MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0051"));
                }

              } else {
                MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0050"));
              }

            },

            selectSessionPhase : function() {
              var qs_phs = sap.ui.getCore().getModel("InspectionPointRoute").getProperty("/qs_phs");
              if (qs_phs != "") {

                if (sap.ui.getCore().getModel("PhasesNextTime").getData() != null) {
                  this.GetInspectPoints();
                  var ChkCount = sap.ui.getCore().getModel("PhasesNextTime").getData().Rowsets.Rowset[0].Row.length;

                  for (var i = 0; i < ChkCount; i++) {
                    var oPhaseNetTime = sap.ui.getCore().getModel("PhasesNextTime").getData().Rowsets.Rowset[0].Row;

                    if (oPhaseNetTime[i].Phase == qs_phs) {
                      this.getView().byId("APLT_CMD_GetPhasesNextTime").setSelectedItem(
                        this.getView().byId("APLT_CMD_GetPhasesNextTime").getItems()[i]);
                      this.GetInspectPoints();
                      break;
                    }
                  }
                  if (sap.ui.getCore().getModel("InspectPointList").getData() != null) {

                    var currenttime = sap.ui.getCore().getModel("InspectionPointRoute").getProperty("/qs_currenttime");
                    var insCount = sap.ui.getCore().getModel("InspectPointList").getData().Rowsets.Rowset[0].Row.length;
                    for (var i = 0; i < insCount; i++) {
                      var insList = sap.ui.getCore().getModel("InspectPointList").getData().Rowsets.Rowset[0].Row;

                      if (insList[i].InsDateTime == currenttime) {
                        var OInsTable = this.getView().byId("APLT_GRI_InspectPoint");
                        OInsTable.setSelectedItem(OInsTable.getItems()[i]);

                        break;
                      }
                    }
                  }

                }
              }

            },
            BackPage : function() {
              var js_resr = document.getElementById('id_hid_resr').value;
              var val_fromdate = sap.ui.getCore().getModel("oInspDetails").getProperty("/FromDate")
              var val_todate = sap.ui.getCore().getModel("oInspDetails").getProperty("/ToDate");
              var val_selmat = sap.ui.getCore().getModel("oInspDetails").getProperty("/qs_matdesc");
              sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty("/Parent_Page", true)
              var oInspDetailsModel = new sap.ui.model.json.JSONModel();
              let sID = {
                "qs_resource" : resource,
                "SelMATDesc" : val_selmat,
                "FromDate" : val_fromdate,
                "ToDate" : val_todate
              }
              oInspDetailsModel.setData(sID)
              sap.ui.getCore().setModel(oInspDetailsModel, "oInspDetails")
              this._oRouter.navTo("QualityInspView");
		autoRefresh=false;
              /*
               * var js_resr = document.getElementById('id_hid_resr').value;
               * val_fromdate = document.getElementById('FromDate').value;
               * val_todate = document.getElementById('ToDate').value;
               * val_selmat = document.getElementById('SelMATNR').value;
               * window.location.href="/XMII/CM/NL_ELS_HUB/IRPT/QualityInspView.irpt?CA_Resource="+js_resr+"&FromDate="+val_fromdate+"&ToDate="+val_todate+"&SelMATNR="+val_selmat;
               */
            },
            menuSelected : function(oEvent) {

              // Navigate the the selected menu page

              var sKey = oEvent.getParameters().key;
              UI_utilities.openMenu(this._oRouter, this, sKey);
		autoRefresh=false;
            },

          });
    });