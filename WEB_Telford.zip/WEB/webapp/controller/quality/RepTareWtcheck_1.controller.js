sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput", "com/khc/rephub/model/formatter", "com/khc/rephub/model/models"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput, formatter, models) {
        "use strict";
        var plant;
        var resource;
        var resourceText;
        var projectName;
        var dt;
        var todayDateTime;
        var scaleName;
        var selectedRes;
        var resultavg;
        var currentfocus_index = 0;
        var validationFlag = 0;
        var validvalues = 0;
        return Controller.extend("com.khc.rephub.controller.quality.RepTareWtcheck_1", {
            formatter: formatter,
            onInit: function() {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("RepTareWtcheck_1").attachPatternMatched(this._oRoutePatternMatched, this);

            },
 /**************************************************************************************************************************************************************************************/
            _oRoutePatternMatched: function(oEvent) {
				
                UI_utilities.qualityPageOpened(this, "RepTareWtMaster");
		 UI_utilities.qualityMenuBar();
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource
                resourceText = sap.ui.getCore().getModel("session").oData.CA_ResrText
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName
                scaleName = sap.ui.getCore().getModel("session").oData.CA_ScaleName



                dt = new Date();
                todayDateTime =CommonUtility.getCurrentDateTime(dt);
                this.getResource();
                this.loadResrFromSession();
                this.getTareWtList();
                this.createInputBoxes();
            },

 /**************************************************************************************************************************************************************************************/
            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },

 /*************************************************************************************************************************************************************************************/
 //On page load,load the Resource combobox
 /**************************************************************************************************************************************************************************************/
            getResource: function() {
                var resourceDD = this.getView().byId("resource");
             var resourceModel = models.createNewXMLModel("com.khc.rephub.controller.quality.RepTareWtcheck_1-->getResource-->XACQ_GetResrByPlant");

                resourceModel.attachRequestCompleted(
                    function() {
                        if ($(resourceModel.getData()).find("Row").length > 0) {
                            resourceDD.setModel(resourceModel, "oresource");
                        }
                    });
                resourceModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetResrByPlant&Param.1=" + plant + "&d=" + new Date() + "&Content-Type=text/xml", "", false);

            },
/*************************************************************************************************************************************************************************************/
 //On page load, Set the resource
 /**************************************************************************************************************************************************************************************/
            loadResrFromSession: function() {
                this.getView().byId("resource").setSelectedKey(resource);
                selectedRes = this.getView().byId("resource").getSelectedKey();
            },
 /*************************************************************************************************************************************************************************************/
  //On page load, Set the resource
 /**************************************************************************************************************************************************************************************/
            getTareWtList: function() {
                selectedRes = this.getView().byId("resource").getSelectedKey();
               var tareWtListModel = models.createNewJSONModel("com.khc.rephub.controller.quality.RepTareWtcheck_1-->getTareWtList-->SQLQ_GetTareWtIDList");
                var tareWtDD = this.getView().byId("txt_TWIDList");
		let that=this;
                tareWtListModel.attachRequestCompleted(
                    function() {
		if(CommonUtility.getJsonModelRowCount(tareWtListModel.getData())){
                        tareWtDD.setModel(tareWtListModel, "oTareWt");
		that.getView().byId("txt_TWIDList").setSelectedKey(tareWtListModel.getData().Rowsets.Rowset[0].Row[0].TAREWEIGHTID);
		}
                    });

                tareWtListModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetTareWtIDList&Param.1=" + plant + "&Param.2=" + selectedRes + "&d=" + new Date() + "&Content-Type=text/json", "", false);

                this.getView().byId("txt_TWIDList").setSelectedKey(sap.ui.getCore().getModel("oTareWtParam").getData().qs_TareWeightID);
                this.getTareWtMaster();
            },
 /*************************************************************************************************************************************************************************************/
 //On page load, Set the resource
 /**************************************************************************************************************************************************************************************/
            getTareWtMaster: function() {

                let selectedTareWT = this.getView().byId("txt_TWIDList").getSelectedKey();
               var tareWtMasterModel = models.createNewJSONModel("com.khc.rephub.controller.quality.RepTareWtcheck_1-->getTareWtMaster-->XACQ_GetTareWeightMaster");
                var that = this;
                tareWtMasterModel.attachRequestCompleted(
                    function() {
                        if (CommonUtility.getJsonModelRowCount(tareWtMasterModel.getData())) {
                            let spath = tareWtMasterModel.getData().Rowsets.Rowset[0].Row[0];

                            that.getView().byId("txt_TWdesc").setValue(spath.TareWtDesc);
                            that.getView().byId("txt_TWlife").setValue(spath.Life);
                            that.getView().byId("txt_TWlifeunit").setValue(spath.LifeUnit);
                            that.getView().byId("txt_method").setValue(spath.Method);
                            that.getView().byId("txt_sample").setValue(spath.Sample);
                            that.getView().byId("txt_lowPlauseLmt").setValue(spath.LowerPlausiblelimit);
                            that.getView().byId("txt_uppPlauseLmt").setValue(spath.UpperPlausibleLimit);
                            that.getView().byId("txt_PlauseUnit").setValue(spath.PlausibleUnit);
                            that.getView().byId("txt_expires").setValue(spath.TareWtExpiry);
                            that.getView().byId("txt_lastrecorded").setValue(spath.TareWtLastRecorded);
                            that.getView().byId("txt_lastresult").setValue(spath.LastResult);

                        }
                    });

                tareWtMasterModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetTareWeightMaster&Param.1=" + plant + "&Param.2=" + selectedRes + "&Param.3=" + selectedTareWT + "&d=" + new Date() + "&Content-Type=text/json", "", false);

                this.GetTareWthistory();
            },
 /*************************************************************************************************************************************************************************************/
 //On page load, Set the resource
 /**************************************************************************************************************************************************************************************/
            back: function() {
                history.go(-1);
            },
 /*************************************************************************************************************************************************************************************/
 //On page load, Set the resource
 /**************************************************************************************************************************************************************************************/
            readTareWtscale: function() {
		var that=this;
                let lowerpl = this.getView().byId("txt_lowPlauseLmt").getValue();
                let upperpl = this.getView().byId("txt_uppPlauseLmt").getValue();
				let o_weight;
               
               var readareWeightModel = models.createNewJSONModel("com.khc.rephub.controller.quality.RepTareWtcheck_1-->readTareWtscale-->XACQ_ReadTareWeight");
                readareWeightModel.attachRequestCompleted(
                    function() {
                        if (CommonUtility.getJsonModelRowCount(readareWeightModel.getData())) {
                            o_weight = readareWeightModel.getData().Rowsets.Rowset[0].Row[0].O_Weight
                            if (isNaN(o_weight) || o_weight == 0) {
                                let msg = "Read scale again";
                                MessageBox.error(msg, {title: "Error", });
                            } else {

                                let samplesize = that.getView().byId("txt_sample").getValue();
                                that.getView().getModel("resultFeild").setProperty("/" + currentfocus_index + "/value", o_weight);
                                var items = that.getView().byId("remark").getItems();
                                if (currentfocus_index + 1 < samplesize) {
                                    currentfocus_index = currentfocus_index + 1;
                                    items[currentfocus_index].focus();
                                }

                            }
                        }
                    });

       readareWeightModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_ReadTareWeight&Param.1=" + scaleName + "&Param.2=" + lowerpl + "&Param.3=" + upperpl + "&Param.5=" + plant + "&d=" + new Date() + "&Content-Type=text/json", "", false);
            },
 /*************************************************************************************************************************************************************************************/
 //On focus
 /**************************************************************************************************************************************************************************************/

            inputFocused: function(event) {

                let sPath = event.getSource().oBindingContexts.resultFeild.sPath;
                currentfocus_index = Number(sPath.replace("/", ""));

            },
 /*************************************************************************************************************************************************************************************/
//On page load, Set the resource
 /**************************************************************************************************************************************************************************************/
            saveTWResult: function() {
                let lowlmt1 = this.getView().byId("txt_lowPlauseLmt").getValue();
                let uplmt1 = this.getView().byId("txt_uppPlauseLmt").getValue();
                let itemcount = this.getView().byId("txt_sample").getValue();

                let nullStatus = this.checkAllNullBoxes(itemcount);


                if (nullStatus != true) {

                    let numberStatus = this.checkNaNValue(itemcount);
                    if (numberStatus != true) {
                        let limitStatus = this.checkValuesWithinLimit(lowlmt1, uplmt1, itemcount);
                        if (limitStatus != true) {
                            let tw_desc = this.getView().byId("txt_TWdesc").getValue();
                            let txt_method = this.getView().byId("txt_method").getValue();
                            let txt_PlauseUnit = this.getView().byId("txt_PlauseUnit").getValue();
                            let selectedTareWT = this.getView().byId("txt_TWIDList").getSelectedKey();
                            let tw_Life = this.getView().byId("txt_TWlife").getValue();
                            let tw_unit = this.getView().byId("txt_TWlifeunit").getValue();
                            resultavg = resultavg / itemcount;

                            //set the values
                           
               var saveTarewtCheckModel = models.createNewJSONModel("com.khc.rephub.controller.quality.RepTareWtcheck_1-->saveTWResult-->XACQ_SaveTareWtCheck");
                            let saveTarewtCheckParam = "Param.1=" + plant + "&Param.2=" + selectedRes + "&Param.3=" + selectedTareWT + "&Param.4=" + tw_Life + "&Param.5=" + tw_unit + "&Param.6=" + resultavg + "&Param.7=" + todayDateTime + "&d=" + dt;
                      	let that=this;
		  saveTarewtCheckModel.attachRequestCompleted(
                 	   function() {
                           if (CommonUtility.getJsonModelRowCount(saveTarewtCheckModel.getData())) {    
			   let spath = saveTarewtCheckModel.getData().Rowsets.Rowset[0].Row[0];

                            that.getView().byId("txt_lastrecorded").setValue(spath.TareWtLastRecorded);
                            that.getView().byId("txt_lastresult").setValue(spath.LastResult);
                            that.getView().byId("txt_expires").setValue(spath.TareWtExpiry);

		  }
		 });
		saveTarewtCheckModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_SaveTareWtCheck&" + saveTarewtCheckParam + "&Content-Type=text/json", "", false);
                         
                        for(var i=0;i<itemcount;i++){
		   var insResultFeildModel = this.getView().getModel("resultFeild").getData()[i];
                   		var result = insResultFeildModel.value;
                    	 
               var saveTarewtHistoryModel = models.createNewJSONModel("com.khc.rephub.controller.quality.RepTareWtcheck_1-->saveTWResult-->XACQ_SaveTWHistory");
                            let saveTarewtHistoryParam = "Param.1=" + plant + "&Param.2=" + selectedRes + "&Param.3=" + selectedTareWT + "&Param.4=" + tw_desc + "&Param.5= " + "&Param.6=" + tw_Life + "&Param.7=" + tw_unit + "&Param.8=" + txt_method + "&Param.9=" + itemcount + "&Param.10=" + lowlmt1 + "&Param.11=" + uplmt1 + "&Param.12=" + txt_PlauseUnit + "&Param.13=" + resultavg + "&Param.14=" + result + "&Param.15=" + todayDateTime + "&d=" + dt;
                            saveTarewtHistoryModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_SaveTWHistory&"+saveTarewtHistoryParam+"&Content-Type=text/json", "", false);
                          }

                            let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0169");
                            MessageBox.success(msg, {  title: "Success", });
                            this.GetTareWthistory();
                        } else {
                            let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0165");
                            MessageBox.error(msg, {
                                title: "Error",
                            });
                        }
                    } else {
                        let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0167");
                        MessageBox.error(msg, {
                            title: "Error",
                        });
                    }

                } else {
                    let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0168");
                    MessageBox.error(msg, {
                        title: "Error",
                    });
                }

            },
/*************************************************************************************************************************************************************************************/
            checkAllNullBoxes: function(itemcount) {
                let status = false;
                for (var i = 0; i < itemcount; i++) {
                    var insResultFeildModel = this.getView().getModel("resultFeild").getData()[i];
                    var result = insResultFeildModel.value;
                    if (result == "") {
                        status = true;
                        //flexboxItem.addStyleClass("InspectionResulteValRejected")
                        this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "R");
                    } else {
                        this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "A");
                    }

                }
                return status;
            },
/*************************************************************************************************************************************************************************************/
            checkValuesWithinLimit: function(lowlmt1, uplmt1, itemcount) {
                let status = false;
		resultavg=0
                for (var i = 0; i < itemcount; i++) {
                    var insResultFeildModel = this.getView().getModel("resultFeild").getData()[i];
                    var result = insResultFeildModel.value;
                    if (Number(result) >= Number(lowlmt1) && Number(result) <= Number(uplmt1)) {
                        resultavg = parseFloat(resultavg) + parseFloat(result);
                        this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "A")
                    } else {
                        status = true;
                        this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "R");
                    }

                }
                return status;
            },
/*************************************************************************************************************************************************************************************/
            checkNaNValue: function(itemcount) {
                let status = false;
                for (var i = 0; i < itemcount; i++) {
                    var insResultFeildModel = this.getView().getModel("resultFeild").getData()[i];
                    var result = insResultFeildModel.value;
                    if (isNaN(result)) {
		  status = true;
                        this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "R")
                    } else {
                        this.getView().getModel("resultFeild").setProperty("/" + i + "/resulteval", "A");
                    }

                }
                return status;
            },
/*************************************************************************************************************************************************************************************/
//On page load, Set the resource
/**************************************************************************************************************************************************************************************/
            GetTareWthistory: function() {
                let selectedTareWT = this.getView().byId("txt_TWIDList").getSelectedKey();
               
               var getTWHistoryModel = models.createNewJSONModel("com.khc.rephub.controller.quality.RepTareWtcheck_1-->GetTareWthistory-->SQLQ_GetTareWtHistory");
                getTWHistoryModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetTareWtHistory&Param.1=" + selectedTareWT + "&Param.2=" + selectedRes + "&Param.3=" + plant + "&d=" + dt + "&Content-Type=text/json", "", false);
                this.getView().setModel(getTWHistoryModel, "oTWHistory")
            },
/*************************************************************************************************************************************************************************************/
 //On page load, Set the resource
/**************************************************************************************************************************************************************************************/

            createInputBoxes: function() {
                let count = this.getView().byId("txt_sample").getValue();
                var result = sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0105");
                this.getView().byId("ResultTxtLabel").setText(result + "   1 - " + count)
                var oresultData = [];
                for (var i = 1; i <= count; i++) {
                    var oDynamicData = {
                        value: "",
                        remark: "",
                        resulteval: "A",
                    }
                    oresultData.push(oDynamicData);
                }
                var oResultModel = new sap.ui.model.json.JSONModel(oresultData);
                this.getView().setModel(oResultModel, "resultFeild")

            },
/*************************************************************************************************************************************************************************************/
//On page load, Set the resource
/**************************************************************************************************************************************************************************************/
            checkValues:function(oEvent){
            	
            	let result=oEvent.getParameters().value;

           		if(result==""){
            	let enteredId =oEvent.getSource();
             		let SPath = enteredId.oBindingContexts.resultFeild.sPath + "/resulteval";
                                        this.getView().getModel("resultFeild").setProperty(SPath, "A");
            	}
            }
        });
    });