var resourceModel;
var dataValues;
var that = this;
var oTable;
var QnSelRow;
var SelRow;
var QnSelectedRow;
var insplot;
var Rowcount;
var matnum;
var InspMethod;
var resetChartType;
var MasterChar;
var ChartParam1;
var SubgroupSize;
var UpperCL;
var UpperUCL;
var UpperLCL;
var inspectionPointModel;
var updateData;
var js_FlagInspectPoint = 0;
var js_FlagOrderList = 0;
var oController;
sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/m/Button",
        "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility",
        "com/khc/rephub/model/formatter",
        "com/khc/rephub/model/models"
    ],
    function(Controller, Button, UI_utilities, CommonUtility, formatter, models) {

        "use strict";
        var plant;
        var resource;
        var resourceText;
        var projectName;
        var crdest;

        return Controller.extend("com.khc.rephub.controller.quality.InspMICViewResults", {
            formatter: formatter,
            onInit: function() {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("InspMICViewResults").attachPatternMatched(this._oRoutePatternMatched, this);
                oController = this;
            },

            _oRoutePatternMatched: function(oEvent) {

                UI_utilities.qualityPageOpened(this, "InspMICViewResults");
                // UI_utilities.qualityMenuBar();
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
		
             this.clearValues();
                this.getResources();

            },
	
	clearValues: function() 
	{
	   var oEmptyModel = new sap.ui.model.json.JSONModel();
              sap.ui.getCore().setModel(oEmptyModel, "InspectionPoint");
	  sap.ui.getCore().setModel(oEmptyModel, "InspectionPointM");
	  this.getView().byId("matDescription").setValue("");
             //  this.getView().byId("id_txt_inspLot").setModel("");
	  this.getView().byId("id_txt_inspLot").setValue("");
	 this.getView().byId("id_txt_order").setValue("");
	 this.getView().byId("id_txt_material").setValue("");
	 this.getView().byId("id_txt_matDesc").setValue("");
	     this.getView().byId("id_btn_showChart").setVisible(false);
	 this.getView().byId("id_btn_showGrid").setVisible(true);
	 this.getView().byId("InspectionMICViewResults_frameVbox").setVisible(false);
	 this.getView().byId("id_txt_dataPoint").setValue("");
	this.getView().byId("id_chk_ThisOrder").setSelected(false)
	},
	

            getResources: function() {

                var resourceVar = this.getView().byId("resource");



                resourceModel = models.createNewXMLModel("com.khc.rephub.controller.quality.InspMICViewResults-->getResources-->XACQ_GetResrByPlant");

                resourceModel.attachRequestCompleted(
                    function() {
                        if ($(resourceModel.getData()).find("Row").length > 0) {
                            resourceVar.setModel(resourceModel, "oresource");
                        }
                    });
                resourceModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetResrByPlant&Param.1=" + plant + "&d=" + new Date() + "&Content-Type=text/xml", "", false);


            },

            menuSelected: function(oEvent) {

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },

            onResourceSelect: function(oEvent) {
                var event = oEvent;

                this.getView().byId("matDescription").setValue(event.getParameters().selectedItem.oBindingContexts.oresource.getProperty("RESRTEXT"));
                resource = event.getParameters().selectedItem.oBindingContexts.oresource.getProperty("RESR");

                this.getRunningOrder()
            },

            getRunningOrder: function() {



                var runningOrderModel = models.createNewJSONModel("com.khc.rephub.controller.quality.InspMICViewResults-->getRunningOrder-->XACQ_GetRunningOrderOpenInsp");

                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=%";
                var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrderOpenInsp&" + params + "&Content-Type=text/json"
                runningOrderModel.loadData(encodeURI(url), "", false);

                if (CommonUtility.getJsonModelRowCount(runningOrderModel.getData()) > 0) {
                    dataValues = runningOrderModel.getData().Rowsets.Rowset[0].Row[0];

                    matnum = dataValues.MATNR;
                    if (dataValues.INSPLOT.length != 0) {
                        this.getView().byId("id_txt_inspLot").setValue(dataValues.INSPLOT)
                        this.getView().byId("id_txt_order").setValue(dataValues.MODORDERID);
                        this.getView().byId("id_txt_material").setValue(dataValues.MODMATNR);
                        this.getView().byId("id_txt_matDesc").setValue(dataValues.MATTEXT);
                    }
                    js_FlagOrderList = 1;
                    this.getPhaseTimes()
                }

            },


            getPhaseTimes: function() {



                inspectionPointModel = models.createNewJSONModel("com.khc.rephub.controller.quality.InspMICViewResults-->getPhaseTimes-->XACQ_SPCPhasedAggregateResults");

                var params = "Param.1=" + this.getView().byId("id_txt_inspLot").getValue() + "&Param.2=%";
                var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_SPCPhasedAggregateResults&" + params + "&Content-Type=text/json"
                inspectionPointModel.loadData(encodeURI(url), "", false);
                sap.ui.getCore().setModel(inspectionPointModel, "InspectionPoint");

            },

            getInspectionPoint: function() {


                oTable = this.getView().byId("id_phaseDueTimes");
                SelRow = oTable.getSelectedContextPaths().length;

                if (SelRow != 0) {
                    QnSelRow = oTable.getSelectedContextPaths()[0];
                    QnSelectedRow = this.getView().getModel("InspectionPoint").getProperty(QnSelRow);

                    var InspOpe = QnSelectedRow.InspectionOperation;
                    var Phase = QnSelectedRow.PhaseNo;
                    MasterChar = QnSelectedRow.MasterChar;
                    var DataPoints = QnSelectedRow.SamplingPoints;
                    this.getView().byId("id_txt_dataPoint").setValue(DataPoints)
                    var ThisOrderOnly = QnSelectedRow.ThisOrderOnly;
                    InspMethod = QnSelectedRow.InspMethod;
                    var InspReq = QnSelectedRow.InspReq;
                    var ResultType = QnSelectedRow.ResultType;
                    var UpperCalculateControlLimits = QnSelectedRow.UpperCalculateControlLimits;
                    var DynamicCL = QnSelectedRow.Dynamic_CL;
                    var DynamicLCL = QnSelectedRow.Dynamic_LCL;
                    var DynamicUCL = QnSelectedRow.Dynamic_UCL;
                    insplot = this.getView().byId("id_txt_inspLot").getValue();

                    if (ResultType == "SINGLE" && InspReq > 0) {

                        Rowcount = DataPoints * InspReq;
                        resetChartType = "XBAR-RANGE";
                        SubgroupSize = InspReq;

                    } else {

                        Rowcount = DataPoints;
                        resetChartType = "XBAR-MR";
                        SubgroupSize = "1";
                    }

                    if (UpperCalculateControlLimits == "1") {

                        UpperCL = DynamicCL;
                        UpperUCL = DynamicUCL;
                        UpperLCL = DynamicLCL;

                    } else {
                        UpperCL = "CL";
                        UpperUCL = "UCL";
                        UpperLCL = "LCL";

                    }

                    if (ThisOrderOnly == 0) {
                        ChartParam1 = "%";


                        var oInspectionPointModel = models.createNewJSONModel("com.khc.rephub.controller.quality.InspMICViewResults-->getInspectionPoint-->XACQ_ViewResult");

                        var params = "Param.1=%&Param.2=" + MasterChar + "&Param.3=" + resource + "&Param.4=" + DataPoints + "&Param.5=" + matnum + "&Param.6=" + plant;
                        var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_ViewResult&" + params + "&Content-Type=text/json"
                        oInspectionPointModel.loadData(encodeURI(url), "", false);
                        sap.ui.getCore().setModel(oInspectionPointModel, "InspectionPointM");
                    } else {

                        ChartParam1 = insplot;



                        var oInspectionPointModel = models.createNewJSONModel("com.khc.rephub.controller.quality.InspMICViewResults-->getInspectionPoint-->XACQ_ViewResult");

                        var params = "Param.1=" + insplot + "&Param.2=" + MasterChar + "&Param.3=" + resource + "&Param.4=" + DataPoints + "&Param.5=" + matnum + "&Param.6=" + plant;
                        var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_ViewResult&" + params + "&Content-Type=text/json"
                        oInspectionPointModel.loadData(encodeURI(url), "", false);
                        sap.ui.getCore().setModel(oInspectionPointModel, "InspectionPointM");
                    }


                    var ichartDataModel = new sap.ui.model.json.JSONModel();
                    let chartData = {
                        InspectionLot: insplot,
                        Masterchar: MasterChar,
                        Method: InspMethod,
                        Material: matnum,
                        Resource: resource,
                        Plant: plant,
                        Rowcount: DataPoints,
                        parent_page: "InspMICViewResults",
                    };
                    ichartDataModel.setData(chartData);
                    sap.ui.getCore().setModel(ichartDataModel, "ichartDataModelDisplay");


                }
                if (this.getView().byId("InspectionMICViewResults_frameVbox").getVisible() == true) {
                    this.showChart();
                }
                js_FlagInspectPoint = 1;
            },

            hideList: function() {
                this.getView().byId("id_phaseDueTimesVbox").setVisible(false);
                this.getView().byId("id_btn_showList").setVisible(true);
                this.getView().byId("id_btn_hideList").setVisible(false);

            },

            showList: function() {
                this.getView().byId("id_phaseDueTimesVbox").setVisible(true);
                this.getView().byId("id_btn_hideList").setVisible(true);
                this.getView().byId("id_btn_showList").setVisible(false);

            },

            showGrid: function() {

                this.getView().byId("InspectionMICViewResults_frameVbox").setVisible(false);
                this.getView().byId("id_inspectionPointsVbox").setVisible(true);
                this.getView().byId("id_btn_showGrid").setVisible(false);
                this.getView().byId("id_btn_showChart").setVisible(true);

            },

            updateChartSettings: function() {
                var dataP = this.getView().byId("id_txt_dataPoint").getValue();
                var thisOrder;
                //          var selectedTableRow= oTable.indexOfItem(oTable.getSelectedItem());

                var selectedTableRow = oTable.getSelectedContextPaths()[oTable.indexOfItem(oTable.getSelectedItem())]
                updateData = this.getView().getModel("InspectionPoint").getProperty(selectedTableRow);
                if (this.getView().byId("id_chk_ThisOrder").getSelected()) {
                    thisOrder = "1";
                } else {
                    thisOrder = "0";
                }


                var updateChartModel = models.createNewJSONModel("com.khc.rephub.controller.quality.InspMICViewResults-->updateChartSettings-->SQLQ_UpdateInspChar");

                updateChartModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_UpdateInspChar&Param.1=" + dataP + "&Param.2=" + thisOrder + "&Param.3=" + plant + "&Param.4=" + resource + "&Param.5=" + updateData.InspectionLot + "&Param.6=" + updateData.InspectionOperation + "&Param.7=" + updateData.PhaseNo + "&Content-Type=text/json", "", false);


                var params = "Param.1=" + this.getView().byId("id_txt_inspLot").getValue() + "&Param.2=%";
                var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_SPCPhasedAggregateResults&" + params + "&Content-Type=text/json"
                inspectionPointModel.loadData(encodeURI(url), "", false);
                sap.ui.getCore().setModel(inspectionPointModel, "InspectionPoint");

                this.getInspectionPoint()
            },
            /*********************************************************************************************************************************************************************/
            showChart: function() {

                this.getView().byId("id_inspectionPointsVbox").setVisible(false);
                this.getView().byId("InspectionMICViewResults_frameVbox").setVisible(true);
                this.getView().byId("id_btn_showGrid").setVisible(true);
                this.getView().byId("id_btn_showChart").setVisible(false);
                /*let sParams = "Param.1="+insplot+"&Param.2="+MasterChar+"&Param.3="+InspMethod+"&Param.4="+matnum+"&Param.5="+resource+"&Param.6="+plant+"&Param.7="+Rowcount+"&d="+new Date();
         
           
            var oModelChartDetails=  models.createNewJSONModel("com.khc.rephub.controller.quality.InspMICViewResults-->showChart-->XACQ_SPCQueryOutput_V1");

            oModelChartDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_SPCQueryOutput_V1&"+sParams+"&Content-Type=text/json", "", false);
            if (CommonUtility.getJsonModelRowCount(oModelChartDetails.getData()) > 0) {
               // load the irpt in iframe with the parameters, i%SPC is having issue with UI5 in Heinz system
               let sInspParams = "qs_insplot="+insplot+"&qs_masterchar="+MasterChar+"&qs_inspmethod="+InspMethod+"&qs_material="+matnum+"&qs_resource="+resource+"&qs_plant="+plant+"&qs_rowcount="+Rowcount+"&qs_chartType="+resetChartType+"&qs_subgroupsize="+SubgroupSize+"&qs_upperCL="+UpperCL+"&qs_upperUCL="+UpperUCL+"&qs_upperLCL="+UpperLCL+"&d="+new Date();
               var frame = this.getView().byId("InspectionMICViewResults_frame");
               var  oFrameContent = frame .$()[0];
               let sBaseURL = "/XMII/CM/RepHubUI5/webapp/irpt/InspMICViewResults_SPC.irpt?";
               oFrameContent.setAttribute("src", sBaseURL+sInspParams); 
            } else  {
               var sNoInspData = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoInspData);
                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
            }*/

                var c = new com.sap.xmii.chart.hchart.i5SPCChart(
                    "RepHubUI5/DisplayTemplate/SPC_InspAnalysisMRChart",
                    projectName + "/QueryTemplate/XACQ_SPCQueryOutput_V1");
                c.getQueryObject().setParameter("Param.1", ChartParam1);
                c.getQueryObject().setParameter("Param.2", MasterChar);
                c.getQueryObject().setParameter("Param.3", InspMethod);
                c.getQueryObject().setParameter("Param.4", matnum);
                c.getQueryObject().setParameter("Param.5", resource);
                c.getQueryObject().setParameter("Param.6", plant);
                c.getQueryObject().setParameter("Param.7", Rowcount);
                c.getChartObject().setChartType(resetChartType);
                c.getChartObject().setSubgroupSize(parseInt(SubgroupSize));
                c.getChartObject().setUpperCL(parseFloat(UpperCL));
                c.getChartObject().setUpperUCL(parseFloat(UpperUCL));
                c.getChartObject().setUpperLCL(parseFloat(UpperLCL));
                c.registerCreationEventHandler(this.spcLoaded);
                var oHtml = new sap.ui.core.HTML({
                    content: "<div id='spc_chart_content'>"
                });
                this.getView().byId("InspectionMICViewResults_frameVbox").addItem(oHtml);
                UI_utilities.setContainerBusyState(this, true);
                setTimeout(function() {
                    c.draw("spc_chart_content");
                }, 1000);
            },
            /** *********************************************************************************************************************************************************************************** */
            spcLoaded: function() {

                console.log("created");
                UI_utilities.setContainerBusyState(oController, false);

            },
        });
    });