sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/rephub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput",
		"com/khc/rephub/model/formatter",  "com/khc/rephub/model/models"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput, formatter, models) {
        "use strict";
        var plant='3101';
        var resource='W1P-LIN1';
        var projectName;
        var shiftname = '';
        var shiftId = '';
        var teamId = '';
        var shiftStartTime = '';
        var shiftEndTime = '';
        var oDownTimeData;
        var sDTStartDateFormatted;
        var userName;
        var crdest='D1';


        //from session
        var count = 0;
        var colorDark = "";
        var colorLight = "";
        var warning = "";
        var warning = "";
        var js_FlagPhasesNextTime = 0;
        var js_FlagInspectPoint = 0;
        var js_FlagOrderList = 0;

        var js_LoopCount = 0;

        //for hidden Variable
        var InspectPoint;
        var txt_Mat;
        var crid;
        var txt_Ord;


        return Controller.extend("com.khc.rephub.controller.quality.RepInspectPointViewer", {
            formatter: formatter,
            onInit: function() {
           this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
             this._oRouter.getRoute("RepInspectPointViewer").attachPatternMatched(this._oRoutePatternMatched, this);

                var oInscPointRoute = {
                    	qs_phs: '',
                    	qs_currenttime:""
                };
                var oInscPointRouteModel = new sap.ui.model.json.JSONModel(oInscPointRoute);
                sap.ui.getCore().setModel(oInscPointRouteModel, "InspectionPointRoute");
            },
            _oRoutePatternMatched: function(oEvent) {

            UI_utilities.qualityPageOpened(this, "RepInspectPointViewer");
 UI_utilities.qualityMenuBar();
                var oInsPointData = {
                    orderId: '',
                    crid: '',
                    ButtonResult: true
                };
                var oInsPointModel = new sap.ui.model.json.JSONModel(oInsPointData);
                sap.ui.getCore().setModel(oInsPointModel, "InsPointDetails");



                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

             //   this.getRunningShift();

                // this.checkApplet();
                this.getRunningOrder();
                //Set session row from route
	if(sap.ui.getCore().getModel("RepInspectionPointViewerRoute") != undefined) {
                this.selectSessionPhase();
	}
            },
            menuSelected : function (oEvent) {
        	
			// Navigate the the selected menu page
			
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
			
     		   },

	onHelp:function(){

		UI_utilities.OpenHelpFileSingle("Resultentry");
	},

            getRunningOrder: function() {
            	//getOrder Details count
	    var that = this;
               var oModelRunningOrder = models.createNewJSONModel("com.khc.rephub.controller.quality.RepInspectPointViewer-->getRunningOrder-->XACQ_GetRunningOrderOpenInsp");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                oModelRunningOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrderOpenInsp&" + params + "&Content-Type=text/json", "", false);
                if (oModelRunningOrder.getData().Rowsets.Rowset[0].Row != undefined) {
                	var OrerForInsp = oModelRunningOrder.getData().Rowsets.Rowset[0].Row[0];
                    var orderCount = oModelRunningOrder.getData().Rowsets.Rowset[0].Row.length;
                    
                    if (orderCount != 0) {
                        that.getView().byId("id_txt_ordstrip").setValue(OrerForInsp.MODORDERID);
                        txt_Ord = OrerForInsp.ORDERID;
                        crid = OrerForInsp.CRID;
                        txt_Mat = OrerForInsp.MATNR;
                        that.getView().byId("id_txt_matstrip").setValue(OrerForInsp.MODMATNR);
                        that.getView().byId("id_txt_mattext").setValue(OrerForInsp.MATTEXT);
                        var inSplot = OrerForInsp.INSPLOT;
                        that.getView().byId("id_txt_insplot").setValue(inSplot);
                        var insporder = OrerForInsp.ORDERID;
                       
               var oOrderListModel = models.createNewJSONModel("com.khc.rephub.controller.quality.RepInspectPointViewer-->getRunningOrder-->XACQ_GetRunningOrder");
                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                        oOrderListModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrder&" + params + "&Content-Type=text/json", "", false);

                        if (oOrderListModel.getData().Rowsets.Rowset[0].Row != undefined) {
                        	var OrerForInsp = oOrderListModel.getData().Rowsets.Rowset[0].Row;

                            var runningorder = OrerForInsp.ORDERID;
                            if (runningorder != "") {
                                if (runningorder != insporder) { 
                                	var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0122");
                                	sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                                	sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                	sap.ui.getCore().getModel("oMessage").setProperty("/type", "Warning");
                                }
                            }
                        }
                        
                        var date = CommonUtility.getCurrentDateTime(new Date());
                      //getOrder Details count
                        
               var oPhasesNextTime = models.createNewJSONModel("com.khc.rephub.controller.quality.RepInspectPointViewer-->getRunningOrder-->XACQ_GetPhaseNextTime");
                        var params = "Param.1=" + inSplot + "&Param.2=" + insporder + "&Param.3=" + plant + "&Param.4=" + resource + "&Param.5=" + date + "&Param.6=" + crdest;
                        oPhasesNextTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetPhaseNextTime&" + params + "&Content-Type=text/json", "", false);

                        if (oPhasesNextTime.getData().Rowsets.Rowset[0].Row != undefined) {
                            var OrerForInsp = oPhasesNextTime.getData().Rowsets.Rowset[0].Row[0];
                     
                            this.getView().setModel(oPhasesNextTime, "PhasesNextTime");
                        }
                        
                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0020"));
                        that.getView().getModel("InsPointDetails").setProperty("/ButtonResult", false);

                    }
                }
            },

            getTodayDate: function() {

                var that = this;
                var SelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths().length;

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                    var phase = NtSelectedRow.Phase;
                    if (phase != "") {
                        var currentDT = CommonUtility.getCurrentDateTime(new Date());


                        var js_insplot = that.getView().byId("id_txt_insplot").getValue();
						var AddInspPoint = models.createNewJSONModel("com.khc.rephub.controller.quality.RepInspectPointViewer-->getTodayDate-->SQLQ_InsInspectPoint");

                        var params = "Param.2=" + "NA" + "&Param.3=" + js_insplot + "&Param.4=" + phase + "&Param.6=" + currentDT +
                            "&Param.10=0&Param.11=" + plant + "&Param.12=" + resource + "&Param.13=" + "0";

                        AddInspPoint.attcheReques
                        AddInspPoint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsInspectPoint&" + params + "&Content-Type=text/json", "", false);

                        //getOrder Details count
						var InspectPointList = models.createNewJSONModel("com.khc.rephub.controller.quality.RepInspectPointViewer-->getTodayDate-->XACQ_GetInspectionPoints");
                        var insplot = that.getView().byId("id_txt_insplot").getValue();
                        var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource;
                        InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
                        this.getView().setModel(InspectPointList, "InspectPointList");


                        //document.APLT_GRI_InspectPoint.getGridObject().setSelectedRow(1);
                        this.getView().byId("id_table_InspectPoint").setSelectedItem(this.getView().byId("id_table_InspectPoint").getItems()[0])

                        this.openSPCCharts();

                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0049"));

                    }


                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0049"));

                }

            },
            
            // **** Populates the inspection points in APLT_GRI_InspectPoint taken from HNZ_INSPPOINT table based on phase selected in APLT_CMD_GetPhasesNextTime Grid

            GetInspectPoints: function() {

                var that = this;
                var SelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths().length;

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                    var phase = NtSelectedRow.Phase;
                    var insStatus = '';

                    //getOrder Details count
					var InspectPointList = models.createNewJSONModel("com.khc.rephub.controller.quality.RepInspectPointViewer-->GetInspectPoints-->XACQ_GetInspectionPoints");
                    var insplot = that.getView().byId("id_txt_insplot").getValue();
                    var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource;
                    InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
                    this.getView().setModel(InspectPointList, "InspectPointList");
                    
                    if (InspectPointList.getData().Rowsets.Rowset[0].Row != undefined) {

                        InspectPoint = InspectPointList.getData().Rowsets.Rowset[0].Row;
                        this.getView().setModel(InspectPointList, "InspectPointList");
                        
                    }
                   
                }


            },
            
            
// **** Redirect to InspectResultSubmitViewer page for selected inspection point and pass required value via query string

            openSPCCharts: function() {

                var PhasesNTSelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths().length;
                var InspectPointSelRow = this.getView().byId("id_table_InspectPoint").getSelectedContextPaths().length;


                if (InspectPointSelRow != 0) {

                    var IpSelRow = this.getView().byId("id_table_InspectPoint").getSelectedContextPaths()[0];
                    var IpSelectedRow = this.getView().getModel("InspectPointList").getProperty(IpSelRow);

                    var NTSelRow = this.getView().byId("id_table_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NTSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(NTSelRow);

                    var InsDateTime = IpSelectedRow.Time;


                    if (InsDateTime != "") {
                        var currentDT = CommonUtility.getCurrentDateTime(new Date());



                        var js_date = IpSelectedRow.InsDate;
                        var js_time = IpSelectedRow.InsTime;
                        var js_currenttime = IpSelectedRow.InsDateTime;

                        var js_phs = NTSelectedRow.Phase;
                        var js_phstxt = NTSelectedRow.PhaseText;
                        //var js_currenttime = NTSelectedRow.Time;


                        var js_stdkey = NTSelectedRow.StdTextKey;



                        var js_mat = txt_Mat;
                        var js_ord = txt_Ord;

                        var js_matdesc =this.getView().byId("id_txt_mattext").getValue();
                        var js_insplot =this.getView().byId("id_txt_insplot").getValue();
                        var js_matstrip =this.getView().byId("id_txt_matstrip").getValue();
                        var js_ordstrip = this.getView().byId("id_txt_ordstrip").getValue();


                        var incResSubmitModel = new sap.ui.model.json.JSONModel();
                        let sID = {
                            qs_insplot: js_insplot,
                            qs_mat: js_mat,
                            qs_matdesc: js_matdesc,
                            qs_ord: js_ord,
                            qs_phs: js_phs,
                            qs_date: js_date,

                            qs_time: js_time,
                            qs_currenttime: js_currenttime,
                            qs_matstrip: js_matstrip,
                            qs_ordstrip: js_ordstrip,
                            qs_phstxt: js_phstxt,
                            qs_ccpsign: js_stdkey,
		     parent_page : "RepInspectPointViewer",
                        };
                        incResSubmitModel.setData(sID);
                        sap.ui.getCore().setModel(incResSubmitModel, "InspectResultSubmitViewerModel");

                        UI_utilities.setContainerBusyState(this, true);
                        //ID is Mandatory parameter in the routing, to find the model path in start phase screen
                       // this._oRouter.navTo("InspectResultSubmitViewer", {
                      //      ID: "InspectResultSubmitViewer"
                      //  });
		 this._oRouter.navTo("InspectResultSubmitViewer");


                        /*   window.location.href = "InspectResultSubmitViewer.irpt?qs_insplot="+
                         * js_insplot+"&qs_mat="+js_mat+"&qs_matdesc="+js_matdesc+"&qs_ord="+
                         * js_ord+"&qs_phs="+js_phs+"&qs_date="+js_date+"&qs_time="+js_time+
                         * "&qs_currenttime="+js_currenttime+"&qs_matstrip="+js_matstrip+
                         * "&qs_ordstrip="+js_ordstrip+"&qs_phstxt="+js_phstxt;
					*/

                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0051"));
                    }

                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0050"));

                }
            },

/************************To keep the prviously selected data intact when one clicks Back button from InspectResultSubmitViewer Page**************************************************/

 selectSessionPhase: function() {
                var qs_phs = sap.ui.getCore().getModel("RepInspectionPointViewerRoute").oData.qs_phs;
                if (qs_phs != "") {

                    if (this.getView().getModel("PhasesNextTime").getData() != null) {
                        this.GetInspectPoints();
                        var ChkCount = this.getView().getModel("PhasesNextTime").getData().Rowsets.Rowset[0].Row.length;

                        for (var i = 0; i < ChkCount; i++) {
                            var oPhaseNetTime =this.getView().getModel("PhasesNextTime").getData().Rowsets.Rowset[0].Row;


                            if (oPhaseNetTime[i].Phase == qs_phs) {
                                this.getView().byId("id_table_GetPhasesNextTime").setSelectedItem(this.getView().byId("id_table_GetPhasesNextTime").getItems()[i]);
                                this.GetInspectPoints();
                                break;
                            }
                        }

                        if (this.getView().getModel("InspectPointList").getData() != null) {

                            var currenttime = this.getView().getModel("RepInspectionPointViewerRoute").oData.qs_currenttime;
                            var insCount = this.getView().getModel("InspectPointList").getData().Rowsets.Rowset[0].Row.length;
                            for (var i = 0; i < insCount; i++) {
                                var insList = this.getView().getModel("InspectPointList").getData().Rowsets.Rowset[0].Row;

                               
                                if (insList[i].InsDateTime == currenttime) {
                                    var OInsTable = this.getView().byId("id_table_InspectPoint");
                                    OInsTable.setSelectedItem(OInsTable.getItems()[i]);

                                   
                                    break;
                                }
                            }
                        }

                    }
                }

            }

});
});