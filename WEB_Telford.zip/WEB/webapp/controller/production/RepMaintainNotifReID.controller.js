sap.ui.define( [ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
                  "sap/m/MessageBox",
                  "com/khc/rephub/utils/UI_utilities",
                  "com/khc/common/Script/CommonUtility","com/khc/rephub/model/models" ],
            function(Controller, Filter, MessageBox, UI_utilities, CommonUtility,models) {
   "use strict";
  
   var plant;
   var resource;
   var projectName;
   var userName;
   var crDest;
   var equiCode='';
   var MNId='';
   var orderId='';
   var CRId='';
   var matNo='';
   var lead='';
   var teamName='';
   var shiftStartTime='';
   var shiftEndTime='';
   var oStatusRadioMap;
   var oWhenBreakdownRadioMap;
   var oOccuranceRadioMap;
   var oPriorityRadioMap;
   var oFixedRadioMap;
   var selected_LinkResr_breakdown='';
   var selected_FuncLoc_breakdown='';
   var selected_Equipment_breakdown='';
   var selected_LinkResr_corrective='';
   var selected_FuncLoc_corrective='';
   var selected_Equipment_corrective='';
   var selected_MN = 0;
   
   
   var shiftname = '';
   var shiftId = '';
   var teamId = '';
   var oDownTimeData;
   var sDTStartDateFormatted;
   

return Controller.extend("com.khc.rephub.controller.production.RepMaintainNotifReID", {
      onInit: function() {
         
         
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         this._oRouter.getRoute("maintenanceNotification").attachPatternMatched(this._oRoutePatternMatched, this);
         
         oStatusRadioMap = {
               "0" : "Breakdown",
               "1" : "Corrective",
               "-1" : ""
         };
         
         oWhenBreakdownRadioMap = {
               "0" : "During continuous running",
               "1" : "After Start Up",
               "2" : "After Change Over",
               "3" : "After Maintenance",
               "4" : "After other breakdown",
               "-1" : ""
         };
         
         oOccuranceRadioMap = {
               "0" : "Once",
               "1" : "Rarely",
               "2" : "Intermittently",
               "3" : "Frequently",
               "4" : "Continually",
               "-1" : ""
         };
         
         oFixedRadioMap = {
               "0" : "During Production",
               "1" : "During Changeover/Cleaning",
               "2" : "During Machine stop",
               "3" : "During factory shutdown",
               "-1" : ""
         };
         
         oPriorityRadioMap = {
               "0" : "Emergency (0-24H)",
               "1" : "Critical (1-7D)",
               "2" : "High (8-14D)",
               "3" : "Medium (15-30D)",
               "4" : "Low (31-90D)",
               "-1" : ""
         };
         
         oFixedRadioMap = {
               "0" : "During Production",
               "1" : "During Changeover/Cleaning",
               "2" : "During Machine stop",
               "3" : "During factory shutdown",
               "-1" : ""
         };
         
         
      
      },
      _oRoutePatternMatched: function(oEvent) {
         
        
         UI_utilities.maintenancePageOpened(this,"maintenanceNotification");
         UI_utilities.DisableDatePickerInput(this.getView().byId("txt_date"));
         UI_utilities.DisableDatePickerInput(this.getView().byId("txt_Enddate"));
         
         plant=sap.ui.getCore().getModel("session").oData.CA_Plant;
         resource=sap.ui.getCore().getModel("session").oData.CA_Resource;
         projectName=sap.ui.getCore().getModel("session").oData.CA_ProjectName;
         userName=sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
         crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

         var oMaintData = {
               corrective : false,
               showNotification : false,
               backToLineStatus: false,
         };
         var oMaintModel = new sap.ui.model.json.JSONModel(oMaintData);
         this.getView().setModel(oMaintModel,"maintenance");
         
         //this.getEquipment();
         this.getLinkedResourceForDTReason();
         this.getOrderDetails();
         //this.prepareChart();
         this.ClearAll();
         
         
      },
      
      
      // Navigate the the selected menu page
      menuSelected : function (oEvent) {
         
         var sKey = oEvent.getParameters().key;
         UI_utilities.openMenu(this._oRouter,this,sKey);
         
        },
onAfterRendering: function() {


},

backtoLinestatus: function() {
   this._oRouter.navTo("lineStatus");
},

/**************************************************************************************************************************************************************************************/
   //To open the help document
/*****************************************************************************************************************************************************************************************/  
onHelp:function(){

   UI_utilities.OpenHelpFileSingle("Mn");
},

/**************************************************************************************************************************************************************************************/
   //Hide notification list table
/*****************************************************************************************************************************************************************************************/  
hideNotification : function(){
         
   this.getView().getModel("maintenance").setProperty("/showNotification",false);
},

/**************************************************************************************************************************************************************************************/
   //Show notification list table
/*****************************************************************************************************************************************************************************************/     
showNotification : function(){
         
   this.getView().getModel("maintenance").setProperty("/showNotification",true); 
   this.getMaintNotifDetails();
},

/**************************************************************************************************************************************************************************************/
   //Show corrective related form fields
/*****************************************************************************************************************************************************************************************/     
showCorrective : function(){
         
   this.getView().getModel("maintenance").setProperty("/corrective",true); 
   //this.getMaintNotifDetails();
},

/**************************************************************************************************************************************************************************************/
   //Show breakdown related form fields
/*****************************************************************************************************************************************************************************************/     
showBreakDown  : function(){
         
   this.getView().getModel("maintenance").setProperty("/corrective",false);      
},

/**************************************************************************************************************************************************************************************/
   //on Load get the Down Time for maintenance
/*****************************************************************************************************************************************************************************************/  
checkOpenDT: function(){
   
   var oModelDowntimeForMN=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->checkOpenDT-->SQLQ_GetDownTimeForMN");
   oModelDowntimeForMN.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetDownTimeForMN&Param.1="+plant+"&Param.2="+resource+"&Content-Type=text/json", "", false);
   this.getView().setModel(oModelDowntimeForMN,"oDowntimeForMN");
   
   
   if(CommonUtility.getJsonModelRowCount(oModelDowntimeForMN.getData())!= 0) {
      var oDowntimeForMNData = oModelDowntimeForMN.getData().Rowsets.Rowset[0].Row[0];
      /**
       * TO-DO
       */
      //document.getElementById("id_btn_back").style.display='block'; 
   
      equiCode = oDowntimeForMNData.REASON;
      MNId = oDowntimeForMNData.MNID;
      this.getView().byId("id_ta_Notes1").setValue("");
      this.getView().getModel("maintenance").setProperty("/backToLineStatus",true);
   }
	
else{
	equiCode="";
	MNId="";
}
   var linkedResourceForDTReason = this.getView().getModel("oLinkedResourceForDTReason");
   if(CommonUtility.getJsonModelRowCount(linkedResourceForDTReason.getData()) == 1 ) {
      
      var sKey = linkedResourceForDTReason.getData().Rowsets.Rowset[0].Row[0].LINKRESR;
      this.getView().byId("id_dropdown_linkresc").setSelectedKey(sKey);
      
      this.getEquipment();
   }
   
},

/**************************************************************************************************************************************************************************************/
//on Load get Linked Resource For DT Reason
/*****************************************************************************************************************************************************************************************/  
getLinkedResourceForDTReason: function(){
   
   var oModelLinkedResourceForDTReason=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getLinkedResourceForDTReason-->SQLQ_GetLinkedResourceForDTReason");

   //oModelLinkedResourceForDTReason.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetLinkedResourceForDTReason&Param.1="+plant+"&Param.2="+resource+"&Param.3=%"+"&Content-Type=text/json", "", false);
   var url = "/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetLinkedResourceForDTReason&Param.1="+plant+"&Param.2="+resource+"&Param.3=%"+"&Content-Type=text/json";
   oModelLinkedResourceForDTReason.loadData(encodeURI(url) , "", false);   
   this.getView().setModel(oModelLinkedResourceForDTReason,"oLinkedResourceForDTReason");
   if(CommonUtility.getJsonModelRowCount(oModelLinkedResourceForDTReason.getData()) > 0) {
         var sKey = oModelLinkedResourceForDTReason.getData().Rowsets.Rowset[0].Row[0].LINKRESR;
          this.getView().byId("id_dropdown_linkresc").setSelectedKey(sKey);
      }
},

/**************************************************************************************************************************************************************************************/
//get functional location
/*****************************************************************************************************************************************************************************************/  
/*getFunctionalLocation: function(sParams) {
   
   this.getView().byId("id_dropdown_fun").setValue("");
  
   var oModelGetFunctionLocation=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getFunctionalLocation-->SQLQ_GetFuncLocByEquipmentTypeRelD");

   oModelGetFunctionLocation.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetFuncLocByEquipmentTypeRelD&"+sParams+"&Content-Type=text/json", "", false);
   this.getView().setModel(oModelGetFunctionLocation,"oGetFunctionLocation");
   
   return oModelGetFunctionLocation;
},*/

/**************************************************************************************************************************************************************************************/
//get order details
/*****************************************************************************************************************************************************************************************/  
getOrderDetails: function(){
			var oShiftTeamDetails;

			var oModelOderDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getOrderDetails-->XACQ_GetRunningOrder");

			oModelOderDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetRunningOrder&Param.1="+plant+"&Param.2="+resource+"&Param.3="+crDest+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelOderDetails,"oOderDetails");
			var TodayDate = CommonUtility.getCurrentDateTime(new Date());
			this.getView().byId("txt_date").setValue(TodayDate);
			if(CommonUtility.getJsonModelRowCount(oModelOderDetails.getData()) > 0) {
				var oOrderData = oModelOderDetails.getData().Rowsets.Rowset[0].Row[0];
				orderId = oOrderData.ORDERID;
				CRId = oOrderData.CRID;
				matNo = oOrderData.MATNR;

				this.getView().byId("txt_GoodDesc").setValue(oOrderData.MATTEXT);
				this.getView().byId("txt_OrdNoStrip").setValue(oOrderData.ORDERSTRIP);
				this.getView().byId("txt_MatNostrip").setValue(oOrderData.MATNRSTRIP);
			}
			else{

				this.getView().byId("txt_GoodDesc").setValue("");
				this.getView().byId("txt_OrdNoStrip").setValue("");
				this.getView().byId("txt_MatNostrip").setValue("");
				this.getView().byId("txt_shift").setValue("");
			}
			// Load the data for functional location drop down
			//   var sParams = "Param.1="+plant+"&Param.2="+resource;
			// var oModelGetFunctionLocation = this.getFunctionalLocation(sParams);


			this.getRunningShiftDetails();
			var runningShiftDetails = this.getView().getModel("oRunningShiftDetails");
			if(CommonUtility.getJsonModelRowCount(runningShiftDetails.getData()) > 0) {
				var oRunningShiftData = runningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
				this.getView().byId("txt_shift").setValue(oRunningShiftData.SHIFTNAME);
				shiftStartTime = oRunningShiftData.STARTTIME;
				shiftEndTime = oRunningShiftData.ENDTIME;
				lead = oRunningShiftData.LEAD;
				teamName = oRunningShiftData.TEAMNAME;

				oShiftTeamDetails = {
						Lead : lead,
						TeamName : teamName,
						RaisedBy : userName
				};
				var oShiftData = new sap.ui.model.json.JSONModel(oShiftTeamDetails);
				this.getView().setModel(oShiftData,"oShiftTeamData");

			} else {
				var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
				sap.ui.getCore().getModel("oMessage").setProperty("/message",sNoShiftMsg);
				sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
				sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
				this.getView().byId("id_btn_addnew").setEnabled(false); 
				this.getView().byId("id_btn_update").setEnabled(false); 
				this.getView().byId("id_btn_clear").setEnabled(false);  
			}
			this.checkOpenDT();
			this.getMaintNotifDetails();



		},

/**************************************************************************************************************************************************************************************/
//Get Maintenance Notification list
/*****************************************************************************************************************************************************************************************/  
getMaintNotifDetails: function(){
 
   var oModelMaintNotifDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getMaintNotifDetails-->XACQ_GetMaintNotV1");

   oModelMaintNotifDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetMaintNotV1&Param.1="+resource+"&Param.2="+plant+"&Content-Type=text/json", "", false);
   this.getView().setModel(oModelMaintNotifDetails,"oMaintNotifDetails");
},

/**************************************************************************************************************************************************************************************/
//Get Running Shift
/*****************************************************************************************************************************************************************************************/  
getRunningShiftDetails: function(){
  
   var oModelRunningShiftDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getRunningShiftDetails-->XACQ_GetRunningShift");

   oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetRunningShift&Param.1="+plant+"&Param.2="+resource+"&Content-Type=text/json", "", false);
   this.getView().setModel(oModelRunningShiftDetails,"oRunningShiftDetails");
},

/**************************************************************************************************************************************************************************************/
//Prepare Long text
/*****************************************************************************************************************************************************************************************/  
prepLongText: function(){
   var LText;
   //Fetch the index of the selected radio button. Use the index to fetch the selected button's text value from the map created above.
   var iRadioSelectedIndex =  this.getView().byId("StatusRadio").getSelectedIndex();
   var sStatusRadio = oStatusRadioMap[iRadioSelectedIndex.toString()];
   
   if(sStatusRadio === "Breakdown") {
      var iWhenRadioIndex = this.getView().byId("WhenBreakdownRadio").getSelectedIndex();
      var sWhenBreakdownRadioValue = oWhenBreakdownRadioMap[iWhenRadioIndex.toString()];
      LText = "|"+this.getView().byId("id_lbl_Notes1").getText()+"| "+this.getView().byId("id_ta_Notes1").getValue()
      +"  |"+this.getView().byId("id_lbl_Notes2").getText()+"| "+this.getView().byId("id_ta_Notes2").getValue()
      +"  |"+this.getView().byId("id_lbl_Notes3").getText()+"| "+this.getView().byId("id_ta_Notes3").getValue()
      +"  |"+this.getView().byId("id_lbl_WhenRadio").getText()+"| "+ sWhenBreakdownRadioValue
      +"  | "+this.getView().byId("id_lbl_Notes4").getText()+" : | "+this.getView().byId("id_ta_Notes4").getValue()
      +"  | "+this.getView().byId("id_lbl_Team").getText()+" : | "+this.getView().byId("txt_Team").getValue()
      +"  |"+this.getView().byId("id_lbl_Lead").getText()+" : | "+this.getView().byId("txt_Lead").getValue()
      +"  |"+this.getView().byId("id_lbl_User").getText()+" : | "+this.getView().byId("txt_User").getValue()
      +"  |"+this.getView().byId("id_lbl_Notes5").getText()+"| "+this.getView().byId("id_ta_Notes5").getValue();
   } else {
      var iOccuranceRadioIndex = this.getView().byId("OccuranceRadio").getSelectedIndex();
      var sOccuranceRadioText = oOccuranceRadioMap[iOccuranceRadioIndex.toString()];
      
      var iPriorityRadioIndex = this.getView().byId("PriorityRadio").getSelectedIndex();
      var sPriorityRadioText = oPriorityRadioMap[iPriorityRadioIndex.toString()];
      
      var iFixedRadioIndex = this.getView().byId("FixedRadio").getSelectedIndex();
      var sFixedRadioText = oFixedRadioMap[iFixedRadioIndex.toString()];
      
      LText = "|"+this.getView().byId("id_lbl_Notes1").getText()+"| "+this.getView().byId("id_ta_Notes1").getValue()+
      "  |"+this.getView().byId("id_lbl_Notes2").getText()+"| "+this.getView().byId("id_ta_Notes2").getValue()+
      "  |"+this.getView().byId("id_lbl_Priority").getText()+"| "+sPriorityRadioText+
      "  |"+this.getView().byId("id_lbl_Notes3").getText()+"| "+this.getView().byId("id_ta_Notes3").getValue()+
      "  |"+this.getView().byId("id_lbl_Occurance").getText()+"| "+sOccuranceRadioText+
      "  |"+this.getView().byId("id_lbl_fixed").getText()+"| "+sFixedRadioText+
      "  |"+this.getView().byId("id_lbl_Notes4").getText()+"| "+this.getView().byId("id_ta_Notes4").getValue()+
      "  |"+this.getView().byId("id_lbl_Team").getText()+"| "+this.getView().byId("txt_Team").getValue()+
      "  |"+this.getView().byId("id_lbl_Lead").getText()+"| "+this.getView().byId("txt_Lead").getValue()+
      "  |"+this.getView().byId("id_lbl_User").getText()+"| "+this.getView().byId("txt_User").getValue()+
      "  |"+this.getView().byId("id_lbl_Notes5").getText()+"| "+this.getView().byId("id_ta_Notes5").getValue()
      
   }

   return LText;
},

/**************************************************************************************************************************************************************************************/
//Populate the Equipment list by Resource
/*****************************************************************************************************************************************************************************************/  
getEquipmentByResr : function(){
   
   var oModelEquipmentByResrDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getEquipmentByResr-->SQLQ_GetEquipmentByResr");

   oModelEquipmentByResrDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetEquipmentByResr&Param.1="+plant+"&Param.2="+resource+"&Content-Type=text/json", "", false);
   this.getView().setModel(oModelEquipmentByResrDetails,"oEquipmentByResrDetails");
},


/**************************************************************************************************************************************************************************************/
//Populate the Equipment list for Breakdown type (Z2) notification
/*****************************************************************************************************************************************************************************************/  
getEquipment: function(){
let selectedResource;
      if(selected_MN == "0"){
         selectedResource=this.getView().byId("id_dropdown_linkresc").getSelectedKey();
      } else {
         selectedResource = selected_LinkResr_breakdown;
      }
    
      var oModelEquipmentByResrDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getEquipment-->SQLQ_GetEquipmentByResr");

      oModelEquipmentByResrDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetEquipmentByResr&Param.1="+plant+"&Param.2="+selectedResource+"&Content-Type=text/json", "", false);
      this.getView().setModel(oModelEquipmentByResrDetails,"oEquipmentByResrDetails");
      
   /*   if(selected_MN == "0")
      {
         //var oModelGetFunctionLocation = new sap.ui.model.json.JSONModel();
         //oModelGetFunctionLocation.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetFuncLocByEquipmentTypeRelD&Param.1="+""+"&Param.2="+""+"&Param.3="+""+"&Content-Type=text/json", "", false);
         //this.getView().setModel(oModelGetFunctionLocation,"oGetFunctionLocation");
         // Load the data for functional location drop down
         var sParams = "Param.1="+""+"&Param.2="+""+"&Param.3=";
         var oModelGetFunctionLocation = this.getFunctionalLocation(sParams);
      }*/
         
},

/**************************************************************************************************************************************************************************************/
//on select of a Notification it populate the detail in respective fields based on notification type.
//Read the value stored in HNZ_MAINTNOT-ELEMENTTEXT field for that notification and split it according to notif type and populate in fields.
/*****************************************************************************************************************************************************************************************/  
setSelRow: function() {
   this.getView().byId("id_btn_addnew").setEnabled(false);
   this.getView().byId("id_btn_update").setEnabled(true);
   this.getView().byId("id_btn_clear").setEnabled(true);
   
   
   var aSelectedRowPath = this.getView().byId("id_tbl_maintNotif").getSelectedContextPaths();
   selected_MN = 1;
   var oMaintNotifDetailsModel = this.getView().getModel("oMaintNotifDetails");
   if(aSelectedRowPath.length > 0) {
      let sPath = aSelectedRowPath[0];
      var type_desc = oMaintNotifDetailsModel.getProperty(sPath+'/MNTYPEDESC');
      var linkresc = oMaintNotifDetailsModel.getProperty(sPath+'/LINKEDRESC');
      selected_Equipment_breakdown = oMaintNotifDetailsModel.getProperty(sPath+'/EQUITYPE');
      selected_FuncLoc_breakdown = oMaintNotifDetailsModel.getProperty(sPath+'/FUNCLOC');
      selected_LinkResr_breakdown = linkresc;
      
      this.getView().byId("id_dropdown_linkresc").setSelectedKey(linkresc);
      this.getEquipment();
      this.getView().byId("id_dropdown_equi").setSelectedKey(selected_Equipment_breakdown);
      this.getFuncLocByEquipment();
      this.getView().byId("id_dropdown_fun").setSelectedKey(selected_FuncLoc_breakdown);
      
      var bdElementArray = new Array();
      bdElementArray = oMaintNotifDetailsModel.getProperty(sPath+'/ELEMENTTEXT').split('|');

      this.getView().byId('id_ta_Notes1').setValue(bdElementArray[0]);
      this.getView().byId('id_ta_Notes2').setValue(bdElementArray[1]);
      this.getView().byId('id_ta_Notes3').setValue(bdElementArray[2]);
      this.getView().byId('id_ta_Notes4').setValue(bdElementArray[4]);
      
      if(type_desc === "Breakdown")
      {
         this.showBreakDown();
         this.getView().byId("StatusRadio").setSelectedIndex(0);
         this.getView().byId('id_ta_Notes5').setValue(bdElementArray[7]);

         this.getView().byId("txt_User").setValue(bdElementArray[8]);
         this.getView().byId("txt_Team").setValue(bdElementArray[5]);
         this.getView().byId("txt_Lead").setValue(bdElementArray[6]);
         this.getView().byId("txt_Enddate").setValue(bdElementArray[9]);

         this.getView().byId("txt_date").setValue(oMaintNotifDetailsModel.getProperty(sPath+'/NOTIFTIME'));
         
         var whenRadioValue = this.getView().byId("WhenBreakdownRadio").getSelectedIndex();
         if(oWhenBreakdownRadioMap[whenRadioValue.toString()] === bdElementArray[3]) {
            this.getView().byId("WhenBreakdownRadio").setSelectedIndex(whenRadioValue);
         }

for(var i=0; i<=4;i++) {
   if(bdElementArray[3] === oWhenBreakdownRadioMap[i]){
      this.getView().byId("WhenBreakdownRadio").setSelectedIndex(i);
      break;
}
}
         
      } else {
         this.showCorrective();
         this.getView().byId("StatusRadio").setSelectedIndex(1);
         this.getView().byId('id_ta_Notes5').setValue(bdElementArray[5]);

         this.getView().byId("txt_User").setValue(bdElementArray[6]);
         this.getView().byId("txt_Team").setValue(bdElementArray[9]);
         this.getView().byId("txt_Lead").setValue(bdElementArray[10]);

         this.getView().byId("txt_date").setValue(oMaintNotifDetailsModel.getProperty(sPath+'/NOTIFTIME'));
         
for(var i=0; i<=4;i++) {
   if(bdElementArray[3] === oOccuranceRadioMap[i]){
      this.getView().byId("OccuranceRadio").setSelectedIndex(i);
      break;
}
}

for(var i=0; i<=4;i++) {
   if(bdElementArray[7] === oPriorityRadioMap[i]){
      this.getView().byId("PriorityRadio").setSelectedIndex(i);
      break;
}
}  

for(var i=0; i<=3;i++) {
   if(bdElementArray[8] === oFixedRadioMap[i]){
      this.getView().byId("FixedRadio").setSelectedIndex(i);
      break;
}
}  
   
         /*var iOccuranceRadioIndex = this.getView().byId("OccuranceRadio").getSelectedIndex();
         var sOccuranceRadioText = oOccuranceRadioMap[iOccuranceRadioIndex.toString()];
         if(sOccuranceRadioText === bdElementArray[3]) {
            this.getView().byId("OccuranceRadio").setSelectedIndex(iOccuranceRadioIndex);
         }
         //var key = this.getView().byId("OccuranceRadio").getKey(bdElementArray[3]);
         this.getView().byId("OccuranceRadio").setSelected(bdElementArray[3]);
         var iPriorityRadioIndex = this.getView().byId("PriorityRadio").getSelectedIndex();
         var sPriorityRadioText = oPriorityRadioMap[iPriorityRadioIndex.toString()];
         if(sPriorityRadioText === bdElementArray[7]) {
            this.getView().byId("PriorityRadio").setSelectedIndex(iPriorityRadioIndex);
         }
         
         var iFixedRadioIndex = this.getView().byId("FixedRadio").getSelectedIndex();
         var sFixedRadioText = oFixedRadioMap[iFixedRadioIndex.toString()];
         if(sFixedRadioText === bdElementArray[8]) {
            this.getView().byId("FixedRadio").setSelectedIndex(iFixedRadioIndex);
         }*/
      }
      
      this.getView().byId("StatusRadio").setEnabled(false); 
      
      selected_MN = 0;  
   }

},


/**************************************************************************************************************************************************************************************/
//Populate the Functional Location list for Breakdown type (Z2) notification
/*****************************************************************************************************************************************************************************************/  
getFuncLocByEquipment : function(){
      if(selected_MN == "0") {
       resource = this.getView().byId("id_dropdown_linkresc").getSelectedKey();
      } else {
       resource = selected_LinkResr_breakdown;
      }

      var equipment;
      if(selected_MN == "0"){
         equipment = this.getView().byId("id_dropdown_equi").getSelectedKey();
      } else {
         equipment = selected_Equipment_breakdown;
      }
      var sParams = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+equipment;
    var oModelGetFunctionLocation=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->getFunctionalLocation-->SQLQ_GetFuncLocByEquipmentTypeRelD");

   oModelGetFunctionLocation.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetFuncLocByEquipmentTypeRelD&"+sParams+"&Content-Type=text/json", "", false);
   this.getView().setModel(oModelGetFunctionLocation,"oGetFunctionLocation");
   
   //   var oModelGetFunctionLocation = this.getFunctionalLocation(sParams);
},

/**************************************************************************************************************************************************************************************/
//Get the 1st 40 character for notification short text as in SAPnotification description is 40 character long.
/*****************************************************************************************************************************************************************************************/  
mnShortText : function(text){

   var desc;
   if(text.length<40){
      desc = text.substr(0,text.length);
   }
   else{
      var desc = text.substr(0,39);
   }
   return desc;
},

/**************************************************************************************************************************************************************************************/
//Prepare the element text by appending different Fields separated by pipeline depending on notification type Which is stored in HNZ_MAINTNOT-ELEMENTTEXT 
/*****************************************************************************************************************************************************************************************/  
prepElementText : function(){
   var elementText;
   //Fetch the index of the selected radio button. Use the index to fetch the selected button's text value from the map created above.
   var iRadioSelectedIndex =  this.getView().byId("StatusRadio").getSelectedIndex();
   var sStatusRadio = oStatusRadioMap[iRadioSelectedIndex.toString()];
   
   if(sStatusRadio === "Breakdown") {
      
      var iWhenRadioIndex = this.getView().byId("WhenBreakdownRadio").getSelectedIndex();
      var sWhenBreakdownRadioValue = oWhenBreakdownRadioMap[iWhenRadioIndex.toString()];
      
      elementText = this.getView().byId("id_ta_Notes1").getValue()+"|"+this.getView().byId("id_ta_Notes2").getValue()
         +"|"+this.getView().byId("id_ta_Notes3").getValue()+"|"+sWhenBreakdownRadioValue+"|"+this.getView().byId("id_ta_Notes4").getValue()
         +"|"+this.getView().byId("txt_Team").getValue()+"|"+this.getView().byId("txt_Lead").getValue()+"|"+this.getView().byId("id_ta_Notes5").getValue()
         +"|"+this.getView().byId("txt_User").getValue()+"|"+this.getView().byId("txt_Enddate").getValue();
   } else {
      var iOccuranceRadioIndex = this.getView().byId("OccuranceRadio").getSelectedIndex();
      var sOccuranceRadioText = oOccuranceRadioMap[iOccuranceRadioIndex.toString()];
      
      var iPriorityRadioIndex = this.getView().byId("PriorityRadio").getSelectedIndex();
      var sPriorityRadioText = oPriorityRadioMap[iPriorityRadioIndex.toString()];
      
      var iFixedRadioIndex = this.getView().byId("FixedRadio").getSelectedIndex();
      var sFixedRadioText = oFixedRadioMap[iFixedRadioIndex.toString()];

         elementText = this.getView().byId("id_ta_Notes1").getValue()+"|"+this.getView().byId("id_ta_Notes2").getValue()
               +"|"+this.getView().byId("id_ta_Notes3").getValue()+"|"+sOccuranceRadioText+"|"+this.getView().byId("id_ta_Notes4").getValue()
               +"|"+this.getView().byId("id_ta_Notes5").getValue()+"|"+this.getView().byId("txt_User").getValue()+"|"+sPriorityRadioText+"|"+sFixedRadioText
               +"|"+this.getView().byId("txt_Team").getValue()+"|"+this.getView().byId("txt_Lead").getValue();    
   }
   return elementText;
},

/**************************************************************************************************************************************************************************************/
//Check if text area notes 1 is greater than 40, then limit it to 40
/*****************************************************************************************************************************************************************************************/  
isMaxLength : function(){
   var sTextAreaValue = this.getView().byId("id_ta_Notes1").getValue();
   if(sTextAreaValue.length > 40){
      this.getView().byId("id_ta_Notes1").setValue(sTextAreaValue.substring(0,40));
   }
},


/**************************************************************************************************************************************************************************************/
//document.id_mntypeform.Status[0].checked means create Z2 type notification along with workorder
//document.id_mntypeform.Status[1].checked means only create Z1 type notification 
/*****************************************************************************************************************************************************************************************/  
createMaintainNotif : function()
{

   this.getView().byId("id_btn_addnew").setEnabled(false);
   this.getView().byId("id_btn_update").setEnabled(false);
   this.getView().byId("id_btn_clear").setEnabled(false);
   
   var desc = "";
   var TodayDate = "";
   var repby = userName;
   var LongTxt = this.prepLongText();

   var iRadioSelectedIndex =  this.getView().byId("StatusRadio").getSelectedIndex();
   var sStatusRadio = oStatusRadioMap[iRadioSelectedIndex.toString()];
   var EquiType='';
   var Tech_Func='';
   var Tech_Func_array='';
   var Tech_Type;
   var FuncLoc='';
   var FuncLocDesc='';
   var LinkedResc='';
   var pmworkcenter='';
   var mnDtLinkId = "";
   var sParams='';
   
      if(equiCode !="" && equiCode !="---"){
         EquiType = equiCode; 
      }
      else{
         EquiType = this.getView().byId("id_dropdown_equi").getSelectedKey();
      }
      TodayDate = this.getView().byId("txt_date").getValue();
   
      Tech_Func = this.getView().byId("id_dropdown_fun").getValue();
      Tech_Func_array = Tech_Func.split(":-");
       Tech_Type = Tech_Func_array[0];
//    var FuncLoc = Tech_Func_array[1];
       FuncLoc = this.getView().byId("id_dropdown_fun").getSelectedKey();  
       FuncLocDesc = Tech_Func_array[1];  
      desc = this.mnShortText(this.getView().byId("id_ta_Notes1").getValue());
       LinkedResc = this.getView().byId("id_dropdown_linkresc").getSelectedKey();


   if(Tech_Func_array.length=="1"){
      FuncLoc=""; 
   }

   mnDtLinkId=MNId;

//get the pmworkenter from HNZ_FLOC table which is needed for create workorder for Z2 type.

   

   var oModelWorkCenterByFlocDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->createMaintainNotif-->SQLQ_GetWorkCenterByFLoc");

   oModelWorkCenterByFlocDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetWorkCenterByFLoc&Param.1="+FuncLoc+"&Content-Type=text/json", "", false);
   this.getView().setModel(oModelWorkCenterByFlocDetails,"oWorkCenterByFlocDetails");
   
   if(CommonUtility.getJsonModelRowCount(oModelWorkCenterByFlocDetails.getData()) > 0) {
      var oWorkCenterData = oModelWorkCenterByFlocDetails.getData().Rowsets.Rowset[0].Row[0];
      pmworkcenter = oWorkCenterData.PMWORKCTR;
   }

   //If pmworkenter is blank in HNZ_FLOC table then get it from HNZ_WORKCENTER table.

   if(pmworkcenter == "---" || pmworkcenter == "")
   {
      
      var oModelWorkCenterByResourceDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->createMaintainNotif-->SQLQ_GetWorkCenterByResr");

      oModelWorkCenterByResourceDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetWorkCenterByResr&Param.1="+plant+"&Param.2="+resource+"&Content-Type=text/json", "", false);
      this.getView().setModel(oModelWorkCenterByResourceDetails,"oWorkCenterByResourceDetails");
      if(CommonUtility.getJsonModelRowCount(oModelWorkCenterByResourceDetails.getData()) > 0) {
         var oWorkCenterData = oModelWorkCenterByResourceDetails.getData().Rowsets.Rowset[0].Row[0];
         pmworkcenter = oWorkCenterData.PMWORKCTR;
      }
   }

   var startdate= CommonUtility.formatDateToCallProcessMsg1(TodayDate);
   var starttime= CommonUtility.formatTimeToCallProcessMsg1(TodayDate);

   if(TodayDate >= shiftStartTime && TodayDate <= shiftEndTime)
   {
      if(desc != "")
      {
         if(FuncLoc != "")
         {
            if(sStatusRadio === "Breakdown")
            {
               var BDElementText = this.prepElementText();
               
               sParams = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+FuncLoc+"&Param.4="+desc
               +"&Param.5="+LongTxt+"&Param.6="+"Z2"+"&Param.7="+TodayDate+"&Param.8="+"ZBRK"+"&Param.9="+repby
               +"&Param.10="+"ZINT"+"&Param.11="+startdate+"&Param.12="+pmworkcenter+"&Param.13="+FuncLocDesc
               +"&Param.14="+orderId+"&Param.15="+starttime+"&Param.16="+BDElementText+"&Param.17="+mnDtLinkId
               +"&Param.18="+EquiType+"&Param.19="+Tech_Type+"&Param.20="+LinkedResc;
               
               var oModelCreateNotifWorkOrder=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->createMaintainNotif-->XACQ_CreateNotifWorkOrderRelE");

               var that = this;
               oModelCreateNotifWorkOrder.attachRequestCompleted(
                     function(){
                        if(CommonUtility.getJsonModelRowCount(oModelCreateNotifWorkOrder.getData()) >0) {
                            
                           var oCreateNotifResponse = oModelCreateNotifWorkOrder.getData().Rowsets.Rowset[0].Row[0];
                           if(oCreateNotifResponse.Type==="S") {
                              var screateNotifMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0031") + oCreateNotifResponse.Message;
                              sap.ui.getCore().getModel("oMessage").setProperty("/message",screateNotifMsg);
                              sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                              sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
                              
                              that.ClearAll();
                           } else if(oCreateNotifResponse.Type==="B"){
                  
                              sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0110"));
                              sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                              sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
                              
                              that.ClearAll();
                           } else{
                              sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0032"));
                              sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                              sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
                           }
                           that.getMaintNotifDetails();
                     }
                      else {
                            sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0032"));
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
                      }
                        
               });
               oModelCreateNotifWorkOrder.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_CreateNotifWorkOrderRelE&"+sParams+"&Content-Type=text/json", "", false);

            }
            else if (sStatusRadio === "Corrective")
            {
               var iPriorityRadioIndex = this.getView().byId("PriorityRadio").getSelectedIndex();
               if(iPriorityRadioIndex ==="" || iPriorityRadioIndex === "-1"){
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0142"), {
                      title: "Alert",                                  
                  });
               } else if(this.getView().byId("id_ta_Notes1").getValue()===""){
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0141"), {
                      title: "Alert",                                  
                  });
               } else{     
                  var PVElementText = this.prepElementText();
                  var iPriorityRadioIndexNumber = (iPriorityRadioIndex + 1);
                  sParams = "Param.1="+plant+"&Param.2="+FuncLoc+"&Param.3="+desc+"&Param.4="+"Z1"
                  +"&Param.5="+TodayDate+"&Param.6="+repby+"&Param.7="+resource+"&Param.8="+1+"&Param.9="+LongTxt
                  +"&Param.10="+FuncLocDesc+"&Param.11="+pmworkcenter+"&Param.12="+orderId+"&Param.13="+PVElementText
                  +"&Param.14="+mnDtLinkId+"&Param.15="+EquiType+"&Param.16="+Tech_Type+"&Param.17="+LinkedResc
                  +"&Param.18="+iPriorityRadioIndexNumber;        
                  
                
                  
                  var oModelCreateNotifWorkOrder=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->createMaintainNotif-->XACQ_CreateMaintainNotifRelD");

                  var that = this;
                  oModelCreateNotifWorkOrder.attachRequestCompleted(
                        function(){
                           if(CommonUtility.getJsonModelRowCount(oModelCreateNotifWorkOrder.getData()) >0) {
                               
                              var oCreateNotifResponse = oModelCreateNotifWorkOrder.getData().Rowsets.Rowset[0].Row[0];
                              if(oCreateNotifResponse.Type==="S") {

                                 var screateNotifMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0031") + oCreateNotifResponse.Message;
                                 sap.ui.getCore().getModel("oMessage").setProperty("/message",screateNotifMsg);
                                 sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                                 sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
                           
                                 that.ClearAll();
                              }
                              else if(oCreateNotifResponse.Type==="B"){
                                 sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0110"));
                                 sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                                 sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");

                                 that.ClearAll();
                              }
                              else{
                                 sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0032"));
                                 sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                                 sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
                              }
                              that.getMaintNotifDetails();
                           }
                           else {
                               sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0032"));
                               sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                               sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
                           }
               });
                  oModelCreateNotifWorkOrder.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_CreateMaintainNotifRelD&"+sParams+"&Content-Type=text/json", "", false);

               }
            }
            else
            {
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0087"), {
                   title: "Alert",                                  
               });
            }
            
         }
         else
         {
            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0093"), {
               title: "Alert",                                  
            });
         }
      }
      else
      {
         MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0109"), {
               title: "Alert",                                  
            });
      }
   }
   else
   {
      MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0106"), {
               title: "Alert",                                  
      });
   }


this.getView().byId("id_btn_addnew").setEnabled(true);
this.getView().byId("id_btn_update").setEnabled(true);
this.getView().byId("id_btn_clear").setEnabled(true);
},

/**************************************************************************************************************************************************************************************/
//prepare the maintenance notification longtext and update the notification longtext in SAP and HNZ_MAINTNOT table by calling APLT_CMD_UpdateMNotif.
/*****************************************************************************************************************************************************************************************/  
updateMaintainNotif : function()
{

   var repby = userName;
   var FuncLoc = "";
   var FuncLocDesc = "";
   var EquiType = "";
   var desc ="";
    var MNStartDate = "" ;
    var MNEndDate = "";
    var Tech_Func='';
    var Tech_Func_array='';
    var Tech_Type='';
    var Notif_Number='';
    var sParams='';
    var LinkedResc='';
    
    Tech_Func = this.getView().byId("id_dropdown_fun").getValue();
    Tech_Func_array = Tech_Func.split(":-");
    Tech_Type = Tech_Func_array[0];
    FuncLoc = this.getView().byId("id_dropdown_fun").getSelectedKey();
   FuncLocDesc = Tech_Func_array[1];   
   EquiType = this.getView().byId("id_dropdown_equi").getSelectedKey(); 
   desc = this.mnShortText(this.getView().byId("id_ta_Notes1").getValue());
    MNStartDate = this.getView().byId("txt_date").getValue();
    LinkedResc = this.getView().byId("id_dropdown_linkresc").getSelectedKey();
    
    var iRadioSelectedIndex =  this.getView().byId("StatusRadio").getSelectedIndex();
   var sStatusRadio = oStatusRadioMap[iRadioSelectedIndex.toString()];
   if(sStatusRadio === "Breakdown")
   {
      MNEndDate = this.getView().byId("txt_Enddate").getValue();
   } else {
      MNEndDate = "";
   }

   if(Tech_Func_array.length=="1"){
      FuncLoc=""; 
   }

   var Long_Txt = this.prepLongText(); 
   var ElementText = this.prepElementText();
    var validdate = true ; 

    if(MNEndDate!=""){
       if(MNEndDate < MNStartDate ){ 
         validdate = false ;
       }
    }

if ( validdate == true )
{
   if(FuncLoc != "") {
   //if(FuncLoc == "") {
      var aSelectedRowPath = this.getView().byId("id_tbl_maintNotif").getSelectedContextPaths();
      var oMaintNotifDetailsModel = this.getView().getModel("oMaintNotifDetails");
      if(aSelectedRowPath.length > 0) {
         let sPath = aSelectedRowPath[0];
         Notif_Number = oMaintNotifDetailsModel.getProperty(sPath+'/MNOTIF');

         if(Notif_Number!="Buffered" || !isNaN(Notif_Number)){
            
            sParams = "Param.1="+Notif_Number+"&Param.2="+Long_Txt+"&Param.3="+plant+"&Param.4="+resource
            +"&Param.5="+desc+"&Param.6="+FuncLoc+"&Param.7="+FuncLocDesc+"&Param.8="+repby+"&Param.9="+ElementText
            +"&Param.10="+EquiType+"&Param.11="+Tech_Type+"&Param.12="+LinkedResc+"&Param.13="+MNEndDate;

         
             
                var oModelUpdateNotifWorkOrder=models.createNewJSONModel("com.khc.rephub.controller.production.RepMaintainNotifReID-->updateMaintainNotif-->XACQ_UpdateMainNotificationRelD");

            var that = this;
            oModelUpdateNotifWorkOrder.attachRequestCompleted(
            function(){
               if(CommonUtility.getJsonModelRowCount(oModelUpdateNotifWorkOrder.getData()) >0) {
                     var oUpdateNotifResponse = oModelUpdateNotifWorkOrder.getData().Rowsets.Rowset[0].Row[0];
                     if(oUpdateNotifResponse.Type==="S") {
                        var sUpdateNotifMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0088");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message",sUpdateNotifMsg);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
                        that.getMaintNotifDetails();  
		that.ClearAll();
                     }
                     else if(oUpdateNotifResponse.Type==="B"){
                        var sUpdateNotifMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0111");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message",sUpdateNotifMsg);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
                        that.getMaintNotifDetails();  
		that.ClearAll();
                     }
                     else {
                        sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0089"));
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
                     }
               }
               else {
                   sap.ui.getCore().getModel("oMessage").setProperty("/message",sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0089"));
                   sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
                   sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
                }
         });
         oModelUpdateNotifWorkOrder.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdateMainNotificationRelD&"+sParams+"&Content-Type=text/json", "", false);
      }
      else{
         MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0107"), {
             title: "Alert",                                  
         });
      }
      
   } else {
         MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0033"), {
         title: "Alert",                                  
         });
      }
   } else {
         MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0093"), {
         title: "Alert",                                  
         });
   }
} else {
      MessageBox.alert("End Date can not be less than start date", {
         title: "Alert",                                  
       });
   }
},

/**************************************************************************************************************************************************************************************/
//clear the values from all fields as well as unselect the item from selected dropdowns.
/*****************************************************************************************************************************************************************************************/  
ClearAll : function(){
   var iRadioSelectedIndex =  this.getView().byId("StatusRadio").getSelectedIndex();
   var sStatusRadio = oStatusRadioMap[iRadioSelectedIndex.toString()];

   this.getView().byId("StatusRadio").setEnabled(true);
   this.getView().byId("WhenBreakdownRadio").setSelectedIndex(-1);
   
   this.getView().byId("OccuranceRadio").setSelectedIndex(-1);
   this.getView().byId("PriorityRadio").setSelectedIndex(-1);
   this.getView().byId("FixedRadio").setSelectedIndex(-1);

   this.getView().byId("id_dropdown_linkresc").setSelectedKey(resource);
   this.getView().byId("id_dropdown_equi").setSelectedKey("");
   this.getView().byId("id_dropdown_fun").setSelectedKey("");

// this.getView().byId("txt_Team").setValue(teamName);
   //this.getView().byId("txt_Lead").setValue(lead);
   //this.getView().byId("txt_User").setValue(userName);
   this.getView().byId("id_btn_addnew").setEnabled(true);
   this.getView().byId("id_btn_update").setEnabled(true);
   this.getView().byId("id_btn_clear").setEnabled(true);
   var currentDT = CommonUtility.getCurrentDateTime(new Date());

   this.getView().byId("txt_date").setValue(currentDT);

   this.getView().byId("id_tbl_maintNotif").removeSelections()
   this.getView().byId('id_ta_Notes1').setValue("");  
   this.getView().byId('id_ta_Notes2').setValue("");  
   this.getView().byId('id_ta_Notes3').setValue("");  
   this.getView().byId('id_ta_Notes4').setValue("");  
   this.getView().byId('id_ta_Notes5').setValue("");
},


});
});