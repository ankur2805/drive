sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox","com/khc/rephub/utils/UI_utilities",
"com/khc/rephub/model/formatter","com/khc/common/Script/CommonUtility","com/khc/rephub/model/models"], 
function(Controller,MessageBox,UI_utilities,formatter,CommonUtility,models) {
	"use strict";
	var plant;
	var resource;
	var projectName;
	var workstation;
	var username;
	var crid;
	var msgid;
	var phase;
	var phasedesc;
	var interval;
	var uom;
	var shift;
	var shiftid;
	var teamid;
	var orderid;
	var matno;
	var matdesc;
	var shiftstarttime;
	var shiftendtime;
	var aSelectedRowPhasePath;
	var PhaseSelectedRowVal;
	var PhaseLength;
	var IntervalLength;
	var IntervalRowLength;
	var OEEScrap;
	var operation;
	var sreason;
	var SelectedReasonCode;
	var scode;
	var scrapbyconversion;
	var scrapbyconversion2;
	var ICT;
	var scrap;
	var scrapQty;
	var conversion;
	var date;
	var time;
	let dt = new Date();
	var PhaseSelected=0;
	var confTime;

	return Controller.extend("com.khc.rephub.controller.production.RepScrapNew", {
		
		onInit: function() {
		this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("RepScrap").attachPatternMatched(this._oRoutePatternMatched, this);
		},
		_oRoutePatternMatched: function(oEvent) {
			
			
			UI_utilities.productionMenuOpened(this,"RepScrap");

			this.getView().byId("addbutton").setEnabled(false);
			this.getView().byId("updatebutton").setEnabled(false);
			this.getView().byId("deletebutton").setEnabled(false);

			this.getView().byId("dialpad").setVisible(false);
			plant=sap.ui.getCore().getModel("session").oData.CA_Plant
			resource=sap.ui.getCore().getModel("session").oData.CA_Resource
			projectName=sap.ui.getCore().getModel("session").oData.CA_ProjectName
			workstation=sap.ui.getCore().getModel("session").oData.CA_CRDest
			username=sap.ui.getCore().getModel("session").oData.CA_IllumLoginName

			
			this.disableButton();
			this.getRunningShiftDetails();
			this.getShiftDetailsConf();
			this.getOrderList();
			this.getOrderDetails();
			this.getShiftIntervalDetails();
			this.getPhaseList();
			this.getScrapReason();
			this.clearFields();
			
		},

		// To remove busy indicator once the page loaded
		onAfterRendering : function () {
			//	UI_utilities.setContainerBusyState( this.getOwnerComponent().oContainer,false);
		},
		
		/**
		 * Called when a User clicked a menu
		 * 
		 */

		menuSelected : function(oEvent) {

			// Navigate the the selected menu page
			
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
		},
		
/*****************************************************************************************************************************************************************************************/
	//on load of page update the values of Resource, Shift, Crew and Lead
/****************************************************************************************************************************************************************************************/	
		
		getRunningShiftDetails:function(){
		
		var oModelRunningShiftDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->getRunningShiftDetails-->SQLQ_GetRunningShiftDetails");
		oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetRunningShiftDetails&Param.1="+plant+"&Param.2="+resource+"&d="+new Date()+"&Content-Type=text/json", "", false);
		var shift = this.getView().byId("Shiftip");
		sap.ui.getCore().setModel(oModelRunningShiftDetails,"oRSDetails");
		let rowCount=CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData())
		if(rowCount>0){

		var lead = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0].LEAD;
		
		this.getView().byId("Shiftip").setValue(oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0].SHIFTNAME);
		this.getView().byId("Crewip").setValue(oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0].TEAMSIZE);		
		this.getView().byId("Leadip").setValue(oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0].LEAD);
		shiftstarttime = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0].STARTTIME;
		shiftendtime = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0].ENDTIME;
	
		interval = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0].INTERVAL;
		}
		},

/*****************************************************************************************************************************************************************************************/
	//on load of page update the values of Order, Material No, Material Desc and Planned Qty
/****************************************************************************************************************************************************************************************/	
		getOrderList:function(){
		
		var oModelOrderList=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->getOrderList-->XACQ_GetRunningOrder");

		oModelOrderList.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetRunningOrder&Param.1="+plant+"&Param.2="+resource+"&Param.3="+workstation+"&d="+new Date()+"&Content-Type=text/json", "", false);
		sap.ui.getCore().setModel(oModelOrderList,"oOrderList");

		let rowCount=CommonUtility.getJsonModelRowCount(oModelOrderList.getData())
		if(rowCount>0){

		this.getView().byId("orderip").setValue(oModelOrderList.getData().Rowsets.Rowset[0].Row[0].ORDERSTRIP);
		this.getView().byId("materialip").setValue(oModelOrderList.getData().Rowsets.Rowset[0].Row[0].MATNRSTRIP);
		this.getView().byId("materialDesip").setValue(oModelOrderList.getData().Rowsets.Rowset[0].Row[0].MATTEXT);
		this.getView().byId("plannedqtyip").setValue(oModelOrderList.getData().Rowsets.Rowset[0].Row[0].MATQTY);
		//this.getView().byId("plannedqtyip").setValue(oModelOrderList.getData().Rowsets.Rowset[0].Row[0].MATQTY);
		crid = oModelOrderList.getData().Rowsets.Rowset[0].Row[0].CRID;
		msgid = oModelOrderList.getData().Rowsets.Rowset[0].Row[0].MSGID;
		orderid = oModelOrderList.getData().Rowsets.Rowset[0].Row[0].ORDERID;
		matno = oModelOrderList.getData().Rowsets.Rowset[0].Row[0].MATNR;
		matdesc = oModelOrderList.getData().Rowsets.Rowset[0].Row[0].MATTEXT;
		}
		},


/*****************************************************************************************************************************************************************************************/
	//on load of page update the values of Pending Qty and % complete
/****************************************************************************************************************************************************************************************/	

		getOrderDetails:function(){
		
		var oModelOrderDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->getOrderDetails-->XACQ_GetOrderDetails");

		oModelOrderDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetOrderDetails&Param.1="+crid+"&d="+new Date()+"&Content-Type=text/json", "", false);
		sap.ui.getCore().setModel(oModelOrderDetails,"oOrdDetails");
		
		let rowCount=CommonUtility.getJsonModelRowCount(oModelOrderDetails.getData())
		if(rowCount>0){

		this.getView().byId("pendingqtyip").setValue(oModelOrderDetails.getData().Rowsets.Rowset[0].Row[0].PENDINGQTY);
		this.getView().byId("completeip").setValue(oModelOrderDetails.getData().Rowsets.Rowset[0].Row[0].PENDINGPERC);

		
		}
		},


/*****************************************************************************************************************************************************************************************/
	//on load of page update the Scrap Shift Interval Details table values 
/****************************************************************************************************************************************************************************************/	
	
		getShiftIntervalDetails:function(){
		
		var oModelShiftIntDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->getShiftIntervalDetails-->XACQ_GetShiftIntervalDetails");

		oModelShiftIntDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetShiftIntervalDetails&Param.1="+plant+"&Param.2="+resource+"&Param.3="+shiftstarttime+"&Param.4="+shiftendtime+"&d="+new Date()+"&Content-Type=text/json", "", false);
		
		sap.ui.getCore().setModel(oModelShiftIntDetails,"oShiftIntDetails");
		let rowCount=CommonUtility.getJsonModelRowCount(oModelShiftIntDetails.getData());
		this.disableButton();
		if(rowCount>0){
		
				this.enableButton();
			}
		
		},

/*****************************************************************************************************************************************************************************************/
	//on load of page update the Phase List table values 
/****************************************************************************************************************************************************************************************/	

		getPhaseList:function(){
		
		var oModelPhaseList=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->getPhaseList-->XACQ_GetPhaseScrap");

		oModelPhaseList.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetPhaseScrap&Param.1="+msgid+"&Param.2="+crid+"&Param.3="+resource+"&d="+new Date()+"&Content-Type=text/json", "", false);
		
		var oScrapPhaseListTable=this.getView().byId("Scraptable2");
		let rowCount=CommonUtility.getJsonModelRowCount(oModelPhaseList.getData())
		if(rowCount>0){
		
		sap.ui.getCore().setModel(oModelPhaseList,"oPhaseList");
		
		
		}
		},


/*****************************************************************************************************************************************************************************************/
	// loading the selected row values of Phase List Table 
/****************************************************************************************************************************************************************************************/	
		ScrapPhaseListRowSelected:function(){

		var aSelectedRowPath = this.getView().byId("Scraptable2").getSelectedContextPaths();
		aSelectedRowPhasePath = aSelectedRowPath;
		var oScrapPhaseListRowModel = this.getView().getModel("oPhaseList");

		if(aSelectedRowPath.length > 0)
		{
		let sPath = aSelectedRowPath[0];

		var SelectedRowVal = oScrapPhaseListRowModel.getProperty(sPath);
		PhaseSelectedRowVal = SelectedRowVal;
		var Phase = oScrapPhaseListRowModel.getProperty(sPath).Phase;
		phase = Phase;
		var PhaseText = oScrapPhaseListRowModel.getProperty(sPath).PhaseText;
		phasedesc = PhaseText;
		var UOM = oScrapPhaseListRowModel.getProperty(sPath).UOM;
		uom = UOM;
		var Quantity = oScrapPhaseListRowModel.getProperty(sPath).ScrapQty;
		scrapQty = Quantity;
		var Reason = oScrapPhaseListRowModel.getProperty(sPath).SReason;
		scode = oScrapPhaseListRowModel.getProperty(sPath).SCode;
		OEEScrap = PhaseSelectedRowVal.OEE_Scrap;
		operation = PhaseSelectedRowVal.Operation;
		conversion = PhaseSelectedRowVal.Conversion;

		this.getView().byId("phase").setValue(PhaseText);
		this.getView().byId("uom").setValue(UOM);
		this.getView().byId("quantity").setValue(Quantity);
		//this.getView().byId("scrapreason").setValue(Reason);
		this.getView().byId("scrapreason").setSelectedKey(scode);

		PhaseSelected=1;


		if((this.getView().byId("Scraptable1").getSelectedContextPaths().length) > 0)
		{
			this.getView().byId("addbutton").setEnabled(true);
			this.getView().byId("updatebutton").setEnabled(true);
			this.getView().byId("deletebutton").setEnabled(true);
			this.getView().byId("confirmbutton").setEnabled(true);
		}
		
		if(conversion=='NA'){
		conversion='0';

		//this.getScrapReason();
		}
		if(scode==""){

			this.getView().byId("updatebutton").setEnabled(false);
			this.getView().byId("deletebutton").setEnabled(false);
		}
		else if(scode!=""){

			this.getView().byId("updatebutton").setEnabled(true);
			this.getView().byId("deletebutton").setEnabled(true);
		}
		
		
		}
		

		},

/*****************************************************************************************************************************************************************************************/
	// loading the Scrap Reason for Reason drop down
/****************************************************************************************************************************************************************************************/	

		getScrapReason:function(){

		
		var oModelReasonList=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->getScrapReason-->SQLQ_GetScrapCode");

		oModelReasonList.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetScrapCode&d="+new Date()+"&Content-Type=text/json", "", false);

		let rowCount=CommonUtility.getJsonModelRowCount(oModelReasonList.getData())
		if(rowCount>0){
		
		sap.ui.getCore().setModel(oModelReasonList,"oReasonList");
		var SReasonCode = this.getView().byId("scrapreason").getSelectedKey();
		SelectedReasonCode = SReasonCode;
		sreason = this.getView().byId("scrapreason")._getSelectedItemText();



		}
		},


/*****************************************************************************************************************************************************************************************/
	// loading the dialpad
/****************************************************************************************************************************************************************************************/	

		onClickDialpad : function(oEvent)	{
	
		let sKey = oEvent.getSource().getText();
		let quantityval = this.getView().byId("quantity").getValue();
		let newquantityval = quantityval + sKey;
		this.getView().byId("quantity").setValue(newquantityval);
		
		},

		onCancelDialPad : function(oEvent)	{
	
		this.getView().byId("quantity").setValue("");
		
		},

		closeDialPad : function(oEvent)	{
		this.getView().byId("dialpad").setVisible(false);
		},

		onAfterRendering : function() {

	 
		var that = this;
	  	// Add event delegate to open dialpad on focus
		this.getView().byId("quantity").addEventDelegate({
		onfocusin : function() {
	        	that.getView().byId("dialpad").setVisible(true);
		}
		});
		},

/*****************************************************************************************************************************************************************************************/
	//on load of page update the values of shift details
/****************************************************************************************************************************************************************************************/	

		getShiftDetailsConf:function(){		

		
		var oModelShifDetailsConf=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->getShiftDetailsConf-->SQLQ_GetRunningShiftDetails_Confirmation");

		oModelShifDetailsConf.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetRunningShiftDetails_Confirmation&Param.1="+plant+"&Param.2="+resource+"&d="+new Date()+"&Content-Type=text/json", "", false);
		sap.ui.getCore().setModel(oModelShifDetailsConf,"oShiftDetailsConf");
		
		let rowCount=CommonUtility.getJsonModelRowCount(oModelShifDetailsConf.getData())
		if(rowCount>0){

		shift = oModelShifDetailsConf.getData().Rowsets.Rowset[0].Row[0].SHIFTNAME;
		shiftid = oModelShifDetailsConf.getData().Rowsets.Rowset[0].Row[0].SHIFTID;
		teamid = oModelShifDetailsConf.getData().Rowsets.Rowset[0].Row[0].TEAMID;
		}
		},



/*****************************************************************************************************************************************************************************************/
	// on click of add button
/****************************************************************************************************************************************************************************************/	
	
		onAdd:function(){

		//this.getScrapReason();
		//var Phase = PhaseSelectedRowVal.Phase;
		var Temp = 1;
		scrap = this.getView().byId("quantity").getValue();
		scrapbyconversion = scrap*parseFloat(conversion);
		scrapbyconversion2 = scrapbyconversion.toFixed(2);
		PhaseLength = this.getView().byId("Scraptable2").getSelectedContextPaths().length;
		IntervalLength = this.getView().byId("Scraptable1").getSelectedContextPaths().length;
		
		var oModelChkPhaseScrap = new sap.ui.model.json.JSONModel();
		
		var oModelInsScrap=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->onAdd-->SQLQ_InsPhaseScrap");

		let todayDate=CommonUtility.formatDate(dt);
		let todayDateTime = CommonUtility.getCurrentDateTime(dt);
		let todayTime = dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
		date = todayDate;
		time = todayTime;
		ICT = confTime;

		SelectedReasonCode = this.getView().byId("scrapreason").getSelectedKey();
		sreason = this.getView().byId("scrapreason")._getSelectedItemText();
		
		
		if(IntervalLength > 0)
		{
			if(PhaseLength > 0)
			{
				if(this.getView().byId("quantity").getValue()!='' && this.getView().byId("quantity").getValue()>0)
				{
					if (this.getView().byId("scrapreason").getProperty("value")!="")
					{
						if(parseInt(this.getView().byId("quantity").getValue())==this.getView().byId("quantity").getValue())
						{
							if(ICT>=shiftstarttime && ICT<=shiftendtime)
							{
								if(PhaseSelectedRowVal.ScrapQty!="" && PhaseSelectedRowVal.SCode == SelectedReasonCode)
								{
									var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0028");
									MessageBox.alert(sAlertMsg, {
										title: "Alert",                                  
									});
								}
								else
								{
									//oModelChkPhaseScrap.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_ChkPhaseScrap&Param.1="+crid+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+phase+"&Param.5="+SelectedReasonCode+"&Param.6="+Temp+"&d="+new Date()+"&Content-Type=text/json", "", false);
									//sap.ui.getCore().setModel(oModelChkPhaseScrap,"oChkPhaseScrap");


									oModelInsScrap.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_InsPhaseScrap&Param.1="+crid+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+phase+"&Param.5="+phasedesc+"&Param.6="+interval+"&Param.7="+username+"&Param.8="+scrapbyconversion2+"&Param.9="+uom+"&Param.10="+SelectedReasonCode+"&Param.11="+sreason+"&Param.12="+operation+"&Param.13="+workstation+"&Param.14="+ICT+"&Param.15="+shift+"&Param.16="+OEEScrap+"&Param.17="+scrap+"&Param.18="+orderid+"&Param.19="+shiftid+"&Param.20="+matno+"&Param.21="+matdesc+"&Param.22="+teamid+"&d="+new Date()+"&Content-Type=text/json", "", false);
									//sap.ui.getCore().setModel(oModelInsScrap,"oInsScrap");

									this.getPhaseList();
									this.clearFields();
								}	
							}
							else{
									var sAlertMsg = "You can only insert Scrap within running shift";
									//sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0139");
									MessageBox.alert(sAlertMsg, {
									title: "Alert",                                  
						});
						

							}
						}
						else{
								var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116");
								MessageBox.alert(sAlertMsg, {
									title: "Alert",                                  
								});
						}
					}
					else
					{
						
						
						var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0026");
									MessageBox.alert(sAlertMsg, {
										title: "Alert",                                  
									});
					}
				}
				else{
					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0027");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",                                  
					});
		
				}
			}
			else{
			var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0025");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
				});
		
			}
		}
		else{
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0207");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
				});
		}


		},


/*****************************************************************************************************************************************************************************************/
	// on click of update button
/****************************************************************************************************************************************************************************************/	

		onUpdate:function(){

		//this.getScrapReason();
		//var Phase = PhaseSelectedRowVal.Phase;
		var Temp = 1;
		scrap = this.getView().byId("quantity").getValue();
		scrapbyconversion = eval(scrap)*eval(conversion);
		scrapbyconversion2 = scrapbyconversion.toFixed(2);
		PhaseLength = this.getView().byId("Scraptable2").getSelectedContextPaths().length;
		var Scode = PhaseSelectedRowVal.SCode;
		//this.getView().byId("scrapreason").setSelectedKey(Scode);
		SelectedReasonCode = this.getView().byId("scrapreason").getSelectedKey();
		sreason = this.getView().byId("scrapreason")._getSelectedItemText();

		
		
		var oModelUpdPhaseScrap=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->onUpdate-->SQLQ_UpdPhaseScrap");

		let todayDate=CommonUtility.formatDate(dt);
		let todayDateTime = CommonUtility.getCurrentDateTime(dt);
		let todayTime = dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
		date = todayDate;
		time = todayTime;
		ICT = confTime;

		if(PhaseLength > 0)
		{
		if(this.getView().byId("quantity").getValue()!='' && this.getView().byId("quantity").getValue()>0)
		{
		if(parseInt(this.getView().byId("quantity").getValue())==this.getView().byId("quantity").getValue())
		{
		if(this.getView().byId("scrapreason")._getSelectedItemText()!="")
		{
		oModelUpdPhaseScrap.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdPhaseScrap&Param.1="+scrapbyconversion2+"&Param.2="+uom+"&Param.3="+SelectedReasonCode+"&Param.4="+sreason+"&Param.5="+crid+"&Param.6="+plant+"&Param.7="+resource+"&Param.8="+phase+"&Param.9="+Scode+"&Param.10="+"1"+"&Param.11="+scrap+"&d="+new Date()+"&Content-Type=text/json", "", false);
		sap.ui.getCore().setModel(oModelUpdPhaseScrap,"oUpdPhaseScrap");

		this.getPhaseList();
		this.clearFields();
		}
		else{
		var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0026");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
			});

		}
		}
		else{
		var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
			});
		}
		}
		else{
		var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0027");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
			});
		
		}
		}
		else{
		var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0025");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
			});
		
		}


		},

/*****************************************************************************************************************************************************************************************/
	// on click of delete button
/****************************************************************************************************************************************************************************************/	

		onDelete:function(){

		this.getScrapReason();
		PhaseLength = this.getView().byId("Scraptable2").getSelectedContextPaths().length;
		var Scode = PhaseSelectedRowVal.SCode;
		this.getView().byId("scrapreason").setSelectedKey(Scode);
		SelectedReasonCode = this.getView().byId("scrapreason").getSelectedKey();
		
		var oModelDelPhaseScrap=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->onDelete-->SQLQ_DelPhaseScrap");

		if(PhaseLength > 0)
		{

		oModelDelPhaseScrap.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_DelPhaseScrap&Param.1="+crid+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+phase+"&Param.5="+SelectedReasonCode+"&Param.6="+"1"+"&d="+new Date()+"&Content-Type=text/json", "", false);
		sap.ui.getCore().setModel(oModelDelPhaseScrap,"oDelPhaseScrap");


		this.getPhaseList();
		}
		else{
		var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0025");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
			});
		
		}
		this.clearFields();

		},


/*****************************************************************************************************************************************************************************************/
	// on click of confirm button
/****************************************************************************************************************************************************************************************/	

		onConfirm:function(){

		//this.getScrapReason();
		var scrapval = 0;
		var sAlertMsg;
		let todayDate=CommonUtility.formatDate(dt);
		let todayDateTime = CommonUtility.getCurrentDateTime(dt);
		let todayTime = dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
		date = todayDate;
		time = todayTime;
		
		
		var oModelConfPhaseScrap=models.createNewJSONModel("com.khc.rephub.controller.production.RepScrapNew-->onConfirm-->XACQ_RecordScrapConfirm");

		IntervalLength = this.getView().byId("Scraptable1").getSelectedContextPaths().length;

		if(IntervalLength ==0)
		{
		sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0140");
				MessageBox.alert(sAlertMsg, {
					 title: "Alert",                                  
			});
		}
		else
		{
			
			ICT = confTime;

			//var datetime = CommonUtility.formatDateToCallProcessMsg();
			var time1 = CommonUtility.formatTimeToCallProcessMsg1(ICT);
			var date1 = CommonUtility.formatDateToCallProcessMsg1(ICT);
			var datetime1 = CommonUtility.formatDateToCallProcessMsg();
			
			var oScrapPhaseListRowModel = this.getView().getModel("oPhaseList");
			IntervalRowLength = CommonUtility.getJsonModelRowCount(oScrapPhaseListRowModel.getData());
			if(IntervalRowLength>0) {
				var oScrapData = oScrapPhaseListRowModel.getData().Rowsets.Rowset[0].Row
				for(let i=0;i<IntervalRowLength;i++)
					{
						
						scrapQty = oScrapData[i].ScrapQty;
					if(scrapQty !="")
					{
						scrapval = 1;
						break;
					}
				
				}
			}
			if(scrapval == 1)
			{
				oModelConfPhaseScrap.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_RecordScrapConfirm&Param.1="+crid+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+datetime1+"&Param.5="+date1+"&Param.6="+time1+"&Param.7="+"00004"+"&Param.8="+orderid+"&Param.9="+username+"&d="+new Date()+"&Content-Type=text/json", "", false);
				sap.ui.getCore().setModel(oModelConfPhaseScrap,"oConfPhaseScrap");
		
				if( CommonUtility.getJsonModelRowCount(oScrapPhaseListRowModel.getData()) >0 )	{
					
				
				var Type = oModelConfPhaseScrap.getData().Rowsets.Rowset[0].Row[0].Type;
					if(Type=="S")
					{
						var confSuccessMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0138");
						sap.ui.getCore().getModel("oMessage").setProperty("/message",confSuccessMsg);
						sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
						sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
						this.getView().byId("confirmbutton").setEnabled(false);
						this.getPhaseList();
						this.clearFields();
					}
					else if(Type=="E")
					{
						var confErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0132");
						sap.ui.getCore().getModel("oMessage").setProperty("/message",confErrorMsg);
						sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
						sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
						this.getView().byId("confirmbutton").setEnabled(false);
					}
				}
				else 
				{
					var confErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0132");
					sap.ui.getCore().getModel("oMessage").setProperty("/message",confErrorMsg);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
					this.getView().byId("confirmbutton").setEnabled(false);
				}
	
	
			}
			else
				{
			sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0139");
						MessageBox.alert(sAlertMsg, {
							 title: "Alert",                                  
					});
				}
			}


		},

/*****************************************************************************************************************************************************************************************/
	// to clear the fields
/****************************************************************************************************************************************************************************************/	

		clearFields:function(){

		this.getView().byId("quantity").setValue("");
		this.getView().byId("uom").setValue("");
		this.getView().byId("uom").setValue("");
		phase="";
		this.getView().byId("phase").setValue("");
		this.getView().byId("scrapreason").setSelectedKey("");
		this.getView().byId("scrapreason").setSelectedItem("");

		},

/*****************************************************************************************************************************************************************************************/
	// to disable the buttons
/****************************************************************************************************************************************************************************************/	

		disableButton:function(){

		var RunningShift = this.getView().byId("alertInput").getValue();

		if(RunningShift =="No running shift")
		{
			var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
			sap.ui.getCore().getModel("oMessage").setProperty("/message",sNoShiftMsg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
			
			this.getView().byId("addbutton").setEnabled(false);
			this.getView().byId("updatebutton").setEnabled(false);
			this.getView().byId("deletebutton").setEnabled(false);
			this.getView().byId("confirmbutton").setEnabled(false);
		}
		else if(IntervalLength == 0)
		{
			this.getView().byId("addbutton").setEnabled(false);
			this.getView().byId("updatebutton").setEnabled(false);
			this.getView().byId("deletebutton").setEnabled(false);
			this.getView().byId("confirmbutton").setEnabled(true);
		}
		
		},

		
		enableButton:function(){
			
			if(IntervalLength > 0)
				{
					this.getView().byId("addbutton").setEnabled(true);
					this.getView().byId("updatebutton").setEnabled(true);
					this.getView().byId("deletebutton").setEnabled(true);
					this.getView().byId("confirmbutton").setEnabled(true);
				}
			
		},
onHelp:function(){

		UI_utilities.OpenHelpFileSingle("Scrap");
	},
		
		ScrapShiftIntRowSelected:function()
		{
			
			var selectedConfTime = sap.ui.getCore().getModel("oShiftIntDetails").getProperty(this.getView().byId("Scraptable1").getSelectedContextPaths()[0]+"/DateTime");
			var dtsplit = selectedConfTime .split('T');
			confTime = dtsplit[0]+" "+ dtsplit[1];
			if(PhaseSelected==1)
			{
				this.getView().byId("addbutton").setEnabled(true);
				PhaseSelected=0;
			}
		}
});

});
