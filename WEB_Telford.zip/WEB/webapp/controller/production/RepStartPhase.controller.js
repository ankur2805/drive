sap.ui.define(["sap/ui/core/mvc/Controller", 
	"sap/m/MessageBox",
	"com/khc/rephub/utils/UI_utilities",
	"com/khc/common/Script/CommonUtility","com/khc/rephub/model/models"], 
	function(Controller,MessageBox,UI_utilities,CommonUtility,models ) {
	"use strict";
 	var plant;
	var resource;
	var projectName;
	var userName;
	var workStation;
	var status = '0,1';
	var btnID='';
	var loginName='';
	var sPath = '';
	
	var msgID;
	var crID;
	var resource;
	var todayDateTime;
	var orderID;
	var todayDate;
	var crDest;
	var sForShiftStart;
	var sForShiftEnd;
	var sShiftID;
	var sOrderStatus;
	var autoFlag='';
	var prodSpeed='';
	var grFlag='';
	var matNum='';
	var dt
	var oLastConfTimeModel = new sap.ui.model.json.JSONModel();
	
	return Controller.extend("com.khc.rephub.controller.production.RepStartPhase", {
		onInit: function() {
			
			
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("startPhase").attachPatternMatched(this._oRoutePatternMatched, this);
			
		},
		_oRoutePatternMatched: function(oEvent) {
			dt = new Date();
			todayDateTime = CommonUtility.getCurrentDateTime(dt);
			todayDate= CommonUtility.formatDate(dt);
			
			// Start Pahse is a sub screen in Schedule page
			UI_utilities.productionMenuOpened(this,"startPhase");
		
			UI_utilities.DisableDatePickerInput(this.getView().byId("startDateTime"));
			UI_utilities.DisableDatePickerInput(this.getView().byId("expiryDateTime"));
		
			var oModelTaskDetails = sap.ui.getCore().getModel("oTaskDetails");
			if(!oModelTaskDetails || 
			   !oModelTaskDetails.getData() ||
			   !CommonUtility.getJsonModelRowCount(oModelTaskDetails.getData())){
						
				 
					
					// Navigate to Production Schedule Page
					UI_utilities.openMenu(this._oRouter,this,"schedule");
					return;
				}
			sPath = "/Rowsets/Rowset/0/Row/" + oEvent.getParameter("arguments").ID;
			// Get tHe binding path and attach the element to the view
			this.getView().bindElement("oTaskDetails>"+sPath);
			
			let session=sap.ui.getCore().getModel("session").oData;
			
			plant=session.CA_Plant
			resource=session.CA_Resource
			projectName=session.CA_ProjectName;
			userName=session.CA_IllumLoginName;
			
			var selectedRow=oModelTaskDetails.getObject(sPath);
			msgID=selectedRow.MSGID
			crID=selectedRow.CRID
			resource=selectedRow.RESR
			orderID=selectedRow.ORDERID
			sOrderStatus = selectedRow.STATUS;
			crDest = selectedRow.CRDEST;
			matNum= selectedRow.MODMATNR
		
			this.clearValues();
			this.getPhaseList();
			this.getMaterialList();
			this.getOrderStart();
			this.getAutoFlag();
			this.populateGRFlag();
	
		},
		
		/**
		 *  to set the long text for order and phase
		 */
		setLongText : function(sID,sPahse) {
			
			//To load the order text
			var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
			//setOrderPahseLongText:function(oView,sId,sLanguage,sOrderID,sPlant,sPhase,sProjectName);
			var oView = this.getView();
			 UI_utilities.setOrderPahseLongText(oView,sID,sLanguage,orderID,plant,sPahse,projectName);
				
		},
		
		// Navigate the the selected menu page
		menuSelected : function (oEvent) {
        	
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
			
        },
/**********************************************************************************************************************************************************************************************/

/**********************************************************************************************************************************************************************************************/
clearValues:function(){
	this.getView().byId("startDateTime").setValue("");
	this.getView().byId("lineSpeed").setValue("");
	this.getView().byId("expiryDateTime").setValue("");
},
/**********************************************************************************************************************************************************************************************/

/**********************************************************************************************************************************************************************************************/
	
	loadPhaseText:function(oControlEvent){
		
		var selectedPhaseRowarr=this.getView().byId("phases").getSelectedContextPaths();
		if(selectedPhaseRowarr.length>0)
		{
			let sPath = selectedPhaseRowarr[0];
			let oModelPhaseDetails = sap.ui.getCore().getModel("oPhaseDetails");
			let sPhase = oModelPhaseDetails.getProperty(sPath+"/Phase");
			this.setLongText("phaseText",sPhase);
		}
		
	},
	
/******************************************************************************************************************************************************************************/

/*****************************************************************************************************************************************************************************/	
	getLastConfirmationData :  function(){
		
		let sLastConfTime = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+sForShiftStart+"&Param.4="+sForShiftEnd+"&d="+dt;
		oLastConfTimeModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetLastConfirmTime&"+sLastConfTime+"&Content-Type=text/json", "", false);
	},
/**********************************************************************************************************************************************************************************************/
//On Load Populate Phase Table, Shift Data-Shift Start Time,End time and shift ID form CheckShift(),load the order text 
/**********************************************************************************************************************************************************************************************/
getPhaseList:function(){
	 var oModelPhaseDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->getPhaseList-->XACQ_GetPhaseList");

     	 sap.ui.getCore().setModel(oModelPhaseDetails,"oPhaseDetails");
    	var that = this;
	this.CheckShift();
	
	oModelPhaseDetails.attachRequestCompleted(
			 function(){ 
				 if(CommonUtility.getJsonModelRowCount(oModelPhaseDetails.getData())) { 
					 that.selectMainPhase(); 
				 }
		});
					
	oModelPhaseDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetPhaseList&Param.1="+msgID+"&Param.2="+crID+"&Param.3="+resource+"&d="+dt+"&Content-Type=text/json", "", false);
	this.setLongText("orderText","");
},
/**********************************************************************************************************************************************************************************************/
//On load select main Phase from table list based on Phase Type
/**********************************************************************************************************************************************************************************************/
selectMainPhase : function() {
	
	
	 var oModelPhaseDetails=sap.ui.getCore().getModel("oPhaseDetails");

	var oPhasTable = this.getView().byId("phases");
	 var oPhaseData = oPhasTable.getItems();
	 var that = this;
		// Preselect the Main phase, PhaseType=1
		
		 oPhaseData.forEach((item)=> { 
			 
			 var sItemPath = item.getBindingContextPath();
			 var sPhaseType = oModelPhaseDetails.getProperty(sItemPath+"/PhaseType");
			 if(sPhaseType === "1"){
				 
				 let sPhase = oModelPhaseDetails.getProperty(sItemPath+"/Phase");
					
				 item.setSelected(true);
				 that.setLongText("phaseText",sPhase);
				// break;
			 }
			 
		 });
	
},
/**********************************************************************************************************************************************************************************************/
//On Load Populate Material List
/**********************************************************************************************************************************************************************************************/
getMaterialList:function(){
	
	 var oModelMatDetails=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->getMaterialList-->XACQ_GetMaterialList");

      	oModelMatDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetMaterialList&Param.1="+crID+"&Param.2="+msgID+"&d="+dt+"&Content-Type=text/json", "", false);
	this.getView().setModel(oModelMatDetails,"oMatDetails");

},
/**********************************************************************************************************************************************************************************************/
//On load populate Order Start date Time and Line Speed
/**********************************************************************************************************************************************************************************************/
getOrderStart:function(){
	
	 var oModelLineSpeed=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->getOrderStart-->SQLQ_GetOrderStart");
    
      	oModelLineSpeed.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetOrderStart&Param.1="+plant+"&Param.2="+resource+"&Param.3="+crID+"&d="+dt+"&Content-Type=text/json", "", false);
	let rowCount=CommonUtility.getJsonModelRowCount(oModelLineSpeed.getData())
	
	
	 var oModelProdSpeed=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->getOrderStart-->SQLQ_GetOrderPrdSpeed");

      	oModelProdSpeed.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetOrderPrdSpeed&Param.1="+plant+"&Param.2="+resource+"&Param.3="+crID+"&d="+dt+"&Content-Type=text/json", "", false);	
	if(CommonUtility.getJsonModelRowCount(oModelProdSpeed.getData())>0){
		prodSpeed=oModelProdSpeed.getData().Rowsets.Rowset[0].Row[0].PRODSPEED
	}
	if(rowCount>0){
		this.getView().byId('startDateTime').setValue(oModelLineSpeed.getData().Rowsets.Rowset[0].Row[0].STARTTIME)
		this.getView().byId('lineSpeed').setValue(oModelLineSpeed.getData().Rowsets.Rowset[0].Row[0].LINESPEED)
	}
	else{
		this.getView().byId('startDateTime').setValue(todayDateTime)
		this.getView().byId('lineSpeed').setValue(prodSpeed)
	}
},
/**********************************************************************************************************************************************************************************************/
//On Page Load set expiry date
/**********************************************************************************************************************************************************************************************/
populateGRFlag:function(){
	
	
	 var oModelGRFlag=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->populateGRFlag-->SQLQ_CheckGRFlagForResr");

      	oModelGRFlag.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_CheckGRFlagForResr&Param.1="+plant+"&Param.2="+resource+"&d="+dt+"&Content-Type=text/json", "", false);
	let rowCount=CommonUtility.getJsonModelRowCount(oModelGRFlag.getData());
	if(rowCount>0){  
		//grFlag="Y"
		grFlag=oModelGRFlag.getData().Rowsets.Rowset[0].Row[0].GRFLAG; 
		if(grFlag=='Y'){
		
			 var oModelGetSLED=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->populateGRFlag-->SQLQ_GetSLED");

      			oModelGetSLED.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetSLED&Param.1="+plant+"&Param.2="+resource+"&Param.3="+orderID+"&Param.4="+crID+"&d="+dt+"&Content-Type=text/json", "", false);
			let rowCountforGetSLED=CommonUtility.getJsonModelRowCount(oModelGetSLED.getData());
			this.getView().byId("bupExpDate").setEnabled(true);
			this.getView().byId("expiryDateTime").setEnabled(true);
			
			if(rowCountforGetSLED>0){
				var rowPath=oModelGetSLED.getData().Rowsets.Rowset[0].Row[0];
				if(rowPath.STATUS==1 && rowPath.EXPIRYDATE !='TimeUnavailable'){
					let expiryDate= CommonUtility.formatDate(rowPath.EXPIRYDATE);
					this.getView().byId("expiryDateTime").setValue(expiryDate);   /*YYYY-MM-DD*/
				}
				else{
					if(rowPath.SLED=="0" || rowPath.SLED=="---"){
						this.getView().byId("expiryDateTime").setValue(todayDate)   /*YYYY-MM-DD*/
					}
					else{
					
					
					 var oModelAddDay=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->populateGRFlag-->XACQ_AddDaysToDate");

      					oModelAddDay.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_AddDaysToDate&Param.1="+todayDateTime+"&Param.2="+rowPath.SLED+"&d="+dt+"&Content-Type=text/json", "", false);
					let sDate=oModelAddDay.getData().Rowsets.Rowset[0].Row[0].OutputDate
					let sExpityDate = "";
					if(sDate && sDate.indexOf("-"))
					{
						sExpityDate = sDate.substring(0,10);
					}
					
					this.getView().byId("expiryDateTime").setValue(sExpityDate);        /*YYYY-MM-DD*/
					}
				}
			}
		}
		else{
			this.getView().byId("bupExpDate").setEnabled(false)
			//this.getView().byId("expiryDateTime").setEnabled(false)
		}		
	}
	else{
			this.getView().byId("bupExpDate").setEnabled(false)
			//this.getView().byId("expiryDateTime").setEnabled(false)
	}	

},
/******************************************************************************************************************************************************************************/
//On Page Load set auto flag  variable
/*****************************************************************************************************************************************************************************/
getAutoFlag:function(){
	
	 var oAutoFlagModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->getAutoFlag-->SQLQ_GetAutoConFlagByResr");

	let sParamsUpdate = "Param.1="+plant+"&Param.2="+resource+"&d="+dt;
	oAutoFlagModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetAutoConFlagByResr&"+sParamsUpdate+"&Content-Type=text/json", "", false);
	if(CommonUtility.getJsonModelRowCount(oAutoFlagModel.getData())>0){
		autoFlag=oAutoFlagModel.getData().Rowsets.Rowset[0].Row[0].AUTOINTFLAG
	}
},
/*******************************************************************************************************************************************************************************************/

  //Get the Running Shift Details, if no running shift, disable start and update Start Time
 
/*********************************************************************************************************************************************************************************************/

CheckShift:function(){
	
	var dt = new Date();
	var datetime = CommonUtility.getCurrentDateTime(dt);
	
	 var oRunningShiftModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->CheckShift-->SQLQ_GetRunningShiftStartPhase");

	var that = this;
	oRunningShiftModel.attachRequestCompleted(
			 function(){
				 
				 if(CommonUtility.getJsonModelRowCount(oRunningShiftModel.getData())) {
					 
					 var oRunningShift = oRunningShiftModel.getData().Rowsets.Rowset[0].Row[0];
					 var shiftstart = oRunningShift.STARTTIME		
					 var Conshiftstart = shiftstart.split("T");
					 sForShiftStart = Conshiftstart[0]+" "+Conshiftstart[1];
					 var shiftend = oRunningShift.ENDTIME;
					 var Conshiftend = shiftend.split("T");
					 sForShiftEnd = Conshiftend[0]+" "+Conshiftend[1];
					 sShiftID = oRunningShift.SHIFTID;
					 
					 
					 that.getView().byId('id_btn_startphs').setEnabled(true);
					 that.getView().byId('id_btn_updordstart').setEnabled(true);
				 }
				 else	{
					 var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
					 sap.ui.getCore().getModel("oMessage").setProperty("/message",sNoShiftMsg);
					 sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					 sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
					 
					 sForShiftStart = "";
					 sForShiftEnd = "";
					 sShiftID = "";
					 
					 that.getView().byId('id_btn_startphs').setEnabled(false);
					 that.getView().byId('id_btn_updordstart').setEnabled(false);
				 }
			 
			 });
	
	oRunningShiftModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetRunningShiftStartPhase&Param.1="+plant+"&Param.2="+resource+"&d="+dt+"&Content-Type=text/json", "", false);
	
	
	
},
/******************************************************************************************************************************************************************************/

/*****************************************************************************************************************************************************************************/
/**
 * to Navigate back to the previous screen
 */
onBack:function(){
	
	UI_utilities.openMenu(this._oRouter,this,"schedule");
	
},

/******************************************************************************************************************************************************************************/
// Update the start time of the order
/*****************************************************************************************************************************************************************************/
updateOrderStart : function(){ 
	
	if(sOrderStatus!="1"){
		var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0192");
		MessageBox.alert(sAlertMsg, {
			 title: "Alert",                                  
	});
		
	}
	else{
		
		
		 var oConfirmationModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->updateOrderStart-->SQLQ_GetConfirmationCount");

		var sParams = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+crID+"&d="+dt;
		var that = this;
		// Check if any confirmation is already done, if yes throw error
		oConfirmationModel.attachRequestCompleted(
				 function(){
					 
					 var bNoConfirmation = true;
					 if(CommonUtility.getJsonModelRowCount(oConfirmationModel.getData())) {
						
						 var sCount = oConfirmationModel.getData().Rowsets.Rowset[0].Row[0].COUNT;
						 if(sCount != "0"){
							 
							 bNoConfirmation = false;
							 var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0193");
								MessageBox.alert(sAlertMsg, {
									 title: "Alert",                                  
							});
							 
						 }
						 
					 }
					 // No confirmation yet, call update start time
					 if(bNoConfirmation){
						 
						 that.proceedUpdateOrderStart();
					 }
					 
				 });
		
		oConfirmationModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetConfirmationCount&"+sParams+"&Content-Type=text/json", "", false);	
	}
},
/******************************************************************************************************************************************************************************/

/*****************************************************************************************************************************************************************************/
proceedUpdateOrderStart : function(){
	
	var lastConfTime ="";
	
	this.getLastConfirmationData();
	var that = this;
	// Check if any confirmation is already done, if yes throw error
	oLastConfTimeModel.attachRequestCompleted(
			 function(){
				 
				 var bNoConfirmation = true;
				 var alertMsgForTimeRange ="";
				 let sEndTimeMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0196");
				 
				 if(CommonUtility.getJsonModelRowCount(oLastConfTimeModel.getData())>0){
					 
					var sStartTimeMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0194");
					lastConfTime=oLastConfTimeModel.getData().Rowsets.Rowset[0].Row[0].RECORDTIME;
					alertMsgForTimeRange =sStartTimeMsg+" "+lastConfTime+" "+sEndTimeMsg+" "+sForShiftEnd;
					
				 }
				 else{
					 
					 lastConfTime=sForShiftStart;
					 var sStartTimeMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0195");
					 alertMsgForTimeRange =sStartTimeMsg+" "+lastConfTime+" "+sEndTimeMsg+" "+sForShiftEnd;
					
				 
					 var ordStartTime = that.getView().byId('startDateTime').getValue();
				 
					let returnExpValue=that.validateExpDate(lastConfTime, ordStartTime);
					if(returnExpValue==true){
						 MessageBox.alert(alertMsgForTimeRange, { title: "Alert", });
					}
					else{	 			 
						var oUpdateStartTimeModel = new sap.ui.model.json.JSONModel();
						let sParamsUpdate = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+crID+"&Param.4="+ordStartTime+"&d="+dt;
						oUpdateStartTimeModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdOrderStartDate&"+sParamsUpdate+"&Content-Type=text/json", "", false);
						
						var oUpdateCounterTelfordModel = new sap.ui.model.json.JSONModel();
						let sParamsUpdateCounter = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+ordStartTime+"&d="+dt;
						oUpdateCounterTelfordModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdateShiftCounterOrderStartTelford&"+sParamsUpdateCounter+"&Content-Type=text/json", "", false);
						
						MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0197"));
				           }
				}
			 });
},
/******************************************************************************************************************************************************************************/

/*****************************************************************************************************************************************************************************/
openManualMaster : function() {
	
	UI_utilities.OpenManualMaster();
	
},

/******************************************************************************************************************************************************************************/
// return true if the line speed is valid
/*****************************************************************************************************************************************************************************/
validateLineSpeed :function(lineSpeed){
	if(lineSpeed == "" || isNaN(lineSpeed))
		{
			return true;			
		}
	else{
		return false;
		}
},
/******************************************************************************************************************************************************************************/
//return true if the Expiry Date is valid
/*****************************************************************************************************************************************************************************/
validateExpDate:function(lastConfTime, ordStartTime){
	if(lastConfTime > ordStartTime || sForShiftEnd<=ordStartTime)
		{
			return true;
			
		}
	else{
		return false;	
	}
},
/******************************************************************************************************************************************************************************/

/*****************************************************************************************************************************************************************************/
startPhase:function(){
	var alertMsgForTimeRange ="";
	var lastConfTime ="";
	
	this.getLastConfirmationData();
	if(CommonUtility.getJsonModelRowCount(oLastConfTimeModel.getData())>0){
		lastConfTime=oLastConfTimeModel.getData().Rowsets.Rowset[0].Row[0].RECORDTIME;
		alertMsgForTimeRange=sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0194")+" "+lastConfTime+" "+sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0196")+" "+sForShiftEnd;
	}
	else{
		lastConfTime=sForShiftStart;
		alertMsgForTimeRange=sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0195")+" "+sForShiftStart+" "+sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0196")+" "+sForShiftEnd;
	}
	
	var selectedPhaseRowarr=this.getView().byId("phases").getSelectedContextPaths();
	if(selectedPhaseRowarr.length=="0")
	{
	 
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0006")
		 MessageBox.alert(msg, { title: "Alert", });
    	 }
	else{		
		let sPath = selectedPhaseRowarr[0];
		let oModelPhaseDetails = sap.ui.getCore().getModel("oPhaseDetails");

		let phase = oModelPhaseDetails.getProperty(sPath+"/Phase");
		let status =oModelPhaseDetails.getProperty(sPath+"/Status");
		let operation =oModelPhaseDetails.getProperty(sPath+"/Operation");
		let uom =oModelPhaseDetails.getProperty(sPath+"/UOM");
		let phaseType =oModelPhaseDetails.getProperty(sPath+"/PhaseType");
		let phaseUOM =oModelPhaseDetails.getProperty(sPath+"/PhaseUOM");
		let convert=oModelPhaseDetails.getProperty(sPath+"/Conversion");
	
		let ordStartTime=this.getView().byId("startDateTime").getValue();
		let expDateTime=this.getView().byId("expiryDateTime").getValue();
		let lineSpeed=this.getView().byId("lineSpeed").getValue();
		let prdSpeedFlag = this.validatePrdSpeed();
		let returnLineSpeed=this.validateLineSpeed(lineSpeed);
		let returnExpValue=this.validateExpDate(lastConfTime, ordStartTime);
		
		
		if(status==1)
		{
			let msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0007")
			 MessageBox.alert(msg, { title: "Alert", });
			
		}
		else if(phaseType!=1)
		{
			let msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0008")
			 MessageBox.alert(msg, { title: "Alert", });
			this.selectMainPhase();
		}
		else if((this.getView().byId("expiryDateTime").getValue()=="" && grFlag=="Y") || (this.getView().byId("expiryDateTime").getValue()=="---" && grFlag=="Y") ||  (this.getView().byId("expiryDateTime").getValue()=="TimeUnavailable" && grFlag=="Y")){
			//alert("Expiry Date cannot be blank. Please reload page or Update Expiry date manually");
			var msg="Expiry Date cannot be blank. Please reload page or Update Expiry date manually";
			 MessageBox.alert(msg, { title: "Alert", });
		}
		else if(expDateTime<todayDate && grFlag=="Y"){
			//alert("Expiry Date cannot be a Past Date");
			let msg="Expiry Date cannot be a Past Date";
			 MessageBox.alert(msg, { title: "Alert", });
			this.getView().byId("expiryDateTime").setValue(todayDate);	
		}
		else if(prdSpeedFlag=="0")
		{
			//alert("Product Speed should be greater than zero");
			var msg="Product Speed should be greater than zero";
			 MessageBox.alert(msg, { title: "Alert", });
		}
		
		else if(returnLineSpeed==true){
			var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0119");
			MessageBox.error(msg, {title: "Error",});
		}
		else if(returnExpValue==true){
			 MessageBox.alert(alertMsgForTimeRange, { title: "Alert", });
		}
		else{
			
			let evtdate =ordStartTime.substring(0,4)+ordStartTime.substring(5,7)+ordStartTime.substring(8,10);
			let evttime =	ordStartTime.substring(11,13)+ordStartTime.substring(14,16)+ordStartTime.substring(17,20);
			var js_charname = "PPPI_YIELD_TO_CONFIRM~PPPI_UNIT_OF_MEASURE~PPPI_STATUS_CONFIRMED~PPPI_SCRAP_TO_CONFIRM~PPPI_PROCESS_ORDER~PPPI_POSTING_DATE~PPPI_PLANT_OF_RESOURCE~PPPI_PHASE_RESOURCE~PPPI_PHASE~PPPI_OPERATION~PPPI_EVENT_TIME~PPPI_EVENT_DATE";
			var js_chardatatype = "NUM~CHAR~CHAR~NUM~CHAR~DATE~CHAR~CHAR~CHAR~CHAR~TIME~DATE";

			var js_charvalue = "0~"+phaseUOM+"~00004~0~"+orderID+"~"+evtdate+"~"+plant+"~"+resource+"~"+phase+"~"+operation+"~"+evttime+"~"+evtdate;
		
			
			 var oStartPhaseModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->startPhase-->XACQ_StartPhase");

			let sStartPhaseParam = "Param.1="+crID+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+phase+"&Param.5="+orderID+"&Param.6="+userName+"&Param.7="+ordStartTime+"&Param.8="+js_chardatatype+"&Param.9="+js_charname+"&Param.10="+js_charvalue+"&Param.11=ZI_PHCON"+"&Param.12="+operation+"&Param.13="+uom+"&Param.14="+crDest+"&Param.15="+phaseUOM+"&Param.16="+convert+"&d="+dt;;
			oStartPhaseModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_StartPhase&"+sStartPhaseParam+"&Content-Type=text/json", "", false);
			let startPhasePath=oStartPhaseModel.getData().Rowsets.Rowset[0].Row[0]
			if(startPhasePath.Type=="E"){
				var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0011");
				MessageBox.error(msg, {title: "Error", });
			}	
			else if(startPhasePath.Type=="S" ||startPhasePath.Type=="B" ){

				sOrderStatus=1;
				this.resetCounter();	
				
				
				 var oUpdateLineSpeedModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->startPhase-->SQLQ_UpdLineSpeed");
				let sUpdateLineSpeedParam = "Param.1="+lineSpeed+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+crID+"&d="+dt;
				oUpdateLineSpeedModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdLineSpeed&"+sUpdateLineSpeedParam+"&Content-Type=text/json", "", false);
			
				let expDateTime=this.getView().byId("expiryDateTime").getValue() +" 00:00:00";
				
				 var oUpdateExpdateModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->startPhase-->SQLQ_UpdExpiryDateForOrder");
				let sUpdateExpdateParam = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+orderID+"&Param.4="+crID+"&Param.5="+expDateTime+"&d="+dt;
				oUpdateExpdateModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdExpiryDateForOrder&"+sUpdateExpdateParam+"&Content-Type=text/json", "", false);
			
			
				if(startPhasePath.Type=="S"){
					var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0009");
					MessageBox.success(msg, {title: "Sucess", });	
				
				}
				else{
					var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0010");
					MessageBox.warning(msg, {title: "Warning", });	
				}
				
			}	
		           else if(startPhasePath.Type=="C"){
			var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0073");
					MessageBox.error(msg, {title: "Error",});
		           }
			
			
		    }
		
	}
},
/******************************************************************************************************************************************************************************/
//Check the boolean values for prod speed in start phase
/*****************************************************************************************************************************************************************************/
validatePrdSpeed:function(){
	if(autoFlag=="Y"){
		if(prodSpeed=="" || prodSpeed=="0" || prodSpeed=="---"){
			return false;
		}
		else{
			return true;
		}	
	}
	else{
		return true;
	}
},
/******************************************************************************************************************************************************************************/
//Reset the counter on successfully execution of start Phase .
/*****************************************************************************************************************************************************************************/
resetCounter:function(){
	let ordStartTime=this.getView().byId("startDateTime").getValue();
	
	 var oResetCounterModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->resetCounter-->XACQ_ResetCountAutoConfirmation");

	let sResetCounterParam = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+orderID+"&Param.4="+ordStartTime+"&Param.5="+sShiftID+"&Param.6="+matNum+"&d="+dt;
	oResetCounterModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_ResetCountAutoConfirmation&"+sResetCounterParam+"&Content-Type=text/json", "", false);

},
/******************************************************************************************************************************************************************************/
//On button click of Update Line Speed
/*****************************************************************************************************************************************************************************/
updateLineSpeed:function(){
	let lineSpeed=this.getView().byId("lineSpeed").getValue();
	let returnValue=this.validateLineSpeed(lineSpeed);
	if(returnValue==true){
	var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0119");
	MessageBox.error(msg, {title: "Error",});
	}
	else{
	
	var oUpdateLineSpeedModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->updateLineSpeed-->SQLQ_UpdLineSpeed");
	let sUpLineSpeedParam = "Param.1="+lineSpeed+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+crID+"&d="+dt;
	oUpdateLineSpeedModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdLineSpeed&"+sUpLineSpeedParam+"&Content-Type=text/json", "", false);
	var msg="Line Speed updated";
	MessageBox.success(msg, {title: "Success",});
	}
},
/******************************************************************************************************************************************************************************/
   //On button click of Update Exp Date 
/*****************************************************************************************************************************************************************************/
updateExpiryDate:function(){
	let expiryDate=this.getView().byId("expiryDateTime").getValue();  
	if(expiryDate<todayDate){
			//alert("Expiry Date cannot be a Past Date");
				var msg="Expiry Date cannot be a Past Date";
		MessageBox.alert(msg, {title: "Alert",});
		this.getView().byId("expiryDateTime").setValue(todayDate);  
	}
	else{
		
	var oUpdateExpiryDateModel=models.createNewJSONModel("com.khc.rephub.controller.production.RepStartPhase-->updateExpiryDate-->SQLQ_UpdExpiryDateForOrder");
	let sUpLineSpeedParam = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+orderID+"&Param.4="+crID+"&Param.5="+expiryDate+" 00:00:00"+"&d="+dt;
	oUpdateExpiryDateModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdExpiryDateForOrder&"+sUpLineSpeedParam+"&Content-Type=text/json", "", false);
		var msg="Expiry Date has been updated for the Order";
	MessageBox.alert(msg, {title: "Alert",});
	}

},
/******************************************************************************************************************************************************************************/

/*****************************************************************************************************************************************************************************/
onHelp:function(){

		UI_utilities.OpenHelpFileSingle("Prodnschedule");
	}
	});

});