sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox", "com/khc/rephub/utils/UI_utilities",
		"com/khc/rephub/model/formatter", "com/khc/common/Script/CommonUtility", "com/khc/rephub/model/models"
	],
	function(Controller, MessageBox, UI_utilities, formatter, CommonUtility, models) {
		"use strict";
		var plant;
		var resource;
		var projectName;
		var cr_dest;
		var userName;
		var twoStageFlag;
		var sIDParam;
		var eccFormat;

		var todayDateTime;
		var todayDate;
		var todayTime;

		var id_hid_oeequal;
		var id_hid_oeeavail;
		var id_hid_oeeperf;
		var id_txt_actspd;
		var dt;
		return Controller.extend("com.khc.rephub.controller.production.RepEIConfirm", {
			formatter: formatter,
			onInit: function() {

				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this._oRouter.getRoute("RepEIConfirm").attachPatternMatched(this._oRoutePatternMatched, this);

			},
			_oRoutePatternMatched: function(oEvent) {

				// To remove busy indicator once the page loaded
				UI_utilities.productionMenuOpened(this, "RepEIConfirm");

				dt = new Date();
				todayDate = CommonUtility.formatDate(dt);
				todayDateTime = CommonUtility.getCurrentDateTime(dt);
				todayTime = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();

				let session = sap.ui.getCore().getModel("session").oData;

				plant = session.CA_Plant;
				resource = session.CA_Resource;
				cr_dest = session.CA_CRDest;
				projectName = session.CA_ProjectName;
				twoStageFlag = session.CA_TwoStageFlag;
				userName = session.CA_IllumLoginName;
				eccFormat = session.CA_NumFormat;

				this.clearValues();
				this.getsIDParam();
				this.getTotalOutputNew();
				this.getAvailTime();
				this.Chart();
			},
			menuSelected: function(oEvent) {

				// Navigate the the selected menu page

				var sKey = oEvent.getParameters().key;
				UI_utilities.openMenu(this._oRouter, this, sKey);

			},
/***********************************************************************************************************************************************************************************/
			clearValues: function() {
				//Clear the values
				this.getView().byId("id_ta_sntext").setValue("");
			},
/***********************************************************************************************************************************************************************************/
// On Load fill the input boxes 
/***********************************************************************************************************************************************************************************/
			getsIDParam: function() {
				sIDParam = sap.ui.getCore().getModel("sIDParam").oData;
				this.getView().byId("id_txt_conftime").setValue(sIDParam.qs_ictime);
				this.getView().byId("id_txt_prodspd").setValue(sIDParam.qs_prodspeed);
				this.getView().byId("id_txt_shift").setValue(sIDParam.qs_shift);
				this.getView().byId("id_txt_lead").setValue(sIDParam.qs_lead);
				this.getView().byId("id_txt_crew").setValue(sIDParam.qs_crew);

				this.getView().byId("id_txt_orderstrip").setValue(sIDParam.qs_orderidstrip);
				this.getView().byId("id_txt_matnostrip").setValue(sIDParam.qs_Matnostrip);
				this.getView().byId("id_txt_desc").setValue(sIDParam.qs_desc);
				this.getView().byId("id_txt_plndqty").setValue(sIDParam.qs_planqty);

				this.getView().byId("id_txt_interval").setValue(sIDParam.qs_interval);
				this.getView().byId("id_txt_yield").setValue(sIDParam.qs_yield);
				//this.getView().byId("id_txt_trgout").setValue(sIDParam.qs_planqty);
				this.getView().byId("id_txt_plndqty").setValue(sIDParam.qs_planqty);
			},
/***********************************************************************************************************************************************************************************/
// On Load fill the input boxes 
/***********************************************************************************************************************************************************************************/
			getTotalOutputNew: function() {
				var js_goodOutput;
				var oConfScrapModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEIConfirm-->getTotalOutputNew-->XACQ_GetConfScrap");
				let getConfScrapParam = "Param.1=" + sIDParam.qs_crid + "&Param.2=" + plant + "&Param.3=" + resource + "&d=" + dt;
				oConfScrapModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetConfScrap&" + getConfScrapParam +
					"&Content-Type=text/json", "", false);
				if (CommonUtility.getJsonModelRowCount(oConfScrapModel.getData()) > 0) {
					let scrap = oConfScrapModel.getData().Rowsets.Rowset[0].Row[0].O_Scrap
					let scrapArray = scrap.split("|");
					let nonOEEScrap = scrapArray[0];
					let oeeScrap = scrapArray[1];
					let js_yield = this.getView().byId("id_txt_yield").getValue();
					let js_totalOutput = eval(js_yield) + eval(nonOEEScrap);

					// **** Calculate yield for CRQ000000064817
					if (eval(js_yield) == 0) {
						js_goodOutput = 0;
					} else {
						js_goodOutput = eval(js_yield) - eval(oeeScrap);
					}

					if (eval(js_goodOutput) < 0) {
						js_goodOutput = 0;
					}
					this.getView().byId("id_txt_yield2").setValue(js_goodOutput);
					this.getView().byId("id_txt_totout").setValue(js_totalOutput);
					var js_quality = (eval(js_goodOutput) / eval(js_totalOutput)) * 100;

					if (isNaN(js_quality)) {
						this.getView().byId("id_txt_qual").setValue("0%");
						id_hid_oeequal = 0;
					} else {
						let qualValue = js_quality.toFixed(2)
						this.getView().byId("id_txt_qual").setValue((js_quality.toFixed(2)) + "%");
						id_hid_oeequal = qualValue;
					}
					if (eval(js_quality) > 90) {
						this.getView().byId("id_txt_qual").getCustomData()[0].setValue("positive");
					} else {
						this.getView().byId("id_txt_qual").getCustomData()[0].setValue("negative");
					}

				}
			},

/***********************************************************************************************************************************************************************************/
// On click of create shift note button 
/***********************************************************************************************************************************************************************************/
			createShiftNotes: function() {
				sIDParam.qs_shift;
				let plainText = this.getView().byId("id_ta_sntext").getValue();
				if (plainText != "") {
				
						var oShiftNoteModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEIConfirm-->createShiftNotes-->XACQ_CreateShiftNotes");
					let shiftNoteParam = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=ZG99" + "&Param.4=" + todayDate + "&Param.5=" +
						todayTime + "&Param.6=" + "&Param.7=" + "&Param.8=" +
						"&Param.9=" + plainText + "&Param.10=" + "&Param.11=" + "&Param.12=Confirmation" + "&Param.13=" + userName + "&d=" + dt;
					oShiftNoteModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CreateShiftNotes&" +
						shiftNoteParam + "&Content-Type=text/json", "", false);
					if (CommonUtility.getJsonModelRowCount(oShiftNoteModel.getData()) > 0) {
						var ShiftNoteNum = oShiftNoteModel.getData().Rowsets.Rowset[0].Row[0].O_ShiftNote;
						//var ShiftNoteNum="Buffered";
						if (ShiftNoteNum == "E") {
							var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0086");
							sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
							sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
							sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
						} else {
								var oCreateShiftNoteModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEIConfirm-->createShiftNotes-->SQLQ_InsShiftNote");
							let createShiftNoteParam = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + sIDParam.qs_shift + "&Param.4=" +
								sIDParam.qs_ictime + "&Param.5=" + "&Param.6=" + plainText + "&Param.7=" + ShiftNoteNum + "&Param.8=" + sIDParam.qs_ShiftId +
								"&d=" + dt;
							oCreateShiftNoteModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsShiftNote&" +
								createShiftNoteParam + "&Content-Type=text/json", "", false);
							var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0085") + ShiftNoteNum;
							sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
							sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
							sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

						}
					}
				} else {
					let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0029");
					MessageBox.error(msg, {
						title: "Error",
					});
				}
			},
/***********************************************************************************************************************************************************************************/
// On Load fill the input boxes 
/***********************************************************************************************************************************************************************************/
			getAvailTime: function() {
					var oAvailTimeModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEIConfirm-->getAvailTime-->XACQ_GetIntervalAvailTime");
			
				let availTimeParam = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + sIDParam.qs_lictime + "&Param.4=" + sIDParam.qs_ictime +
					"&d=" + dt;
				oAvailTimeModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetIntervalAvailTime&" +
					availTimeParam + "&Content-Type=text/json", "", false);
				if (CommonUtility.getJsonModelRowCount(oAvailTimeModel.getData()) > 0) {
					let js_availTime = oAvailTimeModel.getData().Rowsets.Rowset[0].Row[0].O_AvailableTime;
					(parseFloat(js_availTime) > parseFloat(sIDParam.qs_interval)) ? this.getView().byId("id_txt_avl").setValue(sIDParam.qs_interval):
						this.getView().byId("id_txt_avl").setValue(js_availTime)

						var getAvailableDetailsModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEIConfirm-->getAvailTime-->XACQ_OEEAvailability");
					getAvailableDetailsModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEEAvailability&" +
						availTimeParam + "&Content-Type=text/json", "", false);
					let i = CommonUtility.getJsonModelRowCount(getAvailableDetailsModel.getData())
					let unschedule = "0"
					if (CommonUtility.getJsonModelRowCount(getAvailableDetailsModel.getData()) > 0) {
						for (var j = 0; j < i; j++) {
							let name = getAvailableDetailsModel.getData().Rowsets.Rowset[0].Row[j].CatCode;
							if (name == "Unscheduled" || name == "U") {
								unschedule = getAvailableDetailsModel.getData().Rowsets.Rowset[0].Row[j].Duration;
							}
						}

						let actualinterval = parseInt(sIDParam.qs_interval) - parseInt(unschedule);
						if (parseInt(actualinterval) <= 0) {
							actualinterval = 0;
						}

						let js_availability = (parseInt(js_availTime) / parseInt(actualinterval)) * 100;

						if (isNaN(js_availability)) {
							this.getView().byId("id_txt_avail").setValue("100%");
							id_hid_oeeavail = 100;
						} else {
							this.getView().byId("id_txt_avail").setValue(js_availability.toFixed(2) + "%");
							id_hid_oeeavail = js_availability.toFixed(2)
						}

						if (parseInt(id_hid_oeeavail) > 90) {
							this.getView().byId("id_txt_avail").getCustomData()[0].setValue("positive");
						} else {
							this.getView().byId("id_txt_avail").getCustomData()[0].setValue("negative");
						}

						this.populateData();
					}
				}
			},
/***********************************************************************************************************************************************************************************/
// On Load display the scrap chart values
/***********************************************************************************************************************************************************************************/
			populateData: function() {
				let js_trgOutput = this.getView().byId("id_txt_avl").getValue() * sIDParam.qs_prodspeed;
				this.getView().byId("id_txt_trgout").setValue(js_trgOutput);
				let js_yield = this.getView().byId("id_txt_yield").getValue();
				let js_performance = (parseFloat(js_yield) / parseFloat(js_trgOutput)) * 100;

				if (isNaN(js_performance)) {
					this.getView().byId("id_txt_perfom").setValue("0%");
					//this.getView().byId("id_txt_perfom").getCustomData()[0].setValue("0");
					id_hid_oeeperf = "0";
				} else {
					this.getView().byId("id_txt_perfom").setValue(js_performance.toFixed(2) + "%");
					id_hid_oeeperf = js_performance.toFixed(2);
				}

				//let actspd = (eval(js_yield)/eval(this.getView().byId("id_txt_avl").getValue())).toFixed(2);
				//this.getView().byId("id_txt_actspd").setValue(actspd);
				if (eval(js_performance) > 90) {
					this.getView().byId("id_txt_perfom").getCustomData()[0].setValue("positive");
				} else {
					this.getView().byId("id_txt_perfom").getCustomData()[0].setValue("negative");
				}
				// Enable "Confrim Button"
				this.getView().byId("id_btn_confirm").setEnabled(true)

			},
/***********************************************************************************************************************************************************************************/
// On Load display the scrap chart values
/***********************************************************************************************************************************************************************************/
			Chart: function() {
				/*var c = new com.sap.xmii.chart.hchart.i5Chart("RepHubUI5/DisplayTemplate/Scrapreason_i5Chart", "RepHubUI5/Query/SQLQ_GetTotalScrapForInterval");
					c.setChartWidth("640px");
					c.setChartHeight("400px");
					c.draw("div1");*/

					var oDownTimeModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEIConfirm-->Chart-->XACQ_DownTimePareto");
				let oDownTimeParam = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + sIDParam.qs_lictime + "&Param.4=" + sIDParam.qs_ictime +
					"&d=" + dt;
				oDownTimeModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_DownTimePareto&" + oDownTimeParam +
					"&Content-Type=text/json", "", false);
				this.getView().setModel(oDownTimeModel, "downTimeModel");

					var oScrapChartModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEIConfirm-->Chart-->SQLQ_GetTotalScrapForInterval");
				let oScrapCharParam = "Param.1=" + sIDParam.qs_lictime + "&Param.2=" + sIDParam.qs_ictime + "&Param.3=" + plant + "&Param.4=" +
					resource + "&d=" + dt;
				oScrapChartModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetTotalScrapForInterval&" +
					oScrapCharParam + "&Content-Type=text/json", "", false);

				//oScrapChartModel.loadData("/XMII/Illuminator?QueryTemplate=Default/Muthu/SQLQ_GetTotalScrapForInterval&" + oScrapCharParam + "&Content-Type=text/xml", "", false);
				this.getView().setModel(oScrapChartModel, "scrapModel");
			},

/***********************************************************************************************************************************************************************************/
// On Load fill the input boxes 
/***********************************************************************************************************************************************************************************/
			goBackToScrap: function() {
				this._oRouter.navTo("RepEIScrap");
			},
/***********************************************************************************************************************************************************************************/

/***********************************************************************************************************************************************************************************/
			confirmation: function() {
				var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0117");
				sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
				sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
				sap.ui.getCore().getModel("oMessage").setProperty("/type", "Warning");

				this.getView().byId("id_btn_confirm").setEnabled(false);
				this.getView().byId("id_btn_back").setEnabled(false);
				this.getView().byId("id_add_scrap").setEnabled(false);

				var oee = parseFloat(id_hid_oeeavail) * parseFloat(id_hid_oeeperf) * parseFloat(id_hid_oeequal);
				oee = parseFloat(oee / 10000);

				var evtdate = CommonUtility.formatDateToCallProcessMsg1(sIDParam.qs_ictime);
				var evttime = CommonUtility.formatTimeToCallProcessMsg1(sIDParam.qs_ictime);

				var js_clearResr = "";
				if (sIDParam.qs_statusconf == "00002") {
					js_clearResr = "X";
				}
				let confirmModelParam = "Param.1=" + sIDParam.qs_crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + sIDParam.qs_ictime +
					"&Param.5=" + evtdate + "&Param.6=" + evtdate + "&Param.7=" + evttime + "&Param.8=" + sIDParam.qs_statusconf + "&Param.9=" +
					sIDParam.qs_order + "&Param.10=" + sIDParam.qs_lictime +
					"&Param.11=" + sIDParam.qs_interval + "&Param.12=" + sIDParam.qs_crew + "&Param.13=" + eccFormat + "&Param.14=" + sIDParam.qs_endofshift +
					"&Param.15=" + sIDParam.qs_shiftstart + "&Param.16=" + id_hid_oeeavail + "&Param.17=" + id_hid_oeeperf + "&Param.18=" +
					id_hid_oeequal + "&Param.19=" + oee +
					"&Param.20=" + sIDParam.qs_shift + "&Param.21=" + sIDParam.qs_linesetspd + "&Param.22=" + userName + "&Param.23=" + sIDParam.qs_msgid +
					"&Param.24=" + js_clearResr +
					"&Param.25=" + sIDParam.qs_NewShiftCount + "&Param.26=" + sIDParam.qs_ShiftId + "&d=" + dt;
				var type;
				var message;
				var that = this;
				if (twoStageFlag == "1") {
					$.ajax({
						type: "GET",
						url: "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_EndIntervalConfirmV3&Content-Type=text/json",
						dataType: "json",
						data: confirmModelParam,
						success: function(result) {
							type = result.Rowsets.Rowset[0].Row[0].Type;
							message = result.Rowsets.Rowset[0].Row[0].Message;
							that.showOutput(type, message);
						}
					});
				} else {
					$.ajax({
						type: "GET",
						url: "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_EndIntervalConfirmV2&Content-Type=text/json",
						dataType: "json",
						data: confirmModelParam,
						success: function(result) {
							type = result.Rowsets.Rowset[0].Row[0].Type;
							message = result.Rowsets.Rowset[0].Row[0].Message;
							that.showOutput(type, message);
						}
					});
				}
			},

			showOutput: function(type, message) {
				var that = this;
				if (type == "S") {

					var endOfInterval = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0129");
					sap.ui.getCore().getModel("oMessage").setProperty("/message", endOfInterval);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");
					// to navigate back to home screen
					setTimeout(function() {
						that.goBack();
					}, 2000);
				} else if (type == "SFC") {

					var endOfFinalInterval = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0130");
					sap.ui.getCore().getModel("oMessage").setProperty("/message", endOfFinalInterval);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");
					setTimeout(function() {
						that.goBack();
					}, 2000);
				} else if (type == "SSE") {

					let shiftEndmsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0131") + "   " + message;
					sap.ui.getCore().getModel("oMessage").setProperty("/message", shiftEndmsg);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

					/*setTimeout(function(){ 
	
					sap.ui.getCore().getModel("oMessage").setProperty("/message",message);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
					}, 2000);*/

					setTimeout(function() {
						that.goBack();
					}, 2000);
				} else if (type == "E") {

					var error = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0132");
					sap.ui.getCore().getModel("oMessage").setProperty("/message", error);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
					this.getView().byId("id_btn_confirm").setEnabled(false);
				}

				this.getView().byId("id_btn_confirm").setEnabled(true);
				this.getView().byId("id_btn_back").setEnabled(true);
				this.getView().byId("id_add_scrap").setEnabled(true);

			},
			goBack: function() {
				this.getView().byId("id_btn_confirm").setEnabled(false);
				if (sIDParam.qs_endofshift == "1") {
					this._oRouter.navTo("startShift");
				} else {
					this._oRouter.navTo("Production");
				}
			},
			onHelp: function() {

					UI_utilities.OpenHelpFileSingle("Confirmation");
				}
/***********************************************************************************************************************************************************************************/

/***********************************************************************************************************************************************************************************/
		});

	});