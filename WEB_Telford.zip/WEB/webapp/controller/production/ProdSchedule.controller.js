sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox", "com/khc/rephub/utils/UI_utilities",
	"com/khc/rephub/model/formatter", "com/khc/rephub/model/models"
], function(Controller,
	Filter, MessageBox, UI_utilities, formatter, models) {
	"use strict";
	var plant;
	var resource;
	var projectName;
	var workStation;
	var status = '0,1';
	var btnID = '';
	var loginName = '';
	var dt;
	return Controller.extend("com.khc.rephub.controller.production.ProdSchedule", {
		formatter: formatter,
		onInit: function() {

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("schedule").attachPatternMatched(this._oRoutePatternMatched, this);
		},
		_oRoutePatternMatched: function(oEvent) {

			UI_utilities.productionMenuOpened(this, "schedule");

			dt = new Date();

			plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
			resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
			projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
			workStation = sap.ui.getCore().getModel("session").oData.CA_CRDest;
			loginName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;

			this.getTaskDetailsList();
			this.setFirstRowSelected();
		},

		// Navigate the the selected menu page
		menuSelected: function(oEvent) {

			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter, this, sKey);

		},
		onAfterRendering: function() {
			//alert("onAfterRendering function called");
			/*****************TaskList table binding ********************/
			//var oGrid = new com.sap.xmii.grid.init.i5Grid("NL_ELS_HUB_SAPUi5/DisplayTemplate/GetTaskList_BLS_i5Grid", "NL_ELS_HUB_SAPUi5/Query/GetTaskList_BLS_XAC");
			//oGrid.setGridWidth("640px");
			//oGrid.setGridHeight("400px");
			//oGrid.draw(this.getView().byId("div1"));
			//oGrid.draw("div1");

		},

		onHelp: function() {

			UI_utilities.OpenHelpFileSingle("Prodnschedule");
		},
/**************************************************************************************************************************************************************************************/
//on Load get the list of tasks
/*****************************************************************************************************************************************************************************************/
		getTaskDetailsList: function() {
			var oModelTaskDetails = models.createNewJSONModel(
				"com.khc.rephub.controller.production.ProdSchedule-->getTaskDetailsList-->XACQ_GetTaskList");
			oModelTaskDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetTaskList&Param.1=" + plant +
				"&Param.2=" + resource + "&Param.3=" + workStation + "&Param.4=" + status + "&d=" + dt + "&Content-Type=text/json", "", false);

			sap.ui.getCore().setModel(oModelTaskDetails, "oTaskDetails");

		},

/**************************************************************************************************************************************************************************************/
//Set the first Row selected
/*****************************************************************************************************************************************************************************************/
		setFirstRowSelected: function() {
			var taskDetailsObj = this.getView().byId("taskDetailsId");
			var taskDetailItems = taskDetailsObj.getItems();
			if (taskDetailItems && taskDetailItems.length > 0) {
				taskDetailItems[0].setSelected(true);
			}
		},

/**************************************************************************************************************************************************************************************/
//Filter All Orders
/*****************************************************************************************************************************************************************************************/
		filterAllOrders: function() {
			this.filterTaskSelection('0,1');
			this.getView().byId("taskDetailsId").removeSelections(true);
			this.setFirstRowSelected();
		},
/**************************************************************************************************************************************************************************************/
//Filter in progress
/*****************************************************************************************************************************************************************************************/
		filterInProgress: function() {
			this.filterTaskSelection('1');
			this.getView().byId("taskDetailsId").removeSelections(true);
			this.setFirstRowSelected();
		},
/**************************************************************************************************************************************************************************************/
//Filter scheduled
/*****************************************************************************************************************************************************************************************/
		filterScheduled: function() {
			this.filterTaskSelection('0');
			this.getView().byId("taskDetailsId").removeSelections(true);
			this.setFirstRowSelected();
		},

/**************************************************************************************************************************************************************************************/
//Filter as per button selection
/*****************************************************************************************************************************************************************************************/
		filterTaskSelection: function(statuscode) {
			// Get the table Binding to apply filters
			var oTable = this.getView().byId("taskDetailsId");
			var oBinding2 = oTable.getBinding("items");
			// Array to combine filters
			var aFilters = [];
			//STATUS is the json property, EQ is filter operator, "statuscode" is the value to Filter
			if (statuscode === '0' || statuscode === '1') {
				aFilters.push(
					new Filter([new Filter("STATUS", "EQ", statuscode)])
				);
			}

			oBinding2.filter(aFilters);
		},

/**************************************************************************************************************************************************************************************/
//discard as per button selection
/*****************************************************************************************************************************************************************************************/
		discRecipe: function(oEvent) {
			var msg = '';
			var aPaths = this.getView().byId("taskDetailsId").getSelectedContextPaths();
			if (aPaths.length > 0) {
				var sPath = aPaths[0];
				var oModelTaskDetails = sap.ui.getCore().getModel("oTaskDetails");

				var crId = oModelTaskDetails.getProperty(sPath + "/CRID");
				var orderId = oModelTaskDetails.getProperty(sPath + "/ORDERID");
				var statusCode = oModelTaskDetails.getProperty(sPath + "/STATUS");

				if (statusCode === '1') {
					msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0035");
					//alert(msg);
					MessageBox.alert(msg, {
						title: "Alert", // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.OK, // default
						emphasizedAction: sap.m.MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				} else {
					//confirm box - HUB_MSG_0123=Are you sure you want to discard selected order?
					msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0123");
					var that = this;
					MessageBox.confirm(
						msg, {
							icon: MessageBox.Icon.INFORMATION,
							title: "Message from webpage",
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							onClose: function(oAction) {
								if (oAction === "OK") {

									jQuery.ajax({
										url: "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_ControlRecipeDiscard&Param.1=" + crId +
											"&Param.2=" + orderId + "&Param.3=" + plant + "&Param.4=" + resource + "&Param.5=" + loginName + "&d=" + dt +
											"&Content-Type=text/json",
										type: 'POST',
										async: false,
										success: function(xmlData) {

											msg = that.getView().getModel("i18n").getProperty("HUB_MSG_0034");
											MessageBox.alert(msg, {
												title: "Alert", // default
												onClose: null, // default
												styleClass: "", // default
												actions: sap.m.MessageBox.Action.OK
											});

											that.getTaskDetailsList();

										},
										error: function(xmlData) {},

									});
								}
							}
						});
				}
			} else {

				// slectOrderMsg = Please select an Order, need to add this in translation
				var sAlertMsg = this.getView().getModel("i18n").getProperty("slectOrderMsg");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",
				});

			}

		},

/**************************************************************************************************************************************************************************************/
//to Navigate to the start Phase screen
/*****************************************************************************************************************************************************************************************/
		startPhase: function(oEvent) {

			var aPaths = this.getView().byId("taskDetailsId").getSelectedContextPaths();
			if (aPaths.length > 0) {

				var sPath = aPaths[0];
				// To get the model Index
				var sId = sPath.slice(-1);

				//ID is Mandatory parameter in the routing, to find the model path in start phase screen
				this._oRouter.navTo("startPhase", {
					ID: sId
				});

				UI_utilities.setContainerBusyState(this, true);
			} else {

				// slectOrderMsg = Please select an Order, need to add this in translation
				var sAlertMsg = this.getView().getModel("i18n").getProperty("slectOrderMsg");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",
				});

			}

		},

	});

});