sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox",
	"com/khc/common/Script/CommonUtility", "com/khc/rephub/utils/UI_utilities", "com/khc/rephub/model/models",
	"com/khc/rephub/model/formatter"
], function(Controller, MessageBox, CommonUtility, UI_utilities, models,formatter) {
	"use strict";
	var plant;
	var resource;
	var projectName;
	var workstation;
	var username;
	var startdate;
	var ShiftRowCount;
	var shiftcounter = 0;
	var shiftdata;
	var shiftstarttime;
	var shiftenddate;
	var shiftid;
	var avail_running_new;
	var selectedshiftstatus;
	var selectedShiftRunTime;
	var oee_perf = "";
	var oee_qual = "";
	var oee_avail = "";
	var AvailLowLimit;
	var AvailUpLimit;
	var PerfLowLimit;
	var PerfUpLimit;
	var QualLowLimit;
	var QualUpLimit;
	var OEELowLimit;
	var OEEUpLimit;
	var resourcechangeflag = 0;

	return Controller.extend("com.khc.rephub.controller.production.RepEndShift", {
		formatter: formatter,
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("Production").attachPatternMatched(this._oRoutePatternMatched, this);

		},
		_oRoutePatternMatched: function(oEvent) {

			if (sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuPrdViewer") {
				this.getView().byId("ProdMenuBar").setVisible(false);
				UI_utilities.productionMenuOpened(this, "endShiftPrdViewer");
			} else {
				this.getView().byId("ProdMenuBar").setVisible(true);
				UI_utilities.productionMenuOpened(this, "Production");
			}

			plant = sap.ui.getCore().getModel("session").oData.CA_Plant
			resource = sap.ui.getCore().getModel("session").oData.CA_Resource
			projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName
			workstation = sap.ui.getCore().getModel("session").oData.CA_CRDest
			username = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName

			var oUIData = {
				showShiftNotes: "false",
				currentSelection: "Performance"
			};
			var oHomeUIModel = new sap.ui.model.json.JSONModel(oUIData);
			this.getView().setModel(oHomeUIModel, "homeUI");
			this.getView().byId("id_btn_New").setEnabled(false);
			shiftcounter = 0;
			this.getResourceData();
			this.setDuration();
			this.CheckOpenDT();
			this.getShift();
			/*
			this.populateAvailData();
			this.populateQualityData();
			this.calculateOEE();
			this.getOrderData();
			*/

		},

		// Set the Duration Model
		setDuration: function() {

			var oDurationData = {
				showDuration: false,
				duration: ""
			};
			var oDurationModel = new sap.ui.model.json.JSONModel(oDurationData);
			sap.ui.getCore().setModel(oDurationModel, "duration");

		},

		onHelp: function() {

			UI_utilities.OpenHelpFileSingle("Prodnhome");
		},

		CheckIntData: function() {

			this.getIntData();
			this.getView().getModel("homeUI").setProperty("/currentSelection", "Interval");
			this.getView().byId("id_btn_New").setEnabled(false);

		},

		CheckMaintNotif: function() {

			this.getMaintNotifData();
			this.getView().getModel("homeUI").setProperty("/currentSelection", "MaintNotification");
			this.getView().byId("id_btn_New").setEnabled(true);

		},

		CheckQualityNotif: function() {

			this.getQualNotifData();
			this.getView().getModel("homeUI").setProperty("/currentSelection", "QualNotification");
			this.getView().byId("id_btn_New").setEnabled(true);

		},

		CheckDowntime: function() {

			this.getDownTimeData();
			this.getView().getModel("homeUI").setProperty("/currentSelection", "DownTime");
			this.getView().byId("id_btn_New").setEnabled(true);

		},

		CheckShiftNote: function() {

			this.getShiftNoteData();
			this.getView().getModel("homeUI").setProperty("/currentSelection", "ShiftNotes");
			this.getView().byId("id_btn_New").setEnabled(true);

		},

		CheckPerformance: function() {

			this.getView().getModel("homeUI").setProperty("/currentSelection", "Performance");
			this.getView().byId("performlblhdr").setText(sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0052"));
			this.getView().byId("id_btn_New").setEnabled(false);

		},

		CheckAvailability: function() {

			this.getView().getModel("homeUI").setProperty("/currentSelection", "Availability");
			this.getView().byId("performlblhdr").setText(sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0049"));
			this.getView().byId("id_btn_New").setEnabled(false);

		},

		CheckQuality: function() {

			this.getView().getModel("homeUI").setProperty("/currentSelection", "Quality");
			this.getView().byId("performlblhdr").setText(sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0045"));
			this.getView().byId("id_btn_New").setEnabled(false);

		},

		// To remove busy indicator once the page loaded
		onAfterRendering: function() {
			//	UI_utilities.setContainerBusyState( this.getOwnerComponent().oContainer,false);
		},

		/**
		 * Called when a User clicked a menu
		 * 
		 */

		menuSelected: function(oEvent) {

			// Navigate the the selected menu page

			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter, this, sKey);

		},

		getResourceData: function(oEvent) {

			var oModel1 = models.createNewXMLModel("com.khc.rephub.controller.production.RepEndShift-->getResourceData-->XACQ_GetResrByPlant");
			oModel1.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetResrByPlant&Param.1=" + plant +
				"&content-type=text/xml", "", false);
			var oTable = this.getView().byId("id_resource_combobox");
			oTable.setModel(oModel1, "DropDown");
			this.getView().byId("id_resource_combobox").setSelectedKey(resource);
		},

		onResourceChange: function() {
			this.getView().byId("id_resource_combobox").getSelectedKey();
			resource = this.getView().byId("id_resource_combobox").getSelectedKey();
			shiftcounter = 0;
			this.getView().getModel("homeUI").setProperty("/currentSelection", "Performance");
			this.setDuration();
			this.CheckOpenDT();
			this.getShift();
			resourcechangeflag = 1;
		},

/*****************************************************************************************************************************************************************************************/
// on load of page, load the data of 1st row values - Resource, Resource Status and Duration
/****************************************************************************************************************************************************************************************/
		CheckOpenDT: function() {

			var oModelGetopenDTDetails = models.createNewJSONModel("com.khc.rephub.controller.production.RepEndShift-->CheckOpenDT-->SQLQ_GetDownTime");
			oModelGetopenDTDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetDownTime&Param.1=" +plant + "&Param.2=" + resource + "&d=" + new Date() + "&Content-Type=text/json", "", false);
			this.getView().setModel(oModelGetopenDTDetails, "oOpenDTDetails");

			if (CommonUtility.getJsonModelRowCount(oModelGetopenDTDetails.getData()) > 0) {
				startdate = oModelGetopenDTDetails.getData().Rowsets.Rowset[0].Row[0].DTSTART;
			}

			var oModelRunningShiftDetails = models.createNewJSONModel("com.khc.rephub.controller.production.RepEndShift-->CheckOpenDT-->XACQ_GetTaskList");
			oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetTaskList&Param.1=" +
				plant + "&Param.2=" + resource + "&Param.3=" + workstation + "&Param.4=" + "1" + "&d=" + new Date() + "&Content-Type=text/json",
				"", false);
			this.getView().setModel(oModelRunningShiftDetails, "oRunningShiftDetails");

			if (CommonUtility.getJsonModelRowCount(oModelGetopenDTDetails.getData()) == 0 && CommonUtility.getJsonModelRowCount(
					oModelRunningShiftDetails.getData()) == 0) {

				this.getView().byId("resourcestatusip").setValue("");
				this.getView().byId("resourcestatusip").getCustomData()[0].setValue("notRunning");
			} else if (CommonUtility.getJsonModelRowCount(oModelGetopenDTDetails.getData()) == 0 && CommonUtility.getJsonModelRowCount(
					oModelRunningShiftDetails.getData()) != 0) {

				this.getView().byId("resourcestatusip").setValue("Running");
				this.getView().byId("resourcestatusip").getCustomData()[0].setValue("Running");
				this.getView().byId("durationip").setValue("");
			} else {

				var getStatus = oModelGetopenDTDetails.getData().Rowsets.Rowset[0].Row[0].TYPE;
				if (getStatus == "I") {
					this.getView().byId("resourcestatusip").setValue("Idle");
					this.getView().byId("resourcestatusip").getCustomData()[0].setValue("Idle");
				} else if (getStatus == "F") {
					this.getView().byId("resourcestatusip").setValue("Failure");
					this.getView().byId("resourcestatusip").getCustomData()[0].setValue("Failure");
				} else if (getStatus == "U") {
					this.getView().byId("resourcestatusip").setValue("Un-Scheduled");
					this.getView().byId("resourcestatusip").getCustomData()[0].setValue("Un-Scheduled");
				} else {
					this.getView().byId("resourcestatusip").setValue("Restraint");
					this.getView().byId("resourcestatusip").getCustomData()[0].setValue("Restraint");
				}

				startdate = oModelGetopenDTDetails.getData().Rowsets.Rowset[0].Row[0].DTSTART;
				let date = new Date(startdate);
				date.setDate(date.getDate());
				let formatedDate = CommonUtility.getCurrentDateTime(date);
				startdate = formatedDate;
				//this.getView().byId("start_date").setValue(formatedDate);

				let dt = new Date();
				let todayDateTime = CommonUtility.getCurrentDateTime(dt);
				var datetime = todayDateTime;

				this.getView().getModel("duration").setProperty("/showDuration", true);
				this.SetCounterDisp();
				}
			},

/*****************************************************************************************************************************************************************************************/
// on load of page, load current/latest shift data
/****************************************************************************************************************************************************************************************/

		getShift: function() {

			//this.setDuration();
			var that = this;

			var oModelGetShiftDetails = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getShift-->SQLQ_GetShiftDetails_Ordered");
			oModelGetShiftDetails.attachRequestCompleted(
				function() {
					ShiftRowCount = CommonUtility.getJsonModelRowCount(oModelGetShiftDetails.getData());
					if (ShiftRowCount > 0) {
						shiftdata = oModelGetShiftDetails.getData().Rowsets.Rowset[0].Row;
						that.setShiftData();
					} else {
						that.clearAll();
						that.getOrderData();
						that.PrevNextShiftBtnEnableDisable();
					}

				});
			oModelGetShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
				"/QueryTemplate/SQLQ_GetShiftDetails_Ordered&Param.1=" + plant + "&Param.2=" + resource + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelGetShiftDetails, "oGetShiftDetails");

		},

		setShiftData: function() {

			//UI_utilities.setContainerBusyState(this,true);
		
			/*
			var confWarnMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0101");
			sap.ui.getCore().getModel("oMessage").setProperty("/message",confWarnMsg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");
			*/

			var starttime;
			var shiftname;
			var lead;
			var teamname;
			var crew;
			var interval;
			var shiftstatus;

			starttime = shiftdata[shiftcounter].STARTTIME;
			shiftname = shiftdata[shiftcounter].SHIFTNAME;
			lead = shiftdata[shiftcounter].LEAD;
			teamname = shiftdata[shiftcounter].TEAMNAME;
			crew = shiftdata[shiftcounter].TEAMSIZE;
			interval = shiftdata[shiftcounter].INTERVAL;
			shiftstatus = shiftdata[shiftcounter].RUNNING;
			shiftenddate = shiftdata[shiftcounter].ENDTIME;
			shiftid = shiftdata[shiftcounter].SHIFTID;
			selectedShiftRunTime = shiftdata[shiftcounter].RUNTIME;

			shiftstarttime = starttime;
			selectedshiftstatus = shiftstatus;

			this.getView().byId("startdatetimeip").setValue(starttime);
			this.getView().byId("shiftip").setValue(shiftname);
			this.getView().byId("Leadip").setValue(lead);
			this.getView().byId("Teamnameip").setValue(teamname);
			this.getView().byId("crewip").setValue(crew);
			this.getView().byId("intervalminsip").setValue(interval);

			let dt = new Date();
			let todayDateTime = CommonUtility.getCurrentDateTime(dt);
			var datetime = todayDateTime;

			var DurCalc = (Date.parse(shiftenddate) - Date.parse(starttime)) / 1000;
			var Dur_Min = Math.round(DurCalc / 60);

			this.getView().byId("durminsip").setValue(Dur_Min);

			if (shiftstatus == "2") {
				this.getView().byId("shiftstatusip").setValue("Completed");
			} else if (shiftstatus == "3") {
				this.getView().byId("shiftstatusip").setValue("Confirmed");
			} else if (shiftstatus == "1") {
				this.getView().byId("shiftstatusip").setValue("Open");
			} else {
				this.getView().byId("shiftstatusip").setValue("");
			}

			this.populateAvailData();

			this.getOrderData();
			this.PrevNextShiftBtnEnableDisable();

			if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "MaintNotification") {
				this.CheckMaintNotif();
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "QualNotification") {
				this.CheckQualityNotif();
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "DownTime") {
				this.CheckDowntime();
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "ShiftNotes") {
				this.CheckShiftNote();
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "Interval") {
				this.CheckIntData();
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "Performance") {
				this.CheckPerformance();
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "Availability") {
				this.CheckAvailability();
			} else {
				this.CheckQuality();
			}

		},

		PrevNextShiftBtnEnableDisable: function() {
			if (shiftcounter == ShiftRowCount - 1) {
				this.getView().byId("PrevShiftBtn").setEnabled(false);
				this.getView().byId("NextShiftBtn").setEnabled(true);
			} else if (shiftcounter == 0 && ShiftRowCount != 0) {
				this.getView().byId("NextShiftBtn").setEnabled(false);
				this.getView().byId("PrevShiftBtn").setEnabled(true);
			} else if (shiftcounter == 0 && ShiftRowCount == 0) {
				this.getView().byId("PrevShiftBtn").setEnabled(false);
				this.getView().byId("NextShiftBtn").setEnabled(false);
			} else {
				this.getView().byId("PrevShiftBtn").setEnabled(true);
				this.getView().byId("NextShiftBtn").setEnabled(true);
			}
		},

/*****************************************************************************************************************************************************************************************/
// on click of Previous Button, load previous shift data of selected current/next shift data
/****************************************************************************************************************************************************************************************/

		PrevShift: function() {

			this.getView().setBusyIndicatorDelay(0);
			this.getView().setBusy(true);
			shiftcounter = shiftcounter + 1;
			if (shiftcounter < ShiftRowCount) {
				this.setShiftData();
			} else {
				shiftcounter = ShiftRowCount - 1;
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0042");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",
				});
				this.getView().setBusy(false);
			}

		},

/*****************************************************************************************************************************************************************************************/
// on click of Next Button, load next shift data of previously selected data
/****************************************************************************************************************************************************************************************/

		NextShift: function() {

			shiftcounter = shiftcounter - 1; // to set the counter for next shift 
			if (shiftcounter >= 0) {
			
				this.setShiftData();
			} else {
				shiftcounter = 0;
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0043");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",
				});
			}

		},

/*****************************************************************************************************************************************************************************************/
// on click of Current Button, load current/latest shift data
/****************************************************************************************************************************************************************************************/

		CurrShift: function() {

			shiftcounter = 0; // to set the counter for current shift 

			this.setShiftData();

		},

/*****************************************************************************************************************************************************************************************/
// on load of shift data, load Available OEE data
/****************************************************************************************************************************************************************************************/
		populateAvailData: function() {

			let dt = new Date();
			let todayDateTime = CommonUtility.getCurrentDateTime(dt);
			var currentDT = todayDateTime;
			var EDate = shiftenddate;
			var oModelGetAvailDetails = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->populateAvailData-->XACQ_OEEAvailability");

			if (EDate <= currentDT) {
				oModelGetAvailDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEEAvailability&Param.1=" +
					plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + EDate + "&d=" + new Date() +
					"&Content-Type=text/json", "", false);
				this.getView().setModel(oModelGetAvailDetails, "oGetAvailDetails");

			} else {
				oModelGetAvailDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEEAvailability&Param.1=" +
					plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + currentDT + "&d=" + new Date() +
					"&Content-Type=text/json", "", false);
				this.getView().setModel(oModelGetAvailDetails, "oGetAvailDetails");

			}

			var i = CommonUtility.getJsonModelRowCount(oModelGetAvailDetails.getData());
			var j = 0;
			var tot = 0;
			var name = "";
			var avail_running = "0";
			var avail_fail = "0";
			var avail_rest = "0";
			var avail_unsch = "0";
			var avail_idle = "0";
			var avail_rate = "0";
			//var oee_avail="";
			var tot_time = "";
			var unaccounted = "0";
			avail_running_new = "0";

			this.getView().byId("Failureip").setValue(avail_fail);
			this.getView().byId("Restraintip").setValue(avail_rest);
			this.getView().byId("Un-Scheduledip").setValue(avail_unsch);
			this.getView().byId("Idleip").setValue(avail_idle);
			this.getView().byId("TotalTimeip").setValue(tot_time);
			this.getView().byId("Runningip").setValue(avail_running_new);
			this.getView().byId("Unaccountedip").setValue(unaccounted);
			this.getView().byId("AvailabilityRateip").setValue(avail_rate);

			for (j = 0; j < i; j++) {

				name = oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].CatCode;
				if (name == "Running") {
					avail_running = oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration;
					if (oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration != "") {

						tot = tot + parseInt(oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration);
					}
				} else if (name == "Failure" || name == "F") {
					avail_fail = oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration;
					if (oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration != "") {

						this.getView().byId("Failureip").setValue(avail_fail);
						tot = tot + parseInt(oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration);
					}
				} else if (name == "Line Restraint" || name == "L") {
					avail_rest = oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration;
					if (oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration != "") {
						this.getView().byId("Restraintip").setValue(avail_rest);
						tot = tot + parseInt(oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration);
					}
				} else if (name == "Unscheduled" || name == "U") {
					avail_unsch = oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration;
					if (oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration != "") {
						this.getView().byId("Un-Scheduledip").setValue(avail_unsch);
						tot = tot + parseInt(oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration);
					}
				} else if (name == "Idle" || name == "I") {
					avail_idle = oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration;
					if (oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration != "") {
						this.getView().byId("Idleip").setValue(avail_idle);
						tot = tot + parseInt(oModelGetAvailDetails.getData().Rowsets.Rowset[0].Row[j].Duration);
					}
				}
			}
			tot_time = tot;
			this.getView().byId("TotalTimeip").setValue(tot_time);

			if (avail_unsch == "") {
				avail_unsch = 0;
				this.getView().byId("Un-Scheduledip").setValue(avail_unsch);
			}

			this.populatePerfomData();
			this.getView().byId("Runningip").setValue(avail_running_new);
			var js_availability_oee = parseFloat(avail_running_new / parseFloat(parseFloat(tot_time) - parseFloat(avail_unsch))) * 100;

			//var selectedShiftRunTime = shiftdata[shiftcounter].RUNTIME;

			//Change By Sudipta Chakraborty for change order 166136 on 25 Nov.Logic is if shift status is not 1 and (Total time - (Running+Un-Scheduled)) >0
			//Then Unaccounted Time=Total time - (Running+Un-Scheduled)

			if (selectedshiftstatus != "1") {
				if ((selectedShiftRunTime - avail_running_new) > 0) {
					unaccounted = selectedShiftRunTime - avail_running_new;
					this.getView().byId("Unaccountedip").setValue(unaccounted);
				} else {
					unaccounted = 0;
					this.getView().byId("Unaccountedip").setValue(unaccounted);
				}
			}

			//End change order 166136

			if (parseInt(avail_unsch >= "479")) {
				avail_rate = "100 %";
				this.getView().byId("AvailabilityRateip").setValue(avail_rate);
				oee_avail = "100";
			} else if (isNaN(js_availability_oee)) {
				avail_rate = "0 %";
				this.getView().byId("AvailabilityRateip").setValue(avail_rate);
				oee_avail = "0";
			} else {
				avail_rate = js_availability_oee.toFixed(2) + "%";
				oee_avail = js_availability_oee.toFixed(2);
				this.getView().byId("AvailabilityRateip").setValue(avail_rate);
			}

			this.getView().byId("availabilitytxt").setValue(oee_avail);

			this.getOEELimitValues();

			// *******Start Modified By Praveen for CO#114069*******

			if (parseInt(oee_avail) >= parseInt(AvailUpLimit)) {
				this.getView().byId("availabilitytxt").getCustomData()[0].setValue("UPOEE");
			} else if (parseInt(oee_avail) < parseInt(AvailUpLimit) && parseInt(oee_avail) >= parseInt(AvailLowLimit)) {
				this.getView().byId("availabilitytxt").getCustomData()[0].setValue("MidOEE");
			} else {
				this.getView().byId("availabilitytxt").getCustomData()[0].setValue("LowOEE");
			}

			// *******End Modified By Praveen*******

			// load availability chart data
			var oAvailabilityModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->populateAvailData-->XACQ_OEEAvailability");

			// added for setting the chart color code 
			var that = this;
			oAvailabilityModel.attachRequestCompleted(function() {

				var oData = oAvailabilityModel.getData().Rowsets.Rowset[0].Row;
				that.setAvailabilityChartColorCode(oData);

			});

			if (EDate <= currentDT) {
				oAvailabilityModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEEAvailability&Param.1=" +
					plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate + "&d=" + new Date() +
					"&Content-Type=text/json", "", false);
				this.getView().setModel(oAvailabilityModel, "availabilityModel");
			} else {
				oAvailabilityModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEEAvailability&Param.1=" +
					plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + currentDT + "&d=" + new Date() +
					"&Content-Type=text/json", "", false);
				this.getView().setModel(oAvailabilityModel, "availabilityModel");
			}
			this.populateQualityData();
		},

/*****************************************************************************************************************************************************************************************/
// on load of shift data, load Quality OEE data
/****************************************************************************************************************************************************************************************/

		populateQualityData: function() {
			var qual_totout = "";
			var qual_scrap = "";
			var qual_goodout = "";
			var qual_rate = "";
			//var oee_qual="";
			var that = this;

			this.getView().byId("ActualOutputthisshiftip").setValue(qual_totout);
			this.getView().byId("Scrapip").setValue(qual_scrap);
			this.getView().byId("GoodOutputip").setValue(qual_goodout);
			this.getView().byId("QualityRateip").setValue(qual_rate);

			var oModelGetQualDetails = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->populateQualityData-->XACQ_OEEQuality");
			oModelGetQualDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEEQuality&Param.1=" + plant +
				"&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelGetQualDetails, "oGetQualDetails");

			var i = CommonUtility.getJsonModelRowCount(oModelGetQualDetails.getData());

			var j = 0;
			var name;
			var scrap = 0;
			var js_quality_oee = 0;

			for (j = 0; j < i; j++) {

				name = oModelGetQualDetails.getData().Rowsets.Rowset[0].Row[j].Type;

				if (name == "GoodOutput") {
					qual_goodout = oModelGetQualDetails.getData().Rowsets.Rowset[0].Row[j].Quantity;
					this.getView().byId("GoodOutputip").setValue(qual_goodout);
				} else if (name == "TotalOutput") {
					qual_totout = oModelGetQualDetails.getData().Rowsets.Rowset[0].Row[j].Quantity;
					this.getView().byId("ActualOutputthisshiftip").setValue(qual_totout);
				} else if (name == "TotalScrap") {
					qual_scrap = oModelGetQualDetails.getData().Rowsets.Rowset[0].Row[j].Quantity;
					this.getView().byId("Scrapip").setValue(qual_scrap);
				} else if (name == "OEEQuality") {
					js_quality_oee = oModelGetQualDetails.getData().Rowsets.Rowset[0].Row[j].Quantity;
				}

			}

			if (isNaN(js_quality_oee)) {
				qual_rate = "0 %";
				oee_qual = "0";
			} else {
				qual_rate = js_quality_oee + "%";
				oee_qual = js_quality_oee;
				this.getView().byId("QualityRateip").setValue(qual_rate);
			}

			this.getView().byId("qualitytxt").setValue(oee_qual);

			// *******Start Modified By Praveen for CO#114069*******

			if (parseInt(oee_qual) >= parseInt(QualUpLimit)) {
				this.getView().byId("qualitytxt").getCustomData()[0].setValue("UPOEE");
			} else if (parseInt(oee_qual) < parseInt(QualUpLimit) && parseInt(oee_qual) >= parseInt(QualLowLimit)) {
				this.getView().byId("qualitytxt").getCustomData()[0].setValue("MidOEE");
			} else {
				this.getView().byId("qualitytxt").getCustomData()[0].setValue("LowOEE");
			}

			// *******End Modified By Praveen*******

			setTimeout(function() {
				that.calculateOEE();
			}, 2000);
			//this.calculateOEE();

			// load quality chart data

			var oQualityModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->populateQualityData-->XACQ_OEEQualityChart");

			oQualityModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEEQualityChart&Param.1=" + plant +
				"&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);
			this.getView().setModel(oQualityModel, "qualityModel");
		},

/**************************************************************************************************************************************************************************************/
// Use to show the downtime duration.
/*****************************************************************************************************************************************************************************************/
		SetCounterDisp: function() {
			var currenttime = new Date();
			var currentDT = CommonUtility.getCurrentDateTime(currenttime);
			if (startdate) {
				jQuery.ajax({
					url: "/XMII/Runner?Transaction=NL_ELS_HUB/BLS/BLS_GetTimeCounter&I_CurrentDT=" + currentDT + "&I_OpenDTStart=" + startdate +
						"&OutputParameter=O_Time&d=" + new Date() + "&Content-Type=text/xml",
					type: 'GET',
					async: false,
					success: function(xmlData) {

						var sDuration = $(xmlData).find('O_Time').text();
						if (sDuration) {

							sap.ui.getCore().getModel("duration").setProperty("/duration", sDuration);
						} else {
							sap.ui.getCore().getModel("duration").setProperty("/duration", "");

						}
					}
				});

				this.SetDelay();
			} else {
				sap.ui.getCore().getModel("duration").setProperty("/duration", "");
				sap.ui.getCore().getModel("duration").getProperty("/false")

			}
		},

/**************************************************************************************************************************************************************************************/
// Set duration counter
/*****************************************************************************************************************************************************************************************/
		SetDelay: function() {
			if (sap.ui.getCore().getModel("duration").getProperty("/showDuration")) {
				var that = this;
				setTimeout(function() {
					that.SetCounterDisp();
				}, 60000);
			}
		},

		populatePerfomData: function() {
			var tarout = "";
			var spdloss = "";
			var plnout = "";
			var minstop = "";
			var totout = "";
			var rate = "";

			this.getView().byId("performlblhdr").setText(sap.ui.getCore().getModel("i18n").getProperty("HUB_TXT_0052"));

			var oModelPerfomData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->populatePerfomData-->XACQ_GetOEEPerformanceData");
			oModelPerfomData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOEEPerformanceData&Param.1=" +
				plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelPerfomData, "oPerfomData");

			tarout = oModelPerfomData.getData().Rowsets.Rowset[0].Row[0].ProdOut;
			spdloss = oModelPerfomData.getData().Rowsets.Rowset[0].Row[0].SpeedLoss;
			plnout = oModelPerfomData.getData().Rowsets.Rowset[0].Row[0].SetSpeedOutput;
			minstop = oModelPerfomData.getData().Rowsets.Rowset[0].Row[0].MinorStop;
			totout = oModelPerfomData.getData().Rowsets.Rowset[0].Row[0].TotalOutput;

			avail_running_new = oModelPerfomData.getData().Rowsets.Rowset[0].Row[0].Runtime;

			this.getView().byId("IntTargetTheorSpeedip").setValue(tarout);
			this.getView().byId("SpeedLossip").setValue(spdloss);
			this.getView().byId("IntTargetLineSetSpeedip").setValue(plnout);
			this.getView().byId("MinorStopip").setValue(minstop);
			this.getView().byId("ActualOutputip").setValue(totout);

			this.getOEELimitValues();

//**************************************Changes for CO 210951************************//

			if (selectedshiftstatus == '2' || selectedshiftstatus == '3') {
				this.getOEEPerformanceCloseShift();
			}

			//End Change for CO 201951

			var js_perf_oee = (eval(totout) / eval(tarout)) * 100

			if (isNaN(js_perf_oee)) {
				rate = 0;
				this.getView().byId("Performancerateip").setValue(rate);
				this.getView().byId("performancetxt").setValue("0");
			} else {
				rate = js_perf_oee.toFixed(2) + "%";
				this.getView().byId("Performancerateip").setValue(rate);
				this.getView().byId("performancetxt").setValue(js_perf_oee.toFixed(2));
			}

			// *******Start Modified By Praveen for CO#114069*******

			oee_perf = this.getView().byId("performancetxt").getValue();

			if (parseInt(oee_perf) >= parseInt(PerfUpLimit)) {
				this.getView().byId("performancetxt").getCustomData()[0].setValue("UPOEE");
			} else if (parseInt(oee_perf) < parseInt(PerfUpLimit) && parseInt(oee_perf) >= parseInt(PerfLowLimit)) {
				this.getView().byId("performancetxt").getCustomData()[0].setValue("MidOEE");
			} else {
				this.getView().byId("performancetxt").getCustomData()[0].setValue("LowOEE");
			}

			// *******End Modified By Praveen*******

			// load Performance chart

			var oPerformanceModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->populatePerfomData-->XACQ_OEETrgPerfChartNew");
			// New Query template is used to remove the empty plot time data
			/*
			oPerformanceModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_OEETrgPerfChartNew&Param.1=" +
				plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);
				*/
			// 	<IMG SRC = "/XMII/ChartServlet?QueryTemplate={CA_ProjectName}/QueryTemplate/XACQ_OEETrgPerfChartNew&DisplayTemplate={CA_ProjectName}/DisplayTemplate/CHA_OEEPerform&Param.1={qs_plant}&Param.2={qs_resr}&Param.3={qs_shiftstart}&Param.4={qs_shiftend}&Content-Type=image/jpg">
			
			let imageSrc = "/XMII/ChartServlet?QueryTemplate="+projectName+"/QueryTemplate/XACQ_OEETrgPerfChartNew&DisplayTemplate="+projectName+"/DisplayTemplate/CHA_OEEPerform&Param.1="+plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate +"&Content-Type=image/jpg"
			this.getView().byId("perfChartImage").setSrc(imageSrc);
			oPerformanceModel.loadData("/XMII/Illuminator?QueryTemplate=RepHubUI5/Query/XACQ_OEETrgPerfChartNew&Param.1=" +
					plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate + "&d=" + new Date() +
					"&Content-Type=text/json", "", false);
			this.getView().setModel(oPerformanceModel, "performanceModel");

			// load DownTime Summary
			var that = this;

			var currenttime = new Date();
			var currentDT = CommonUtility.getCurrentDateTime(currenttime);

			if (currentDT > shiftenddate) {
				currentDT = shiftenddate;
			}

			var oDownTimeModel = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->populatePerfomData-->XACQ_GenerateDTChart");
			this.getView().byId("DTChart").setContent("");

			oDownTimeModel.attachRequestCompleted(
				function() {

					if (CommonUtility.getJsonModelRowCount(oDownTimeModel.getData()) > 0) {

						that.getView().byId("DTChart").setContent(oDownTimeModel.getData().Rowsets.Rowset[0].Row[0].O_Return);

					}

				});

			oDownTimeModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GenerateDTChart&Param.1=" + plant +
				"&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + currentDT + "&Param.5=" + shiftenddate + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);

		},

		calculateOEE: function() {
			var js_oee = (eval(oee_qual) * eval(oee_perf) * eval(oee_avail)) / 10000;
			this.getView().byId("oeetxt").setValue(js_oee.toFixed(2));

			var oee_OEE = this.getView().byId("oeetxt").getValue();
			// *******Start Modified By Praveen for CO#114069*******

			if (parseInt(oee_OEE) >= parseInt(OEEUpLimit)) {
				this.getView().byId("oeetxt").getCustomData()[0].setValue("UPOEE");
			} else if (parseInt(oee_OEE) < parseInt(OEEUpLimit) && parseInt(oee_OEE) >= parseInt(OEELowLimit)) {
				this.getView().byId("oeetxt").getCustomData()[0].setValue("MidOEE");
			} else {
				this.getView().byId("oeetxt").getCustomData()[0].setValue("LowOEE");
			}

			// *******End Modified By Praveen*******
			//UI_utilities.setContainerBusyState(this,false);
			this.getView().setBusy(false);

		},

		getOEELimitValues: function() {
			var oModelgetOEELimitData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getOEELimitValues-->SQLQ_GetOEEValuesByShift");
			oModelgetOEELimitData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
				"/QueryTemplate/SQLQ_GetOEEValuesByShift&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" +
				shiftenddate + "&d=" + new Date() + "&Content-Type=text/json", "", false);
			this.getView().setModel(oModelgetOEELimitData, "ogetOEELimitData");

			if (CommonUtility.getJsonModelRowCount(oModelgetOEELimitData.getData()) > 0) {

				AvailLowLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].AVAILOWLMT;
				AvailUpLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].AVAILUPLMT;
				PerfLowLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].PERFLOWLMT;
				PerfUpLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].PERFUPLMT;
				QualLowLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].QUALLOWLMT;
				QualUpLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].QUALUPLMT;
				OEELowLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].OEELOWLMT;
				OEEUpLimit = oModelgetOEELimitData.getData().Rowsets.Rowset[0].Row[0].OEEUPLMT;
			}
		},

		getOEEPerformanceCloseShift: function() {
			var tarout = "";
			var spdloss = "";
			var plnout = "";
			var minstop = "";
			var totout = "";
			var rate = "";

			var oModelgetOEEPerformanceCloseShiftData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getOEEPerformanceCloseShift-->XACQ_OEEPerformanceCloseShift");
			oModelgetOEEPerformanceCloseShiftData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
				"/QueryTemplate/XACQ_OEEPerformanceCloseShift&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftid + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelgetOEEPerformanceCloseShiftData, "ogetOEEPerformanceCloseShiftData");

			tarout = oModelgetOEEPerformanceCloseShiftData.getData().Rowsets.Rowset[0].Row[0].ProdOut;
			spdloss = oModelgetOEEPerformanceCloseShiftData.getData().Rowsets.Rowset[0].Row[0].SpeedLoss;
			plnout = oModelgetOEEPerformanceCloseShiftData.getData().Rowsets.Rowset[0].Row[0].SetSpeedOutput;
			minstop = oModelgetOEEPerformanceCloseShiftData.getData().Rowsets.Rowset[0].Row[0].MinorStop;
			totout = oModelgetOEEPerformanceCloseShiftData.getData().Rowsets.Rowset[0].Row[0].TotalOutput;

			avail_running_new = oModelgetOEEPerformanceCloseShiftData.getData().Rowsets.Rowset[0].Row[0].Runtime;

			this.getView().byId("IntTargetTheorSpeedip").setValue(tarout);
			this.getView().byId("SpeedLossip").setValue(spdloss);
			this.getView().byId("IntTargetLineSetSpeedip").setValue(plnout);
			this.getView().byId("MinorStopip").setValue(minstop);
			this.getView().byId("ActualOutputip").setValue(totout);

		},

		getOrderData: function() {
			var oModelgetOrderData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getOrderData-->XACQ_GetTaskListByResr");
			oModelgetOrderData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetTaskListByResr&Param.1=" +
				plant + "&Param.2=" + resource + "&Param.3=" + "1" + "&d=" + new Date() + "&Content-Type=text/json", "", false);
			this.getView().setModel(oModelgetOrderData, "ogetOrderData");

			if (CommonUtility.getJsonModelRowCount(oModelgetOrderData.getData()) > 0) {
				var UOM = oModelgetOrderData.getData().Rowsets.Rowset[0].Row[0].PHASEUOM;

				this.getView().byId("UOMip").setValue(UOM);
			}
		},

		getIntData: function() {
			var oModelgetIntData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getIntData-->XACQ_GetShiftIntervalDetails");
			oModelgetIntData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetShiftIntervalDetails&Param.1=" +
				plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" + shiftenddate + "&d=" + new Date() +
				"&Content-Type=text/json", "", false);
			sap.ui.getCore().setModel(oModelgetIntData, "ogetIntData");
		},

		getMaintNotifData: function() {
			var oModelgetMaintNotifData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getMaintNotifData-->XACQ_GetShiftMaintNotList");
			oModelgetMaintNotifData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
				"/QueryTemplate/XACQ_GetShiftMaintNotList&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" +
				shiftenddate + "&d=" + new Date() + "&Content-Type=text/json", "", false);
			sap.ui.getCore().setModel(oModelgetMaintNotifData, "ogetMaintNotifData");

		},

		getQualNotifData: function() {
			var oModelgetQualNotifData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getQualNotifData-->XACQ_GetShiftQualNotList");
			oModelgetQualNotifData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
				"/QueryTemplate/XACQ_GetShiftQualNotList&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" +
				shiftenddate + "&d=" + new Date() + "&Content-Type=text/json", "", false);
			sap.ui.getCore().setModel(oModelgetQualNotifData, "ogetQualNotifData");

		},

		getDownTimeData: function() {
			var oModelgetDownTimeData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getDownTimeData-->XACQ_GetShiftNoteDetails");
			oModelgetDownTimeData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
				"/QueryTemplate/XACQ_GetShiftNoteDetails&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" +
				shiftenddate + "&d=" + new Date() + "&Content-Type=text/json", "", false);
			sap.ui.getCore().setModel(oModelgetDownTimeData, "ogetDownTimeData");

		},

		getShiftNoteData: function() {
			var oModelgetShiftNoteData = models.createNewJSONModel(
				"com.khc.rephub.controller.production.RepEndShift-->getShiftNoteData-->XACQ_GetShiftNoteTextNum");
			oModelgetShiftNoteData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
				"/QueryTemplate/XACQ_GetShiftNoteTextNum&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftstarttime + "&Param.4=" +
				shiftenddate + "&d=" + new Date() + "&Content-Type=text/json", "", false);
			sap.ui.getCore().setModel(oModelgetShiftNoteData, "ogetShiftNoteData");

		},

		createShiftNotes: function() {
			var dt = new Date();
			var date = CommonUtility.formatDate(dt);
			var currentDT = CommonUtility.getCurrentDateTime(dt);
			var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
			var ShiftName = this.getView().byId("shiftip").getValue();
			var Dur = this.getView().byId("durminsip").getValue();
			var shiftStime = this.getView().byId("startdatetimeip").getValue();

			//shiftid

			var hour = Dur / 60;
			var hour = Math.floor(hour);
			var minute = Dur - (hour * 60);
			minute = minute - 1;

			var endtime = new Date(shiftStime.substring(0, 4), shiftStime.substring(5, 7) - 1, shiftStime.substring(8, 10), shiftStime.substring(
				11, 13), shiftStime.substring(14, 16), shiftStime.substring(17, 19), 0);
			endtime.setHours(endtime.getHours() + hour);
			endtime.setMinutes(endtime.getMinutes() + minute);

			if (dt > endtime) {
				date = CommonUtility.formatDate(endtime);
				currentDT = CommonUtility.getCurrentDateTime(endtime);
				time = endtime.getHours() + ":" + endtime.getMinutes() + ":" + endtime.getSeconds();
			}

			if (this.getView().byId("CreateShiftNoteTA").getValue() != "") {
				var shiftnote = this.getView().byId("CreateShiftNoteTA").getValue();
				var oModelCrtShiftNotesData = models.createNewJSONModel(
					"com.khc.rephub.controller.production.RepEndShift-->createShiftNotes-->XACQ_CreateShiftNotes");
				oModelCrtShiftNotesData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
					"/QueryTemplate/XACQ_CreateShiftNotes&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + "ZG99" + "&Param.4=" + date +
					"&Param.5=" + time + "&Param.6=" + "" + "&Param.7=" + "" + "&Param.8=" + "" + "&Param.9=" + shiftnote + "&Param.10=" + "" +
					"&Param.11=" + "" + "&Param.12=" + "HomePageShiftNote" + "&Param.13=" + username + "&d=" + new Date() +
					"&Content-Type=text/json", "", false);
				sap.ui.getCore().setModel(oModelCrtShiftNotesData, "oCrtShiftNotesData");

				var ShiftNoteNum = oModelCrtShiftNotesData.getData().Rowsets.Rowset[0].Row[0].O_ShiftNote;
				if (ShiftNoteNum == "E") {
					/*var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0086");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",                                  
					});*/

					var confErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0086");
					sap.ui.getCore().getModel("oMessage").setProperty("/message", confErrorMsg);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
				} else {
					//success message
					/*var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0085");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",                                  
					});*/

					var confSuccessMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0085");
					confSuccessMsg = confSuccessMsg.concat(ShiftNoteNum);
					sap.ui.getCore().getModel("oMessage").setProperty("/message", confSuccessMsg);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

					var shift = this.getView().byId("shiftip").getValue();

					var oModelInsShiftNoteData = models.createNewJSONModel(
						"com.khc.rephub.controller.production.RepEndShift-->createShiftNotes-->XACQ_InsShiftNote");
					oModelInsShiftNoteData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_InsShiftNote&Param.1=" +
						plant + "&Param.2=" + resource + "&Param.3=" + shift + "&Param.4=" + currentDT + "&Param.5=" + "" + "&Param.6=" + shiftnote +
						"&Param.7=" + ShiftNoteNum + "&Param.8=" + shiftid + "&d=" + new Date() + "&Content-Type=text/json", "", false);
					sap.ui.getCore().setModel(oModelInsShiftNoteData, "oInsShiftNoteData");

					// Refresh Shift note grid

					this.getIntData();

					this.getView().byId("CreateShiftNoteTA").setValue("");

				}
			} else {
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0029");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",
				});
			}

		},

		OpenNew: function() {
			if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "MaintNotification") {
				UI_utilities.setContainerBusyState(this, true);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("maintenanceNotification");
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "QualNotification") {
				UI_utilities.setContainerBusyState(this, true);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RepQualityNotification");
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "DownTime") {
				UI_utilities.setContainerBusyState(this, true);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("lineStatus");
			} else if (this.getView().getModel("homeUI").getProperty("/currentSelection") == "ShiftNotes") {
				//UI_utilities.setContainerBusyState(this,true);
				this.getView().getModel("homeUI").setProperty("/showShiftNotes", "true");
			} else {
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0044");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",
				});
			}
		},

		cancel: function() {
			this.getView().byId("CreateShiftNoteTA").setValue("");
			this.getView().getModel("homeUI").setProperty("/showShiftNotes", "false");
		},

		// Opens ShiftReport.irpt which shows a printable version for shift report.

		OpenShiftReport: function() {

			/*
			var shiftstart = document.getElementById("StartDateTime").value;
			var shiftend= document.getElementById("id_hid_shiftenddate").value;
			var shiftname = document.getElementById("Shift").value;
			var shiftlead = document.getElementById("Lead").value;
			var shiftcrew = document.getElementById("Crew").value;
			*/

			var shiftstart = shiftdata[shiftcounter].STARTTIME;
			var shiftend = shiftdata[shiftcounter].ENDTIME;
			var shiftname = shiftdata[shiftcounter].SHIFTNAME;
			var shiftlead = shiftdata[shiftcounter].LEAD;
			var shiftcrew = shiftdata[shiftcounter].TEAMSIZE;

			//Change By Sudipta Chakraborty for change order 166136 on 25 Nov.Passing Unaccounted field
			//var unaccounted = document.getElementById("id_unaccounted").value;

			//var selectedShiftstatus = APLT_GRI_ShiftList.getGridObject().getSelectedCellValueByName('RUNNING');
			//var selectedShiftRunTime = APLT_GRI_ShiftList.getGridObject().getSelectedCellValueByName('RUNTIME');	

			var selectedShiftstatus = shiftdata[shiftcounter].RUNNING;
			var selectedShiftRunTime = shiftdata[shiftcounter].RUNTIME

			window.open('/XMII/CM/RepHubUI5/webapp/irpt/ShiftReport.irpt?qs_plant=' + plant + '&qs_resr=' + resource + '&qs_shiftstart=' +
				shiftstart + '&qs_shiftend=' + shiftend + '&qs_shiftname=' + shiftname + '&qs_lead=' + shiftlead + '&qs_crew=' + shiftcrew +
				'&qs_shiftrunstatus=' + selectedShiftstatus + '&qs_shiftruntime=' + selectedShiftRunTime, 'ShiftReport',
				'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');
			//window.open('../IRPT/ShiftReport.irpt?qs_resr='+resr+'&qs_shiftstart='+shiftstart+'&qs_shiftend='+shiftend+'&qs_shiftname='+shiftname+'&qs_lead='+shiftlead+'&qs_crew='+shiftcrew , 'ShiftReport', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');

		},

		clearAll: function() {

			this.getView().byId("startdatetimeip").setValue("");
			this.getView().byId("shiftip").setValue("");
			this.getView().byId("Leadip").setValue("");
			this.getView().byId("Teamnameip").setValue("");
			this.getView().byId("crewip").setValue("");
			this.getView().byId("intervalminsip").setValue("");
			this.getView().byId("durminsip").setValue("0");
			this.getView().byId("shiftstatusip").setValue("");
			//sap.ui.getCore().getModel("duration").setData(null);
			sap.ui.getCore().getModel("duration").setProperty("/showDuration",false);
			this.getView().byId("availabilitytxt").setValue("0");
			this.getView().byId("performancetxt").setValue("0");
			this.getView().byId("qualitytxt").setValue("0");
			this.getView().byId("oeetxt").setValue("0");
			this.getView().byId("IntTargetTheorSpeedip").setValue("");
			this.getView().byId("IntTargetLineSetSpeedip").setValue("");
			this.getView().byId("ActualOutputip").setValue("");
			this.getView().byId("Performancerateip").setValue("0");
			this.getView().byId("SpeedLossip").setValue("");
			this.getView().byId("MinorStopip").setValue("");
			this.getView().byId("UOMip").setValue("");
			this.getView().byId("TotalTimeip").setValue("NaN");
			this.getView().byId("Failureip").setValue("0");
			this.getView().byId("Restraintip").setValue("0");
			this.getView().byId("Unaccountedip").setValue("0");
			this.getView().byId("Runningip").setValue("");
			this.getView().byId("Idleip").setValue("0");
			this.getView().byId("Un-Scheduledip").setValue("0");
			this.getView().byId("AvailabilityRateip").setValue("0%");
			this.getView().byId("ActualOutputthisshiftip").setValue("0");
			this.getView().byId("Scrapip").setValue("0");
			this.getView().byId("GoodOutputip").setValue("0");
			this.getView().byId("QualityRateip").setValue("0%");
			this.getView().byId("DTChart").setContent("");
			//this.getView().byId("durationip").setValue("00:00");
			//this.setDuration();
			this.getView().byId("durationip").setValue("");

			if (resourcechangeflag == 1) {
				/*
				this.getView().getModel("oOpenDTDetails").setData(null);
				this.getView().getModel("oGetAvailDetails").setData(null);
				this.getView().getModel("oPerfomData").setData(null);
				this.getView().getModel("oGetQualDetails").setData(null);
				this.getView().getModel("ogetOrderData").setData(null);
				*/
				this.getView().byId("availabilitytxt").getCustomData()[0].setValue("LowOEE");
				this.getView().byId("performancetxt").getCustomData()[0].setValue("LowOEE");
				this.getView().byId("qualitytxt").getCustomData()[0].setValue("LowOEE");
				this.getView().byId("oeetxt").getCustomData()[0].setValue("LowOEE");
				//sap.ui.getCore().getModel("duration").setData(null);
				this.getView().byId("durationip").setValue("");
				this.getView().getModel("performanceModel").setData(null);
				this.getView().getModel("availabilityModel").setData(null);
				this.getView().getModel("qualityModel").setData(null);
				resourcechangeflag = 0;
			}
		},

		/**
		 * Set the color code for the chart, like running is green, Failure is red etc..
		 */
		setAvailabilityChartColorCode: function(oData) {

			var aColorCode = [];
			var that = this;

			oData.forEach(function(data) {

				aColorCode.push(that.getCatColor(data.CatCode));

			});

			var Chart_Availability = this.getView().byId("Chart_Availability");
			Chart_Availability.setVizProperties({
				title: {
					text: "Availability"
				},
				plotArea: {
					colorPalette: aColorCode,
					//drawingEffect: "glossy"
				}
			});

		},

		/**
		 *	Return the color code for the availability chart based on the category 
		 */

		getCatColor: function(catCode) {

			if (catCode.toLowerCase().indexOf("running") >= 0) {

				return "#00FF00";
			} else if (catCode.toLowerCase().indexOf("idle") >= 0) {

				return "#FF9900";
			} else if (catCode.toLowerCase().indexOf("failure") >= 0) {

				return "#FF0000";
			} else if (catCode.toLowerCase().indexOf("scheduled") >= 0) {

				return "#FFFF00";
			} else if (catCode.toLowerCase().indexOf("restraint") >= 0) {

				return "#0000FF";
			} else {

				return this.generateRandomColor();
			}

		},

		/**
		 *	Generate a random color for the availability chart, for new reason codes  
		 */
		generateRandomColor: function() {
			let maxVal = 0xFFFFFF; // 16777215
			let randomNumber = Math.random() * maxVal;
			randomNumber = Math.floor(randomNumber);
			randomNumber = randomNumber.toString(16);
			let randColor = randomNumber.padStart(6, 0);
			return `#${randColor.toUpperCase()}`
		},
	});

});