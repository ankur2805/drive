// jQuery.sap.require("sap.m.MessageBox");
sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox","com/khc/rephub/utils/UI_utilities",
"com/khc/rephub/model/formatter","com/khc/common/Script/CommonUtility","com/khc/rephub/model/models"], 
   function(Controller,MessageBox,UI_utilities,formatter,CommonUtility,models) {
   "use strict";
   var plant;
   var resource;
   var projectName;
   var cr_dest;
   var userName;

   var orderID;
   var crID;
   var orderStrip;
   
   var sShiftDetails;
   var enddateTime;
   var startdateTime;
   var todayDateTime;
   
   var availableTime;
   var shiftID;

   var twoStageFlag;
   //var shiftEnd;  
   var phase;
   var opr;
   var spath;
   var dt;
   //var rendered=false;
      var ShiftCloseCkhTime;
   /******/
   var smanualCodingPath="";

      /******/
   return Controller.extend("com.khc.rephub.controller.production.RepProdEndInterval", {formatter:formatter,
      onInit: function() {
         
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         this._oRouter.getRoute("endInterval").attachPatternMatched(this._oRoutePatternMatched, this);
         
      },
      _oRoutePatternMatched: function(oEvent) {
            
         // To remove busy indicator once the page loaded
         UI_utilities.productionMenuOpened(this,"endInterval");
   
         dt = new Date();
         todayDateTime = CommonUtility.getCurrentDateTime(dt);
         
         UI_utilities.DisableDatePickerInput(this.getView().byId("intConfirmationTime"));
         let session=sap.ui.getCore().getModel("session").oData;
      
         plant=session.CA_Plant;
         resource=session.CA_Resource;
         cr_dest=session.CA_CRDest;
         projectName=session.CA_ProjectName;
         twoStageFlag=session.CA_TwoStageFlag;
         userName=session.CA_IllumLoginName;
         //if(rendered){
         this.clearValues();
         this.getRunningOrder();
         //}
         
      },
      
      
      menuSelected : function (oEvent) {
         
         // Navigate the the selected menu page
         
         var sKey = oEvent.getParameters().key;
         UI_utilities.openMenu(this._oRouter,this,sKey);
         
            },
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/
clearValues:function(){
   //Clear the values
      this.getView().byId("bottleneckCounter").setValue("0");
      this.getView().byId("actualOutInterval").setValue("0");
      this.getView().byId("endOfShift").setSelected(false);
      this.getView().byId("targetSpeed").setValue("0");
      this.getView().byId("closeOrder").setSelected(false);
      this.getView().byId("endOfShift").setEnabled(true);
      this.getView().byId("closeOrder").setEnabled(true);
      this.getView().byId("bNext").setVisible(true);
      this.getView().byId("bNext").setEnabled(true);
}, 
/*************************************************************************************************************************************************************************************/   
getRunningOrder:function(){
   
    var oRunningOrderModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->getRunningOrder-->XACQ_GetRunningOrder");
   let sRunningOrder = "Param.1="+plant+"&Param.2="+resource+"&Param.3="+cr_dest+"&d="+dt;
   oRunningOrderModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetRunningOrder&"+sRunningOrder+"&Content-Type=text/json", "", false);
   var bRunningOrder = false;
   if(CommonUtility.getJsonModelRowCount(oRunningOrderModel.getData())>0){
      let runningOrder=oRunningOrderModel.getData().Rowsets.Rowset[0].Row[0]
      orderID=runningOrder.ORDERID;
      crID=runningOrder.CRID;
      orderStrip=runningOrder.ORDERSTRIP;
      this.getView().byId("orderID").setValue(orderStrip);
      bRunningOrder = true;
   }
   else  {
      
      this.getView().byId("orderID").setValue("");
      this.getView().byId("matNum").setValue("");
      this.getView().byId("matDesc").setValue("");
      this.getView().byId("plannedQty").setValue("");
      this.getView().byId("pendingQty").setValue("");
      this.getView().byId("perComplete").setValue("");
      this.getView().byId("prodSpeed").setValue("");
      this.getView().byId("uom").setValue("");
      this.getView().byId("lastIntConfirmation").setValue("");
      this.getView().byId("intMinutes").setValue("");
      this.getView().byId("intTarlineSetSpeed").setValue("");

   }
      this.getView().byId("intConfirmationTime").setValue(todayDateTime);
      this.getOrderDetails(bRunningOrder);
      this.GetTagConfigforResr();
   
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/
getOrderDetails:function(bRunningOrder){
   
   this.getView().byId("bCloseShift").setEnabled(false);
   this.getView().byId("bCloseShift").setVisible(true);
   this.getView().byId("intConfirmationTime").setEnabled(true);
   
    var oOrderDetailsModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->getOrderDetails-->XACQ_GetOrderDetails");

   let sOrderDetails = "Param.1="+crID+"&d="+dt;
   if(bRunningOrder) {
      oOrderDetailsModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetOrderDetails&"+sOrderDetails+"&Content-Type=text/json", "", false);
   }
   if(bRunningOrder && CommonUtility.getJsonModelRowCount(oOrderDetailsModel.getData())>0){       
      //this.getView().setModel(oOrderDetailsModel,"orderDetails");
      this.getView().byId("bCloseShift").setVisible(false);
      spath=oOrderDetailsModel.getData().Rowsets.Rowset[0].Row[0];
      this.getView().byId("matNum").setValue(spath.ModMATNR);
      this.getView().byId("matDesc").setValue(spath.MATTEXT);
      this.getView().byId("plannedQty").setValue(spath.MATQTY);
      phase=spath.PHASE;
      opr=spath.OPR;
      let pendingQty=(parseFloat(spath.PENDINGQTY)).toFixed(2);
      this.getView().byId("pendingQty").setValue(pendingQty);
      this.getView().byId("perComplete").setValue(spath.PENDINGPERC+"%");
      
      this.getView().byId("prodSpeed").setValue(spath.PRODSPEED);

      this.getView().byId("targetSpeed").setValue(spath.LINESPEED);
      this.getView().byId("uom").setValue(spath.PHASEUOM);

      if(isNaN(this.getView().byId("targetSpeed").getValue())){
         this.getView().byId("targetSpeed").setValue(spath.PRODSPEED);
      }
      this.getView().byId("lastIntConfirmation").setValue((spath.RECORDTIME).replace("T"," "));

      let rowCount=this.getShiftDetails();
      
      if(rowCount==true){
      
      if(this.getView().byId("lastIntConfirmation").getValue()<startdateTime){
         this.getView().byId("lastIntConfirmation").setValue(startdateTime);
      }
      
      
      if(this.getView().byId("intConfirmationTime").getValue()>=enddateTime){
         this.getView().byId("intConfirmationTime").setValue(enddateTime);
         this.getView().byId("intConfirmationTime").setEnabled(false);
         
         this.getView().byId("endOfShift").setSelected(true);
         this.getView().byId("endOfShift").setEnabled(false);
      }

      if(sShiftDetails.RUNNING=="2"){
         var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0030");
         sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
         sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
         sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");   
         this.getView().byId("bNext").setEnabled(false);
         this.getView().byId("endOfShift").setEnabled(false);
         
      }
      }
      else{
         var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
         sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
         sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
         sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");   
         this.getView().byId("bNext").setEnabled(false);
         this.getView().byId("endOfShift").setEnabled(false);
      }  
      
      this.getIntervalMinutes();
      this.getShiftNoteObj();
   }
   else{
      let rowCount=this.getShiftDetails();
      
      if(rowCount==true){
         if(this.getView().byId("intConfirmationTime").getValue()>=enddateTime){
         this.getView().byId("intConfirmationTime").setValue(enddateTime);
         
         this.getView().byId("intConfirmationTime").setEnabled(false);
         this.getView().byId("endOfShift").setSelected(true);
         this.getView().byId("endOfShift").setEnabled(false);
         this.getView().byId("closeOrder").setEnabled(false);
         this.getView().byId("bNext").setVisible(false);
         this.getView().byId("bCloseShift").setEnabled(true);

         var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0020");
         sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
         sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
         sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");   
         }
         else{
            this.getView().byId("closeOrder").setEnabled(false);
            this.getView().byId("bNext").setVisible(false);
            var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0020");
            sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
         sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
         sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");   
      
         }
         
         if(sShiftDetails.RUNNING=="2"){
         var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0030");
         sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
         sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
         sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");   
      
         this.getView().byId("bNext").setEnabled(false);
         this.getView().byId("endOfShift").setEnabled(false);
         }
            
      }
      else{
         this.getView().byId("bNext").setEnabled(false);
         this.getView().byId("bCloseShift").setVisible(false);
         this.getView().byId("endOfShift").setEnabled(false);
         var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
         sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
         sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
         sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");   
         
      }
   
   }
   
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/
getShiftDetails:function(){
   
    var oShiftDetailsModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->getShiftDetails-->SQLQ_GetRunningShiftDetails_Confirmation");

   let sshiftDetailsParam =  "Param.1="+plant+"&Param.2="+resource+"&d="+dt;
   oShiftDetailsModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetRunningShiftDetails_Confirmation&"+sshiftDetailsParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(oShiftDetailsModel.getData())>0){
      sShiftDetails=oShiftDetailsModel.getData().Rowsets.Rowset[0].Row[0];
      this.getView().byId("shift").setValue(sShiftDetails.SHIFTNAME);
      this.getView().byId("lead").setValue(sShiftDetails.LEAD);
      this.getView().byId("crew").setValue(sShiftDetails.TEAMSIZE);
      shiftID=sShiftDetails.SHIFTID;
      this.getTeamName();
      
      let enddt=new Date(sShiftDetails.ENDTIME);
      enddateTime=CommonUtility.getCurrentDateTime(enddt);
      //shiftEnd=enddateTime;  
      let startdt=new Date(sShiftDetails.STARTTIME);
      startdateTime=CommonUtility.getCurrentDateTime(startdt);
      
      
      return true;
   }  
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/
getIntervalMinutes:function(){
   let ict=this.getView().byId("intConfirmationTime").getValue();
   let lic=this.getView().byId("lastIntConfirmation").getValue();
    var oIntMintModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->getIntervalMinutes-->XACQ_GetIntervalMinutes");

   let sIntMintParam =  "Param.1="+ict+"&Param.2="+lic+"&d="+dt;
   oIntMintModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetIntervalMinutes&"+sIntMintParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(oIntMintModel.getData())>0){
      this.getView().byId("intMinutes").setValue(oIntMintModel.getData().Rowsets.Rowset[0].Row[0].O_Interval);
   }
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/               
getShiftNoteObj:function(){
   let ict=this.getView().byId("intConfirmationTime").getValue();
   let lic=this.getView().byId("lastIntConfirmation").getValue();
   
    var oShiftNoteModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->getShiftNoteObj-->XACQ_GetIntervalAvailTime");

   let sShiftNiteParam =  "Param.1="+plant+"&Param.2="+resource+"&Param.3="+lic+"&Param.4="+ict+"&d="+dt;
   oShiftNoteModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetIntervalAvailTime&"+sShiftNiteParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(oShiftNoteModel.getData())>0){
       availableTime=oShiftNoteModel.getData().Rowsets.Rowset[0].Row[0].O_AvailableTime
      this.getView().byId("intTarTheorySpeed").setValue(parseInt(parseFloat(this.getView().byId("prodSpeed").getValue()*availableTime)));
      this.getView().byId("intTarlineSetSpeed").setValue(parseInt(parseFloat(this.getView().byId("targetSpeed").getValue()*availableTime)));
      this.getView().byId("bottleneckCounter").focus();
   }
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/         
getTeamName:function(){
   let teamID=sShiftDetails.TEAMID;
   
    var oTeamNameModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->getTeamName-->SQLQ_GetTeamNameById");

   oTeamNameModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetTeamNameById&Param.1="+teamID+"&d="+dt+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(oTeamNameModel.getData())>0){
      this.getView().byId("teamName").setValue(oTeamNameModel.getData().Rowsets.Rowset[0].Row[0].TEAMNAME);
   }
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/      

   
GetTagConfigforResr:function(){
   let ict=this.getView().byId("intConfirmationTime").getValue();
   
    var oTagConfigModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->GetTagConfigforResr-->SQLQ_GetTagResource");

   oTagConfigModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetTagResource&Param.1="+plant+"&Param.2="+resource+"&d="+dt+"&Content-Type=text/json", "", false);
   //oTagConfigModel.loadData("/XMII/Illuminator?QueryTemplate=Default/Muthu/SQLQ_GetTagResource&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(oTagConfigModel.getData())>0){
      if(oTagConfigModel.getData().Rowsets.Rowset[0].Row[0].AUTOINTFLAG=="Y"){
         
          var oYieldCountModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->GetTagConfigforResr-->XACQ_GetYieldCountHIS");
         let sYieldCountParam="Param.1="+plant+"&Param.2="+resource+"&Param.3="+ict+"&Param.4="+orderID+"&d="+dt;
         oYieldCountModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetYieldCountHIS&"+sYieldCountParam+"&Content-Type=text/json", "", false);
         //oYieldCountModel.loadData("/XMII/Illuminator?QueryTemplate=Default/Muthu/XACQ_GetYieldCountHIS&Content-Type=text/json", "", false);
         if(CommonUtility.getJsonModelRowCount(oYieldCountModel.getData())>0){
            this.getView().byId("bottleneckCounter").setValue(oYieldCountModel.getData().Rowsets.Rowset[0].Row[0].O_Count);
            this.CalculateOutput()
            this.getView().byId("bottleneckCounter").focus();
         }
      }
      else{
         this.getView().byId("bottleneckCounter").setValue("0");
         this.getView().byId("actualOutInterval").setValue("0");
            this.getView().byId("bottleneckCounter").focus();
      }
   }
}, 

/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
CalculateLineSetOutput:function(){
   let targetSpeed=this.getView().byId("targetSpeed").getValue();
   if(targetSpeed  == "" || (isNaN(targetSpeed))){
      let sAlertMsg = "Target Speed can not be blank";
         MessageBox.error(sAlertMsg, {title: "Error", });
   }
   else{
      if(parseFloat(targetSpeed)<=(parseFloat(this.getView().byId("prodSpeed").getValue()*1.5))){
      if(!isNaN(this.getView().byId("bottleneckCounter").getValue())){
         this.getView().byId("intTarlineSetSpeed").setValue(parseInt(parseFloat(this.getView().byId("targetSpeed").getValue())*availableTime))
      }
      else{
         let sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0118");
         MessageBox.error(sAlertMsg, {title: "Error", });
      }
      }
      else{
      let sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0187");
         MessageBox.error(sAlertMsg, {title: "Error", });
      }
   }
}, 
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
CalcInterval:function(){
      this.getShiftNoteObj();
      this.getIntervalMinutes();
      this.GetTagConfigforResr();
}, 
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
CalculateOutput:function(){
   
   if(sShiftDetails) {
      let shiftCounter=sShiftDetails.COUNTER;
      let bottleneckCounter=this.getView().byId("bottleneckCounter").getValue();
      if(bottleneckCounter==""){
         let msg = "Bottleneck counter can not be blank";
            MessageBox.error(msg, {title: "Error", });
         this.getView().byId("actualOutInterval").setValue("0");
      }
      else{
         if(!isNaN(this.getView().byId("bottleneckCounter").getValue())){
            let actualOutInt=parseInt(bottleneckCounter)-parseInt(shiftCounter);
            this.getView().byId("actualOutInterval").setValue(actualOutInt);
         }
         else{
            let sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0120");
               MessageBox.error(sAlertMsg, {title: "Error", });
         }
      }
   }
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/         
checksBeforeShiftEnd:function(){
    
      let type=this.DoubleCheckShift();
      if(type=="B"){
         let sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0082");
         MessageBox.error(sAlertMsg, {title: "Error", });
         return;
      }
   
      let dtFlag=this.ShiftEndShortStop();
      if(dtFlag=="1"){
         let sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0214");
         MessageBox.error(sAlertMsg, {title: "Error", });
         return;
      }
   
      this.ManualCoding();
      if(smanualCodingPath && smanualCodingPath.Type=="E"){
         let msg = smanualCodingPath.Message;
         MessageBox.error(msg, {title: "Error", });
      }
      else{
         this.closeShift();
      }
},
/*************************************************************************************************************************************************************************************/
ShiftEndShortStop:function(){
   var dtFlag="";
   
    var oShiftEndShortStopModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->ShiftEndShortStop-->XACQ_ShiftEndShortStopDTChk");
   let sShiftEndShortStopParam="Param.1="+plant+"&Param.2="+resource+"&Param.3="+shiftID+"&Param.4="+enddateTime+"&d="+dt;
   oShiftEndShortStopModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_ShiftEndShortStopDTChk&"+sShiftEndShortStopParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(oShiftEndShortStopModel.getData())>0){
      dtFlag=oShiftEndShortStopModel.getData().Rowsets.Rowset[0].Row[0].DTFlag;
      
   }
   return dtFlag;
},
/*************************************************************************************************************************************************************************************/
DoubleCheckShift:function(){
   var type="";
   
    var ocheckShiftModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->DoubleCheckShift-->XACQ_DoubleCheckShift");

   let scheckShiftParam="Param.1="+plant+"&Param.2="+resource+"&Param.3="+todayDateTime+"&d="+dt;
   ocheckShiftModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_DoubleCheckShift&"+scheckShiftParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(ocheckShiftModel.getData())>0){
      type=ocheckShiftModel.getData().Rowsets.Rowset[0].Row[0].TYPE;
      
   }
   return type;
},
/*************************************************************************************************************************************************************************************/
ManualCoding:function(){
   
   
    var oManualCodingModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->ManualCoding-->XACQ_CheckUnclassifiedDtShiftClose");

   let sManualCodingParam="Param.1="+plant+"&Param.2="+resource+"&Param.3="+shiftID+"&d="+dt;
   oManualCodingModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_CheckUnclassifiedDtShiftClose&"+sManualCodingParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(oManualCodingModel.getData())>0){
      this.getView().setModel(oManualCodingModel, "oManualCoding");
      smanualCodingPath=this.getView().getModel("oManualCoding").getData().Rowsets.Rowset[0].Row[0];
   }
   else{
     smanualCodingPath=null;
   }
},
/*************************************************************************************************************************************************************************************/      
closeShift:function(){
         //let shiftStart=sShiftDetails.STARTTIME;   /*MM-DD-YYYY HH:MM:SS*/
         let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0117");
         sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
         sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
         sap.ui.getCore().getModel("oMessage").setProperty("/type","Warning");   
   
         //this.getView().byId("bCloseShift").setEnabled(true);
   
         
          var oCloseShiftModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->closeShift-->XACQ_CloseShiftV3");

         let sCloseShiftParam="Param.1="+plant+"&Param.2="+resource+"&Param.3="+startdateTime+"&Param.4="+enddateTime+"&Param.5="+userName+"&d="+dt;
         if(twoStageFlag=="1"){
         oCloseShiftModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_CloseShiftV3&"+sCloseShiftParam+"&Content-Type=text/json", "", false);
         }
         else{
         oCloseShiftModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_CloseShiftV2&"+sCloseShiftParam+"&Content-Type=text/json", "", false);
         }
         if(oCloseShiftModel.getData().Rowsets.Rowset[0].Row[0].Type=="S"){
            
            let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0114");
            sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
            sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");   
            let that = this;
               setTimeout(function(){ 
                  that._oRouter.navTo("Production");
               }, 2000);
            
         }
         else{
            let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0115");
            sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
            sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");  
         }
            //sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",false);
            //this.getView().byId("bCloseShift").setEnabled(true);
}, 
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/      
assignShiftEndTime:function(){
      let checkboxStatus=this.getView().byId("endOfShift").getSelected();
      if(checkboxStatus==true){
         //let dt=new Date(shiftEnd);
         //let ashiftEnd=CommonUtility.getCurrentDateTime(dt);
         this.getView().byId("intConfirmationTime").setValue(enddateTime);       
         this.getView().byId("intConfirmationTime").setEnabled(false);
         this.getView().byId("bCloseShift").setEnabled(true);
      }
      else{
         //this.getRunningOrder();
         this.getView().byId("intConfirmationTime").setEnabled(true);
         this.getView().byId("bCloseShift").setEnabled(false);
      }
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   

goToScrap: function() {
   
    
    var oGetEndDateModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->goToScrap-->XACQ_GetDeductedDate");

    oGetEndDateModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetDeductedDate&Param.1=" + enddateTime + "&d="+dt+"&Content-Type=text/json", "", false);
   ShiftCloseCkhTime = oGetEndDateModel.getData().Rowsets.Rowset[0].Row[0].O_ShiftEndTimeChk

    this.ManualCoding();

   

    let type = this.DoubleCheckShift();
    if (type == "B" && this.getView().byId("endOfShift").getSelected() == true) {
        let msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0082");
        MessageBox.error(msg, {
            title: "Error",
        });
    } else {
        var ActGudOpt = this.getView().byId("actualOutInterval").getValue();
        var TheoOut = this.getView().byId("intTarTheorySpeed").getValue();

        var PerfPerc = (ActGudOpt / TheoOut) * 100;

        if (TheoOut == 0 && ActGudOpt == 0 || TheoOut == "0.00" && ActGudOpt == "0.00") {
            PerfPerc = 0;
        }

        if (this.getView().byId("targetSpeed").getValue() <= this.getView().byId("prodSpeed").getValue()) {
      var that = this;
            if (PerfPerc <= 150) {
                if (this.getView().byId("closeOrder").getSelected()) {
                    var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0124")
                 
                    MessageBox.warning(
                        msg, {
                            icon: MessageBox.Icon.WARNING,
                            title: "Message from webpage",
                            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                            onClose: function(oAction) {
                                if (oAction === "OK") {
                                    if (that.getView().byId("endOfShift").getSelected()) {
            that.EOSChecked();  
                                    } //end of if condition endofShift
                                    else {
                                       that.redirectToScrap();
                                    }
                                }
         /*else{
         UI_utilities.setContainerBusyState(that,false);
         }*/
                            }
                        });


                } else if (this.getView().byId("endOfShift").getSelected()) {
         that.EOSChecked();      
                } else {
                    that.redirectToScrap();
                }
            } //(PerfPerc<=150) closing
            else {
                let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0208");
                MessageBox.error(msg, {
                    title: "Error",
                });
            }
        } else {
            let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0187");
            MessageBox.error(msg, {
                title: "Error",
            });
        }
    }
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
closeShiftNotReversibleMSG:function(){
   var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0039")
   var that=this;
   MessageBox.warning(
         msg, {
         icon: MessageBox.Icon.WARNING,
            title: "Message from webpage",
            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
            onClose: function(oAction) { 
      if(oAction==="OK"){
         that.redirectToScrap();
      }
      /*else{
         UI_utilities.setContainerBusyState(that,false);
      }*/
   }
   });
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
CloseShiftEarly:function(){
   
      var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0201")
      var that=this;
      MessageBox.warning(
            msg, {
            icon: MessageBox.Icon.WARNING,
               title: "Message from webpage",
               actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
               onClose: function(oAction) { 
         if(oAction==="OK"){
            that.closeShiftNotReversibleMSG();
         }
      }
      });
},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
EOSChecked:function(){
 
  
if (smanualCodingPath && smanualCodingPath.Type == "E") {
    let msg = smanualCodingPath.Message;
    MessageBox.error(msg, {
        title: "Error",
    });
} else if (smanualCodingPath && smanualCodingPath.Type == "W") {
	var that=this;
        let msg = smanualCodingPath.Message;
        MessageBox.warning(msg, {
	onClose: function(oAction) { 
     		  if (todayDateTime < ShiftCloseCkhTime) {
     that.CloseShiftEarly();
    } else {
     that.closeShiftNotReversibleMSG();
    }
         }
        });
	
  }
else{
    if (todayDateTime < ShiftCloseCkhTime) {
       this.CloseShiftEarly();
    } else {
       this.closeShiftNotReversibleMSG();
    }
}

},
/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
redirectToScrap:function(){
   var js_statusconf;
   var js_finalconf;
   var js_endofshift;
   var js_yield=this.getView().byId("actualOutInterval").getValue();
   var js_TheoOut=this.getView().byId("intTarTheorySpeed").getValue();
   var js_ictime=this.getView().byId("intConfirmationTime").getValue();
   var js_interval=this.getView().byId("intMinutes").getValue();  
   var js_LineSetSpeed=this.getView().byId("targetSpeed").getValue();
   var uom=this.getView().byId("uom").getValue();  
   var js_lictime=this.getView().byId("lastIntConfirmation").getValue();   
   var prodSpeed=this.getView().byId("prodSpeed").getValue();  
   var lineSetOut=this.getView().byId("intTarlineSetSpeed").getValue(); 
   var js_planqty=this.getView().byId("plannedQty").getValue();   
   var js_lead=this.getView().byId("lead").getValue();   
   var js_NewShiftCount=this.getView().byId("bottleneckCounter").getValue();  

   if(this.getView().byId("closeOrder").getSelected()){
      js_statusconf = "00002";
       js_finalconf = "1";
   }else{
      js_statusconf = "00004";
      js_finalconf = "0";
   }
   
   this.getView().byId("endOfShift").getSelected()==true?js_endofshift = "1":js_endofshift = "0";
   
   let dtFlag=this.ShiftEndShortStop();

   if(parseFloat(js_yield)>parseFloat(js_TheoOut)){
     let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0040");
             MessageBox.alert(msg);
   }
   else if(js_yield==""){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0021");
             MessageBox.alert(msg);
   }
   else if(isNaN(js_yield)){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0023");
             MessageBox.alert(msg); 
   }
   else if(js_yield<0){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0121");
             MessageBox.alert(msg); 
   }
   else if(parseInt(js_yield) !=js_yield){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116");
             MessageBox.alert(msg); 
   }
   
   else if(enddateTime< js_ictime){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0022");
             MessageBox.alert(msg); 
   }
   else if(js_interval<0){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0024");
             MessageBox.alert(msg); 
   }
   else if(js_LineSetSpeed<0 || js_LineSetSpeed=="" || isNaN(js_LineSetSpeed)){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0118");
             MessageBox.alert(msg); 
   }
   else if(dtFlag==1 && this.getView().byId("endOfShift").getSelected()){
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0214");
             MessageBox.alert(msg); 
   }
   else{
   
let js_speedloss=parseFloat(js_TheoOut)-parseFloat(lineSetOut);
   let js_minorstop=parseFloat(lineSetOut)-parseFloat(js_yield);
   
    var oPhaseYieldModel=  models.createNewJSONModel("com.khc.rephub.controller.production.RepProdEndInterval-->redirectToScrap-->XACQ_InsPhaseYield");

   let sPhaseYieldParam="Param.1="+crID+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+phase+"&Param.5="+userName+"&Param.6="+js_yield+"&Param.7="+js_interval+"&Param.8="+js_ictime+"&Param.9="+uom+"&Param.10="+opr+
   "&Param.11="+cr_dest+"&Param.12="+js_LineSetSpeed+"&Param.13="+shiftID+"&Param.14="+orderID+"&Param.15="+spath.MATNR+"&Param.16="+spath.MATTEXT+"&Param.17="+js_lictime+"&Param.18="+prodSpeed+"&Param.19="+js_TheoOut+
   "&Param.20="+lineSetOut+"&Param.21="+js_speedloss.toString()+"&Param.22="+js_minorstop.toString()+"&Param.23="+js_finalconf.toString()+"&Param.24="+sShiftDetails.TEAMID+"&d="+dt;;
   oPhaseYieldModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_InsPhaseYield&"+sPhaseYieldParam+"&Content-Type=text/json", "", false);
   
   var osIDModel = new sap.ui.model.json.JSONModel();
   let sID={
         qs_order:orderID,
         qs_matno:spath.MATNR,
         qs_Matnostrip:spath.ModMATNR,
         qs_planqty:js_planqty,
         qs_ictime:js_ictime,
         qs_desc:spath.MATTEXT,
         qs_crew:sShiftDetails.TEAMSIZE,
         qs_lead:js_lead,
         qs_shift:sShiftDetails.SHIFTNAME,
         qs_yield:js_yield,
         qs_trgspd:spath.TARGETSPEED,
         qs_interval:js_interval,
         qs_crid:crID,
         qs_msgid:spath.MSGID,
         qs_lictime:js_lictime,
         qs_opr:opr,
         qs_statusconf:js_statusconf,
         qs_endofshift:js_endofshift,
         qs_shiftstart:startdateTime,
         qs_orderidstrip:orderStrip,
         qs_shiftspeed:sShiftDetails.SPEED,
         qs_prodspeed:prodSpeed,
         qs_linesetspd:js_LineSetSpeed,
         qs_NewShiftCount:js_NewShiftCount,
         qs_ShiftId:shiftID,
         qs_TeamId:sShiftDetails.TEAMID
   }
   osIDModel.setData(sID)
   sap.ui.getCore().setModel(osIDModel,"sIDParam") 

   this._oRouter.navTo("RepEIScrap");     
   }
},

/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
getStatus:function(){
    var flag=0;
   var that=this;
$(document).ready(function(){

        $.ajax({
            type: 'POST',
            url: '/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/INF_FetchCustomAttributes_XMLQuery&Content-Type=text/xml',
           
            dataType: 'xml',
            success:function(data)  {
             
      $(data).find('Row').each(function(index){
                var name = $(this).find('Name').text();
                var status = $(this).find('Status').text();
      if(name=='CreateAutroConfirmation')
      {
         flag=1;
         if(status=='RUNNING')
         {
            alert("Cannot enter manual confirmation as auto confirmation scheduler has status:"+status) ;
            return;
         }
         else
         {
            //UI_utilities.setContainerBusyState(that,true);
            that.goToScrap(); 
         }
      }    
      
        });  //end function

   if(flag==0)
      {
         //UI_utilities.setContainerBusyState(that,true);
         that.goToScrap(); 
      }        
           
  }, //end success
               error: function(e) { 
   var err=JSON.stringify(e) ;      
   alert(err); 
   return;
                                 }
   
        });

})
},

/*************************************************************************************************************************************************************************************/
//Keyboard inputs
/*************************************************************************************************************************************************************************************/   
onClickDialpad : function(oEvent)   {
   
   let sKey = oEvent.getSource().getText();
   let bottleneckCounter=this.getView().byId("bottleneckCounter").getValue();
   let newBottleneckCounter = bottleneckCounter + sKey;
   this.getView().byId("bottleneckCounter").setValue(newBottleneckCounter);
   this.CalculateOutput();
   
   
},

onCancelDialPad : function(oEvent)  {
   
   this.getView().byId("bottleneckCounter").setValue("");
   this.getView().byId("actualOutInterval").setValue("0");
   
   
},

closeDialPad : function(oEvent)  {
   
   this.getView().byId("dialpad").setVisible(false);
   
   
},

onAfterRendering : function() {

    
   var that = this;
     // Add event delegate to open dialpad on focus
   this.getView().byId("bottleneckCounter").addEventDelegate({
        onfocusin : function() {
         that.getView().byId("dialpad").setVisible(true);
        }
      });
   //this.getRunningOrder();
   
   //rendered=true;
},


/*************************************************************************************************************************************************************************************/

/*************************************************************************************************************************************************************************************/   
onHelp:function(){

      UI_utilities.OpenHelpFileSingle("Confirmation");
   }
   });

});
    