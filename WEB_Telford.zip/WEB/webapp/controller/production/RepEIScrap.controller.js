// jQuery.sap.require("sap.m.MessageBox");
sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox", "com/khc/rephub/utils/UI_utilities",
		"com/khc/rephub/model/formatter", "com/khc/common/Script/CommonUtility", "com/khc/rephub/model/models"
	],
	function(Controller, MessageBox, UI_utilities, formatter, CommonUtility, models) {

		var plant;
		var resource;
		var projectName;
		var workstation;
		var userName;
		var oConfObject;
		var todayDateTime;
		var PhaseSelectedRowVal;
		var phase;
		var phasedesc;
		var uom;
		var OEEScrap;
		var operation;
		var sreason;
		var SelectedReasonCode;
		var scrapbyconversion;
		var scrapbyconversion2;
		var ICT;
		var scrap;
		var scrapQty;
		var conversion;
		var date;
		var time;
		let dt = new Date();

		return Controller.extend("com.khc.rephub.controller.production.RepEIScrap", {
			formatter: formatter,
			onInit: function() {

				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this._oRouter.getRoute("RepEIScrap").attachPatternMatched(this._oRoutePatternMatched, this);

			},
			_oRoutePatternMatched: function(oEvent) {

				// To remove busy indicator once the page loaded
				UI_utilities.productionMenuOpened(this, "endInterval");
			    this.getView().byId("dialpad").setVisible(false);
				let dt = new Date();
				todayDateTime = CommonUtility.getCurrentDateTime(dt);

				plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
				resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
				workstation = sap.ui.getCore().getModel("session").oData.CA_CRDest;
				projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
				//twoStageFlag=sap.ui.getCore().getModel("session").oData.CA_TwoStageFlag;
				userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;

				if (sap.ui.getCore().getModel("sIDParam")) {

					oConfObject = sap.ui.getCore().getModel("sIDParam").getData();
					this.clearFields();
					this.getPhaseList();
					this.getScrapReason();

				} else {

					this.goBack();
				}

			},

			menuSelected: function(oEvent) {

				// Navigate the the selected menu page

				var sKey = oEvent.getParameters().key;
				UI_utilities.openMenu(this._oRouter, this, sKey);

			},

			GoToConfirm: function() {
				this._oRouter.navTo("RepEIConfirm");
			},

			goBack: function() {
				this._oRouter.navTo("endInterval");
			},

/*****************************************************************************************************************************************************************************************/
//on load of page update the Phase List table values 
/****************************************************************************************************************************************************************************************/

			getPhaseList: function() {
				var oModelPhaseList = models.createNewJSONModel(
					"com.khc.rephub.controller.production.RepEIScrap-->getPhaseList-->XACQ_GetPhaseScrap");
				oModelPhaseList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetPhaseScrap&Param.1=" +
					oConfObject.qs_msgid + "&Param.2=" + oConfObject.qs_crid + "&Param.3=" + resource + "&Content-Type=text/json", "", false);

				var oScrapPhaseListTable = this.getView().byId("Scraptable2");
				let rowCount = CommonUtility.getJsonModelRowCount(oModelPhaseList.getData())

				if (rowCount > 0) {

					this.getView().setModel(oModelPhaseList, "oPhaseList");
				}
			},

/*****************************************************************************************************************************************************************************************/
// loading the Scrap Reason for Reason drop down
/****************************************************************************************************************************************************************************************/

			getScrapReason: function() {

				var oModelReasonList = models.createNewJSONModel(
					"com.khc.rephub.controller.production.RepEIScrap-->getScrapReason-->SQLQ_GetScrapCode");
				oModelReasonList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
					"/QueryTemplate/SQLQ_GetScrapCode&Content-Type=text/json", "", false);
				this.getView().setModel(oModelReasonList, "oReasonList");

			},

/*****************************************************************************************************************************************************************************************/
// loading the dialpad
/****************************************************************************************************************************************************************************************/

			onClickDialpad: function(oEvent) {

				let sKey = oEvent.getSource().getText();
				let quantityval = this.getView().byId("quantity").getValue();
				let newquantityval = quantityval + sKey;
				this.getView().byId("quantity").setValue(newquantityval);

			},

			onCancelDialPad: function(oEvent) {

				this.getView().byId("quantity").setValue("");
				//this.getView().byId("quantity").setValue("0");

			},

			closeDialPad: function(oEvent) {

				this.getView().byId("dialpad").setVisible(false);

			},

			onAfterRendering: function() {

				var that = this;
				// Add event delegate to open dialpad on focus
				this.getView().byId("quantity").addEventDelegate({
					onfocusin: function() {
						that.getView().byId("dialpad").setVisible(true);
					}
				});
			},

/*****************************************************************************************************************************************************************************************/
// loading the selected row values of Phase List Table 
/****************************************************************************************************************************************************************************************/
			ScrapPhaseListRowSelected: function() {

				var aSelectedRowPath = this.getView().byId("Scraptable2").getSelectedContextPaths();
				var oScrapPhaseListRowModel = this.getView().getModel("oPhaseList");

				if (aSelectedRowPath.length > 0) {
					let sPath = aSelectedRowPath[0];

					var SelectedRowVal = oScrapPhaseListRowModel.getProperty(sPath);
					PhaseSelectedRowVal = SelectedRowVal;
					var Phase = oScrapPhaseListRowModel.getProperty(sPath).Phase;
					phase = Phase;
					var PhaseText = oScrapPhaseListRowModel.getProperty(sPath).PhaseText;
					phasedesc = PhaseText;
					var UOM = oScrapPhaseListRowModel.getProperty(sPath).UOM;
					uom = UOM;
					var Quantity = oScrapPhaseListRowModel.getProperty(sPath).ScrapQty;
					scrapQty = Quantity;
					var Reason = oScrapPhaseListRowModel.getProperty(sPath).SReason;
					var scode = oScrapPhaseListRowModel.getProperty(sPath).SCode;
					OEEScrap = PhaseSelectedRowVal.OEE_Scrap;
					operation = PhaseSelectedRowVal.Operation;
					conversion = PhaseSelectedRowVal.Conversion;

					this.getView().byId("phase").setValue(PhaseText);
					this.getView().byId("uom").setValue(UOM);
					this.getView().byId("quantity").setValue(Quantity);
					//this.getView().byId("scrapreason").setValue(Reason);
					this.getView().byId("scrapreason").setSelectedKey(scode);

					if (conversion == 'NA') {

						conversion = '0';

						//this.getScrapReason();
					}

					if (scode == "") {

						this.getView().byId("updatebutton").setEnabled(false);
						this.getView().byId("deletebutton").setEnabled(false);
					} else {

						this.getView().byId("updatebutton").setEnabled(true);
						this.getView().byId("deletebutton").setEnabled(true);
					}
				}

			},

/*****************************************************************************************************************************************************************************************/
// on click of add button
/****************************************************************************************************************************************************************************************/

			onAdd: function() {

				//var Phase = PhaseSelectedRowVal.Phase;
				var Temp = 1;
				scrap = this.getView().byId("quantity").getValue();
				scrapbyconversion = scrap * parseFloat(conversion);
				scrapbyconversion2 = scrapbyconversion.toFixed(2);
				PhaseLength = this.getView().byId("Scraptable2").getSelectedContextPaths().length;

				var oModelChkPhaseScrap = models.createNewJSONModel("com.khc.rephub.controller.production.RepEIScrap-->onAdd-->SQLQ_ChkPhaseScrap");
				var oModelInsScrap = models.createNewJSONModel("com.khc.rephub.controller.production.RepEIScrap-->onAdd-->SQLQ_InsPhaseScrap");
				let todayDate = CommonUtility.formatDate(dt);
				let todayDateTime = CommonUtility.getCurrentDateTime(dt);
				let todayTime = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
				date = todayDate;
				time = todayTime;
				ICT = todayDateTime;
				SelectedReasonCode = this.getView().byId("scrapreason").getSelectedKey();

				if (PhaseLength > 0) {
					if (this.getView().byId("quantity").getValue() != '' && this.getView().byId("quantity").getValue() > 0) {
						if (parseInt(this.getView().byId("quantity").getValue()) == this.getView().byId("quantity").getValue()) {
							if (SelectedReasonCode) {
								if (PhaseSelectedRowVal.ScrapQty != "" && PhaseSelectedRowVal.SCode == SelectedReasonCode) {
									var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0028");
									MessageBox.alert(sAlertMsg, {
										title: "Alert",
									});
								} else {
									//oModelChkPhaseScrap.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_ChkPhaseScrap&Param.1="+crid+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+phase+"&Param.5="+SelectedReasonCode+"&Param.6="+Temp+"&Content-Type=text/json", "", false);
									//sap.ui.getCore().setModel(oModelChkPhaseScrap,"oChkPhaseScrap");
									sreason = this.getView().byId("scrapreason").getSelectedItem().getText()

									oModelInsScrap.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsPhaseScrap&Param.1=" +
										oConfObject.qs_crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + phase + "&Param.5=" + phasedesc +
										"&Param.6=" + oConfObject.qs_interval + "&Param.7=" + userName + "&Param.8=" + scrapbyconversion2 + "&Param.9=" + uom +
										"&Param.10=" + SelectedReasonCode + "&Param.11=" + sreason + "&Param.12=" + operation + "&Param.13=" + workstation +
										"&Param.14=" + oConfObject.qs_ictime + "&Param.15=" + oConfObject.qs_shift + "&Param.16=" + OEEScrap + "&Param.17=" + scrap +
										"&Param.18=" + oConfObject.qs_order + "&Param.19=" + oConfObject.qs_ShiftId + "&Param.20=" + oConfObject.qs_matno +
										"&Param.21=" + oConfObject.qs_desc + "&Param.22=" + oConfObject.qs_TeamId + "&Content-Type=text/json", "", false);
									//sap.ui.getCore().setModel(oModelChkPhaseScrap,"oChkPhaseScrap");

									this.getPhaseList();
									this.clearFields();

								}
							} else {
								var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0026");
								MessageBox.alert(sAlertMsg, {
									title: "Alert",
								});

							}
						} else {
							var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116");
							MessageBox.alert(sAlertMsg, {
								title: "Alert",
							});
						}
					} else {
						var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0027");
						MessageBox.alert(sAlertMsg, {
							title: "Alert",
						});

					}
				} else {
					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0025");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",
					});

				}
				//	this.clearFields();

			},

/*****************************************************************************************************************************************************************************************/
// on click of update button
/****************************************************************************************************************************************************************************************/

			onUpdate: function() {

				var Temp = 1;
				PhaseLength = this.getView().byId("Scraptable2").getSelectedContextPaths().length;

				if (PhaseLength > 0) {

					scrap = this.getView().byId("quantity").getValue();

					if (scrap != '' && scrap > 0) {
						if (parseInt(scrap) == scrap) {

							sreason = this.getView().byId("scrapreason").getSelectedItem().getText();

							if (sreason != "") {

								scrapbyconversion = eval(scrap) * eval(conversion);
								scrapbyconversion2 = scrapbyconversion.toFixed(2);

								var Scode = PhaseSelectedRowVal.SCode;
								//this.getView().byId("scrapreason").setSelectedKey(Scode);
								SelectedReasonCode = Scode;

								var oModelUpdPhaseScrap = models.createNewJSONModel(
									"com.khc.rephub.controller.production.RepEIScrap-->onUpdate-->SQLQ_UpdPhaseScrap");
								let todayDate = CommonUtility.formatDate(dt);
								let todayDateTime = CommonUtility.getCurrentDateTime(dt);
								let todayTime = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
								date = todayDate;
								time = todayTime;
								ICT = todayDateTime;

								oModelUpdPhaseScrap.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_UpdPhaseScrap&Param.1=" +
									scrapbyconversion2 + "&Param.2=" + uom + "&Param.3=" + SelectedReasonCode + "&Param.4=" + sreason + "&Param.5=" + oConfObject
									.qs_crid + "&Param.6=" + plant + "&Param.7=" + resource + "&Param.8=" + phase + "&Param.9=" + Scode +
									"&Param.10=" + "1" + "&Param.11=" + scrap + "&Content-Type=text/json", "", false);
								sap.ui.getCore().setModel(oModelUpdPhaseScrap, "oUpdPhaseScrap");

								this.getPhaseList();
								this.clearFields();
							} else {
								var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0026");
								MessageBox.alert(sAlertMsg, {
									title: "Alert",
								});

							}
						} else {
							var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116");
							MessageBox.alert(sAlertMsg, {
								title: "Alert",
							});
						}
					} else {
						var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0027");
						MessageBox.alert(sAlertMsg, {
							title: "Alert",
						});

					}
				} else {

					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0025");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",
					});

				}

			},

/*****************************************************************************************************************************************************************************************/
// on click of delete button
/****************************************************************************************************************************************************************************************/

			onDelete: function() {

				PhaseLength = this.getView().byId("Scraptable2").getSelectedContextPaths().length;
				if (PhaseLength > 0) {

					var Scode = PhaseSelectedRowVal.SCode;
					this.getView().byId("scrapreason").setSelectedKey(Scode);
					SelectedReasonCode = Scode;
					var oModelDelPhaseScrap = models.createNewJSONModel(
						"com.khc.rephub.controller.production.RepEIScrap-->onDelete-->SQLQ_DelPhaseScrap");

					oModelDelPhaseScrap.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_DelPhaseScrap&Param.1=" +
						oConfObject.qs_crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + phase + "&Param.5=" + SelectedReasonCode +
						"&Param.6=" + "1" + "&Content-Type=text/json", "", false);
					sap.ui.getCore().setModel(oModelDelPhaseScrap, "oDelPhaseScrap");

					this.clearFields();
					this.getPhaseList();

				} else {
					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0025");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",
					});

				}

			},

/*****************************************************************************************************************************************************************************************/
// to clear the fields
/****************************************************************************************************************************************************************************************/

			clearFields: function() {

				this.getView().byId("quantity").setValue("");
				this.getView().byId("uom").setValue("");
				phase = "";
				this.getView().byId("phase").setValue("");
				this.getView().byId("scrapreason").setSelectedKey("");

			},
			onHelp: function() {

				UI_utilities.OpenHelpFileSingle("Confirmation");
			}

		});
	});