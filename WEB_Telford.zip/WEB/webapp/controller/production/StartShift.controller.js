// jQuery.sap.require("sap.m.MessageBox");
sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox","com/khc/rephub/utils/UI_utilities",
"com/khc/rephub/model/formatter","com/khc/common/Script/CommonUtility","com/khc/rephub/model/models"], 
	function(Controller,MessageBox,UI_utilities,formatter,CommonUtility,models) {
	"use strict";
	var plant;
	var resource;
	var projectName;
	var userName;
	return Controller.extend("com.khc.rephub.controller.production.StartShift", {formatter:formatter,
		onInit: function() {
			
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("startShift").attachPatternMatched(this._oRoutePatternMatched, this);
			
		},
		_oRoutePatternMatched: function(oEvent) {
			
			// To remove busy indicator once the page loaded
			UI_utilities.productionMenuOpened(this,"startShift");
			
			this.getView().byId("add").setVisible(false);
			this.getView().byId("reduce").setVisible(false);
			this.getView().byId("updshift").setEnabled(false);
			plant=sap.ui.getCore().getModel("session").oData.CA_Plant
			resource=sap.ui.getCore().getModel("session").oData.CA_Resource
			projectName=sap.ui.getCore().getModel("session").oData.CA_ProjectName
			userName=sap.ui.getCore().getModel("session").oData.CA_IllumLoginName
			
			this.getShifts();
			this.getTeamList();
			this.getCrewList();
			this.getScheduledOrder();
			this.getPrevNotes();
			this.getShiftDetails();
			this.getMaintenanceNotif();
			this.getOrderData();
	
			
		},
		
		menuSelected : function (oEvent) {
        	
			// Navigate the the selected menu page
			
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
			
     		   },

/**********************************************************************************************************/
	//on load of page insert the shift details to dropdown
/*************************************************************************************************************/	
	getShifts:function(){
	
	 var oModelShiftName=models.createNewXMLModel("com.khc.rephub.controller.production.StartShift-->getShifts-->XACQ_GetShiftsByResr");
        oModelShiftName.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetShiftsByResr&Param.1="+plant+"&Param.2="+resource+"&d="+new Date()+"&Content-Type=text/xml", "", false);
      	var shiftDataDD = this.getView().byId("shifts");
	let rowCount=$(oModelShiftName.getData()).find("Row").length
	if(rowCount>0){
      	shiftDataDD.setModel(oModelShiftName, "oshiftName");
	}
	},

/**********************************************************************************************************/
	//on load of page insert the Team details to dropdown
/*************************************************************************************************************/	

	getTeamList:function(){
	
	 var oModelTeamList=models.createNewXMLModel("com.khc.rephub.controller.production.StartShift-->getTeamList-->SQLQ_GetTeamList");
      	oModelTeamList.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetTeamList&d="+new Date()+"&Content-Type=text/xml", "", false);
	let rowCount=$(oModelTeamList.getData()).find("Row").length
	if(rowCount>0){
	sap.ui.getCore().setModel(oModelTeamList,"oteamList")
	}
	},

/**********************************************************************************************************/
	//on load of page insert the Crew details to dropdown
/*************************************************************************************************************/	

	getCrewList:function(){
	
	 var oModelCrewList=models.createNewXMLModel("com.khc.rephub.controller.production.StartShift-->getCrewList-->XACQ_GetCrewList");
      	oModelCrewList.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetCrewList&d="+new Date()+"&Content-Type=text/xml", "", false);
	var crewListDD=this.getView().byId("crewList")
	let rowCount=$(oModelCrewList.getData()).find("Row").length
	if(rowCount>0){
	crewListDD.setModel(oModelCrewList,"ocrewList")
	}
	},

/*****************************************************************************************************************************************************************************************/
	//on load of page insert the SScheduled orders for resource details to dropdown. Get the list of order with status =0 from HNZ_TASKLIST table.
/****************************************************************************************************************************************************************************************/	

	getScheduledOrder:function(){
		
       var oModelSchedList=models.createNewXMLModel("com.khc.rephub.controller.production.StartShift-->getScheduledOrder-->XACQ_GetTaskListByResr");
      	oModelSchedList.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetTaskListByResr&Param.1="+plant+"&Param.2="+resource+"&Param.3=0&d="+new Date()+"&Content-Type=text/xml", "", false);
	var oSchedOrderTable=this.getView().byId("schedOrder")
	let rowCount=$(oModelSchedList.getData()).find("Row").length
	if(rowCount>0){
	oSchedOrderTable.setModel(oModelSchedList,"oSchedOrder")
	}
	},

/*****************************************************************************************************************************************************************************************/
	//on load of page insert the Shift Notes for Previous Shift dropdown. Get the list of order with status =0 from HNZ_TASKLIST table.
/****************************************************************************************************************************************************************************************/	

	getPrevNotes:function(){		
         var oModelPrevNotes=models.createNewXMLModel("com.khc.rephub.controller.production.StartShift-->getPrevNotes-->XACQ_GetShiftNotes_PrevShift");
      	 oModelPrevNotes.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetShiftNotes_PrevShift&Param.1="+plant+"&Param.2="+resource+"&d="+new Date()+"&Content-Type=text/xml", "", false);
	var oPrevNotesTable=this.getView().byId("prevNotes")
	let rowCount=$(oModelPrevNotes.getData()).find("Row").length
	if(rowCount>0){
	oPrevNotesTable.setModel(oModelPrevNotes,"oPrevNotes")
	}
	},

/*****************************************************************************************************************************************************************************************/
//**** Called from creation event of APLT_CMD_GetShiftDetails applet. Get the details of a running shift and populate required fields.
/*****************************************************************************************************************************************************************************************/

getShiftDetails:function(){

	var currenttime = new Date();
	var currentDT =  CommonUtility.getCurrentDateTime(currenttime);
	
	
	 var oModelCurrentShiftData=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->getShiftDetails-->XACQ_GetShiftDetails");
        	oModelCurrentShiftData.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetShiftDetails&Param.1="+plant+"&Param.2="+resource+"&Param.3="+currentDT+"&d="+new Date()+"&Content-Type=text/json", "", false);
	sap.ui.getCore().setModel(oModelCurrentShiftData,"oCurrentShiftData")	

	let rowCount=CommonUtility.getJsonModelRowCount(oModelCurrentShiftData.getData())
	if(rowCount>0){
	var startTime=oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].StartTime

	this.getView().byId('start_date').setValue(startTime.split("T")[0]+" "+startTime.split("T")[1]);
	this.getView().byId('duration').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].DurMin)
	this.getView().byId('shifts').setSelectedKey(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].ShiftName)
	this.getView().byId("teamList").setSelectedKey(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].TeamId);
	//this.getView().byId('teamId').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].TeamId);
	this.getView().byId('Lead').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].Lead)
	this.getView().byId('crewList').setSelectedKey(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].TeamSize)
	this.getView().byId('Interval').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].Interval)
	//this.getView().byId('targetSpeed').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].Speed)
	this.getView().byId('shift_target').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].Target)
	this.getView().byId('shift_counter').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].Counter)
		
	this.getView().byId("setshift").setEnabled(false);	
	this.getView().byId("updshift").setEnabled(true);

	}
	else{
	this.getView().byId("start_date").setValue("")
	this.getView().byId('duration').setValue("")
	this.getView().byId('Lead').setValue(userName)
	this.getView().byId("teamList").setSelectedKey("");
	this.getView().byId('crewList').setSelectedKey("")	
	this.getView().byId('Interval').setValue("")
	this.getView().byId('shift_target').setValue("0")
	this.getView().byId('shift_counter').setValue("0")
	this.getView().byId("shifts").setSelectedKey("");
	}

},
/**************************************************************************************************************************************************************************************/
	//on Load get the list of running order
/*****************************************************************************************************************************************************************************************/	
getOrderData:function(){
	
	var oModelOrderDetails=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->getOrderData-->XACQ_GetTaskListByResr");
	var that=this;
	oModelOrderDetails.attachRequestCompleted(
			 function(){ 
				 if(CommonUtility.getJsonModelRowCount(oModelOrderDetails.getData())) { 
					sap.ui.getCore().setModel(oModelOrderDetails,"oOrderdetails");
					that.getQualityNotif();
				 }
		});
	
      	oModelOrderDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetTaskListByResr&Param.1="+plant+"&Param.2="+resource+"&Param.3=1&d="+new Date()+"&Content-Type=text/json", "", false);
},
/**************************************************************************************************************************************************************************************/
	//on load get the Quality notification
/*****************************************************************************************************************************************************************************************/	
getQualityNotif:function(){
	
	let matNum=this.getView().getModel("oOrderdetails").getData().Rowsets.Rowset[0].Row[0].MATNR
	let orderId=this.getView().getModel("oOrderdetails").getData().Rowsets.Rowset[0].Row[0].ORDERID
	
	 var oModelQualityNotif=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->getQualityNotif-->XACQ_GetQualNotList");

      	oModelQualityNotif.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetQualNotList&Param.1="+plant+"&Param.2="+resource+"&Param.3="+orderId+"&Param.4="+matNum+"&d="+new Date()+"&Content-Type=text/json", "", false);
	let rowCount=CommonUtility.getJsonModelRowCount(oModelQualityNotif.getData())
	if(rowCount>0){
	sap.ui.getCore().setModel(oModelQualityNotif,"oQualityNotif");
	}
},

/**************************************************************************************************************************************************************************************/
	//on load get the Maintenance notification
/*****************************************************************************************************************************************************************************************/	
getMaintenanceNotif:function(){
	
	
	 var oModelMaintenanceNotif=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->getMaintenanceNotif-->SQLQ_GetMaintNotV1");

      	oModelMaintenanceNotif.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetMaintNotV1&Param.1="+resource+"&Param.2="+plant+"&d="+new Date()+"&Content-Type=text/json", "", false);
	let rowCount=CommonUtility.getJsonModelRowCount(oModelMaintenanceNotif.getData())
	if(rowCount>0){
	sap.ui.getCore().setModel(oModelMaintenanceNotif,"oMaintNotif");
	}
},


/**********************************************************************************************************/
	//on load of page insert the Team details to dropdown.......Code not in use
/*************************************************************************************************************/	
/*getShiftNames:function(selectedShift){
	
	$.ajax({url: "/XMII/Runner?Transaction=NL_ELS_HUB_SAPUi5/BLS/NightShiftName&Content-Type=text&OutputParameter=*",
		type: "GET",
		async:false,
		success: function (result) {
			let shiftNames=$(result).find("shiftNames").text()
			if(shiftNames.indexOf(selectedShift)=="0"){
				this.getView().byId("add").setVisible(false);
				this.getView().byId("reduce").setVisible(true);
			}
	   	 }
	});
	
},*/

/**************************************************************************************************************************************************************************************/
	//on select of item from dropdown load other input boxes
/*****************************************************************************************************************************************************************************************/	
	GetOldShiftDetails:function(oEvent){
	var selectedShift=this.getView().byId("shifts").getValue()
	//this.getShiftNames(selectedShift);
	
	if(selectedShift == "Night" || selectedShift == "Nacht" || selectedShift == "Nights" || selectedShift == "Sunday Night 10 hr" || selectedShift == "Start-Up - Sunday" || selectedShift == "Trzecia zmiana" || selectedShift == "Nuit" || selectedShift == "Red Shift" || selectedShift == "Blue Shift")
	{
		this.getView().byId("add").setVisible(false);
		this.getView().byId("reduce").setVisible(true);
	}
	else
	{
		this.getView().byId("add").setVisible(false);
		this.getView().byId("reduce").setVisible(false);
	}
	
	
	 var oModelShiftData=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->GetOldShiftDetails-->XACQ_GetOldShiftDetails");

        	oModelShiftData.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetOldShiftDetails&Param.1="+plant+"&Param.2="+resource+"&Param.3="+selectedShift+"&d="+new Date()+"&Content-Type=text/json", "", false);

	let rowCount=CommonUtility.getJsonModelRowCount(oModelShiftData.getData())
		
	if(rowCount>0){
	sap.ui.getCore().setModel(oModelShiftData,"shiftData")
	
	var currentDate=  CommonUtility.getCurrentDate()
	this.getView().byId("start_date").setValue(currentDate+" "+oModelShiftData.getData().Rowsets.Rowset[0].Row[0].StartTime)
	this.getView().byId('duration').setValue(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].Duration)
	this.getView().byId('Lead').setValue(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].Lead)
	this.getView().byId("teamList").setSelectedKey(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].TeamId);
	this.getView().byId('crewList').setSelectedKey(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].TeamSize)	
	this.getView().byId('Interval').setValue(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].Interval)
	let rowCount=CommonUtility.getJsonModelRowCount(this.getView().getModel("oCurrentShiftData").getData())
	if(rowCount>0){
		this.getView().byId('shift_target').setValue(this.getView().getModel("oCurrentShiftData").getData().Rowsets.Rowset[0].Row[0].Target)
		this.getView().byId('shift_counter').setValue(this.getView().getModel("oCurrentShiftData").getData().Rowsets.Rowset[0].Row[0].Counter)
	}
	
	this.GetTagConfigforResrByTime(this.getView().byId('start_date').getValue())
	
	//if (plant=="3278"|| plant=="3005" || plant=="3017")
	//23-06-2023-Removing the plant check for Telford(3017) so that ShiftCounter gets updated on load of page in GetTagConfigforResrByTime()
	if (plant=="3278"|| plant=="3005")
	{
		if((oModelShiftData.getData().Rowsets.Rowset[0].Row[0].Running) != "1")
		{
			this.getView().byId('shift_counter').setValue("0")
		}
				
	}
	this.getView().byId("setshift").setEnabled(true);
	}
	else{
		this.getView().byId("duration").setValue("8");
	this.getView().byId("Lead").setValue(userName)
	this.getView().byId("Interval").setValue("60")
	this.getView().byId("shift_target").setValue("")
	if (plant=="3278"|| plant=="3005")
	{
		this.getView().byId("shift_counter").setValue("0")
		
	}
	this.GetTagConfigforResrByTime(this.getView().byId("start_date").getValue());
	this.getView().byId("setshift").setEnabled(true);	

	}
	
	},

/**********************************************************************************************************/
	
/*************************************************************************************************************/	

GetTagConfigforResrByTime:function(date){
		
		 var oTagResourse=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->GetTagConfigforResrByTime-->SQLQ_GetTagResource");

      	oTagResourse.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetTagResource&Param.1="+plant+"&Param.2="+resource+"&d="+new Date()+"&Content-Type=text/json", "", false);
	
	let rowCountforoTagResourse=CommonUtility.getJsonModelRowCount(oTagResourse.getData())

	if(rowCountforoTagResourse>0){
	  if(oTagResourse.getData().Rowsets.Rowset[0].Row[0].AUTOINTFLAG=="Y"){
		
		 var oModelCount=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->GetTagConfigforResrByTime-->XACQ_GetYieldCountHISWrapper");

      		oModelCount.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetYieldCountHISWrapper&Param.1="+plant+"&Param.2="+resource+"&Param.3="+date+"&d="+new Date()+"&Content-Type=text/json", "", false);
	
		let rowCountforoModelCount=CommonUtility.getJsonModelRowCount(oModelCount.getData())
		if(rowCountforoModelCount>0){this.getView().byId("shift_counter").setValue(oModelCount.getData().Rowsets.Rowset[0].Row[0].O_Count)}
	
		if(plant == '3309'){
		
		 var oModelCounter=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->GetTagConfigforResrByTime-->SQLQ_GetLastShiftCounter");

      		oModelCounter.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/SQLQ_GetLastShiftCounter&Param.1="+plant+"&Param.2="+resource+"&d="+new Date()+"&Content-Type=text/json", "", false);	
		let rowCount=CommonUtility.getJsonModelRowCount(oModelCounter.getData())
		if(rowCount>0){this.getView().byId("shift_counter").setValue(oModelCount.getData().Rowsets.Rowset[0].Row[0].COUNTER);}
		}
	      }
	  }
        },

/**********************************************************************************************************/
	//on click of set shift button 
/*************************************************************************************************************/	
	CheckValue_Ins:function(){
	
	var ShiftTrgt = this.getView().byId("shift_target").getValue()
	if(ShiftTrgt != "")
	{	
		if(this.getView().byId("shift_target").getValue() == 0)
		{
			
			var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0064")
			var that=this;
			MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
          			onClose: function(oAction) { 
				if(oAction==="OK"){
					that.Ins_ShiftData();
				}
			 }
     			 });					
		}
		else
		{
			this.Ins_ShiftData();
		}
	}
	else{
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0063")
		MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK]
          		
     			 });
	}
	},

/**********************************************************************************************************/
	//on click of set shift button 
/*************************************************************************************************************/	
	Ins_ShiftData:function(){
		
	var startTime =this.getView().byId("start_date").getValue();
	var duration = this.getView().byId("duration").getValue();	
	var shiftName = this.getView().byId("shifts").getSelectedKey();
	var lead = this.getView().byId("Lead").getValue();	
	var teamSize =  this.getView().byId("crewList").getSelectedKey();
	var interval = this.getView().byId("Interval").getValue();	
	//var trgtspeed = document.getElementById("targetSpeed").value;	
	var shiftTarget =  this.getView().byId("shift_target").getValue();	
	var shiftCounter  = this.getView().byId("shift_counter").getValue();
	var teamId =this.getView().byId("teamList").getSelectedKey()
	var teamName =this.getView().byId("teamList").getProperty("value")
	

	var dt = new Date();
	var currentTime =  CommonUtility.getCurrentDateTime(dt);

	if(startTime <= currentTime){
	if(startTime == "" ||  duration =="" || shiftName == "" || lead == "" || teamSize == "" || interval == "" ||  shiftTarget == "" )
	{
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0003")
		MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK]
           			 });		
		
	}
	
	else if(teamName == "")
	{
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0128")
		MessageBox.warning(
      				msg, {
       			   icon:MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK]
           			 });	
		
	}
	else if(shiftTarget < 0 || shiftCounter<0){
			let msg="Please enter positive number";
				
			MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
     			 });					

		}
	else
	{		
		if(shiftCounter == "") 
		{ 
			shiftCounter = "0"; 
		}

		
var oModelSetShift=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->GetTagConfigforResrByTime-->XACQ_InsShiftV2");
      	oModelSetShift.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_InsShiftV2&Param.1="+plant+"&Param.2="+resource+"&Param.3="+startTime+"&Param.4="+duration+"&Param.5="+shiftName+"&Param.6="+lead+"&Param.7="+teamSize+"&Param.8="+interval+"&Param.9="+shiftTarget+"&Param.10="+teamName+"&Param.11="+teamId+"&Param.12="+shiftCounter+"&d="+new Date()+"&Content-Type=text/json", "", false);	
	
	let rowCount=CommonUtility.getJsonModelRowCount(oModelSetShift.getData())
	if(rowCount>0){
	if(oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type=="S"){
	var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0001")
		sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
		UI_utilities.showAlert();
	}
	else if(oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type=="C"){
	var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0002")+"."+oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Message
		sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
	}
	else if(oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type=="E"){
	var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0005")
	sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
	}
	else if(oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type=="CO"){
	var msg=oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Message
	sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
	}
	}
	
	}
}
else{
		var msg= "You cannot start a future shift"
		MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK]
           			 });	
}
	
	 
	
	},

/**********************************************************************************************************/
	//on click of update shift button 
/*************************************************************************************************************/	
	Check_UpdShift:function(){
		var ShiftTrgt = this.getView().byId("shift_target").getValue()
		var ShiftCounter= this.getView().byId("shift_counter").getValue()
	if(ShiftTrgt != "")
	{	
		if(ShiftTrgt== 0 && ShiftCounter>0)
		{
			var that=this;
			var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0064")
				
			MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK,MessageBox.Action.CANCEL],
          			onClose: function(oAction) { 
				if(oAction==="OK"){
					that.Upd_Shift();
				}
			 }
     			 });					
		}
		else if(ShiftTrgt < 0 || ShiftCounter<0){
			let msg="Please enter positive number";
				
			MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
     			 });					

		}
		else
		{
			this.Upd_Shift();
		}
	}
	else{
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0063")
		MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK]
          		
     			 });
	}
	},
/**********************************************************************************************************/
	//on click of update shift button call-Check_UpdShift and Check_UpdShift calls-below function 
/*************************************************************************************************************/	
	Upd_Shift:function(){
	
	var duration = this.getView().byId("duration").getValue();	
	var lead = this.getView().byId("Lead").getValue();	
	var teamSize =  this.getView().byId("crewList").getSelectedKey();
	var interval = this.getView().byId("Interval").getValue();	
	var shiftTarget =  this.getView().byId("shift_target").getValue();	
	var shiftCounter  = this.getView().byId("shift_counter").getValue();
	var teamId =this.getView().byId("teamList").getSelectedKey()
	var teamName =this.getView().byId("teamList").getProperty("value")
	var startTime =this.getView().byId("start_date").getValue();	
	var shiftName = this.getView().byId("shifts").getSelectedKey();
	
	//var trgtspeed = document.getElementById("TrgtSpd").value;	

	if(startTime == "" ||  duration =="" || shiftName == "" || lead == "" || teamSize == "" || interval == "" ||  shiftTarget == "" )
		{
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0003")
		MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK,MessageBox.Action.CANCEL]
           			 });	
		}
	
	else if(teamName == "")
	{
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0128")
		MessageBox.warning(
      				msg, {
       			   icon: MessageBox.Icon.WARNING,
         			title: "Message from webpage",
          			actions: [MessageBox.Action.OK,MessageBox.Action.CANCEL]
           			 });
	}
	else{
		if(shiftCounter == "") 
		{ 
			shiftCounter = "0"; 
		}

		
		var oModelUpdateShift=models.createNewJSONModel("com.khc.rephub.controller.production.StartShift-->Upd_Shift-->XACQ_UpdShiftV2");

      		oModelUpdateShift.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdShiftV2&Param.1="+shiftCounter+"&Param.2="+duration+"&Param.3="+interval+"&Param.4="+lead+"&Param.5="+plant+"&Param.6="+resource+"&Param.7="+shiftTarget+"&Param.8="+teamId+"&Param.9="+teamName+"&Param.10="+teamSize+"&d="+new Date()+"&Content-Type=text/json", "", false);	
		let rowCount=CommonUtility.getJsonModelRowCount(oModelUpdateShift.getData())
		if(rowCount>0){
		
		if(oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Type=="S"){
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0133")
		sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
		
		}
		else if(oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Type=="E"){
		var msg= this.getView().getModel("i18n").getProperty("HUB_MSG_0005")
		sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");	
		}
		else if(oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Type=="CO"){
		var msg=oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Message
		sap.ui.getCore().getModel("oMessage").setProperty("/message",msg);
			sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
			sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");	
           			 }	
		}
	}
},

/**********************************************************************************************************/
	
/*************************************************************************************************************/		
addDate:function(){
	let dateTime =this.getView().byId("start_date").getValue();
	this.getView().byId("add").setVisible(false);
		this.getView().byId("reduce").setVisible(true);	
		 let date= new Date(dateTime);
		date.setDate(date.getDate() + 1);
		let formatedDate=CommonUtility.getCurrentDateTime(date);
 		  this.getView().byId("start_date").setValue(formatedDate);
this.GetTagConfigforResrByTime(this.getView().byId("start_date").getValue());
},
/**********************************************************************************************************/
	
/*************************************************************************************************************/		
reduceDate:function(){
	let dateTime =this.getView().byId("start_date").getValue();
	this.getView().byId("add").setVisible(true);
		this.getView().byId("reduce").setVisible(false);
		 let date= new Date(dateTime);
		date.setDate(date.getDate() - 1);
		let formatedDate=CommonUtility.getCurrentDateTime(date);
 		  this.getView().byId("start_date").setValue(formatedDate);
this.GetTagConfigforResrByTime(this.getView().byId("start_date").getValue());
}

/**********************************************************************************************************/
	
/*************************************************************************************************************/		
	});

});