sap.ui.define([ "sap/ui/core/mvc/Controller", "sap/m/MessageBox", "sap/ui/model/Filter", "sap/m/DateTimeInput", "sap/m/Button", "sap/m/Dialog",
		"com/khc/rephub/utils/UI_utilities", 
		"com/khc/common/Script/CommonUtility" ,"com/khc/rephub/model/formatter"], function(Controller, MessageBox, Filter, DateTimeInput, Button, Dialog,
		 UI_utilities, CommonUtility, formatter) {
	"use strict";
	var plant;
	var resource;
	var projectName;
	var workstation;
	var username;
	var RSRData;
	var ShiftId;
	var sType="";
	var qs_lastconf;
    	var qs_crid;
    	var qs_msgid;
    	var qs_interval;
    	var qs_orderid;
    	var qs_matnum;
    	var qs_matdesc;
    	var qs_teamid;
    	var qs_shiftid;
    	var qs_crdest;
    	var qs_actqty;
	var aSelectedRowPhasePath;
	var PhaseSelectedRowVal;
	var phase;
	var phasedesc;
	var uom;
	var OEEScrap;
	var operation;
	var scode;
	var scrap;
	var scrapQty;
	var conversion;
	var SelectedReasonCode;
	var sreason;
	var scrapbyconversion;
	var scrapbyconversion2;
	var PhaseLength;
	var IntervalLength;
	var date;
	var time;
	let dt = new Date();
	var ICT;
	var gb_changeflag = 0;
	var PopulateDTFlag=0;
	
	return Controller.extend("com.khc.rephub.controller.RepShiftReviewMain", {
		formatter:formatter,
		onInit : function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("RepShiftReviewMain").attachPatternMatched(
					this._oRoutePatternMatched, this);
			/*this._oRouter.getRoute("default").attachPatternMatched(
					this._oRoutePatternMatched, this);*/
			
		
			
		},


		/**
		 * Called when the Routing is matched, 'RepShiftReviewMain'
		 * 
		 */

		_oRoutePatternMatched : function(oEvent) {

			// To set the menu as selected, hide message ad remove busy
			UI_utilities.shiftReviewPageOpened(this,"RepShiftReviewMain");
			
			plant=sap.ui.getCore().getModel("session").getData().CA_Plant;
			//resource=sap.ui.getCore().getModel("session").getData().CA_Resource;
			projectName=sap.ui.getCore().getModel("session").getData().CA_ProjectName;
			workstation=sap.ui.getCore().getModel("session").getData().CA_CRDest;
			username=sap.ui.getCore().getModel("session").getData().CA_IllumLoginName;
			UI_utilities.DisableDatePickerInput(this.getView().byId("RSLostSTDTPck"));
			UI_utilities.DisableDatePickerInput(this.getView().byId("RSLostEndDTPck"));
			var oreasonRadioData = {
					ReasonRadioFlag : false,
					activeShiftFlag : false,
					openDownTimeFlag : false,
					failureReasonFlag : false,
					classifyFlag: false
				};
			var oreasonRadioJSONModel = new sap.ui.model.json.JSONModel(oreasonRadioData);
			this.getView().setModel(oreasonRadioJSONModel, "reasonRadio");
		
			this.getRSRData();
			this.onLoad();
			this.GetIntervalData();
			this.clearFields();
			this.clearFieldsScrap();
			this.getScrapReason();

			var oUIData = {
					showShiftNotes : "false",
					currentSelection: "Header"
				};
			var oRSRUIModel = new sap.ui.model.json.JSONModel(oUIData);
			this.getView().setModel(oRSRUIModel, "RSRUI");

		},
		
		
		onAfterRendering : function() {


		},

		menuSelected : function (oEvent) {
        	
			// Navigate the the selected menu page
			
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
			
     		   },
		
		
		onLoad : function() {

			this.GetShiftNoteDetails();
			//XACQ_GetLSReasonList Lost Time Table 2 data
			
			var oModelLSReasonDetails = new sap.ui.model.json.JSONModel();
			oModelLSReasonDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetLSReasonList&Param.1="+plant+"&Param.2="+resource+"&Param.3="+""+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelLSReasonDetails,"oLSReasonDetails");
			
			//this.PopulateDTDetails();
		},

			// Lost Time table 1 data model
		GetShiftNoteDetails : function()
		{
			var starttime = RSRData.qs_shiftstart;
			var endtime = RSRData.qs_endtime;

			var oModelShiftNoteDetails = new sap.ui.model.json.JSONModel();
			oModelShiftNoteDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetShiftNoteDetailsV2&Param.1="+plant+"&Param.2="+resource+"&Param.3="+starttime+"&Param.4="+endtime+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelShiftNoteDetails,"oShiftNoteDetails");
		},
		
		// Lost Time table 1 data 
		PopulateDTDetails : function() 
		{
			
			var aSelectedRowPath = this.getView().byId("RSLostTable1").getSelectedContextPaths();
			var oShiftNoteDetails = this.getView().getModel("oShiftNoteDetails");
			var getStatus='';
			if(aSelectedRowPath.length > 0) 
			{
				var sPath = aSelectedRowPath[0];
				var catCode = oShiftNoteDetails.getProperty(sPath+'/CATCODE');
				this.getView().byId("RSLostSTDTPck").setValue(oShiftNoteDetails.getProperty(sPath+'/DTSTART'));
				this.getView().byId("RSLostEndDTPck").setValue(oShiftNoteDetails.getProperty(sPath+'/DTEND'));
				var txtCodeDesc = oShiftNoteDetails.getProperty(sPath+'/CATTEXT');
				this.getView().byId("RSLostTA").setValue(oShiftNoteDetails.getProperty(sPath+'/SNTEXT'));
				getStatus = oShiftNoteDetails.getProperty(sPath+'/TYPE');
				
				
				var splitCatText = txtCodeDesc.split(":");
				var DTType = splitCatText[0];
				var DTReason = splitCatText[2];

				this.getView().byId("reason-"+getStatus).setSelected(true);
				this.filterReasonCodesForType(getStatus);

				var sReasonType =  oShiftNoteDetails.getProperty(sPath+'/TYPE');
				 
				 //To do, select the reason code for the failure
				var EQUITYPE =  oShiftNoteDetails.getProperty(sPath+'/EQUITYPE');
				var CATCODE =  oShiftNoteDetails.getProperty(sPath+'/CATCODE');

				this.setDTReasonRow(sReasonType,CATCODE,EQUITYPE);
				PopulateDTFlag=1;
			}
			
		},
		// data from RepShiftReview Page via model
		getRSRData : function()
		{

			if(sap.ui.getCore().getModel("RepShiftReviewData")!=null)
			{
				RSRData=sap.ui.getCore().getModel("RepShiftReviewData").oData;
				this.getView().byId("Resrip").setValue(RSRData.qs_resr);
				resource = RSRData.qs_resr;
				this.getView().byId("Startdtip").setValue(RSRData.qs_shiftstart);
				this.getView().byId("Durip").setValue(RSRData.qs_Dur);
				this.getView().byId("Shiftip").setValue(RSRData.qs_shift);
				this.getView().byId("Leadip").setValue(RSRData.qs_lead);
				this.getView().byId("Crewip").setValue(RSRData.qs_teamsize);
				this.getView().byId("TargetQtyEAip").setValue(RSRData.qs_Target);
			
				var oModelRSRTeamListDetails = new sap.ui.model.json.JSONModel();
				oModelRSRTeamListDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetTeamList&d="+new Date()+"&Content-Type=text/json", "", false);
				this.getView().setModel(oModelRSRTeamListDetails,"oRSRTeamListDetails");
			
				if(RSRData.qs_teamid!="")
				{
					this.getView().byId("TeamNameCmbx").setSelectedKey(RSRData.qs_teamid);
				}
			
				this.PopulateOEEDetails();
			}
			else
			{
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RepShiftReview");
			}
		},
		// populating main page oee data (2nd row)
		PopulateOEEDetails : function()
		{
			ShiftId = RSRData.qs_shiftid;
			
			var oModelPopulateOEEDetails = new sap.ui.model.json.JSONModel();
			oModelPopulateOEEDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetShiftOEEDetailsByShiftId&Param.1="+plant+"&Param.2="+"2"+"&Param.3="+resource+"&Param.4="+ShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelPopulateOEEDetails,"oPopulateOEEDetails");
			
			var avail = oModelPopulateOEEDetails.oData.Rowsets.Rowset[0].Row[0].Availability;
			var perf = oModelPopulateOEEDetails.oData.Rowsets.Rowset[0].Row[0].Performance;
			var qual = oModelPopulateOEEDetails.oData.Rowsets.Rowset[0].Row[0].Quality;
			var oee = oModelPopulateOEEDetails.oData.Rowsets.Rowset[0].Row[0].OEE;
			var ActQty = oModelPopulateOEEDetails.oData.Rowsets.Rowset[0].Row[0].ActualQty;
			var ScQty = oModelPopulateOEEDetails.oData.Rowsets.Rowset[0].Row[0].ScrapQty;
			
			this.getView().byId("Availip").setValue(avail);
			this.getView().byId("Perfip").setValue(perf);
			this.getView().byId("Qualip").setValue(qual);
			this.getView().byId("Oeeip").setValue(oee);
			this.getView().byId("ActualQtyip").setValue(ActQty);
			this.getView().byId("ScrapQtyip").setValue(ScQty);
			
			this.GetPrevNotes();
			
		},
		// update button to update header data
		UpdateHeader : function()
		{
			var Dur = this.getView().byId("Durip").getValue();
			var Teamname = this.getView().byId("TeamNameCmbx")._getSelectedItemText();
			var TeamId = this.getView().byId("TeamNameCmbx").getSelectedKey();
			var TeamSize = this.getView().byId("Crewip").getValue();
			var Lead = this.getView().byId("Leadip").getValue();
			var TargetQty = this.getView().byId("TargetQtyEAip").getValue();
			
			var oModelUpdateDetails = new sap.ui.model.json.JSONModel();
			oModelUpdateDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdShiftReviewHeader&Param.1="+plant+"&Param.2="+resource+"&Param.3="+ShiftId+"&Param.4="+Lead+"&Param.5="+TeamId+"&Param.6="+Teamname+"&Param.7="+TeamSize+"&Param.8="+TargetQty+"&Param.9="+Dur+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelUpdateDetails,"oUpdateDetails");

			//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//oRouter.navTo("RepShiftReview");
         			if(CommonUtility.getJsonModelRowCount(oModelUpdateDetails.getData()) > 0) {
            			var oUpdateDetails = oModelUpdateDetails.getData().Rowsets.Rowset[0].Row[0];
            			MessageBox.alert(oUpdateDetails.Message, {
                 				 title: "Alert",                                  
            			});
         			}
      
      		},
		// confirm button to confirm the shift review data
		confirmshift : function()
		{
			var that=this;
			var sAlertMsg = "Confirm Shift - Are you sure? This will lock the shift for updates. The action is irreversible.";
			
			MessageBox.confirm(
					sAlertMsg, {
                			onClose: function(oAction) {
                    				if (oAction === "OK") {
                    					that.GetConfirmAction();
                    				}
               			 }
            	});
		},
		GetConfirmAction : function()
		{
			
			var oModelConfirmDetails = new sap.ui.model.json.JSONModel();
			oModelConfirmDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdShifttoConfirmed&Param.1="+plant+"&Param.2="+resource+"&Param.3="+ShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelConfirmDetails,"oConfirmDetails");

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RepShiftReview"); 
		},	
		// create shift notes button to create shift notes
		createShiftNotes : function()
		{
			let dt = new Date();
			let todayDateTime = CommonUtility.getCurrentDateTime(dt);
			let date=CommonUtility.formatDate(dt);
			var currentDT = todayDateTime;
			
			var time = dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
			var ShiftName = this.getView().byId("Shiftip").getValue();
			
			var SNText = this.getView().byId("id_ta_sntext").getValue();
			if(SNText!="")
			{
				var oModelcreateShiftNotes = new sap.ui.model.json.JSONModel();
				oModelcreateShiftNotes.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_CreateShiftNotes&Param.1="+plant+"&Param.2="+resource+"&Param.3="+"ZG99"+"&Param.4="+date+"&Param.5="+time+"&Param.6="+""+"&Param.7="+""+"&Param.8="+""+"&Param.9="+SNText+"&Param.10="+""+"&Param.11="+""+"&Param.12="+"Shift Review"+"&Param.13="+username+"&d="+new Date()+"&Content-Type=text/json", "", false);
				this.getView().setModel(oModelcreateShiftNotes,"ocreateShiftNotes");
				
				var ShiftNoteNum = oModelcreateShiftNotes.getData().Rowsets.Rowset[0].Row[0].O_ShiftNote;
				
				if(ShiftNoteNum=="E")
				{
					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0086");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",  
					});
					/*
					var confErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0086");
					sap.ui.getCore().getModel("oMessage").setProperty("/message",confErrorMsg);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
					*/
				}
				else
				{
					/*
					var confSuccessMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0085");
					var O_SN = ShiftNoteNum;
					var confSuccessMsg2 = confSuccessMsg.concat(O_SN);
					sap.ui.getCore().getModel("oMessage").setProperty("/message",confSuccessMsg2);
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
					*/

					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0085");
					var O_SN = ShiftNoteNum;
					var sAlertMsg2 = sAlertMsg.concat(O_SN);
					MessageBox.alert(sAlertMsg2, {
						title: "Alert",  
					});
					
					var oModelcreateShiftNotes = new sap.ui.model.json.JSONModel();
					oModelcreateShiftNotes.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_InsShiftNote&Param.1="+plant+"&Param.2="+resource+"&Param.3="+ShiftName+"&Param.4="+currentDT+"&Param.5="+""+"&Param.6="+SNText+"&Param.7="+ShiftNoteNum+"&Param.8="+ShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
					this.getView().setModel(oModelcreateShiftNotes,"ocreateShiftNotes");
					this.GetPrevNotes();
				}
			}
			else
			{
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0029");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",  
				});
			}
		},
		// to get prev notes data
		GetPrevNotes : function()
		{
			var oModelGetPrevNotes = new sap.ui.model.json.JSONModel();
			oModelGetPrevNotes.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_ShiftNote&Param.1="+plant+"&Param.2="+resource+"&Param.3="+ShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelGetPrevNotes,"oGetPrevNotes");
			
		},

		selectedLSReasonData : function()
		{
			//alert("checking LS Reason Data");
		},
		// to filter the Lost down time table 2 depending on the selection of radio button/ first table row
		filterReasonCodes : function(oEvent){
			if(oEvent!=undefined && oEvent.getParameters().selected)
			{
		
					var sID = oEvent.getSource().getId();
					sType = sID.charAt(sID.length-1)
				
				if(sType === "X"){
					sType = "";
				}
				//if(PopulateDTFlag!=1)
				//{
					this.filterReasonCodesForType(sType);
				//}
				PopulateDTFlag=0;
			}
		},

		filterReasonCodesForType: function(sType)
		{
	
	
		// Get the table Binding to apply filters
		var oTable = this.getView().byId("RSLostTable2");
		var  oBinding =oTable.getBinding("items");
		// Array to combine filters
		var aFilters = [];
		//STATUS is the json property, EQ is filter operator, "statuscode" is the value to Filter
		if(sType) {
			aFilters.push(
				new Filter([new Filter("TCODE", "EQ", sType)])
			);
		}
		
		oBinding.filter(aFilters);
		},
		// Lost Time Insert button to insert downtime
		Ins_Downtime: function() {
		    // alert("Inserted");
		    var SelRow = this.getView().byId("RSLostTable2").getSelectedContextPaths()[0];
		    
		    if (SelRow) {
		    	
		    var currenttime = new Date();
		    var currentDT = CommonUtility.getCurrentDateTime(currenttime);
		    var oRow = this.getView().getModel("oLSReasonDetails").getProperty(SelRow);
			
		    var catcode = oRow.CatCode;
		    var cattext = oRow.CatDesc;
		    /** from UI**/
		    var DTstart = this.getView().byId("RSLostSTDTPck").getValue();
		    var sntext = this.getView().byId("RSLostTA").getValue();
		    var DTEnd = this.getView().byId("RSLostEndDTPck").getValue();
		    if (sntext.search("'") > 0) {
		        sntext = sntext.replace(/'/g, "");
		    }
		    	
		        var selectedTypeVal = oRow.TCODE;
		        var selectedAreaVal = oRow.ACODE;
		        var selectedSubAreaVal = oRow.SACODE; 
		        var selectedTypeTxt = oRow.TDESC;
		        var selectedAreaTxt = oRow.ADESC;
		        var selectedSubAreaTxt = oRow.SADESC;
		        var DispDesc = oRow.DispDesc;
		        var EquiType = oRow.EquipmentCode;
		        
		        var teamId = RSRData.qs_teamid;
		        var shiftStartTime = RSRData.qs_shiftstart;
		        var shiftEndTime = RSRData.qs_endtime;
		        var ShiftName = this.getView().byId("Shiftip").getValue();
		        
		        if (DTstart != "" && DTEnd != "") {
		            if (DTstart < DTEnd) {
		                if (cattext!="" && catcode!="" ) {
		                	
		                    if (DTstart >= shiftStartTime &&DTstart <=shiftEndTime &&
		                        DTEnd >= shiftStartTime && DTEnd <=shiftEndTime) {
		                    	
		                    	var that = this;
		                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + DTstart + "&Param.4=" + DTEnd +
		                            "&Param.5=" + catcode + "&Param.6=" + cattext + "&Param.7=" + selectedTypeVal + "&Param.8=" + selectedAreaVal +
		                            "&Param.9=" + selectedSubAreaVal + "&Param.10=" + sntext + "&Param.11=" + "BUS0010" +
		                            "&Param.12=" + "" + "&Param.13=" + "" + "&Param.14=" + ShiftName +
		                            "&Param.15=" + ShiftId + "&Param.16=" + selectedTypeTxt +
		                            "&Param.17=" + selectedAreaTxt + "&Param.18=" + selectedSubAreaTxt + "&Param.19=" + "" + "&Param.20=" +
		                            teamId + "&Param.21=" + "" + "&Param.22=" + "" + "&Param.23=" + DispDesc +
		                            "&Param.24=" + "" + "&Param.25=" + EquiType;
		                        var url = "/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_InsRetroDownTimeShiftReview&" +
		                            "Content-Type=text/json&" + params
		                        $.ajax({
		                            url: url,
		                            type: "POST",
		                            async: false,
		                            success: function(data, txt, jqXHR) {
		                                var getData = data.Rowsets.Rowset[0].Row[0];
		                                if (getData.Type == "S") {
		                                     MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0077") + getData.Message)
		                                /*	var sAlertMsg = (sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0077") + getData.Message);
		                					MessageBox.alert(sAlertMsg, {
		                						title: "Alert",  
		                					}); */
		                                    //this.getOpenDowntime();
		                                    that.GetShiftNoteDetails();
					that.ClearAll();
		                                } else if (getData.Type == "E") {
		                                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0079") );
		                                } else if (getData.Type == "C") {
		                                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0078"))
		                                }
		                            },
		                            error: function(jqXHR, textStatus, errorThrown) {
		                            	 MessageBox.error(jqXHR.responseText);
		                            }
		                        });
		                    } else {
		                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0062"));
		                    }
		                } else {
		                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
		                }
		            } else {
		                MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0054"));
		            }
		        } else {
		            MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0060"));
		        }
		    } else {
		        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
		    }
		},
		// Delete button to delete selected downtime
		Del_ShiftNoteDetails : function()
		{
				var aSelectedRowPath = this.getView().byId("RSLostTable1").getSelectedContextPaths();
				var oShiftNoteDetails = this.getView().getModel("oShiftNoteDetails");
				var getStatus='';
				if(aSelectedRowPath.length > 0) 
				{
					var sPath = aSelectedRowPath[0];
					var SelStart = oShiftNoteDetails.getProperty(sPath+'/DTSTART');
					
					var oModelDelShiftNoteDetails = new sap.ui.model.json.JSONModel();
					oModelDelShiftNoteDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_DelShiftNoteDetails&Param.1="+SelStart+"&Param.2="+plant+"&Param.3="+resource+"&d="+new Date()+"&Content-Type=text/json", "", false);
					this.getView().setModel(oModelDelShiftNoteDetails,"oDelShiftNoteDetails");
					
					this.GetShiftNoteDetails();
					MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0084"));
					this.ClearAll();
				}
			else
				{
				 MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
				}
		},
		// to clear the selected values of text area, start date time and end date time of lost time 
		ClearAll : function()
		{
			this.getView().byId("RSLostTA").setValue("");
			this.getView().byId("RSLostSTDTPck").setValue("");
			this.getView().byId("RSLostEndDTPck").setValue("");
		},
		// to recalculate the shift data
		Recalculate : function()
		{
			var resource = RSRData.qs_resr;
			var ShiftStart = RSRData.qs_shiftstart;
			var ShiftEnd = RSRData.qs_endtime;
			
			var oModelRecalDetails = new sap.ui.model.json.JSONModel();
			oModelRecalDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_TwoStageShiftOEECalculation&Param.1="+plant+"&Param.2="+resource+"&Param.3="+ShiftStart+"&Param.4="+ShiftEnd+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelRecalDetails,"oRecalDetails");
			this.PopulateOEEDetails();
		},
		// to filter and select the table row depending on table 1 row data or radio button
		setDTReasonRow : function(type,catCode, equitype)
		{
	 

		var oLSReasonListModel = this.getView().getModel("oLSReasonDetails");
	 
		var oReasonTable = this.getView().byId("RSLostTable2");
		 var oReasonData = oReasonTable.getItems();
		 var that = this;

		 oReasonData.forEach((item)=> { 
				 
				 var sItemPath = item.getBindingContextPath();
				 var sCatCode = oLSReasonListModel.getProperty(sItemPath+"/CatCode");
				 var sEqType = oLSReasonListModel.getProperty(sItemPath+"/EquipmentCode");
				 var bSelected = false;
				//var SADesc="";
				//var TDesc ="";
					
				 if(type === "F"){
					 
					 if(sCatCode === catCode && sEqType === equitype){
						 item.setSelected(true);
						 bSelected = true;
					 }
				 }
				 else{
					 
					 if(sCatCode===catCode){
						 item.setSelected(true);
						 bSelected = true;
					 }
				 }
				 
				 if(bSelected){
					
					//var SADesc = oLSReasonListModel.getProperty(sItemPath+'/SADESC');
					//var TDesc =  oLSReasonListModel.getProperty(sItemPath+'/TDESC');
					
					//that.getView().byId("category").setValue(TDesc);
					//that.getView().byId("reason").setValue(SADesc);
						
					 
				 }
				 
			 });

		},
		//Split button to split downtime in Lost Time 
		Split_Downtime : function()
		{
			var DT_SelRow = this.getView().byId("RSLostTable1").getSelectedContextPaths()[0];
			var SelRow = this.getView().byId("RSLostTable2").getSelectedContextPaths()[0];
			
		    
		    if(DT_SelRow!=null)
		    	{
		    	if(SelRow != null)
		    		{
		    		var ShiftId = RSRData.qs_shiftid;
					var currenttime = new Date();
					var currentDT = CommonUtility.getCurrentDateTime(currenttime);
					var resource = RSRData.qs_resr;
					var oRow = this.getView().getModel("oLSReasonDetails").getProperty(SelRow);
				    var cattext = oRow.CatDesc;
				    var gri_cattext = this.getView().getModel("oShiftNoteDetails").getProperty(DT_SelRow+'/CATTEXT'); 
				    var DTstart = this.getView().byId("Startdtip").getValue();
				    var gri_DTstart = this.getView().getModel("oShiftNoteDetails").getProperty(DT_SelRow+'/DTSTART');
				    var gri_DTend = this.getView().getModel("oShiftNoteDetails").getProperty(DT_SelRow+'/DTEND');
				    var sntext = this.getView().byId("RSLostTA").getValue();
				    var DTEnd = RSRData.qs_endtime;
				    var catcode = oRow.CatCode;
				    var gri_catcode = this.getView().getModel("oShiftNoteDetails").getProperty(DT_SelRow+'/CATCODE'); 
				    var selectedTypeVal = oRow.TCODE;
				    var selectedAreaVal = oRow.ACODE;
				    var selectedSubAreaVal = oRow.SACODE;
				    var selectedTypeTxt = oRow.TDESC;
				    var selectedAreaTxt = oRow.ADESC;
				    var selectedSubAreaTxt = oRow.SADESC;
				    var DispDesc = oRow.DispDesc;
				    var EquiType = oRow.EquipmentCode;
				    var gri_DTStatus = this.getView().getModel("oShiftNoteDetails").getProperty(DT_SelRow+'/OPEN');
				    var TeamId = RSRData.qs_teamid;
				    var shiftname = this.getView().byId("Shiftip").getValue();
		    		var that = this;
		            if (!this.oEscapePreventDialog) {
		                var dialogInput = new DateTimeInput("SplitTime", {
		                    placeholder: "Enter Split Time",
		                    valueFormat: "yyyy-MM-dd HH:mm:ss",
		                    displayFormat: "yyyy-MM-dd HH:mm:ss",
		                    type : "DateTime"
		                });
		                this.oEscapePreventDialog = new Dialog({
		                    title: "Enter Split time",
		                    content: dialogInput,
		                    buttons: [
		                        new Button({
		                            text: "OK",
		                            press: function(event)
		                            {
		                            	var New_DTEnd = sap.ui.getCore().byId("SplitTime").getValue();
					
		    			if((New_DTEnd<=DTEnd)&&(gri_DTstart<New_DTEnd))
		    				{
		    				var oNew_DTEnd = sap.ui.getCore().byId("SplitTime").getDateValue();
		    				// add 1 second
		    				oNew_DTEnd.setSeconds(oNew_DTEnd.getSeconds() + 1);
                            // setting value for new start downtime after spliting-----------------------
                            var new_startTime = CommonUtility.getCurrentDateTime(oNew_DTEnd);

                            if(gri_DTStatus!=1)
                            	{
                    				var oModelCalculateDuration = new sap.ui.model.json.JSONModel();
                    				oModelCalculateDuration.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdateSplitDowntime&Param.1="+new_startTime+"&Param.2="+gri_DTend+"&d="+new Date()+"&Content-Type=text/json", "", false);
                    				this.getView().setModel(oModelCalculateDuration,"oCalculateDuration");
                    				
                    				var Duration = this.getView().getModel("oCalculateDuration").getData().Rowsets.Rowset[0].Row[0].O_Duration;
                    				
                    				var oModelUpdateSplitDowntime = new sap.ui.model.json.JSONModel();
                    				oModelUpdateSplitDowntime.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdateSplitTime&Param.1="+new_startTime+"&Param.2="+Duration+"&Param.3="+gri_DTstart+"&Param.4="+ShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
                    				this.getView().setModel(oModelUpdateSplitDowntime,"oUpdateSplitDowntime");
                            	}
                            else
                            	{
                            		/*

				APLT_CMD_UpdateActiveSplitDowntime.getQueryObject().setParam(1, new_startTime);
				APLT_CMD_UpdateActiveSplitDowntime.getQueryObject().setParam(2, gri_DTstart);
				APLT_CMD_UpdateActiveSplitDowntime.getQueryObject().setParam(3, shiftId);	
				APLT_CMD_UpdateActiveSplitDowntime.executeCommand();

				APLT_CMD_UpdateActiveSplitDowntime is not found/used in existing irpt
				*/
                            	}
                					var oModelCalculateDuration = new sap.ui.model.json.JSONModel();
                					oModelCalculateDuration.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdateSplitDowntime&Param.1="+gri_DTstart+"&Param.2="+New_DTEnd+"&d="+new Date()+"&Content-Type=text/json", "", false);
                					this.getView().setModel(oModelCalculateDuration,"oCalculateDuration");
                            	
                					var New_Duration = this.getView().getModel("oCalculateDuration").getData().Rowsets.Rowset[0].Row[0].O_Duration;
                					
                					var params = "Param.1=" + catcode + "&Param.2=" + cattext + "&Param.3=" + New_DTEnd +
                               				"&Param.4=" + gri_DTstart + "&Param.5=" + plant + "&Param.6=" + resource + "&Param.7=" +
			                                    sntext + "&Param.8=" + selectedTypeVal + "&Param.9=" + selectedAreaVal + "&Param.10=" + selectedSubAreaVal +
                        			            "&Param.11=" + "" + "&Param.12=" + shiftname + "&Param.13=" + New_Duration + "&Param.14=" +
                                    			ShiftId + "&Param.15=" + selectedTypeTxt + "&Param.16=" + selectedAreaTxt + "&Param.17=" + selectedSubAreaTxt +
			                                    "&Param.18=" + "" + "&Param.19=" + TeamId + "&Param.20=" + "" + "&Param.21=" +
			                                    "" + "&Param.22=" + DispDesc + "&Param.23=" + "" + "&Param.24=" + EquiType;
                					
                					var oModelInsDownTime = new sap.ui.model.json.JSONModel();
                					oModelInsDownTime.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_InsDownTime&Param.1="+params+"&d="+new Date()+"&Content-Type=text/json", "", false);
                					this.getView().setModel(oModelInsDownTime,"oInsDownTime");
                            	
                					this.GetShiftNoteDetails();
                					this.PopulateDTDetails();
                					this.ClearAll();
                					MessageBox.success("Downtime split successfully");
                            
                            
		    				}
		    			else
		    				{
		    				MessageBox.error("Please enter end time less than current end time and greater than Start time");
		    				}
		    					that.oEscapePreventDialog.close();
		                            }.bind(that)
					//
		                        }),

				new Button({
                		            	text: "Cancel",
                        			press: function(event) {
		                        	that.oEscapePreventDialog.close();
		                        }.bind(that)
				})

		                ]
		                });
		                
		    		}this.oEscapePreventDialog.open();
		    	}
		    	else
		    		{
		    			MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
		    		}

		    	}
		    else
		    	{
		    		MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
		    	}
		},
		// Update button to update the selected downtime data 
		Upd_Downtime: function() {
            //alert("Upd_Downtime");

            var currenttime = new Date();
            var currentDT = CommonUtility.getCurrentDateTime(currenttime);

            //Get from UI
            var DTstart = this.getView().byId("RSLostSTDTPck").getValue();
            var sntext = this.getView().byId("RSLostTA").getValue();
            var DTEnd = this.getView().byId("RSLostEndDTPck").getValue();

            var SelRow = this.getView().byId("RSLostTable2").getSelectedContextPaths().length;
            if (SelRow != 0) {
                var SelRowReasonList = this.getView().byId("RSLostTable2").getSelectedContextPaths()[0];

                //Get from shiftNote table
                var ReasonListSltRow = this.getView().getModel("oLSReasonDetails").getProperty(SelRowReasonList)

                var selectedTypeVal = ReasonListSltRow.TCODE;
                var selectedAreaVal = ReasonListSltRow.ACODE;
                var selectedSubAreaVal = ReasonListSltRow.SACODE;
                var selectedTypeTxt = ReasonListSltRow.TDESC;
                var selectedAreaTxt = ReasonListSltRow.ADESC;
                var selectedSubAreaTxt = ReasonListSltRow.SADESC;
                var DispDesc = ReasonListSltRow.DispDesc;
                var EquiType = ReasonListSltRow.EquipmentCode;
                var catcode = ReasonListSltRow.CatCode;
                var cattext = ReasonListSltRow.CatDesc;

                var DT_SelRow = this.getView().byId("RSLostTable1").getSelectedContextPaths().length;
                if (DT_SelRow != 0) {
                    var ShiftNDSelRow = this.getView().byId("RSLostTable1").getSelectedContextPaths()[0];

                    //Get from Downtime Table
                    var DTSelectedRow = this.getView().getModel("oShiftNoteDetails").getProperty(ShiftNDSelRow);
                    var gri_cattext = DTSelectedRow.CATTEXT;
                    var gri_DTstart = DTSelectedRow.DTSTART;
                    var gri_DTStatus = DTSelectedRow.OPEN;
                    var gri_catcode = DTSelectedRow.CATCODE;
				if (gri_DTStatus!=1) {
                    //** single quotes replacement **
                    if (sntext.search("'") > 0) {
                        sntext = sntext.replace(/'/g, "");

                    }
                    //alert(sntext)


                        var uName = username;//this.getView().getModel("session").getData().IllumLoginName;
                        var params = "Param.1=" + catcode + "&Param.2=" + cattext + "&Param.3=" + DTEnd + "&Param.4=" + DTstart +
                        "&Param.5=" + sntext + "&Param.6=" + selectedTypeVal + "&Param.7=" + selectedAreaVal + "&Param.8=" + selectedSubAreaVal +
                        "&Param.9=" + "" + "&Param.10=" + plant + "&Param.11=" + resource +
                        "&Param.12=" + gri_DTstart + "&Param.13=" + gri_catcode + "&Param.14=" + uName +
                        "&Param.15=" + selectedTypeTxt + "&Param.16=" + selectedAreaTxt +
                        "&Param.17=" + selectedSubAreaTxt + "&Param.18=" + "" + "&Param.19=" + "" + "&Param.20=" +
                        "" + "&Param.21=" + DispDesc + "&Param.22=" + EquiType;

                        var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_UpdateDownTimeTwoStage&" +
                            "Content-Type=text/json&" + params
                                var that = this;
                                $.ajax({
                                    url: url,
                                    type: "POST",
                                    async: false,
                                    success: function(data, txt, jqXHR) {
                                        var getData = data.Rowsets.Rowset[0].Row[0];
                                        if (getData.Type == "S") {
                                            sap.m.MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0075") + getData.Message)

											that.GetShiftNoteDetails();
											that.PopulateDTDetails();
											that.ClearAll();
                                            //document.APLT_GRI_Downtime.refresh();

                                        } else if (getData.Type == "E") {
                                                sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0097") + getData.Message)
                                        } else if (getData.Type == "C") {
                                                sap.m.MessageBox.error(getData.Message)
                                        }
                                    },
                                    error: function(jqXHR, textStatus, errorThrown) {
                                        alert(jqXHR.responseText);
                                    }
                                });

                } else {
					 sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0092"));
				}
				} else {
                    sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
                }
            } else {
                sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
            }

        },
        
        /****************************************** Interval data***************************************/
        
        GetIntervalData : function()
        {
        	var resource = RSRData.qs_resr;
        	var starttime = RSRData.qs_shiftstart;
			var endtime = RSRData.qs_endtime;
			
			var oModelGetIntervalData = new sap.ui.model.json.JSONModel();
			oModelGetIntervalData.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetIntervalDetails_ShiftReview&Param.1="+plant+"&Param.2="+resource+"&Param.3="+starttime+"&Param.4="+endtime+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelGetIntervalData,"oGetIntervalData");
			
        },
        
        PopulateData : function()
        {
        	var selrow = this.getView().byId("RSIntDataTable").getSelectedContextPaths()[0];
        	var startdate = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/DateTime');
        	this.getView().byId("RSIntSTDTPck").setValue(startdate);
        	
        	var duration = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Duration');
        	this.getView().byId("RSIntDurip").setValue(duration);
        	
        	var actualqty = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Actual');
        	this.getView().byId("RSIntActQtyip").setValue(actualqty);
        	
        	var linespeed = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/LineSetSpeed');
        	this.getView().byId("RSIntLSPMip").setValue(linespeed);
        	
        	var status = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Status');
        	if(status==1)
        		{
        			this.getView().byId("RSIntCloseBtn").setEnabled(true);
        		}
        	else
        		{
        			this.getView().byId("RSIntCloseBtn").setEnabled(false);
        		}
        },
        
        UpdateInterval : function()
        {
        	var selrow = this.getView().byId("RSIntDataTable").getSelectedContextPaths()[0];
        	var Target = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Target');
        	var Actual = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Actual');
        	var ActualQty = this.getView().byId("RSIntActQtyip").getValue();
    		
        	var PerfPerc = (ActualQty/Target)*100;
        	
        	var resource = RSRData.qs_resr;
        	var starttime = RSRData.qs_shiftstart;
			var endtime = RSRData.qs_endtime;
			var ShiftId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/ShiftId');
			var DateTime = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/DateTime');
			var LineSpeed = this.getView().byId("RSIntLSPMip").getValue();
			var Duration = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Duration');
			var CRDest = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/CRDest');
			var CRId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/CRId');
			var Opr = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Opr');
			var OrderId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/OrderId');
			var Phase = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Phase');
			var UOM = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/UOM');
        	
        	if(selrow)
        		{
        			if(isNaN(ActualQty) || isNaN(LineSpeed))
        				{
        					sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0027"));
        				}
        			else if(parseInt(ActualQty)!=ActualQty)
            			{
            				sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116"));
            			}
        			else if(parseFloat(LineSpeed)>parseFloat(this.getView().getModel("oGetIntervalData").getProperty(selrow+'/ProdSpeed')))
        				{
        					sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0187"));
        				}
        			else if(PerfPerc > 150)
        				{
        					sap.m.MessageBox.error("Output is too large. Please check");
        				}
        			else
        				{
        					var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + starttime + "&Param.4=" + endtime +
        					"&Param.5=" + ShiftId + "&Param.6=" + DateTime + "&Param.7=" + ActualQty + "&Param.8=" + LineSpeed +
        					"&Param.9=" + Duration + "&Param.10=" + CRDest + "&Param.11=" + CRId +
        					"&Param.12=" + Actual + "&Param.13=" + username + "&Param.14=" + Opr +
        					"&Param.15=" + OrderId + "&Param.16=" + Phase +
        					"&Param.17=" + UOM;
        					
        					var oModelUpdIntervalShiftReview = new sap.ui.model.json.JSONModel();
        					oModelUpdIntervalShiftReview.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdIntervalShiftReview&"+params+"&d="+new Date()+"&Content-Type=text/json", "", false);
        					this.getView().setModel(oModelUpdIntervalShiftReview,"oUpdIntervalShiftReview");
        					

        					var oResultData = oModelUpdIntervalShiftReview.getData();
        					if(oResultData && oResultData.Rowsets && oResultData.Rowsets.FatalError)					//APLT_CMD_ScrapOEE.getLastError()!=""
        							{
        								sap.m.MessageBox.error(oResultData.Rowsets.FatalError);
        					
        						}
        					else
        						{
        							this.clearFields();
        							this.GetIntervalData();
        							this.PopulateOEEDetails();
							gb_changeflag = 1;
        						}
        				}
        		}  else {
                		MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"), {
                  			title: "Alert",                                  
                		});
            }
        	
        	
        },
        
        clearFields : function()
        {
        	this.getView().byId("RSIntSTDTPck").setValue("");
        	this.getView().byId("RSIntDurip").setValue("");
        	this.getView().byId("RSIntActQtyip").setValue("");
        	this.getView().byId("RSIntLSPMip").setValue("");
        },

        RedirecttoScrap : function()
        {
        	/*
        	var selrow = this.getView().byId("RSIntDataTable").getSelectedContextPaths()[0];
        	if(selrow!=0 && selrow!=null)
        		{
        			var lastconf = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/IntTime');
        			var crid = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/CRId');
        			var msgid = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/MsgId');
        			var interval = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Interval');
        			var MatNum = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Material_Num');
        			var MatDesc = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Material_Desc'); 
        			var TeamId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/TeamId');
        			var ShiftId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/ShiftId');
        			var OrderId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/OrderId');
        			var CRdest = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/CRDest');
        			var ActualQty = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Actual');
        			
    						qs_lastconf=lastconf;
    						qs_crid=crid;
    						qs_msgid=msgid;
    						qs_interval=interval;
    						qs_orderid=OrderId;
    						qs_matnum=MatNum;
    						qs_matdesc=MatDesc;
    						qs_teamid=TeamId;
    						qs_shiftid=ShiftId;
    						qs_crdest=CRdest;
    						qs_actqty=ActualQty;
    				
        		}
        	else
        		{
        			sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
        		} */
	//this.getView().getModel("RSRUI").setProperty("/currentSelection","Scrap");
	this.GetIntervalScrapData();
        },

        /********************************************RepShiftReviewScrap data****************************************/
       GetIntervalScrapData : function()
        {
	
        	var selrow = this.getView().byId("RSIntDataTable").getSelectedContextPaths()[0];
        	var resource = RSRData.qs_resr;
        	
        	if(selrow!=0 && selrow!=null)
    		{
    			var lastconf = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/IntTime');
    			var crid = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/CRId');
    			var msgid = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/MsgId');
    			var interval = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Interval');
    			var MatNum = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Material_Num');
    			var MatDesc = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Material_Desc'); 
    			var TeamId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/TeamId');
    			var ShiftId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/ShiftId');
    			var OrderId = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/OrderId');
    			var CRdest = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/CRDest');
    			var ActualQty = this.getView().getModel("oGetIntervalData").getProperty(selrow+'/Actual');
    			
    			
						
						qs_lastconf=this.getView().getModel("oGetIntervalData").getProperty(selrow+'/DateTime');
						qs_crid=crid;
						qs_msgid=msgid;
						qs_interval=interval;
						qs_orderid=OrderId;
						qs_matnum=MatNum;
						qs_matdesc=MatDesc;
						qs_teamid=TeamId;
						qs_shiftid=ShiftId;
						qs_crdest=CRdest;
						qs_actqty=ActualQty;
				
			this.getView().getModel("RSRUI").setProperty("/currentSelection","Scrap");
    		}
    	else
    		{
    			sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
    		}
        	
			var oModelGetIntervalScrapData = new sap.ui.model.json.JSONModel();
			oModelGetIntervalScrapData.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetPhaseScrap_ShiftReview&Param.1="+qs_msgid+"&Param.2="+qs_crid+"&Param.3="+resource+"&Param.4="+plant+"&Param.5="+qs_lastconf+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelGetIntervalScrapData,"oGetIntervalScrapData");

			if(this.getView().byId("Scraptable2").getSelectedContextPaths().length==0)
				{
					this.getView().byId("addbutton").setEnabled(false);
					this.getView().byId("updatebutton").setEnabled(false);
					this.getView().byId("deletebutton").setEnabled(false);
				}
        },

	ScrapPhaseListRowSelected:function(){

		var aSelectedRowPath = this.getView().byId("Scraptable2").getSelectedContextPaths();
		aSelectedRowPhasePath = aSelectedRowPath;
		var oScrapPhaseListRowModel = this.getView().getModel("oGetIntervalScrapData");

		if(aSelectedRowPath.length > 0)
		{
		let sPath = aSelectedRowPath[0];

		var SelectedRowVal = oScrapPhaseListRowModel.getProperty(sPath);
		PhaseSelectedRowVal = SelectedRowVal;
		var Phase = oScrapPhaseListRowModel.getProperty(sPath).Phase;
		phase = Phase;
		var PhaseText = oScrapPhaseListRowModel.getProperty(sPath).PhaseText;
		phasedesc = PhaseText;
		var UOM = oScrapPhaseListRowModel.getProperty(sPath).UOM;
		uom = UOM;
		var Quantity = oScrapPhaseListRowModel.getProperty(sPath).ScrapQty;
		scrapQty = Quantity;
		var Reason = oScrapPhaseListRowModel.getProperty(sPath).SReason;
		scode = oScrapPhaseListRowModel.getProperty(sPath).SCode;
		OEEScrap = PhaseSelectedRowVal.OEE_Scrap;
		operation = PhaseSelectedRowVal.Operation;
		conversion = PhaseSelectedRowVal.Conversion;

		this.getView().byId("phase").setValue(PhaseText);
		this.getView().byId("uom").setValue(UOM);
		this.getView().byId("quantity").setValue(Quantity);
		//this.getView().byId("scrapreason").setValue(Reason);
		this.getView().byId("scrapreason").setSelectedKey(scode);


		if((this.getView().byId("RSIntDataTable").getSelectedContextPaths().length) > 0)
		{
			this.getView().byId("addbutton").setEnabled(true);
			this.getView().byId("updatebutton").setEnabled(true);
			this.getView().byId("deletebutton").setEnabled(true);
			this.getView().byId("recalbutton").setEnabled(true);
		}
		
		if(conversion=='NA'){
		conversion='0';

		//this.getScrapReason();
		}
		if(scode==""){

			this.getView().byId("updatebutton").setEnabled(false);
			this.getView().byId("deletebutton").setEnabled(false);
		}
		else if(scode!=""){

			this.getView().byId("updatebutton").setEnabled(true);
			this.getView().byId("deletebutton").setEnabled(true);
		}
		
		
		}
			//this.getScrapReason();

		},

		getScrapReason:function(){

		var oModelReasonList = new sap.ui.model.json.JSONModel();
		oModelReasonList.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetScrapCode&d="+new Date()+"&Content-Type=text/json", "", false);

		let rowCount=CommonUtility.getJsonModelRowCount(oModelReasonList.getData())
		if(rowCount>0){
		
		sap.ui.getCore().setModel(oModelReasonList,"oReasonList");



		}
		},
	
		ScrapOEE : function(QueryType)
		{
			var selRow = this.getView().byId("Scraptable2").getSelectedContextPaths()[0];
			SelectedReasonCode = this.getView().byId("scrapreason").getSelectedKey();
			sreason = this.getView().byId("scrapreason")._getSelectedItemText();

			if(QueryType == "I")
			{
			
					var oModelChkPhaseScrapShiftReview = new sap.ui.model.json.JSONModel();
					oModelChkPhaseScrapShiftReview.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_ChkPhaseScrapShiftReview&Param.1="+qs_crid+"&Param.2="+plant+"&Param.3="+resource+"&Param.4="+phase+"&Param.5="+SelectedReasonCode+"&Param.6="+qs_shiftid+"&Param.7="+qs_lastconf+"&d="+new Date()+"&Content-Type=text/json", "", false);
					this.getView().setModel(oModelChkPhaseScrapShiftReview,"oChkPhaseScrapShiftReview");
			

				if(this.getView().byId("scrapreason").getSelectedKey() != "")
				{
					if(isNaN(this.getView().byId("quantity").getValue()) || this.getView().byId("quantity").getValue()=="")
					{
						sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0027"));
					}
					else if(parseInt(this.getView().byId("quantity").getValue()) != this.getView().byId("quantity").getValue())
					{
						sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116"));
					}
					else
					{
						if(this.getView().getModel("oChkPhaseScrapShiftReview").getData().Rowsets.Rowset[0].Row[0].COUNT==0)
						{
							this.RecalculateOEE(QueryType);
						}
						else
						{
							sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0028"));
						}
					}
				}
				else
				{
					sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0026"));
				}
			}
			else if(QueryType == "U")
			{
				if(selRow==0)
				{
			 		sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
		    	}
				else
				{
					if(isNaN(this.getView().byId("quantity").getValue()))
					{
						sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0027"));
					}
					else if(parseInt(this.getView().byId("quantity").getValue()) != this.getView().byId("quantity").getValue())
					{
						sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0116"));
					}
					else
					{	
						this.RecalculateOEE(QueryType);
					}
				}
			}
			else if(QueryType == "D")
			{
				if(selRow==0)
				{
			 		sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
		    		}
				else
				{
					this.RecalculateOEE(QueryType);
				}
			}
		},
		
		onAdd:function()
		{
			//this.getScrapReason();
			var QueryType = "I";
			//scrapQty = this.getView().byId("quantity").getValue();
			//scode = this.getView().byId("scrapreason").getSelectedKey();
			this.ScrapOEE(QueryType);
		},

		onUpdate:function()
		{
			//this.getScrapReason();
			var QueryType = "U";
			scrapQty = this.getView().byId("quantity").getValue();
			//scode = this.getView().byId("scrapreason").getSelectedKey();
			this.ScrapOEE(QueryType);
		},
		
		onDelete:function()
		{
			//this.getScrapReason();
			var QueryType = "D";
			scrapQty = this.getView().byId("quantity").getValue();
			scode = this.getView().byId("scrapreason").getSelectedKey();
			this.ScrapOEE(QueryType);
		},
		
		RecalculateOEE : function(TypeVal)
{
	//this.getScrapReason();
	var scrapbyconversion = parseFloat(this.getView().byId("quantity").getValue())*parseFloat(conversion);
	
	var scrapbyconversion2 = scrapbyconversion.toFixed(2);
	var scrap = this.getView().byId("quantity").getValue();
	//scode = this.getView().byId("scrapreason").getSelectedKey();
	
	SelectedReasonCode = this.getView().byId("scrapreason").getSelectedKey();
	sreason = this.getView().byId("scrapreason")._getSelectedItemText();

	
	var params = "Param.1=" + qs_crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + phase +
	"&Param.5=" + phasedesc + "&Param.6=" + qs_interval + "&Param.7=" + username + "&Param.8=" + scrapbyconversion2 +
	"&Param.9=" + uom + "&Param.10=" + SelectedReasonCode + "&Param.11=" + sreason +
	"&Param.12=" + operation + "&Param.13=" + qs_crdest + "&Param.14=" + qs_lastconf +
	"&Param.15=" + "" + "&Param.16=" + OEEScrap +
	"&Param.17=" + scrap + "&Param.18=" + qs_orderid + "&Param.19=" + qs_shiftid + "&Param.20=" +
	qs_matnum + "&Param.21=" + qs_matdesc + "&Param.22=" + qs_teamid + "&Param.23=" + RSRData.qs_shiftstart +
	"&Param.24=" + RSRData.qs_endtime + "&Param.25=" + qs_actqty + "&Param.26=" + scode+ "&Param.27=" + TypeVal + "&Param.28=" + scrapQty;
	
	var oModelScrapOEEShiftReview = new sap.ui.model.json.JSONModel();
	oModelScrapOEEShiftReview.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_ScrapOEEShiftReview&"+params+"&d="+new Date()+"&Content-Type=text/json", "", false);
	this.getView().setModel(oModelScrapOEEShiftReview,"oScrapOEEShiftReview");


	var oResultData = this.getView().getModel("oScrapOEEShiftReview").getData();
	if(oResultData && oResultData.Rowsets && oResultData.Rowsets.FatalError)					//APLT_CMD_ScrapOEE.getLastError()!=""
			{
				sap.m.MessageBox.error(oResultData.Rowsets.FatalError);
				//alert(APLT_CMD_ScrapOEE.getLastError());
			}
	else
	{	
		this.clearFieldsScrap();
		this.GetIntervalScrapData();
//		this.PopulateOEEDetails();
//		this.RefreshData();
	}
},

		clearFieldsScrap : function()
		{
			this.getView().byId("quantity").setValue("");
			this.getView().byId("uom").setValue("");
			this.getView().byId("uom").setValue("");
			phase="";
			this.getView().byId("phase").setValue("");
			this.getView().byId("scrapreason").setSelectedKey("");
			this.getView().byId("scrapreason").setSelectedItem("");
		},
		
		GetBack : function()
		{
			var that = this;
			if(gb_changeflag==0)
				{
					this.UnlockShift();
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("RepShiftReview"); 
				}
			else
				{
					var sAlertMsg = "You want to come out without confirming the Shift?";
					MessageBox.confirm(
							sAlertMsg, {
		                			onClose: function(oAction) {
		                    				if (oAction === "OK") {
		            					that.Back();
		                    				}
		               			 }
		            	});
				}
		},
		
		// on clicking close order
		onIntShift : function()	{
			
			var selrowLength = this.getView().byId("RSIntDataTable").getSelectedContextPaths().length;
			
			if(selrowLength>0)	{
				
				var selrowPath = this.getView().byId("RSIntDataTable").getSelectedContextPaths()[0];
	        	var selrow = this.getView().getModel("oGetIntervalData").getProperty(selrowPath);
	        	
	        	var crid = selrow.CRId;
	    		var status = '00002';
	    		var clearresv = 'X';
	    		var eventdate = '';
	    		var msgid = selrow.MsgId;
	    		var eventtime = '';
	    		var crew = '0';
	    		var phase = selrow.Phase;
	    		var interval = "0";
	    		var order = selrow.OrderId;
	    		var uom = selrow.UOM;
	    		var opr = selrow.Opr;
	    		var postingdate = '';
	    		
	    		var sParams = "Param.1=" + crid + "&Param.2=" + resource + "&Param.3=" + username +
   				"&Param.4=" + status + "&Param.5=" + clearresv + "&Param.6=" + eventdate + "&Param.7=" +
   				msgid + "&Param.8=" + eventtime + "&Param.9=" + crew + "&Param.10=" + phase +
		            "&Param.11=" + interval + "&Param.12=" + order + "&Param.13=" + plant + "&Param.14=" +
		            uom + "&Param.15=" + opr + "&Param.16=" + postingdate;
		
	    		var oCloseOrderModel = new sap.ui.model.json.JSONModel();
	    		oCloseOrderModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_CloseOrderFromShiftReview&"+sParams+"&d="+new Date()+"&Content-Type=text/json", "", false);
	        
	    		let rowCount=CommonUtility.getJsonModelRowCount(oCloseOrderModel.getData())
	    		if(rowCount>0)	{
	    			
	    			var sType = oCloseOrderModel.oData.Rowsets.Rowset[0].Row[0].Type;
	    			if(sType == 'SFC')	{
	    				
	    				MessageBox.success("Order closed");
	    				this.getView().byId("RSIntCloseBtn").setEnabled(false);
	    				this.GetIntervalData();
	    				
	    			}
	    			else	{
	    				
	    				MessageBox.alert("Error during order close");
	    				
	    			}
	    			
	    		}
	    		else	{
	    			
	    			MessageBox.alert("Error during order close");
	    		}
	    		
			}
			
			else	{
				
				MessageBox.alert("Select an interval");
			}
        	
        	
		},
		
		

		Back : function()
		{
			this.UnlockShift();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		            oRouter.navTo("RepShiftReview");
		},

		UnlockShift : function()
		{
			var oModelUnlockShift = new sap.ui.model.json.JSONModel();
			oModelUnlockShift.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdShiftLockStatus&Param.1="+"0"+"&Param.2="+""+"&Param.3="+ShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelUnlockShift,"oUnlockShift");
		},

		onClickedMainMenu : function()
		{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		            oRouter.navTo("repHome");
		},
		
		onClickedShiftReview : function()
		{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RepShiftReview");
		},

		GetHeader : function()
		{
			 this.getView().byId("id_ta_sntext").setValue("");
			 this.getView().getModel("RSRUI").setProperty("/currentSelection","Header");
		},
		
		GetLostTime : function()
		{
			this.getView().getModel("RSRUI").setProperty("/currentSelection","LostTime");
			this.getView().byId("RSLostTable1").removeSelections();
			this.filterReasonCodesForType("");
			this.getView().byId("RSLostSTDTPck").setValue("");
			this.getView().byId("RSLostEndDTPck").setValue("");
			this.getView().byId("RSLostTA").setValue("");
			this.getView().byId("reason-X").setSelected(true);
		},

		GetIntervals : function()
		{
			this.getView().getModel("RSRUI").setProperty("/currentSelection","Interval");
			this.getView().byId("RSIntCloseBtn").setEnabled(false);
		},

		onClickedMainMenu : function()
		{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RepHome");
		},

	});

});