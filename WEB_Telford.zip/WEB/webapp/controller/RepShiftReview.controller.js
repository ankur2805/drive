sap.ui.define([ "sap/ui/core/mvc/Controller", "sap/m/MessageBox",
		"com/khc/rephub/utils/UI_utilities", 
		"com/khc/common/Script/CommonUtility" ,"com/khc/rephub/model/formatter"], function(Controller, MessageBox,
		 UI_utilities, CommonUtility,formatter) {
	"use strict";
	var plant;
	var resource;
	var projectName;
	var workstation;
	var username;
	
	return Controller.extend("com.khc.rephub.controller.RepShiftReview", {
		formatter:formatter,
		onInit : function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("RepShiftReview").attachPatternMatched(
					this._oRoutePatternMatched, this);
			/*this._oRouter.getRoute("default").attachPatternMatched(
					this._oRoutePatternMatched, this);*/
			
		
			
		},


		/**
		 * Called when the Routing is matched, 'RepShiftReview'
		 * 
		 */

		_oRoutePatternMatched : function(oEvent) {

			// To set the menu as selected, hide message ad remove busy
			UI_utilities.shiftReviewPageOpened(this,"RepShiftReview");
			
			plant=sap.ui.getCore().getModel("session").getData().CA_Plant;
			resource=sap.ui.getCore().getModel("session").getData().CA_Resource;
			projectName=sap.ui.getCore().getModel("session").getData().CA_ProjectName;
			workstation=sap.ui.getCore().getModel("session").getData().CA_CRDest;
			username=sap.ui.getCore().getModel("session").getData().CA_IllumLoginName;

			this.enablebutton();
	    		this.GetResrByPlant();
			this.PopulateShiftData();
		},
		
		
		onAfterRendering : function() {

			// To set the menu as selected, hide message ad remove busy
			//UI_utilities.menuOpened(this,"RepShiftReview");

		},

		menuSelected : function (oEvent) {
        	
			// Navigate the the selected menu page
			
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
			
     		   },
		
		GetResrByPlant : function()
		{
			var oModelGetResrByPlant = new sap.ui.model.json.JSONModel();
			oModelGetResrByPlant.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetResrByPlant&Param.1="+plant+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelGetResrByPlant,"oGetResrByPlant");
			
			if(this.getView().byId("ResourceDescText").getSelectedKey()=="")
			{
				this.getView().byId("ResourceDescText").setSelectedKey(resource);
			}
		},
		
		PopulateShiftData : function()
		{
			var ResourceT = this.getView().byId("ResourceDescText").getSelectedKey();
			var oModelPopulateShiftData = new sap.ui.model.json.JSONModel();
			oModelPopulateShiftData.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetShiftOEEDetailsShiftReviewV2&Param.1="+plant+"&Param.2="+"2"+"&Param.3="+ResourceT+"&Param.4="+workstation+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelPopulateShiftData,"oPopulateShiftData");
			
					
				

		},

		onResourceChange : function()
		{
			
			resource = this.getView().byId("ResourceDescText").getSelectedKey();
			this.PopulateShiftData();
			
		},

		selectedShiftData : function()
		{
			this.disableEnable();
		},
		
		onClickedMainMenu : function()
		{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RepHome");
		},

		onClickedShiftReview : function()
		{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RepShiftReview");
		},
		
		onClickedHelp : function()
		{
			//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//oRouter.navTo("RepHome");
		},
		
		onBack : function()
		{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RepHome");
		},

		onUpdateShift : function()
		{
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			
			
			if(selrow != 0)
				{
				
				var sPath = rowVal[0];
				var selresr = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Resource;
				var selshiftstart = this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftStartTime;
				var selshift = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Shift;
				var selavail = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Availability;
				var selperf = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Performance;
				var selqual = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Quality;
				var selOEE = this.getView().getModel("oPopulateShiftData").getProperty(sPath).OEE;
				var selActQty =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ActualQty;
				var selTarget =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TargetQty;
				var selScrap =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ScrapQty;
				var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;
				var selEndTime =this.getView().getModel("oPopulateShiftData").getProperty(sPath).EndTime;
				var selTeamName =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TeamName;
				var selTeamSize =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TeamSize;
				var selTeamId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TeamId;
				var selLead =this.getView().getModel("oPopulateShiftData").getProperty(sPath).Lead;
				var selLockStatus = this.getView().getModel("oPopulateShiftData").getProperty(sPath).LockStatus;
				var selLockUser = this.getView().getModel("oPopulateShiftData").getProperty(sPath).LockUser;

				var DurCalc = (Date.parse(selEndTime)-Date.parse(selshiftstart))/1000;
				var Dur_Min = Math.round(DurCalc/60);
				
					if(selLockStatus == "N" || selLockStatus == "---")
						{
							var oModelUpdShiftLockStatus = new sap.ui.model.json.JSONModel();
							oModelUpdShiftLockStatus.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdShiftLockStatus&Param.1="+"1"+"&Param.2="+username+"&Param.3="+selShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
							this.getView().setModel(oModelUpdShiftLockStatus,"oUpdShiftLockStatus");

							this.redirectToRepShiftReviewMain();
							var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
							oRouter.navTo("RepShiftReviewMain"); // to be routed to RepShiftReviewMain.irpt
						}
					else if(selLockUser == username && selLockStatus == "Y")
						{
							this.redirectToRepShiftReviewMain();
							var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
							oRouter.navTo("RepShiftReviewMain"); // to be routed to RepShiftReviewMain.irpt
						}
					else 
						{
							var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0210");
							var sAlertMsg2 = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0211");
							var sAlertMsg3 = sAlertMsg.concat(selLockUser);
							var sAlertMsg4 = sAlertMsg3.concat(sAlertMsg2);
							var that = this;
						  /*MessageBox.alert(sAlertMsg4, {
								title: "Alert",                                  
							});
							
							if(sAlertMsg4)
								{
									var oModelUpdShiftLockStatus = new sap.ui.model.json.JSONModel();
									oModelUpdShiftLockStatus.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdShiftLockStatus&Param.1="+"1"+"&Param.2="+username+"&Param.3="+selShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
									this.getView().setModel(oModelUpdShiftLockStatus,"oUpdShiftLockStatus");
									
									var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
									oRouter.navTo("RepShiftReviewMain"); // to be routed to RepShiftReviewMain.irpt
								}
							else
								{
								
								}*/
							
							MessageBox.confirm(
									sAlertMsg4, {
	                            			onClose: function(oAction) {
	                                				if (oAction === "OK") {
	                                					that.GetUpdateAction();
	                                				}
	                           			 }
	                        	});
						}
				}
			else
				{
					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",  
					});
				}
		},
		
		GetUpdateAction : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			var sPath = rowVal[0];
			var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;	
			
			var oModelUpdShiftLockStatus = new sap.ui.model.json.JSONModel();
			oModelUpdShiftLockStatus.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdShiftLockStatus&Param.1="+"1"+"&Param.2="+username+"&Param.3="+selShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelUpdShiftLockStatus,"oUpdShiftLockStatus");
			
			this.redirectToRepShiftReviewMain();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RepShiftReviewMain"); // to be routed to RepShiftReviewMain.irpt
		},

		confirmshift : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			
			if(selrow != 0)
			{
				var sPath = rowVal[0];
				var selstatus = this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftStatus;
				var selresr = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Resource;
				var selEndTime =this.getView().getModel("oPopulateShiftData").getProperty(sPath).EndTime;
				var selshiftstart = this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftStartTime;
				var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;
				var that = this;
				
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0188");
				/*MessageBox.alert(sAlertMsg, {
					title: "Alert",  
				});
				
				if(sAlertMsg)
					{
					
					var oModelConfirmShift = new sap.ui.model.json.JSONModel();
					oModelConfirmShift.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_ShiftReviewConfirm&Param.1="+plant+"&Param.2="+selresr+"&Param.3="+selEndTime+"&Param.4="+selshiftstart+"&Param.5="+selShiftId+"&Param.6="+username+"&d="+new Date()+"&Content-Type=text/json", "", false);
					this.getView().setModel(oModelConfirmShift,"oConfirmShift");
					
					this.PopulateShiftData();
					
					}
				else
					{
					
					}*/
				MessageBox.confirm(
						sAlertMsg, {
                    			onClose: function(oAction) {
                        				if (oAction === "OK") {
                        					that.GetConfirmAction();
                        				}
                   			 }
                	});
			}
			else
				{
					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",  
					});
				}
		},
		
		GetConfirmAction : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			
			var sPath = rowVal[0];
			var selresr = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Resource;
			var selEndTime =this.getView().getModel("oPopulateShiftData").getProperty(sPath).EndTime;
			var selshiftstart = this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftStartTime;
			var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;
			
			var oModelConfirmShift = new sap.ui.model.json.JSONModel();
			oModelConfirmShift.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_ShiftReviewConfirm&Param.1="+plant+"&Param.2="+selresr+"&Param.3="+selEndTime+"&Param.4="+selshiftstart+"&Param.5="+selShiftId+"&Param.6="+username+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelConfirmShift,"oConfirmShift");
			
			this.PopulateShiftData();
		},
		
		onValidateConfirmShift : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			
			if(selrow != 0)
			{
				var sPath = rowVal[0];
				var selLockStatus = this.getView().getModel("oPopulateShiftData").getProperty(sPath).LockStatus;
				var selLockUser = this.getView().getModel("oPopulateShiftData").getProperty(sPath).LockUser;
				var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;
				
				if(selLockUser!=username && selLockStatus=="Y")
				{
					var answerunlock = "Shift Locked By User : "+selLockUser+". Press OK to unlock and continue.";
					var that = this;
					MessageBox.confirm(
							answerunlock, {
                        			onClose: function(oAction) {
                            				if (oAction === "OK") {
                            					that.GetActionValidConf();
                            				}
                       			 }
                    	});
					
					
					
					
					//MessageBox.alert(answerunlock, {
					//	title: "Alert",  
					//});
					
					/*if(answerunlock)
						{
						
						var oModelUpdShiftLockStatus = new sap.ui.model.json.JSONModel();
						oModelUpdShiftLockStatus.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdShiftLockStatus&Param.1="+"1"+"&Param.2="+username+"&Param.3="+selShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
						this.getView().setModel(oModelUpdShiftLockStatus,"oUpdShiftLockStatus");
						
						this.confirmshift();
						}
					else
						{
						
						}*/
				}
				else
					{
					this.confirmshift();
					}
			}
			else
				{
					var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096");
					MessageBox.alert(sAlertMsg, {
						title: "Alert",  
					});
				}
		},
		
		GetActionValidConf : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			var sPath = rowVal[0];
			var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;	
			
			var oModelUpdShiftLockStatus = new sap.ui.model.json.JSONModel();
			oModelUpdShiftLockStatus.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_UpdShiftLockStatus&Param.1="+"1"+"&Param.2="+username+"&Param.3="+selShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelUpdShiftLockStatus,"oUpdShiftLockStatus");
			
			this.confirmshift();
		},
		
		onReopenShift : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			
			if(selrow != 0)
			{
				var sPath = rowVal[0];
				var selresr = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Resource;
				var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;
				var that = this;

				var answerfco = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0215");
				MessageBox.confirm(
						answerfco, {
                    			onClose: function(oAction) {
                        				if (oAction === "OK") {
                        					that.GetActionReopen();
                        				}
                        				else
                    					{
                    					
                    						var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0216");
                    						MessageBox.alert(sAlertMsg, {
                    							title: "Alert",  
                    						});
                    					}
                   			 }
                	});
				//MessageBox.alert(answerfco, {
				//	title: "Alert",  
				//});
				
				
				
				
			}
			else
			{
				var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096");
				MessageBox.alert(sAlertMsg, {
					title: "Alert",  
				});
			}
		},

		GetActionReopen : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			var sPath = rowVal[0];
			var selresr = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Resource;
			var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;		

			var oModelShiftReOpen = new sap.ui.model.json.JSONModel();
			oModelShiftReOpen.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQL_ShiftReOpen&Param.1="+plant+"&Param.2="+selresr+"&Param.3="+selShiftId+"&d="+new Date()+"&Content-Type=text/json", "", false);
			this.getView().setModel(oModelShiftReOpen,"oShiftReOpen");
					
			this.PopulateShiftData();
					
		},
		
		disableEnable : function()
		{
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			
			if(selrow != 0)
			{
				var sPath = rowVal[0];
				var selstatus = this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftStatus;
				
				if(selstatus=='3')
					{
						this.getView().byId("UpdateBtnSR").setEnabled(false);
						this.getView().byId("ConfirmBtnSR").setEnabled(false);
						this.getView().byId("ReopenBtnSR").setEnabled(true);
						
					}
				else if(selstatus=='2')
					{
						this.getView().byId("ReopenBtnSR").setEnabled(false);
						this.getView().byId("UpdateBtnSR").setEnabled(true);
						this.getView().byId("ConfirmBtnSR").setEnabled(true);
					}
				
			}
			
		},

		enablebutton:function()
		{
						this.getView().byId("UpdateBtnSR").setEnabled(true);
						this.getView().byId("ConfirmBtnSR").setEnabled(true);
						this.getView().byId("ReopenBtnSR").setEnabled(true);
						this.getView().byId("BackBtnSR").setEnabled(true);
		},

		redirectToRepShiftReviewMain:function(){
			
			var rowVal = this.getView().byId("ShiftDatatbl").getSelectedContextPaths();
			var selrow = this.getView().byId("ShiftDatatbl").getSelectedContextPaths().length;
			
			
			if(selrow != 0)
			{
				
				var sPath = rowVal[0];
				var selresr = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Resource;
				var selshiftstart = this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftStartTime;
				var selshift = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Shift;
				var selavail = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Availability;
				var selperf = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Performance;
				var selqual = this.getView().getModel("oPopulateShiftData").getProperty(sPath).Quality;
				var selOEE = this.getView().getModel("oPopulateShiftData").getProperty(sPath).OEE;
				var selActQty =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ActualQty;
				var selTarget =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TargetQty;
				var selScrap =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ScrapQty;
				var selShiftId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).ShiftId;
				var selEndTime =this.getView().getModel("oPopulateShiftData").getProperty(sPath).EndTime;
				var selTeamName =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TeamName;
				var selTeamSize =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TeamSize;
				var selTeamId =this.getView().getModel("oPopulateShiftData").getProperty(sPath).TeamId;
				var selLead =this.getView().getModel("oPopulateShiftData").getProperty(sPath).Lead;
				var selLockStatus = this.getView().getModel("oPopulateShiftData").getProperty(sPath).LockStatus;
				var selLockUser = this.getView().getModel("oPopulateShiftData").getProperty(sPath).LockUser;

				var DurCalc = (Date.parse(selEndTime)-Date.parse(selshiftstart))/1000;
				var Dur_Min = Math.round(DurCalc/60);

				var osIDModel = new sap.ui.model.json.JSONModel();
				let sID={

					qs_resr:selresr,
					qs_shiftstart:selshiftstart,
					qs_shift:selshift,
					qs_avail:selavail,
					qs_perf:selperf,
					qs_qual:selqual,
					qs_OEE:selOEE,
					qs_ActQty:selActQty,
					qs_Target:selTarget,
					qs_Scrap:selScrap,
					qs_shiftid:selShiftId,
					qs_endtime:selEndTime,
					qs_teamname:selTeamName,
					qs_teamsize:selTeamSize,
					qs_teamid:selTeamId,
					qs_lead:selLead,
					qs_Dur:Dur_Min
		
				}
		
				osIDModel.setData(sID)
				sap.ui.getCore().setModel(osIDModel,"RepShiftReviewData")

			
			}
		
		},
		
	});

});