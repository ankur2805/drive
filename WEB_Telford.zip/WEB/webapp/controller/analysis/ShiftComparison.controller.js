sap.ui
    .define(
        [ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox", "com/khc/rephub/utils/UI_utilities",
            "com/khc/common/Script/CommonUtility", "com/khc/rephub/model/models" ],
        function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models) {
          "use strict";
          var plant;
          var resource;
          var projectName;
          var userName;
          var crDest;
          var frequencyRadioGroupMap;

          return Controller
              .extend(
                  "com.khc.rephub.controller.analysis.ShiftComparison",
                  {
                    onInit : function() {
                      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                      this._oRouter.getRoute("ShiftComparison").attachPatternMatched(this._oRoutePatternMatched, this);

                    },

                    _oRoutePatternMatched : function(oEvent) {

                      // Hide the messages and set busy to false
                      UI_utilities.analysisPageOpened(this, "ShiftComparison");
                      UI_utilities.DisableDatePickerInput(this.getView().byId("FromTimeX"));
                      UI_utilities.DisableDatePickerInput(this.getView().byId("ToTimeX"));

	          UI_utilities.DisableDatePickerInput(this.getView().byId("FromTimeY"));
                      UI_utilities.DisableDatePickerInput(this.getView().byId("ToTimeY"));

                      plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                      resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                      projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                      userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                      crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

                      var oModelGetResourceList = CommonUtility.getResourceListByPlant(projectName, plant);
                      this.getView().setModel(oModelGetResourceList, "oResourceList");

                      var oDisplayData = {
                        selectedOption : "oAnalysisOEEAvail"
                      };
                      var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
                      this.getView().setModel(oDisplayOptionModel, "displayOption");

                      // ResourceX
                      this.getView().byId("id_dropdown_resourceX").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_resourceX").setSelectedKey("All");

                      // ResourceY
                      this.getView().byId("id_dropdown_resourceY").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_resourceY").setSelectedKey("All");

                      var TodayDate = CommonUtility.getCurrentDateTime(new Date());
                      var Dateprt = TodayDate.split(" ");
                      var fromTimeValue = Dateprt[0] + " " + "00:00:00";
                      var toTimeValue = Dateprt[0] + " " + "23:59:59"
                      this.getView().byId("FromTimeX").setValue(fromTimeValue);
                      this.getView().byId("ToTimeX").setValue(toTimeValue);

                      var TodayDate = CommonUtility.getCurrentDateTime(new Date());
                      var Dateprt = TodayDate.split(" ");
                      var fromTimeValue = Dateprt[0] + " " + "00:00:00";
                      var toTimeValue = Dateprt[0] + " " + "23:59:59"
                      this.getView().byId("FromTimeY").setValue(fromTimeValue);
                      this.getView().byId("ToTimeY").setValue(toTimeValue);

                      // ShiftListX
                      var oModelGetShiftList = CommonUtility.getShiftListByResource(projectName, plant, resource);
                      this.getView().setModel(oModelGetShiftList, "oShiftList");
                      this.getView().byId("id_dropdown_shiftX").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      // this.getView().byId("id_dropdown_shiftX").setSelectedKey("All");
                      this.getView().byId("id_dropdown_shiftX").setSelectedItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }))

                      // ShiftListY
                      var oModelGetShiftList = CommonUtility.getShiftListByResource(projectName, plant, resource);
                      this.getView().setModel(oModelGetShiftList, "oShiftList");
                      this.getView().byId("id_dropdown_shiftY").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_shiftY").setSelectedKey("All");

                      // Clear Chart
                      var oEmptyModel = new sap.ui.model.json.JSONModel();
                      this.getView().setModel(oEmptyModel, "oAnalysisOEEAvailX");
                      this.getView().setModel(oEmptyModel, "oAnalysisOEEAvailY");

                    },
                    // Navigate the the selected menu page
                    menuSelected : function(oEvent) {
                      var sKey = oEvent.getParameters().key;
                      UI_utilities.openMenu(this._oRouter, this, sKey);
                    },

                    GetChartModif : function() {
                      if (fromTimeValueX != "" && toTimeValueX != "") {

                        var selectedFrequencyRadioGroup = this.getView().byId("FrequencyRadioGroup").getSelectedIndex();

                        var fromTimeValueX = this.getView().byId("FromTimeX").getValue();
                        var toTimeValueX = this.getView().byId("ToTimeX").getValue();

                        var fromTimeValueY = this.getView().byId("FromTimeY").getValue();
                        var toTimeValueY = this.getView().byId("ToTimeY").getValue();

                        var resourcetxtX = this.getView().byId("id_dropdown_resourceX").getValue();
                        var resourceValueX = "";
                        if (resourcetxtX != "All") {
                          resourceValueX = this.getView().byId("id_dropdown_resourceX").getSelectedKey();
                        }

                        var resourcetxtY = this.getView().byId("id_dropdown_resourceY").getValue();
                        var resourceValueY = "";
                        if (resourcetxtY != "All") {
                          resourceValueY = this.getView().byId("id_dropdown_resourceY").getSelectedKey();
                        }

                        var Shift1 = this.getView().byId("id_dropdown_shiftX").getValue();
                        var Shift1 = "";
                        if (Shift1 != "All") {
                          Shift1 = this.getView().byId("id_dropdown_shiftX").getSelectedKey();
                        } else
                          (Shift1 == "All")
                        {
                          Shift1 = "";
                        }

                        var Shift2 = this.getView().byId("id_dropdown_shiftY").getValue();
                        var Shift2 = "";
                        if (Shift2 != "All") {
                          Shift2 = this.getView().byId("id_dropdown_shiftY").getSelectedKey();
                        } else
                          (Shift2 == "All")
                        {
                          Shift2 = "";
                        }

                        var sParamsX = "&Param.1=" + plant + "&Param.2=" + resourceValueX + "&Param.3=" + fromTimeValueX
                            + "&Param.4=" + toTimeValueX + "&Param.5=" + Shift1;

                        var sParamsY = "&Param.1=" + plant + "&Param.2=" + resourceValueY + "&Param.3=" + fromTimeValueY
                            + "&Param.4=" + toTimeValueY + "&Param.5=" + Shift2;

                        if (selectedFrequencyRadioGroup == "1") {

                          var oModelAnalysisOEEAvailXData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEEAvail");
                          oModelAnalysisOEEAvailXData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEEAvail&" + sParamsX + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOEEAvailXData, "oAnalysisOEEAvailX");

                          var oModelAnalysisOEEAvailYData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEEAvail");
                          oModelAnalysisOEEAvailYData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEEAvail&" + sParamsY + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOEEAvailYData, "oAnalysisOEEAvailY");

                          this.getView().getModel("displayOption").setProperty("/selectedOption", "oAnalysisOEEAvail");
                        } else if (selectedFrequencyRadioGroup == "0") {

                          var oModelAnalysisOeeXData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEE");
                          oModelAnalysisOeeXData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEE&" + sParamsX + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOeeXData, "oAnalysisOeeX");

                          var oModelAnalysisOeeYData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEE");
                          oModelAnalysisOeeYData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEE&" + sParamsY + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOeeYData, "oAnalysisOeeY");

                          this.getView().getModel("displayOption").setProperty("/selectedOption", "oAnalysisOee");

                        } else if (selectedFrequencyRadioGroup == "2") {

                          var oModelAnalysisOEEPerfXData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEEPerf");
                          oModelAnalysisOEEPerfXData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEEPerf&" + sParamsX + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOEEPerfXData, "oAnalysisOEEPerfX");

                          var oModelAnalysisOEEPerfYData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEEPerf");
                          oModelAnalysisOEEPerfYData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEEPerf&" + sParamsY + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOEEPerfYData, "oAnalysisOEEPerfY");

                          this.getView().getModel("displayOption").setProperty("/selectedOption", "oAnalysisOEEPerf");
                        }

                        else if (selectedFrequencyRadioGroup == "3") {

                          var oModelAnalysisOEEQualXData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEEQual");
                          oModelAnalysisOEEQualXData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEEQual&" + sParamsX + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOEEQualXData, "oAnalysisOEEQualX");

                          var oModelAnalysisOEEQualYData = models
                              .createNewJSONModel("com.khc.rephub.controller.analysis.ShiftComparison-->GetChartModif-->SQLQ_ProdAnalysisOEEQual");
                          oModelAnalysisOEEQualYData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_ProdAnalysisOEEQual&" + sParamsY + "&d=" + new Date()
                              + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelAnalysisOEEQualYData, "oAnalysisOEEYQualY");

                          this.getView().getModel("displayOption").setProperty("/selectedOption", "oAnalysisOEEQual");

                        } else {

                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0057"), {
                            title : "Alert",
                          });
                        }
                      } else {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0056"));
                      }

                    },
                    onHelp : function() {

                      UI_utilities.OpenHelpFileSingle("Analysis");
                    },

                  });
        });
