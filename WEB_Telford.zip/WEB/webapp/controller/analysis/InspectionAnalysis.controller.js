sap.ui
    .define(
        [ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox",
            "com/khc/rephub/utils/UI_utilities", "com/khc/common/Script/CommonUtility",
            "com/khc/rephub/model/models" ],
        function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models) {
          "use strict";
          var plant = '';
          var resource = '';
          var projectName;
          var userName;
          var crDest;
          var oController;

          return Controller
              .extend(
                  "com.khc.rephub.controller.analysis.InspectionAnalysis",
                  {
                    onInit : function() {
                      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                      this._oRouter.getRoute("InspectionAnalysis").attachPatternMatched(
                          this._oRoutePatternMatched, this);
                      oController = this;

                    },

                    _oRoutePatternMatched : function(oEvent) {

                      UI_utilities.analysisPageOpened(this, "InspectionAnalysis");
   
                      UI_utilities.DisableDatePickerInput(this.getView().byId("FromTime"));
                      UI_utilities.DisableDatePickerInput(this.getView().byId("ToTime"));

                      plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                      resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                      projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                      userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                      crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

                      this.clearAll();
                      this.onLoad();

                    },

                    // Navigate the the selected menu page
                    menuSelected : function(oEvent) {
                      var sKey = oEvent.getParameters().key;
                      UI_utilities.openMenu(this._oRouter, this, sKey);
                    },

                    onAfterRendering : function() {
                    },

                    clearAll : function() {

                      this.getView().byId("id_dropdown_material").setSelectedKey("All");
                      this.getView().byId("id_dropdown_order").setSelectedKey("All");
                      this.getView().byId("id_dropdown_operation").setSelectedKey("All");
                      this.getView().byId("id_dropdown_mic").setSelectedKey("All");
                    //  this.setAllForCombox();

                      this.setFromTo();
                    },

/** *********************************************************************************************************************************************************************************** */
// Call this function on load of page
/** ************************************************************************************************************************************************************************************** */
                    onLoad : function() {
                      var oModelMaterialDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.InspectionAnalysis-->onLoad-->SQLQ_InspAnalysisGetMaterial");
                      oModelMaterialDetails.loadData("/XMII/Illuminator?QueryTemplate="
                          + projectName + "/QueryTemplate/SQLQ_InspAnalysisGetMaterial&Param.1="
                          + plant + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelMaterialDetails, "oMaterialDetails");
                      this.getView().byId("id_dropdown_material").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_material").setSelectedKey("All");
                      this.setAllForCombox();

                      this.setFromTo();

                    },
/** *********************************************************************************************************************************************************************************** */
// Get order by material
/** ************************************************************************************************************************************************************************************** */
                    GetOrderByMat : function() {
                      var sMaterial = this.getView().byId("id_dropdown_material").getSelectedKey();

                      var oModelOrderDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.InspectionAnalysis-->GetOrderByMat-->SQLQ_InspAnalysisGetOrderByMat");

                      oModelOrderDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/SQLQ_InspAnalysisGetOrderByMat&Param.1=" + plant
                          + "&Param.2=" + sMaterial + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelOrderDetails, "oOrderDetails");
                      this.getView().byId("id_dropdown_order").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_order").setSelectedKey("All");
                    },
/** *********************************************************************************************************************************************************************************** */
// Get Operation by order
/** ************************************************************************************************************************************************************************************** */
                    GetOperation : function() {

                      var sOrderData = this.getView().byId("id_dropdown_order").getValue();
                      if (sOrderData == null || sOrderData == "All" || sOrderData == undefined) {
                        sOrderData = "";
                      }

                      var oModelOperationDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.InspectionAnalysis-->GetOperation-->SQLQ_InspAnalysisGetOperByOrder");
                      oModelOperationDetails
                          .loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                              + "/QueryTemplate/SQLQ_InspAnalysisGetOperByOrder&Param.1=" + plant
                              + "&Param.2=" + sOrderData + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelOperationDetails, "oOperationDetails");
                      this.getView().byId("id_dropdown_operation").insertItem(
                          new sap.ui.core.Item({
                            key : "All",
                            text : "All"
                          }), 0);
                      this.getView().byId("id_dropdown_operation").setSelectedKey("All");
                    },
/** *********************************************************************************************************************************************************************************** */
// Get MIC
/** ************************************************************************************************************************************************************************************** */
                    getMIC : function() {
                      var sOrderData = this.getView().byId("id_dropdown_order").getValue();
                      if (sOrderData == null || sOrderData == "All" || sOrderData == undefined) {
                        sOrderData = "";
                      }

                      var sOperationData = this.getView().byId("id_dropdown_operation")
                          .getSelectedKey();
                      if (sOperationData == null || sOperationData == "All" || sOperationData == undefined) {
                        sOperationData = "";
                      }

                      var oModelMICDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.InspectionAnalysis-->getMIC-->SQLQ_InspAnalysisGetMIC");

                      oModelMICDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/SQLQ_InspAnalysisGetMIC&Param.1=" + plant + "&Param.2="
                          + sOrderData + "&Param.3=" + sOperationData + "&Content-Type=text/json",
                          "", false);
                      this.getView().setModel(oModelMICDetails, "oMICDetails");
                      this.getView().byId("id_dropdown_mic").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_mic").setSelectedKey("All");
                    },

/** *********************************************************************************************************************************************************************************** */
// Set from to date time
/** ************************************************************************************************************************************************************************************** */
                    setFromTo : function() {
                      var TodayDate = CommonUtility.getCurrentDateTime(new Date());
                      var Dateprt = TodayDate.split(" ");
                      this.getView().byId("FromTime").setValue(Dateprt[0] + " " + "00:00:00");
                      this.getView().byId("ToTime").setValue(Dateprt[0] + " " + "23:59:59");

                    },
/** *********************************************************************************************************************************************************************************** */
// Populate chart on click of Button
/** ************************************************************************************************************************************************************************************** */
                    GetBtnDis : function() {
                      UI_utilities.setContainerBusyState(this, true);
                      var sOrderData = this.getView().byId("id_dropdown_order").getSelectedKey();
                      if (sOrderData == null || sOrderData == "All" || sOrderData == undefined) {
                        sOrderData = "";
                      }
                      var sOperationData = this.getView().byId("id_dropdown_operation")
                          .getSelectedKey();
                      if (sOperationData == null || sOperationData == "All" || sOperationData == undefined) {
                        sOperationData = "";
                      }
                      var sMICData = this.getView().byId("id_dropdown_mic").getSelectedKey();
                      if (sMICData == null || sMICData == "All" || sMICData == undefined) {
                        sMICData = "";
                      }
                      var FromDate = this.getView().byId("FromTime").getValue();
                      var ToDate = this.getView().byId("ToTime").getValue();

                      /*
                       * var sParams =
                       * "Param.1="+sOrderData+"&Param.2="+sOperationData+"&Param.3="+sMICData+"&Param.4="+FromDate
                       * +"&Param.5="+ToDate+"&d="+new Date(); var
                       * oModelChartDetails = new sap.ui.model.json.JSONModel();
                       * oModelChartDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_InspAnalysisSPC&"+sParams+"&Content-Type=text/json",
                       * "", false); if
                       * (CommonUtility.getJsonModelRowCount(oModelChartDetails.getData()) >
                       * 0) { // load the irpt in iframe with the parameters,
                       * i%SPC is having issue with UI5 in Heinz system var
                       * frame =
                       * this.getView().byId("InspectionAnalysis_frame"); var
                       * oFrameContent = frame .$()[0]; let sBaseURL =
                       * "/XMII/CM/RepHubUI5/webapp/irpt/InspectionAnalysis_spc.irpt?";
                       * let sParams =
                       * "qs_insplot="+sOrderData+"&qs_phase="+sOperationData+"&qs_char="+sMICData+"&qs_startdate="+FromDate+"&qs_enddate="+ToDate+"&d="+new
                       * Date(); oFrameContent.setAttribute("src",
                       * sBaseURL+sParams); } else { var sNoInspData =
                       * sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
                       * sap.ui.getCore().getModel("oMessage").setProperty("/message",
                       * sNoInspData);
                       * sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",
                       * true);
                       * sap.ui.getCore().getModel("oMessage").setProperty("/type",
                       * "Error"); }
                       */

                      var c = new com.sap.xmii.chart.hchart.i5SPCChart(
                          "RepHubUI5/DisplayTemplate/SPC_InspAnalysis", projectName
                              + "/QueryTemplate/SQLQ_InspAnalysisSPC");
                      c.getQueryObject().setParameter("Param.1", sOrderData);
                      c.getQueryObject().setParameter("Param.2", sOperationData);
                      c.getQueryObject().setParameter("Param.3", sMICData);
                      c.getQueryObject().setParameter("Param.4", FromDate);
                      c.getQueryObject().setParameter("Param.5", ToDate);

                      let that = this;
                      c.registerCreationEventHandler(this.spcLoaded);
                      var oHtml = new sap.ui.core.HTML({
                        content : "<div id='spc_content'>"
                      });
                      this.getView().byId("id_spcCharts_div").addItem(oHtml);
                      UI_utilities.setContainerBusyState(this, true);
                      setTimeout(function() {
                        c.draw("spc_content");
                      }, 1000);

                    },
/** *********************************************************************************************************************************************************************************** */
                    spcLoaded : function() {
                      UI_utilities.setContainerBusyState(oController, false);
                    },
/** *********************************************************************************************************************************************************************************** */
                    onHelp : function() {

                      UI_utilities.OpenHelpFileSingle("Analysis");
                    },
/** *********************************************************************************************************************************************************************************** */
                    setAllForCombox : function() {
                      this.getView().byId("id_dropdown_order").removeAllItems();
                      this.getView().byId("id_dropdown_order").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_order").setSelectedKey("All");
                      this.getView().byId("id_dropdown_operation").removeAllItems();
                      this.getView().byId("id_dropdown_operation").insertItem(
                          new sap.ui.core.Item({
                            key : "All",
                            text : "All"
                          }), 0);
                      this.getView().byId("id_dropdown_operation").setSelectedKey("All");
                      this.getView().byId("id_dropdown_mic").removeAllItems();
                      this.getView().byId("id_dropdown_mic").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_mic").setSelectedKey("All");

                    },
                  });

        });