sap.ui.define(	[ "sap/ui/core/mvc/Controller",
                                                                        "sap/ui/model/Filter",
						"sap/m/MessageBox",
						"com/khc/rephub/utils/UI_utilities",
						"com/khc/common/Script/CommonUtility", "com/khc/rephub/model/models" ],
				function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models) {
	"use strict";
 	var plant='3101';
	var resource='W1P-LIN1';
	//var plant;
	//var resource;
	var projectName;
	var userName;
	var crDest;
	var frequencyRadioGroupMap;

return Controller.extend("com.khc.rephub.controller.analysis.ProductionAnalysis", {
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("ProductionAnalysis").attachPatternMatched(this._oRoutePatternMatched, this);
				
		},

		_oRoutePatternMatched : function(oEvent) {
			
			//Hide the messages and set busy to false
			UI_utilities.nonProductionPageOpened(this);
			 UI_utilities.DisableDatePickerInput(this.getView().byId("FromTime"));
                      		UI_utilities.DisableDatePickerInput(this.getView().byId("ToTime"));
			plant=sap.ui.getCore().getModel("session").oData.CA_Plant;
			resource=sap.ui.getCore().getModel("session").oData.CA_Resource;
			projectName=sap.ui.getCore().getModel("session").oData.CA_ProjectName;
			userName=sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
			crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
			
			var oDisplayData = {
					selectedOption : "oAnalysisOee"
			};
			var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
			this.getView().setModel(oDisplayOptionModel,"displayOption");
			
			//ResourceList
            var oModelGetResourceList = CommonUtility.getResourceListByPlant(projectName, plant);
			this.getView().setModel(oModelGetResourceList,"oResourceList");		
			this.getView().byId("id_dropdown_resource").insertItem(new 	sap.ui.core.Item({key:"All",text:"All"}),0);
			this.getView().byId("id_dropdown_resource").setSelectedKey("All");

			//Date&Time
			var TodayDate = CommonUtility.getCurrentDateTime(new Date());
			var Dateprt = TodayDate.split(" ");
			var fromTimeValue = Dateprt[0] + " " + "00:00:00";
			var toTimeValue = Dateprt[0] + " " + "23:59:59"
			this.getView().byId("FromTime").setValue(fromTimeValue);
			this.getView().byId("ToTime").setValue(toTimeValue);

			//ShiftList
			var oModelGetShiftList = CommonUtility.getShiftListByResource(projectName, plant,resource);
			this.getView().setModel(oModelGetShiftList,"oShiftList");
			this.getView().byId("id_dropdown_shift").insertItem(new 	sap.ui.core.Item({key:"All",text:"All"}),0);
			this.getView().byId("id_dropdown_shift").setSelectedKey("All");
			
			//this.GetChartModif();
		},

			// Navigate the the selected menu page
		            menuSelected : function (oEvent) {
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
       		 },	

		GetChartModif : function() {
			
			
			if (fromTimeValue != "" && toTimeValue != "") {
				var selectedFrequencyRadioGroup = this.getView().byId("FrequencyRadioGroup").getSelectedIndex();
				var fromTimeValue = this.getView().byId("FromTime").getValue();
				
				var toTimeValue = this.getView().byId("ToTime").getValue();
				var resourcetxt = this.getView().byId("id_dropdown_resource").getValue();
				
				var resourceValue = "";
				if (resourcetxt != "All") {
					resourceValue = this.getView().byId("id_dropdown_resource").getSelectedKey();
				}
				
				var Shift = this.getView().byId("id_dropdown_shift").getValue();
				var ShiftCde = "";
				if (Shift != "All") {
					ShiftCde = this.getView().byId("id_dropdown_shift").getSelectedKey();
				}
				
				
				var sParams = "&Param.1="+plant+"&Param.2="+resourceValue+"&Param.3="+fromTimeValue+
				"&Param.4="+toTimeValue+"&Param.5="+ShiftCde+"&d="+new Date();
				
				if(selectedFrequencyRadioGroup == "0") {
							
					
            		 var oModelAnalysisOeeData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ProductionAnalysis-->GetChartModif-->SQLQ_ProdAnalysisOEE");
					oModelAnalysisOeeData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ProdAnalysisOEE&" + sParams + "&d="+new Date() + "&Content-Type=text/json", "", false);
					this.getView().setModel(oModelAnalysisOeeData,"oAnalysisOee");
					this.getView().getModel("displayOption").setProperty("/selectedOption","oAnalysisOee");
					 }
				
				 else if(selectedFrequencyRadioGroup == "1"){
						
            			 var oModelAnalysisOEEAvailData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ProductionAnalysis-->GetChartModif-->SQLQ_ProdAnalysisOEEAvail");
						oModelAnalysisOEEAvailData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ProdAnalysisOEEAvail&" + sParams + "&Content-Type=text/json", "", false);
						this.getView().setModel(oModelAnalysisOEEAvailData,"oAnalysisOEEAvail");
						this.getView().getModel("displayOption").setProperty("/selectedOption","oAnalysisOEEAvail");
						 }
				 else if(selectedFrequencyRadioGroup == "2"){
						
            			 var oModelAnalysisOEEPerfData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ProductionAnalysis-->GetChartModif-->SQLQ_ProdAnalysisOEEPerf");
						oModelAnalysisOEEPerfData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ProdAnalysisOEEPerf&" + sParams + "&Content-Type=text/json", "", false);
						this.getView().setModel(oModelAnalysisOEEPerfData,"oAnalysisOEEPerf");
						this.getView().getModel("displayOption").setProperty("/selectedOption","oAnalysisOEEPerf");
						 }
				
				 else if(selectedFrequencyRadioGroup == "3"){
						
            			 var oModelAnalysisOEEQualData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ProductionAnalysis-->GetChartModif-->SQLQ_ProdAnalysisOEEQual");	
						oModelAnalysisOEEQualData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ProdAnalysisOEEQual&" + sParams + "&Content-Type=text/json", "", false);
						this.getView().setModel(oModelAnalysisOEEQualData,"oAnalysisOEEQual");
						this.getView().getModel("displayOption").setProperty("/selectedOption","oAnalysisOEEQual");
						 }
				 else {
						
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0057"), {
							 title: "Alert",
						});
					}
				}
				else{
					MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0056"));
				}
},
onHelp:function(){

		UI_utilities.OpenHelpFileSingle("Analysis");
	}



});
});
