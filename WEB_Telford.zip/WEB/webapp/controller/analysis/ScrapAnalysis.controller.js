sap.ui.define(	[ "sap/ui/core/mvc/Controller",
                       "sap/ui/model/Filter",
						"sap/m/MessageBox",
						"com/khc/rephub/utils/UI_utilities",
						"com/khc/common/Script/CommonUtility" ,"com/khc/rephub/model/models" ],
				function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models) {
	"use strict";
 	var plant;
	var resource;
	var projectName;
	var userName;
	var crDest;
	var frequencyRadioGroupMap;

return Controller.extend("com.khc.rephub.controller.analysis.ScrapAnalysis", {
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("ScrapAnalysis").attachPatternMatched(this._oRoutePatternMatched, this);
		
                            
		},

		_oRoutePatternMatched : function(oEvent) {
			
			//Hide the messages and set busy to false
			UI_utilities.analysisPageOpened(this,"ScrapAnalysis");
			 UI_utilities.DisableDatePickerInput(this.getView().byId("FromTime"));
                 		     UI_utilities.DisableDatePickerInput(this.getView().byId("ToTime"));
			
			plant=sap.ui.getCore().getModel("session").oData.CA_Plant;
			resource=sap.ui.getCore().getModel("session").oData.CA_Resource;
			projectName=sap.ui.getCore().getModel("session").oData.CA_ProjectName;
			userName=sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
			crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
		
			 this.getReason();
			 
			 var oDisplayData = {
						selectedOption : "oQtyPareto"
				};
				var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
				this.getView().setModel(oDisplayOptionModel,"displayOption");
			 
			var oModelGetResourceList = CommonUtility.getResourceListByPlant(projectName, plant);
			this.getView().setModel(oModelGetResourceList,"oResourceList");
			
			this.getView().byId("id_dropdown_resource").insertItem(new 	sap.ui.core.Item({key:"All",text:"All"}),0);
			this.getView().byId("id_dropdown_resource").setSelectedKey("All");
			
			var oModelGetShiftList = CommonUtility.getShiftListByResource(projectName, plant,resource);
			this.getView().setModel(oModelGetShiftList,"oShiftList");
			this.getView().byId("id_dropdown_shift").insertItem(new 	sap.ui.core.Item({key:"All",text:"All"}),0);
			this.getView().byId("id_dropdown_shift").setSelectedKey("All");
			
			var TodayDate = CommonUtility.getCurrentDateTime(new Date());
			var Dateprt = TodayDate.split(" ");
			var fromTimeValue = Dateprt[0] + " " + "00:00:00";
			var toTimeValue = Dateprt[0] + " " + "23:59:59"
			this.getView().byId("FromTime").setValue(fromTimeValue);
			this.getView().byId("ToTime").setValue(toTimeValue);
			
			this.getView().byId("FrequencyRadio").setSelectedIndex(1);
			this.getView().byId("TrendRadio").setSelectedIndex(1);
			this.getView().byId("FrequencyRadioGroup").setSelectedIndex(0);
			//this.getView().byId("Top10").setSelectedIndex(0);
			
			
			// load today data by on page load
			var sParams = "&Param.1="+plant+"&Param.2=&Param.3="+fromTimeValue+
			"&Param.4="+toTimeValue+"&Param.5=&Param.6=&d="+new Date();
	
             var oModelQtyParetooData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ScrapAnalysis-->_oRoutePatternMatched-->SQLQ_ScrapAnalysisQtyPareto");
			oModelQtyParetooData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ScrapAnalysisQtyPareto&" + sParams + "&d="+new Date() + "&Content-Type=text/json", "", false);
			this.getView().setModel(oModelQtyParetooData,"oQtyPareto");

			
		},
		
		// Navigate the the selected menu page
		menuSelected : function (oEvent) {
			var sKey = oEvent.getParameters().key;
			UI_utilities.openMenu(this._oRouter,this,sKey);
       		 },	
		
       getTodayDatepop: function(oControlEvent) {
    	   
    	   // setDateFromFrequency: function(oView,selectedRadioBtn,fromTimeID, toTimeID) {
    	   
    	   var selectedRadioBtn = oControlEvent.getParameters().selectedIndex;
    	   UI_utilities.setDateFromFrequency(this.getView(),selectedRadioBtn,"FromTime","ToTime");
			
		},

        getReason :function(){
        	
             var oReasonListModel =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ScrapAnalysis-->getReason-->SQLQ_GetScrapCode");
			oReasonListModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetScrapCode&Content-Type=text/json&d="+new Date(), "", false);
			this.getView().setModel(oReasonListModel,"oReasonList");
			this.getView().byId("id_dropdown_reason").insertItem(new 	sap.ui.core.Item({key:"All",text:"All"}),0);
			this.getView().byId("id_dropdown_reason").setSelectedKey("All");
			
		},
		
		
		GetBtnDis : function() {
			

			var fromTimeValue = this.getView().byId("FromTime").getValue();
			var toTimeValue = this.getView().byId("ToTime").getValue();
			
			
			if (fromTimeValue != "" && toTimeValue != "") {
				var selectedTrendRadioBtn = this.getView().byId("TrendRadio").getSelectedIndex();
				if (selectedTrendRadioBtn === 0) {
					
					var StartDt = this.getView().byId("FromTime").getDateValue();
					var EndDt = this.getView().byId("ToTime").getDateValue();
					
					var Dt_Diff = Math.ceil((EndDt-StartDt)/1000);
					if (Dt_Diff > 86400) {
						
						var that = this;
						var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0100");
						MessageBox.confirm(
		                        msg, {
		                            onClose: function(oAction) {
		                                if (oAction === "OK") {
		                                	that.GetChartModif();
		                                }
		                            }
		                        });

						
					}
					else{
						this.GetChartModif();
					}
					
				}
				else{
					
					this.GetChartModif();
				}
				
			}
			else {
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0056"));
			}


		},
		
		fnValidateDate : function(oEvent) {
        	
        	 var toSelectedDate= this.getView().byId("ToTime").getValue();
        	 var fromSelectedDate = this.getView().byId("FromTime").getValue();
         	
        	if(fromSelectedDate && toSelectedDate && fromSelectedDate > toSelectedDate) {
        		
        		MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0081"));
        		oEvent.getSource().setValue("")
        	}
		},
		
		GetChartModif : function() {
        
			var selectedFreqRadioBtn = this.getView().byId("FrequencyRadio").getSelectedIndex();
			var selectedTrendRadioBtn = this.getView().byId("TrendRadio").getSelectedIndex();
			var fromTimeValue = this.getView().byId("FromTime").getValue();
			var toTimeValue = this.getView().byId("ToTime").getValue();
			
			var resourcetxt = this.getView().byId("id_dropdown_resource").getValue();
			var resourceValue = "";
			if (resourcetxt != "All") {
				resourceValue = this.getView().byId("id_dropdown_resource").getSelectedKey();
			}
			
			var Shift = this.getView().byId("id_dropdown_shift").getValue();
			var ShiftCde = "";
			if (Shift != "All") {
				ShiftCde = this.getView().byId("id_dropdown_shift").getSelectedKey();
			}
			
			var reason = this.getView().byId("id_dropdown_reason").getValue();
			var ReasonCde = "";
			if (reason != "All") {
				ReasonCde = this.getView().byId("id_dropdown_reason").getSelectedKey();
			}
			
			var sParams = "&Param.1="+plant+"&Param.2="+resourceValue+"&Param.3="+fromTimeValue+
				"&Param.4="+toTimeValue+"&Param.5="+ReasonCde+"&Param.6="+ShiftCde+"&d="+new Date();
			
        	  
  		 if(selectedFreqRadioBtn == "1" && selectedTrendRadioBtn == "0") {
  				
		         var oModelQtyTrendData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ScrapAnalysis-->GetChartModif-->XACQ_ScrapAnalysisQtyTrend");	
  			     oModelQtyTrendData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_ScrapAnalysisQtyTrend&" + sParams + "&d="+new Date() +"&Content-Type=text/json", "", false);
  			     this.getView().setModel(oModelQtyTrendData,"oQtyTrend");
  			     this.getView().getModel("displayOption").setProperty("/selectedOption","oQtyTrend");
  					 
  				
  			} 
        	  
        	  else if(selectedFreqRadioBtn == "0" && selectedTrendRadioBtn == "0") {
  				
		             var oModelFreqTrendoData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ScrapAnalysis-->GetChartModif-->XACQ_ScrapAnalysisFreqTrend");
					oModelFreqTrendoData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_ScrapAnalysisFreqTrend&" + sParams + "&d="+new Date() + "&Content-Type=text/json", "", false);
  					this.getView().setModel(oModelFreqTrendoData,"oFreqTrend");
  					 this.getView().getModel("displayOption").setProperty("/selectedOption","oFreqTrend");
   					
  					
  			} 
  			
        	  else if(selectedFreqRadioBtn == "1" && selectedTrendRadioBtn == "1") {
				  
		        var oModelQtyParetooData =   models.createNewJSONModel("com.khc.rephub.controller.analysis.ScrapAnalysis-->GetChartModif-->SQLQ_ScrapAnalysisQtyPareto");
				oModelQtyParetooData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ScrapAnalysisQtyPareto&" + sParams + "&d="+new Date() + "&Content-Type=text/json", "", false);
				this.getView().setModel(oModelQtyParetooData,"oQtyPareto");
				this.getView().getModel("displayOption").setProperty("/selectedOption","oQtyPareto");
		} 
  		 
  		 
        	  else if(selectedFreqRadioBtn == "0" && selectedTrendRadioBtn == "1") {
  				
  				
		       		 var oModelFrqParetooData = models.createNewJSONModel("com.khc.rephub.controller.analysis.ScrapAnalysis-->GetChartModif-->SQLQ_ScrapAnalysisFrqPareto");
  					oModelFrqParetooData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ScrapAnalysisFrqPareto&" + sParams + "&d="+new Date() + "&Content-Type=text/json", "", false);
  					this.getView().setModel(oModelFrqParetooData,"oFrqPareto");
  					this.getView().getModel("displayOption").setProperty("/selectedOption","oFrqPareto");
  			} 
  			
  			else {
  				
  				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0057"), {
  					 title: "Alert",                                  
  				});
  			}
		},
onHelp:function(){

		UI_utilities.OpenHelpFileSingle("Analysis");
	},
});
});