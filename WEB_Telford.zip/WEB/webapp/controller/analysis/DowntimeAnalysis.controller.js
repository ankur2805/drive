sap.ui
    .define(
        [ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox",
            "com/khc/rephub/utils/UI_utilities", "com/khc/common/Script/CommonUtility",
            "com/khc/rephub/model/models" ],
        function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models) {
          "use strict";
          var plant = '';
          var resource = '';
          var projectName;
          var userName;
          var crDest;
          var frequencyRadioGroupMap;

          return Controller
              .extend(
                  "com.khc.rephub.controller.analysis.DowntimeAnalysis",
                  {
                    onInit : function() {
                      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                      this._oRouter.getRoute("DowntimeAnalysis").attachPatternMatched(
                          this._oRoutePatternMatched, this);

                    },

                    _oRoutePatternMatched : function(oEvent) {

                      UI_utilities.analysisPageOpened(this, "DowntimeAnalysis");
                      UI_utilities.DisableDatePickerInput(this.getView().byId("FromTime"));
                      UI_utilities.DisableDatePickerInput(this.getView().byId("ToTime"));

                      plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                      resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                      projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                      userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                      crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

                      this.getView().byId("id_dropdown_area").setSelectedItem(null);
                      this.getView().byId("id_dropdown_catsubarea").setSelectedItem(null);

                      frequencyRadioGroupMap = {
                        0 : "TodayDate",
                        1 : "Yesterday",
                        2 : "Previous Week",
                        3 : "Previous Month"
                      };

                      var oDisplayData = {
                        selectedOption : "showDurPareto"
                      };
                      var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
                      this.getView().setModel(oDisplayOptionModel, "displayOption");
                      var oDisplayOptionModel

                      this.onLoad();

                    },

                    // Navigate the the selected menu page
                    menuSelected : function(oEvent) {
                      var sKey = oEvent.getParameters().key;
                      UI_utilities.openMenu(this._oRouter, this, sKey);
                    },

                    onAfterRendering : function() {
                    },

                    /** *********************************************************************************************************************************************************************************** */
                    // Call this function on load of page
                    /** ************************************************************************************************************************************************************************************** */
                    onLoad : function() {
                      var oModelGetResourceList = CommonUtility.getResourceListByPlant(projectName,
                          plant);
                      this.getView().setModel(oModelGetResourceList, "oResourceList");
                      this.getView().byId("id_dropdown_resource").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_resource").setSelectedKey("All");

                      var oModelGetShiftList = CommonUtility.getShiftListByResource(projectName,
                          plant, resource);
                      this.getView().setModel(oModelGetShiftList, "oShiftList");
                      this.getView().byId("id_dropdown_shift").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_shift").setSelectedKey("All");

                      var TodayDate = CommonUtility.getCurrentDateTime(new Date());
                      var Dateprt = TodayDate.split(" ");
                      this.getView().byId("FromTime").setValue(Dateprt[0] + " " + "00:00:00");
                      this.getView().byId("ToTime").setValue(Dateprt[0] + " " + "23:59:59");
                      this.getView().byId("FrequencyRadio").setSelectedIndex(1);
                      this.getView().byId("TrendRadio").setSelectedIndex(1);
                      this.getView().byId("FrequencyRadioGroup").setSelectedIndex(0);

                      this.getCatType();
                      this.setAllForCombox();
                      this.populateDurationTable();
                      this.PopulateCSV();
                    },
/** *********************************************************************************************************************************************************************************** */
// On click of CSV
/** ************************************************************************************************************************************************************************************** */
                    PopulateCSV : function() {

                      var fromTimeValue = this.getView().byId("FromTime").getValue();
                      var toTimeValue = this.getView().byId("ToTime").getValue();
                      var sParams = "&Param.1=" + fromTimeValue + "&Param.2=" + toTimeValue
                          + "&Param.3=" + "" + "&Param.4=" + "" + "&Param.5=" + plant + "&Param.6="
                          + "" + "&Param.7=" + "" + "&Param.8=" + "" + "&Param.9=" + "";

                      var oModelDTAnaForCSV = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.DowntimeAnalysis-->PopulateCSV-->XACQ_GetDTAnalysisForCSV");
                      oModelDTAnaForCSV.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/XACQ_GetDTAnalysisForCSV" + sParams
                          + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelDTAnaForCSV, "oDTAnalysisForCSV");
                    },
/** *********************************************************************************************************************************************************************************** */
// Populate duration pareto
/** ************************************************************************************************************************************************************************************** */
                    populateDurationTable : function() {
                      this.getView().getModel("displayOption").setProperty("/selectedOption",
                          "showDurPareto");
                      var fromTimeValue = this.getView().byId("FromTime").getValue();
                      var toTimeValue = this.getView().byId("ToTime").getValue();
                      var sParams = "Param.1=" + plant + "&Param.2=" + "" + "&Param.3="
                          + fromTimeValue + "&Param.4=" + toTimeValue + "&Param.5=" + ""
                          + "&Param.6=" + "" + "&Param.7=" + "" + "&Param.8=" + "" + "&Param.9="
                          + "";
                      var oModelDurParetoData = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.DowntimeAnalysis-->populateDurationTable-->XACQ_DTAnalysisDurPareto");
                      oModelDurParetoData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/XACQ_DTAnalysisDurPareto&" + sParams
                          + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelDurParetoData, "oDurPareto");
                    },
                    /** *********************************************************************************************************************************************************************************** */
                    // get Functional Location
                    /** ************************************************************************************************************************************************************************************** */
                    getFuncLoc : function() {
                      var resourcetxt = this.getView().byId("id_dropdown_resource").getValue();
                      var resourceValue = "";
                      if (resourcetxt != "All") {
                        resourceValue = this.getView().byId("id_dropdown_resource")
                            .getSelectedKey();
                      }

                      var oModelFuncLocByResrDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.DowntimeAnalysis-->getFuncLoc-->SQLQ_GetFuncLocByResr");
                      oModelFuncLocByResrDetails.loadData("/XMII/Illuminator?QueryTemplate="
                          + projectName + "/QueryTemplate/SQLQ_GetFuncLocByResr&Param.1=" + plant
                          + "&Param.2=" + resourceValue + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelFuncLocByResrDetails, "oFuncLocByResr");
                      this.getView().byId("id_dropdown_functionalLocation").insertItem(
                          new sap.ui.core.Item({
                            key : "All",
                            text : "All"
                          }), 0);
                      this.getView().byId("id_dropdown_functionalLocation").setSelectedKey("All");
                    },
/** *********************************************************************************************************************************************************************************** */
// Get cat type
/** ************************************************************************************************************************************************************************************** */
                    getCatType : function() {
                      // this.getView().byId("id_dropdown_cattype").insertItem(new
                      // sap.ui.core.Item({key:"All",text:"All"}),0);

                      var oModelCatTypeDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.DowntimeAnalysis-->getCatType-->XACQ_GetCatType");
                      oModelCatTypeDetails.loadData("/XMII/Illuminator?QueryTemplate="
                          + projectName + "/QueryTemplate/XACQ_GetCatType&Content-Type=text/json",
                          "", false);
                      this.getView().setModel(oModelCatTypeDetails, "oCatTypeDetails");
                      this.getView().byId("id_dropdown_cattype").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_cattype").setSelectedKey("All");
                    },
/** *********************************************************************************************************************************************************************************** */
// Get Cat Area
/** ************************************************************************************************************************************************************************************** */
                    getCatArea : function() {
                      var selCatType = this.getView().byId("id_dropdown_cattype").getSelectedKey();
                      var oModelCatAreaDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.DowntimeAnalysis-->getCatArea-->SQLQ_GetCatArea");
                      oModelCatAreaDetails.loadData("/XMII/Illuminator?QueryTemplate="
                          + projectName + "/QueryTemplate/SQLQ_GetCatArea&Param.1=" + selCatType
                          + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelCatAreaDetails, "oCatAreaDetails");
                      this.getView().byId("id_dropdown_area").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_area").setSelectedKey("All");
                    },
/** *********************************************************************************************************************************************************************************** */
// Get sub area dropdown
/** ************************************************************************************************************************************************************************************** */
                    getCatSubArea : function() {
                      var selCatType = this.getView().byId("id_dropdown_cattype").getSelectedKey();
                      var selCatAreaType = this.getView().byId("id_dropdown_area").getSelectedKey();

                      var oModelCatSubAreaDetails = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.DowntimeAnalysis-->getCatSubArea-->SQLQ_GetCatSubArea");
                      oModelCatSubAreaDetails.loadData("/XMII/Illuminator?QueryTemplate="
                          + projectName + "/QueryTemplate/SQLQ_GetCatSubArea&Param.1="
                          + selCatAreaType + "&Param.2=" + selCatType + "&Content-Type=text/json",
                          "", false);
                      this.getView().setModel(oModelCatSubAreaDetails, "oCatSubAreaDetails");
                      this.getView().byId("id_dropdown_catsubarea").insertItem(
                          new sap.ui.core.Item({
                            key : "All",
                            text : "All"
                          }), 0);
                      this.getView().byId("id_dropdown_catsubarea").setSelectedKey("All");
                    },
/** *********************************************************************************************************************************************************************************** */
//
/** ************************************************************************************************************************************************************************************** */
                    /*
                     * getDTAnalysisDurPareto : function() { var FromTime =
                     * this.getView().byId("FromTime").getValue(); var ToTime =
                     * this.getView().byId("ToTime").getValue(); var sParams =
                     * "Param.1="+plant+"&Param.2="+""+"&Param.3="+FromTime+"&Param.4="+ToTime+"&Param.5="+""+"&Param.6="+""+"&Param.7="+""+"&Param.8="+""+"&Param.9="+"";
                     * var oModelDTAnalysisDurDetails = new
                     * sap.ui.model.json.JSONModel();
                     * oModelCatSubAreaDetails.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_DTAnalysisDurPareto&"+sParams+"&Content-Type=text/json",
                     * "", false);
                     * this.getView().setModel(oModelDTAnalysisDurDetails,"oCatSubAreaDetails"); },
                     */
/** *********************************************************************************************************************************************************************************** */
// get today's date pop
/** ************************************************************************************************************************************************************************************** */
                    getTodayDatepop : function() {

                      var selectedRadioBtn = this.getView().byId("FrequencyRadio")
                          .getSelectedIndex();
                      var TodayDate = CommonUtility.getCurrentDateTime(new Date());
                      var fromTimeValue = "";
                      var toTimeValue = "";

                      if (selectedRadioBtn === "0") {
                        var Dateprt = TodayDate.split(" ");
                        fromTimeValue = Dateprt[0] + " " + "00:00:00";
                        toTimeValue = Dateprt[0] + " " + "23:59:59";

                      } else if (selectedRadioBtn === "1") {
                        fromTimeValue = "Yesterday";
                        toTimeValue = TodayDate;

                      } else if (selectedRadioBtn === "2") {
                        fromTimeValue = "Prevweek";
                        toTimeValue = TodayDate;

                      } else if (selectedRadioBtn === "3") {
                        fromTimeValue = "PrevMon";
                        toTimeValue = TodayDate;

                      }

                      var startDate = "";
                      var endDate = "";
                      var sParams = "Param.1=" + fromTimeValue + "Param.2=" + toTimeValue;
                      var oModelDateRange = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.DowntimeAnalysis-->getTodayDatepop-->XACQ_GetDateRange");
                      oModelDateRange.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/XACQ_GetDateRange&" + sParams
                          + "&Content-Type=text/json", "", false);
                      if (CommonUtility.getJsonModelRowCount(oModelDateRange.getData()) == 1) {

                        var dateRangeResp = oModelDateRange.getData().Rowsets.Rowset[0].Row[0];
                        startDate = dateRangeResp.StartDate;
                        endDate = dateRangeResp.EndDate;
                      }
                      this.getView().byId("FromTime").setValue(startDate);
                      this.getView().byId("ToTime").setValue(endDate);
                    },
/** *********************************************************************************************************************************************************************************** */
// get chart and table detail
/** ************************************************************************************************************************************************************************************** */
                    GetChartModif : function() {
                      var resourcetxt = this.getView().byId("id_dropdown_resource").getValue();
                      var resourceValue = "";
                      if (resourcetxt != "All") {
                        resourceValue = this.getView().byId("id_dropdown_resource")
                            .getSelectedKey();
                      }

                      var TypeTxt = this.getView().byId("id_dropdown_cattype").getValue();
                      var TypeCde = "";
                      if (TypeTxt != "All") {
                        TypeCde = this.getView().byId("id_dropdown_cattype").getSelectedKey();
                      }

                      var AreaTxt = this.getView().byId("id_dropdown_area").getValue();
                      var AreaCde = "";
                      if (AreaTxt != "All") {
                        AreaCde = this.getView().byId("id_dropdown_area").getSelectedKey();
                      }

                      var SAreaTxt = this.getView().byId("id_dropdown_catsubarea").getValue();
                      var SAreaCde = "";
                      if (SAreaTxt != "All") {
                        SAreaCde = this.getView().byId("id_dropdown_catsubarea").getSelectedKey();
                      }

                      var FuncLocTxt = this.getView().byId("id_dropdown_functionalLocation")
                          .getValue();
                      var FuncLocCde = "";
                      if (FuncLocTxt != "All") {
                        FuncLocCde = this.getView().byId("id_dropdown_functionalLocation")
                            .getSelectedKey();
                      }

                      var Shift = this.getView().byId("id_dropdown_shift").getValue();
                      var ShiftCde = "";
                      if (Shift != "All") {
                        ShiftCde = this.getView().byId("id_dropdown_shift").getSelectedKey();
                      }

                      var selectedFreqRadioBtn = this.getView().byId("FrequencyRadio")
                          .getSelectedIndex();
                      var selectedTrendRadioBtn = this.getView().byId("TrendRadio")
                          .getSelectedIndex();

                      var fromTimeValue = this.getView().byId("FromTime").getValue();
                      var toTimeValue = this.getView().byId("ToTime").getValue();

                      var sParams = "&Param.1=" + plant + "&Param.2=" + resource + "&Param.3="
                          + fromTimeValue + "&Param.4=" + toTimeValue + "&Param.5=" + TypeCde
                          + "&Param.6=" + ShiftCde + "&Param.7=" + AreaCde + "&Param.8=" + SAreaCde
                          + "&Param.9=" + FuncLocCde + "&d=" + new Date();
                      var queryTemplate = "";

                      // 1. FrequencyRadio == 1 TrendRadio == 1
                      // XACQ_DTAnalysisDurPareto
                      if (selectedFreqRadioBtn == "1" && selectedTrendRadioBtn == "1") {
                        // Table generation
                        queryTemplate = "/QueryTemplate/XACQ_DTAnalysisDurPareto";

                        var oModelDurParetoData = models
                            .createNewJSONModel("com.khc.rephub.controller.analysis.GetChartModif-->getTodayDatepop-->XACQ_DTAnalysisDurPareto");

                        oModelDurParetoData.loadData("/XMII/Illuminator?QueryTemplate="
                            + projectName + queryTemplate + sParams + "&Content-Type=text/json",
                            "", false);
                        this.getView().setModel(oModelDurParetoData, "oDurPareto");
                        this.getView().getModel("displayOption").setProperty("/selectedOption",
                            "showDurPareto");

                      }

                      // 2. FrequencyRadio == 1 TrendRadio == 0
                      // XACQ_DTAnalysisDurTrend
                      else if (selectedFreqRadioBtn == "1" && selectedTrendRadioBtn == "0") {
                        queryTemplate = "/QueryTemplate/XACQ_DTAnalysisDurTrend";

                        var oModelDurTrendData = models
                            .createNewJSONModel("com.khc.rephub.controller.analysis.GetChartModif-->getTodayDatepop-->XACQ_DTAnalysisDurTrend");

                        oModelDurTrendData.loadData("/XMII/Illuminator?QueryTemplate="
                            + projectName + queryTemplate + sParams + "&Content-Type=text/json",
                            "", false);
                        this.getView().setModel(oModelDurTrendData, "oDurTrend");
                        this.getView().getModel("displayOption").setProperty("/selectedOption",
                            "showDurTrend");

                      }

                      // 3. FrequencyRadio == 0 TrendRadio == 0
                      // XACQ_DTAnalysisFreqTrend
                      else if (selectedFreqRadioBtn == "0" && selectedTrendRadioBtn == "0") {
                        queryTemplate = "/QueryTemplate/XACQ_DTAnalysisFreqTrend";

                        var oModelFreqTrendData = models
                            .createNewJSONModel("com.khc.rephub.controller.analysis.GetChartModif-->getTodayDatepop-->XACQ_DTAnalysisDurTrend");

                        oModelFreqTrendData.loadData("/XMII/Illuminator?QueryTemplate="
                            + projectName + queryTemplate + sParams + "&Content-Type=text/json",
                            "", false);
                        this.getView().setModel(oModelFreqTrendData, "oFreqTrend");
                        this.getView().getModel("displayOption").setProperty("/selectedOption",
                            "showFreqTrend");

                      }

                      // 4. FrequencyRadio == 0 TrendRadio == 1
                      // XACQ_DTAnalysisFreqPareto
                      else if (selectedFreqRadioBtn == "0" && selectedTrendRadioBtn == "1") {
                        queryTemplate = "/QueryTemplate/XACQ_DTAnalysisFreqPareto";

                        var oModelFreqParetoData = models
                            .createNewJSONModel("com.khc.rephub.controller.analysis.GetChartModif-->getTodayDatepop-->XACQ_DTAnalysisFreqPareto");

                        oModelFreqParetoData.loadData("/XMII/Illuminator?QueryTemplate="
                            + projectName + queryTemplate + sParams + "&Content-Type=text/json",
                            "", false);
                        this.getView().setModel(oModelFreqParetoData, "oFreqPareto");
                        this.getView().getModel("displayOption").setProperty("/selectedOption",
                            "showFreqPareto");

                      }

                      else {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty(
                            "HUB_MSG_0057"), {
                          title : "Alert",
                        });
                      }

                      // CSV
                      sParams = "&Param.1=" + fromTimeValue + "&Param.2=" + toTimeValue
                          + "&Param.3=" + TypeCde + "&Param.4=" + ShiftCde + "&Param.5=" + plant
                          + "&Param.6=" + resource + "&Param.7=" + AreaCde + "&Param.8=" + SAreaCde
                          + "&Param.9=" + FuncLocCde;

                      var oModelDTAnaForCSV = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.GetChartModif-->getTodayDatepop-->XACQ_GetDTAnalysisForCSV");

                      oModelDTAnaForCSV.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/XACQ_GetDTAnalysisForCSV" + sParams
                          + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelDTAnaForCSV, "oDTAnalysisForCSV");

                    },
/** *********************************************************************************************************************************************************************************** */
// On click of Run Query button
/** ************************************************************************************************************************************************************************************** */
                    GetBtnDis : function() {
                      // TO-DO Need to show the busy icon instead of disabling
                      // buttons manually
                      this.getView().byId("id_btn_RunQuery").setEnabled(false);
                      this.getView().byId("id_btn_SaveCSV").setEnabled(false);
                      // TO-DO Need to show the busy icon instead of disabling
                      // buttons manually

                      var sDataLoadingMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0101");
                      sap.ui.getCore().getModel("oMessage").setProperty("/message", sDataLoadingMsg);
                      sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                      sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

                      var fromTimeValue = this.getView().byId("FromTime").getValue();
                      var toTimeValue = this.getView().byId("ToTime").getValue();

                      if (fromTimeValue != "" && toTimeValue != "") {
                        var StartDt = this.getView().byId("FromTime").getDateValue();
                        var EndDt = this.getView().byId("ToTime").getDateValue();
                        var selectedTrendRadioBtn = this.getView().byId("TrendRadio")
                            .getSelectedIndex();
                        if (selectedTrendRadioBtn === 0) {

                          var Dt_Diff = Math.ceil((EndDt - StartDt) / 1000);
                          if (Dt_Diff > 86400) {

                            var that = this;
                            var msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0100");
                            MessageBox.confirm(msg, {
                              onClose : function(oAction) {
                                if (oAction === "OK") {
                                  that.GetChartModif();
                                }
                              }
                            });
                          } else {
                            this.GetChartModif();
                          }
                        } else {
                          this.GetChartModif();
                        }
                      } else {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty(
                            "HUB_MSG_0056"));
                      }

                      this.getView().byId("id_btn_RunQuery").setEnabled(true);
                      this.getView().byId("id_btn_SaveCSV").setEnabled(true);
                      sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);

                    },
/** *********************************************************************************************************************************************************************************** */
// get csv data on click of csv button click
/** ************************************************************************************************************************************************************************************** */
                    getCSVData : function() {

                      var resourcetxt = this.getView().byId("id_dropdown_resource").getValue();
                      var resourceValue = "";
                      if (resourcetxt != "All") {
                        resourceValue = this.getView().byId("id_dropdown_resource")
                            .getSelectedKey();
                      }

                      var TypeTxt = this.getView().byId("id_dropdown_cattype").getValue();
                      var TypeCde = "";
                      if (TypeTxt != "All") {
                        TypeCde = this.getView().byId("id_dropdown_cattype").getSelectedKey();
                      }

                      var AreaTxt = this.getView().byId("id_dropdown_area").getValue();
                      var AreaCde = "";
                      if (AreaTxt != "All") {
                        AreaCde = this.getView().byId("id_dropdown_area").getSelectedKey();
                      }

                      var SAreaTxt = this.getView().byId("id_dropdown_catsubarea").getValue();
                      var SAreaCde = "";
                      if (SAreaTxt != "All") {
                        SAreaCde = this.getView().byId("id_dropdown_catsubarea").getSelectedKey();
                      }

                      var FuncLocTxt = this.getView().byId("id_dropdown_functionalLocation")
                          .getValue();
                      var FuncLocCde = "";
                      if (FuncLocTxt != "All") {
                        FuncLocCde = this.getView().byId("id_dropdown_functionalLocation")
                            .getSelectedKey();
                      }

                      var Shift = this.getView().byId("id_dropdown_shift").getValue();
                      var ShiftCde = "";
                      if (Shift != "All") {
                        ShiftCde = this.getView().byId("id_dropdown_shift").getSelectedKey();
                      }

                      var fromTimeValue = this.getView().byId("FromTime").getValue();
                      var toTimeValue = this.getView().byId("ToTime").getValue();

                      var sParams = "&Param.1=" + fromTimeValue + "&Param.2=" + toTimeValue
                          + "&Param.3=" + TypeCde + "&Param.4=" + ShiftCde + "&Param.5=" + plant
                          + "&Param.6=" + resource + "&Param.7=" + AreaCde + "&Param.8=" + SAreaCde
                          + "&Param.9=" + FuncLocCde;
                      var oModelDTAnaForCSV = models
                          .createNewJSONModel("com.khc.rephub.controller.analysis.GetChartModif-->getTodayDatepop-->XACQ_GetDTAnalysisForCSV");
                      oModelDTAnaForCSV.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/XACQ_GetDTAnalysisForCSV" + sParams
                          + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelDTAnaForCSV, "oDTAnalysisForCSV");

                      var url = "/XMII/Illuminator?QueryTemplate=" + projectName
                          + "/QueryTemplate/XACQ_GetDTAnalysisForCSV" + sParams
                          + "&Content-Type=text/csv";
                      window.open(url);
                    },
/** *********************************************************************************************************************************************************************************** */
// populate date fields on selection of radio button
/** ************************************************************************************************************************************************************************************** */
                    getDatepop : function(oControlEvent) {
                      var selectedRadioBtn = oControlEvent.getParameters().selectedIndex;
                      UI_utilities.setDateFromFrequency(this.getView(), selectedRadioBtn,
                          "FromTime", "ToTime");

                    },
/** *********************************************************************************************************************************************************************************** */
// on click of Help button
/** ************************************************************************************************************************************************************************************** */
                    onHelp : function() {

                      UI_utilities.OpenHelpFileSingle("Analysis");
                    },
/** *********************************************************************************************************************************************************************************** */
// Set all for combo box
/** ************************************************************************************************************************************************************************************** */
                    
                    setAllForCombox : function() {
                      this.getView().byId("id_dropdown_area").removeAllItems();
                      this.getView().byId("id_dropdown_area").insertItem(new sap.ui.core.Item({
                        key : "All",
                        text : "All"
                      }), 0);
                      this.getView().byId("id_dropdown_area").setSelectedKey("All");
                      
                      this.getView().byId("id_dropdown_catsubarea").removeAllItems();
                      this.getView().byId("id_dropdown_catsubarea").insertItem(
                          new sap.ui.core.Item({
                            key : "All",
                            text : "All"
                          }), 0);
                      this.getView().byId("id_dropdown_catsubarea").setSelectedKey("All");

                    },

                  });
        });