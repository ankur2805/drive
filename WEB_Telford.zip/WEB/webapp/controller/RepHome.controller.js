sap.ui.define([ "sap/ui/core/mvc/Controller", 
		"com/khc/rephub/utils/UI_utilities",
		"com/khc/common/Script/CommonUtility" ,"com/khc/rephub/model/formatter"], function(Controller,
		 UI_utilities, CommonUtility,formatter) {
	"use strict";
	return Controller.extend("com.khc.rephub.controller.RepHome", {
		formatter:formatter,
		onInit : function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("RepHome").attachPatternMatched(
					this._oRoutePatternMatched, this);
			this._oRouter.getRoute("default").attachPatternMatched(
					this._oRoutePatternMatched, this);
			
		
			
		},


		/**
		 * Called when the Routing is matched, 'RepHome'
		 * 
		 */

		_oRoutePatternMatched : function(oEvent) {

			// To set the menu as selected, hide message ad remove busy
			UI_utilities.nonProductionPageOpened(this);
			this.setCustomHeaderText();

	        var oData = {
					validDestination : "false"
				};
	        var oDestModel = new sap.ui.model.json.JSONModel(oData);
			this.getView().setModel(oDestModel, "destModel");
			
			this.validateDestination();
			this.setNcLineButtonVisibility();
		},
		
	setCustomHeaderText:function(){ 
		if( sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuPrdViewer" || 
			sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuInspector"){
			this.getView().byId("customHeader").setText("MII02 Main Menu")
		}
		else{
		this.getView().byId("customHeader").setText("MII Repetitive Hub Main Menu")
		}

	},	
	
	validateDestination : function() {
                var oModel = new sap.ui.model.json.JSONModel();
                var params = "Param.1=" + "REPHUB";
                oModel.loadData("/XMII/Illuminator?QueryTemplate=ReuseLibrary/Common/Query Template/XACQ_GetCRDestByApp&" + params + "&Content-Type=text/json", "", false);
                
                if (CommonUtility.getJsonModelRowCount(oModel.getData()) > 0) {
                	
                	var batchhubCRDest =oModel.getData().Rowsets.Rowset[0].Row[0].O_Destination;
              	   	var sessionCRDest = sap.ui.getCore().getModel("session").getData().CA_CRDest;
	              	
	             if(sessionCRDest!="*"){
	            	 
	           		if(sessionCRDest != batchhubCRDest){
	           			
	           			this.getView().getModel("destModel").setProperty("/validDestination","false");
	           		}
	           		else{
	           			
	           			this.getView().getModel("destModel").setProperty("/validDestination","true");                		}	
	           	}
	           	else{
	           		
	           		this.getView().getModel("destModel").setProperty("/validDestination","true");	
	               }
	}
	},
	
	
		
		onAfterRendering : function() {

			// To set the menu as selected, hide message ad remove busy
			//UI_utilities.menuOpened(this,"RepHome");

		},

		


		onChangeSettingsBT : function() {
			
			// Set the busy indicator until the page  load
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("sessionSetting");
			sap.ui.getCore().getModel("oMenu").setProperty("/selectedMenu","sessionSetting");
		},
                                  
                       checkLogBt : function(){
                     UI_utilities.setContainerBusyState(this,true);
                          var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("logRep");
                              },




		onPressProduction : function() {

			
			// Set the busy indicator until the page  load
			UI_utilities.setContainerBusyState(this,true);
			

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Production");

		},
		onPressresponsive : function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("repHomeResponsive");
		},

		onPressMaintenance : function() {
			this._oRouter.navTo("maintenanceNotification");
		},

		onPressQuality : function() {
			UI_utilities.setContainerBusyState(this,true);

			if(sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuPrdViewer") { 
				this._oRouter.navTo("RepInspectPointViewer");
			}
			else if(sap.ui.getCore().getModel("role").getProperty("/role") ==="MainMenuQualityOperator"){
				this._oRouter.navTo("QualityInspView");
				}
			 else {
				this._oRouter.navTo("InspectionPoint");
			}
		},

		onPressAnalysis: function(){
			this._oRouter.navTo("DowntimeAnalysis");
		},

		OpenManualMaster : function() {

			window.open(sap.ui.getCore().getModel("session").getData().CA_ManualMasterURL, 'ManualMaster', 'width=1050,height=800,scrollbars=yes,left=10,top=10,resizable=yes,status=yes,location=no');
		},
		
		
		LogOff : function(){
			top.location.href='/XMII/Illuminator?service=logout';
		},

		openPlantView : function()  {

			var js_plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
			var js_resr = sap.ui.getCore().getModel("session").oData.CA_Resource;
			window.open('/XMII/CM/NL_ELS_HUB/WebContent/PlantView.html?plant='+js_plant+'&resr='+js_resr, 'PlantView');
			
		},

		OpenNonClearance : function()
		{
			var js_plant=sap.ui.getCore().getModel("session").getData().CA_Plant;
			var js_resr=sap.ui.getCore().getModel("session").getData().CA_Resource;
			var js_crdest=sap.ui.getCore().getModel("session").getData().CA_CRDest;
			var js_uname=sap.ui.getCore().getModel("session").getData().CA_IllumLoginName;
			var js_resrtext=sap.ui.getCore().getModel("session").getData().CA_ResrText;
	
			window.open("/XMII/CM/NL_ELS_HUB/WebContent/Non_Clearance.html?qs_plant="+js_plant+"&qs_resr="+js_resr+"&qs_crdest="+js_crdest+"&qs_uname="+js_uname+"&qs_resrtext="+js_resrtext,"_parent");
		},
		
		onPressShiftReview : function()
		{
			if(sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuPrdViewer") { 
				this._oRouter.navTo("Production");
			} else {
				this._oRouter.navTo("RepShiftReview");
			}
			
		},
		
		setNcLineButtonVisibility: function(sPageName) {
  			var js_plant=sap.ui.getCore().getModel("session").getData().CA_Plant;
  			var js_resr=sap.ui.getCore().getModel("session").getData().CA_Resource;
  			
  			var  dateNw = new Date();
  		
	    		if(js_plant == '3101' && sap.ui.getCore().getModel("role").getProperty("/role") === "RepMainMenuOperator")
	    		{
	    			var oModel = new sap.ui.model.xml.XMLModel();
	    			oModel.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/SQLQ_NC_GetNCFLAG&Param.1="+js_plant+"&Param.2="+js_resr+"&d="+dateNw+"&Content-Type=text/xml","",false);	
	    			var NCFLAG = oModel.getProperty("/Rowset/Row/NCFLAG");
	    			if(NCFLAG != 'Y')
	    			{
	    				// return false;
	    				// set Button visibiliti to false button.setVisible(false)
	    				this.getView().byId("id_btn_ProductionNC").setVisible(false);
	    				this.getView().byId("id_img_ProductionNC").setVisible(false);
				
	    			}
                else
	    		{
	    			this.getView().byId("id_btn_ProductionNC").setVisible(true);
    				this.getView().byId("id_img_ProductionNC").setVisible(true);
	    		}
	    		}
	    		else
	    		{
	    			this.getView().byId("id_btn_ProductionNC").setVisible(false);
    				this.getView().byId("id_img_ProductionNC").setVisible(false);
	    		}
	            	
	              
	           
      },
		
		
	});

});