/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define([
        "sap/ui/core/UIComponent",
        "sap/ui/Device",
        "com/khc/rephub/model/models"
    ],
    function (UIComponent, Device, models) {
        "use strict";

        return UIComponent.extend("com.khc.rephub.Component", {
	
            metadata: {

            	interfaces: [
    				"sap.ui.core.IAsyncContentCreation" 
    			],
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);


                //load Uitility library
                jQuery.sap.require('com.khc.rephub.utils.UI_utilities');
                jQuery.sap.require("com.khc.common.Script.CommonUtility");
                
                
                // Set the resource model based on user's UME language
                var language = document.getElementById("id_hid_lan").value;
               
             	
		var oLocalizationModel = new sap.ui.model.resource.ResourceModel(
					             			{
								bundleUrl : "/XMII/CM/ReuseLibraryUI5/Common/i18n/i18n.properties",
								
								bundleLocale : language
							});
             	 sap.ui.getCore().setModel(oLocalizationModel, "i18n");

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
                sap.ui.getCore().setModel(models.createDeviceModel(), "device");
                sap.ui.getCore().setModel(models.createSessionModel(), "session");
                sap.ui.getCore().setModel(models.createMessageModel(), "oMessage");
                 sap.ui.getCore().setModel(models.createMenuModel(), "oMenu");
                sap.ui.getCore().setModel(models.createAlertModel(), "oAlert");
                sap.ui.getCore().setModel(models.createQualityMenuBarModel(), "oQualityMenuBar");
	  sap.ui.getCore().setModel(models.createRedirectFromChildPage(), "oRedirectFromChildPage");
            },
            getContentDensityClass : function () {
    			if (!this._sContentDensityClass) {
    				if (!Device.support.touch) {
    					this._sContentDensityClass = "sapUiSizeCompact";
    				} else {
    					this._sContentDensityClass = "sapUiSizeCozy";
    				}
    			}
    			return this._sContentDensityClass;
    		}
        });
    }
);