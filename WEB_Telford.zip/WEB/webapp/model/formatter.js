sap.ui.define([], function() {
    "use strict";
    return {

        fnTrimLeadingZeros: function(value) {




            if (value) {

                //	value =  value.replace(/^0+/, '');

                value = value.replace(/\b0+/g, '')

                return value;
            } else {
                return value;
            }
        },

	fnGetLogTypeImage: function(LOGTYPE){
				
				
				
				console.log("fnGetStatusImage  "+status);
				if(LOGTYPE==="E"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
				}
				if(LOGTYPE==="S"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
								}
				if(LOGTYPE==="W"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
				}
				if(LOGTYPE==="I"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/blue.png';
				}
				else{
							return '/XMII/CM/ReuseLibraryUI5/Common/css/magenta.png';
				}
				
			},


        fnGetStatusImage: function(status) {




            if (status.replace(/^\D+/g, '') > 0) {


                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            } else {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }
        },
        //Quality Notif start
        fnQualityNotifStatusImage: function(status) {
	if(status<2){ 
                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
		}
	else if(status>1){ 
                return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
	}
/*if(status<=2){ 
                return 'css/green.png';
}
else if(status<=2&&status>=1){ 
                return 'css/red.png';
}*/

         /*   if (status == 1) {
                return 'css/green.png';
            } else {
                return 'css/red.png';
            }*/
        },
        //Quality Notif End
        //insception Point
        fnPhaseDueTimeStatusImage: function(status) {
            console.log(status)

            if (status == "G") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            }
            if (status == "R") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            }
            if (status == "Y") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }
        },
        fnInspPointStatus: function(Eval  ) {
             var insp5=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0005") 
             var insp4=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0004")  
        
            if (Eval == "Fail") {
                return insp5
            } else if (Eval == "Pass") { 
                    return insp4
            }
        },
        fnInspPointColor: function(Eval, PassColor) {
           
            if(Eval==null){Eval=""}   
	
            if (Eval == "Fail") {
                return "RED"
            } else if (Eval == "Pass") {
                if (PassColor == "G") {
                    return "GREEN"
                } else if (PassColor == "Y") {
                    return "YELLOW"
                }

            }
	else{
		return Eval;
	}

        },//dlt
	fntoString:function(value){
		if(value==null){
		 value='';
		return value;
		}
		else{
		return value.toString();
		}
	},
        fnInspOrderPointColor: function(Eval, PassColor) {
            console.log(Eval + "-" + PassColor)
                
                return "RED"
             

        },//dlt

 fnoGetInspDisplayResultColor: function(Eval) {
            console.log(Eval);
               
           if (Eval == "Accepted" ) {
                    return "GREEN";
            } else  if(Eval == "Rejected") {
                   return "RED";
            } else {
	         return "GREY";
	}
        },

 fnGetEvalBckColor: function(Eval) {
            console.log(Eval);
               
           if (Eval == "Pass" || Eval == "Running") {
                    return "GREEN";
            } else  if(Eval == "Fail" || Eval == "Closed") {
                   return "RED";
            } else {
	         return "YELLOW";
	}
        },
 fnGetStatusBckColor: function(Status) {
            console.log(Status);
               
           if (Status == "Completed") {
                    return "Completed";
            } else  if(Status == "%") {
                   return "%";
            } else if(Status == "Not Started") {
	         return "Not Started";
	} else if(Status == "Partly Finish"){
	         return "Partly Finish";
	}
        },
        fnInspPointGetEval: function(Eval) {
		if(Eval==null){Eval=""}
             var insp1=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0001") 
             var insp2=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0002") 
             var insp3=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0003") 
            
            if (Eval == "Completed") {
                return insp1
            } else if (Eval == "Not Started") { 
                return insp2 
            } else if (Eval == "Partly Finish") { 
                return insp3
            }
	else{
		return Eval;
	}

        },
        //insception Point End
        //insceptionSubmit Start

        fnvaluationImgSrc: function(VALUATION) { 
         

            if (VALUATION == "R") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            } else if (VALUATION == "A") { 
                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            } 

        },
        
        //insception Point End

        productionButtonVisibility: function(sPageName) {


            if (sPageName === "RepMainMenuOperator" || sPageName === "MainMenuSupervisor") {

                return true;
            } else {

                return false;
            }

        },

        MaintenanceButtonVisibility: function(sPageName) {
            if (sPageName === "RepMainMenuOperator" || sPageName === "MainMenuSupervisor") {
                return true;
            } else {

                return false;
            }
        },

        AnalysisButtonVisibility: function(sPageName) {
            if (sPageName === "RepMainMenuOperator" || sPageName === "MainMenuSupervisor" || sPageName === "MainMenuPrdViewer" || sPageName === "MainMenuInspector") {
                return true;
            } else {

                return false;
            }
        },
	fnPhaseDueTimeStatusImageDisplay: function(Lights) {
		console.log(Lights)
           		if (Lights == "G") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            }
            	if (Lights == "R") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            }
            	if (Lights == "Y") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }

	},

	fnStatusBackground: function(Status) {
		console.log(Status)
           		if (Status == "Completed") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            }
            	if (Status == "%") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            }
            	if (Status == "Not started") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }
            	if (Status == "Partly Finish") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/lightgreen.png';
            }
	},
        CheckLogButtonVisibility: function(sPageName) {
            if (sPageName === "RepMainMenuOperator" || sPageName === "MainMenuSupervisor" || sPageName === "MainMenuInspector") {
                return true;
            } else {

                return false;
            }
        },

        NcLineButtonVisibility: function(sPageName) {

            if (sPageName === "RepMainMenuOperator") {
                return true;
            } else {

                return false;
            }

        },

        ShiftReviewButtonVisibility: function(sPageName) {

            if (sPageName === "MainMenuSupervisor" ) {
                return true;
            } else {

                return false;
            }
        },
        
        productionReadOnlyButtonVisibility : function(sPageName) {

            if (sPageName === "MainMenuPrdViewer") {
                return true;
            } else {

                return false;
            }
        },

	ProdHomeNewButtonVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return false;
          		  } else {
             		   return true;
           		 }
        },

	ProdHomeResourceVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return true;
          		  } else {
             		   return false;
           		 }
        	},

ProdHomeMenuBarVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return false;
          		  } else {
             		   return true;
           		 }
        },

ProdHomeMenuBarPrdViewerVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return true;
          		  } else {
             		   return false;
           		 }
        },
fnGetInspDisplayResult: function(parent_page,result,displayResult) {

	console.log(parent_page);

	if (parent_page === "InspPointOrderViewer") {
                return result;
            } else {

                return displayResult;
            }        
        },
/***************************Menu Bar visibility -Quality*************************************************************************************************************************/
/*ProductionQualityMenuBar:function(sPageName){
	if(sPageName==="ProductionQuality1"){
	  return true;
	}
	else{
	  return false;
	}
}*/


   

// Muthu - Performance Issue
        
        fnInspPointGetEvalNew: function(status) {
    		
                 var insp1=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0001") 
                 var insp2=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0002") 
                 var insp3=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0003") 
                
                if (status == "2") {
                    return insp1
                } else if (status == "0") { 
                    return insp2 
                } else if (status == "1") { 
                    return insp3
                }
    	else{
    		return status;
		}
    	},

        fnInspPointStatusNew: function(rejectedCount) {
                    var insp5=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0005") 
                    var insp4=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0004")  
               
                   if (!isNaN(rejectedCount) && rejectedCount>0) {
                       return insp5
                   } else  { 
                           return insp4
                   }
               },
               
       fnInspPointDate: function(inspTime) {
    	   
    	   var date = new Date(inspTime);
    	   let yyyy = date.getFullYear();
    	   let mm = date.getMonth() + 1; // Months start at 0!
    	   let dd = date.getDate();

    	   if (dd < 10) dd = '0' + dd;
    	   if (mm < 10) mm = '0' + mm;

    	   return  dd + '-' + mm + '-' + yyyy;
         },
              
      fnInspPointTime: function(inspTime) {
    	  
    	  return inspTime.split(" ")[1];
                 
             },
            

       fnInspPointColorNew : function(rejectedCount, inspectionCount, MICCount) {


    	   if (!isNaN(rejectedCount) && rejectedCount>0) {
               	return "RED"
			} 
    	   else  {
    		   
				if (inspectionCount == MICCount) {
					return "GREEN"
				} else  {
					return "YELLOW"
				}

			} 

		},
    }
});
