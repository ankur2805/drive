/* global QUnit */

sap.ui.require(["my/test/project1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
