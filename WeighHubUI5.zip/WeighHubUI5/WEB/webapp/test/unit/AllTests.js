sap.ui.define([
	"mytest/project1/test/unit/controller/Test.controller"
], function () {
	"use strict";
});
