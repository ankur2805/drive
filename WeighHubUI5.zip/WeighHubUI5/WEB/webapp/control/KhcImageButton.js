sap.ui.define([ "sap/ui/core/Control","sap/m/Button", "sap/m/Image" ], function(Control,Button, Image) {
	"use strict";

	var KhcImageButton= Control.extend("com.khc.rephub.control.KhcImageButton", {

		metadata : {
			properties : {
				text : {
					type : "string",
					defaultValue : ""
				},
				imgSrc : {
					type : "string",
					defaultValue : ""
				},
				width : {
					type : "sap.ui.core.CSSSize",
					defaultValue : "auto"
				},
				height : {
					type : "sap.ui.core.CSSSize",
					defaultValue : "auto"
				},
				buttonType : {
					type : "string",
					defaultValue : "Unstyled"
				},
				buttonClass: {
					type : "string",
					defaultValue : ""
				},
				buttonClassOnClick: 
				{
					type : "string",
					defaultValue : ""
				},
			},
			aggregations : {
				
				image : {
					type : "sap.m.Image",
					multiple : false,
					visibility : "public"
				},
				button: {
					type : "sap.m.Button",
					multiple : false,
					visibility : "public"
				}
			},
		},
		// hover event handler
		onmousedown : function(evt) {
			 this.getButton().addStyleClass("mainMenuButtonSelection");
			// this.fireMouseDown();
		},
		onmouseup : function(evt) {

			 this.getButton().removeStyleClass('mainMenuButtonSelection');
		},

		init : function() {
			
			var oControl = this,oBtn, oImage;
			
			
			oBtn   = new Button({
               // text: this.getText()
            });
			
			this.setButton(oBtn);
			
			 oImage = new Image({
				src:this.getImgSrc(),
                decorative: true,
               // width: "25px",
                //height: "25px",
                tooltip: "Image for Button"
            });
            this.setImage(oImage);

		},
		
		setText : function (sVal) {
	        if (sVal) {
	            this.getButton().setText(sVal);
	        }
	    },
	    
	    setButtonType: function (sVal) {
	            this.getButton().setType(sVal);
	    },
	    
	    setButtonClass: function (sVal) {
            this.getButton().addStyleClass(sVal);
    },
	    
	    setButtonClassOnClick: function (sVal) {
	           // this.getButton().addStyleClass(sVal);
	    },
	    
	    setImgSrc : function (sVal) {
	        if (sVal) {
	            this.getImage().setSrc(sVal);
	        }
	    },
	
		renderer : {

			render : function(oRm, oControl) {
				
				oRm.openStart("div", oControl);
				//oRm.class("imageButtonClass");
				oRm.openEnd();
				oRm.renderControl(oControl.getAggregation("button"));
				oRm.renderControl(oControl.getAggregation("image"));
				oRm.close("div");
			}

				/*oRm.write("<div");
				oRm.writeControlData(oControl);

				oRm.writeClasses();

				oRm.addStyle("width", oControl.getWidth());
				oRm.addStyle("height", oControl.getHeight());
				oRm.writeStyles();

				oRm.write(">");

				// content:
				
				oRm.write("<div>");
				oRm.renderControl(oControl.getButton());
				oRm.write("</div>");

				oRm.write("<div>");
				oRm.renderControl(oControl.getImage());
				oRm.write("</div>");*/

		}

		
	});
	
	
	return KhcImageButton;
});