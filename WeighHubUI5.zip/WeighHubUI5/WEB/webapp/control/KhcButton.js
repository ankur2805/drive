sap.ui.define([
	"sap/m/Button"
], function (Button) {
	"use strict";

	return Button.extend("com.khc.rephub.control.KhcButton", {

		metadata: {
		    
		  },
		  //hover event handler
		  onmousedown : function(evt) {
			this.addStyleClass('mainMenuButtonSelection');
		   // this.fireMouseDown();
		  },
		  onmouseup : function(evt) {
			   
			  this.removeStyleClass('mainMenuButtonSelection');
			  },
		  renderer: {} //St

	});
});