var plant;
var resource;
var printerID;
var CRId;
var msgid;
var Component;
var OrderId;
var counter;
var MatNoStrip;
var ScaleDecimal;
var addweigh=1;
var gb_material="";
var addblendfrompartial=0;
var PredefinedBagSize;
var PartialFlag;
var kits;
var packingMat;
var minval;
var maxval;
var LowTolerance;
var UpTolerance;
var hid_flag;
var MatCount;
var scanhuFlag;
var PreWeighedBagFlag;
var sumBlendWeight = 0;
var TargetFlag = 0;
var blendcode;
var BackFlag = 0;
var resetFlag = 0;
var CountBlend = 0;
var BlendType ="";
var BlendName = "";
var blendPrintFlag;
var gaugeDialFlag;
var MatPosition=0;
var UpTrgtWgt;
var LowTrgtWgt;
var blendPrintPopupFlag;
var WebsocketConnectionFlag;
var getWeighingMaterialModel;
var currentMaterialModel;
var getWeighingMaterialModel;
var getBatchByMaterialModel;
var scalename;
var PrevComponent;
var CurrSelRow =0;
var uname;
var id_hid_counter;
var hid_eflag;
var currentfocusID;

/*****Partial Weigh variables*****/

var js_FlagBROBatch = 0;
var js_FlagCMDGetSelBatch;
var getPartialMaterialModel;
var selectedRowVar;
var HUSCAN;
var carrysum;
var sumBlendWeight1 = 0;
var PartialBackFlag;
//var popup;

sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/Button",
	"com/khc/weighhub/utils/UI_utilities",
	"com/khc/common/Script/CommonUtility",
	"com/khc/weighhub/model/formatter",
	"sap/m/MessageBox"
	],
	function(Controller,Button,UI_utilities,CommonUtility,formatter,MessageBox) {

	"use strict";
	var plant;
	var resource;

	return Controller.extend("com.khc.weighhub.controller.ReadWeightTest", {
		formatter:formatter,
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("ReadWeightTest").attachPatternMatched(this._oRoutePatternMatched, this);
			console.log("on init function");	
		},

		_oRoutePatternMatched: function(oEvent) {
			console.log("pattern match funtion");
			//UI_utilities.setContainerBusyState(this, true);

			MatPosition=0;
			sumBlendWeight=0;
			PartialBackFlag = false;
			plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
			ScaleDecimal = sap.ui.getCore().getModel("session").oData.CA_ScaleDecimal;
			uname = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
			scalename = sap.ui.getCore().getModel("session").oData.CA_ScaleName;
			printerID =sap.ui.getCore().getModel("session").oData.CA_PrinterID; 
			resource = sap.ui.getCore().getModel("session").oData.CA_Resource;

			if (sap.ui.getCore().getModel("weighingDataModel").oData.qs_matno) {
				MatNoStrip = sap.ui.getCore().getModel("weighingDataModel").oData.qs_matno;
				msgid = sap.ui.getCore().getModel("weighingDataModel").oData.qs_msgid;
				CRId = sap.ui.getCore().getModel("weighingDataModel").oData.qs_crid;
				Component = sap.ui.getCore().getModel("weighingDataModel").oData.qs_comp;
				OrderId = sap.ui.getCore().getModel("weighingDataModel").oData.qs_ordid;
				hid_flag = sap.ui.getCore().getModel("weighingDataModel").oData.qs_navtype;
				id_hid_counter = sap.ui.getCore().getModel("weighingDataModel").oData.qs_counter;
				hid_eflag = sap.ui.getCore().getModel("weighingDataModel").oData.qs_eflag;
			}
			else {
				window.history.back(-1);
			}

			counter = this.getView().byId("txt_Counter").getValue();
			this.getView().byId("id_pageErrorMsg2").setVisible(true);
			this.getView().byId("id_pageErrorMsg1").setVisible(false);
			this.getView().byId("id_pageErrorMsg3").setVisible(false);
			this.getView().byId("txt_Avail").setValue("");
			this.getView().byId("id_btn_ReadScale").setType("Emphasized");
			this.getView().byId("id_chk_partial").setSelected(false);
			this.clearValues();
			this.SetBatch();
			this.SetScaleName();
			this.getGaugeDialFlagFromSharedMem();
			this.getWeighingMaterial();
			UI_utilities.weighPageOpened(this, "ReadWeightTest");
		},

		SetBatch: function() {

			//Component = sap.ui.getCore().getModel("weighingDataModel").oData.qs_comp;

			var counterarray = counter.split("/");
			var counterval = counterarray[0];

			getBatchByMaterialModel = new sap.ui.model.json.JSONModel();
			var batchVar= this.getView().byId("td_select_batch");
			//getBatchByMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchByMaterial&Param.1="+CRId+"&Param.2="+Component+"&Content-Type=text/xml", "", false);
			//sap.ui.getCore().setModel(getBatchByMaterialModel, "getBatchByMaterialData");

			getBatchByMaterialModel.attachRequestCompleted(
					function(){ 
						if(CommonUtility.getJsonModelRowCount(getBatchByMaterialModel.getData()) > 0){
							batchVar.setModel(getBatchByMaterialModel, "getBatchByMaterialData");
						}
					});
			getBatchByMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchByMaterial&Param.1="+CRId+"&Param.2="+Component+"&Content-Type=text/json", "", false);

			var getMatWeighedBatchModel = new sap.ui.model.json.JSONModel();
			getMatWeighedBatchModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetMatWeighedBatch&Param.1="+Component+"&Param.2="+OrderId+"&Param.3="+CRId+"&Content-Type=text/json", "", false);

			if (CommonUtility.getJsonModelRowCount(getMatWeighedBatchModel.getData()) > 0) {
				var DefBatch= getMatWeighedBatchModel.getData().Rowsets.Rowset[0].Row[0].BATCH;
				this.getView().byId("td_select_batch").setSelectedKey(DefBatch);
				var path = this.getView().byId("td_select_batch").getSelectedItem().oBindingContexts.getBatchByMaterialData.sPath;
				var text_avail= getBatchByMaterialModel.getProperty(path+"/AVAIL")
				var avail_unit= text_avail+" "+this.getView().byId("txt_GridUOM").getValue();
				this.getView().byId("txt_Avail").setValue(avail_unit);
			}
		},

		SetScaleName: function() {

			var GetWeighScaleListModel = new sap.ui.model.xml.XMLModel();
			GetWeighScaleListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighScaleList&Content-Type=text/xml", "", false);
			sap.ui.getCore().setModel(GetWeighScaleListModel, "GetWeighScaleListData");
			this.getView().byId("weighScaleList").setSelectedKey(scalename);
		},

		getGaugeDialFlagFromSharedMem: function() {

			var getPlantDetailsFromSharedMemoryModel = new sap.ui.model.json.JSONModel();
			getPlantDetailsFromSharedMemoryModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPlantDetailsFromSharedMemory&Param.1="+plant+"&Content-Type=text/json", "", false);
			blendPrintFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].Output;
			gaugeDialFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].Output_flag;
			blendPrintPopupFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].O_Flag;
			WebsocketConnectionFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].WebSocket_Output_Flag;

		},

		getWeighingMaterial: function() {

			getWeighingMaterialModel = new sap.ui.model.json.JSONModel();
			getWeighingMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighingMaterial&Param.1="+CRId+"&Param.2="+OrderId+"&Content-Type=text/json", "", false);

			var Seq = this.getView().byId("txt_Seq").getValue();

			if(CommonUtility.getJsonModelRowCount(getWeighingMaterialModel.getData())>=(Seq-1)) {
			var MatNo = getWeighingMaterialModel.getData().Rowsets.Rowset[0].Row[Seq-1].MatNo;
			var Blend = getWeighingMaterialModel.getData().Rowsets.Rowset[0].Row[Seq-1].Blend;
			var itemno = getWeighingMaterialModel.getData().Rowsets.Rowset[0].Row[Seq-1].ITEMNO;
			}
			else {

				window.history.back(-1);
			}
			this.getView().byId("txt_ScaleWgt").focus();

			if(hid_flag=="Auto") {

				this.getView().byId("id_btn_ReadManual").setEnabled(false);

				if (Blend != "SINGLE")
				{
					this.getBlendMatDetails(Blend, itemno);
				}
				else
				{
					this.getCurrentMatDetails(MatNo, itemno);
				}
				if (gb_material == "")
				{
					gb_material = Component;
				}
			}
			else {
				this.getView().byId("id_btn_NextIngr").setEnabled(false);
				this.getCurrentMatDetails(MatNo, itemno);
			}
			this.getView().byId("id_btn_ReadScale").setType("Emphasized");
			this.getView().byId("id_btn_NextIngr").setEnabled(false);		

			if (TargetFlag == "0")
			{
				TargetFlag = "1";
			}
		},

		GetBack: function() {
			/*********
			//var qs_mattext=this.getView().byId("txt_GoodDesc").getValue();
			//var qs_matqty=this.getView().byId("txt_PlannedQty").getValue();
			//var qs_uom=this.getView().byId("txt_UOM").getValue();
			//var qs_duedate=this.getView().byId("txt_DueDate").getValue();
			var qs_modmatno=this.getView().byId("txt_modMatNoStrip").getValue();
			var qs_modorderid=this.getView().byId("txt_modOrderId").getValue();
			//var qs_receiveqty=this.getView().byId("txt_RecQty").getValue();
			var qs_toreceiveqty=this.getView().byId("txt_ToRecQty").getValue();

			var weighNewModel = new sap.ui.model.json.JSONModel();
			let weighNewData = {
					qs_msgid:msgid,  
					qs_crid:CRId,
					qs_ordid:OrderId,
					qs_matno:MatNoStrip,
					qs_modmatno:qs_modmatno,
					qs_mattext:qs_mattext,
					qs_modorderid:qs_modorderid,
					qs_matqty:qs_matqty,
					qs_uom:qs_uom,  
					qs_duedate:qs_duedate,
					qs_receiveqty:qs_receiveqty,  
					qs_toreceiveqty:qs_toreceiveqty

			};
			weighNewModel.setData(weighNewData);
			sap.ui.getCore().setModel(weighNewModel, "weighingNewDataModel");
			 *********/
			BackFlag = 1;
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("WeighingListNew1");


		},

		ReadWeight: function() {

			this.getView().byId("id_pageErrorMsg1").setVisible(false);
			var dp = parseInt(ScaleDecimal);
			addweigh = 1;
			sumBlendWeight = sumBlendWeight + parseFloat(addblendfrompartial);
			addblendfrompartial = 0;

			if(PreWeighedBagFlag != false) {

				if(this.getView().byId("txt_ScaleWgt").getValue() % PredefinedBagSize == 0) {

					this.getView().byId("txt_NumberOfBag").setValue(this.getView().byId("txt_ScaleWgt").getValue() / PredefinedBagSize)

				}
				else {

					MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_082"));	
					return;
				}
			}

			var weighType = "";
			var continueFlag = "1";


			if (this.getView().byId("id_chk_partial").getSelected()) {
				console.log("checked")
				PartialFlag = "Partial";
				weighType = "Partial";

				var msg = sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_039");
				var that = this;
				MessageBox.confirm(
						msg, {
							icon: MessageBox.Icon.INFORMATION,
							title: "Message from webpage",
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							onClose: function(oAction) { 
								if(oAction==="OK"){
									continueFlag = "1";
								}
								else {
									continueFlag = "0";
									that.getView().byId("id_btn_NextIngr").setType("Default")
									that.getView().byId("id_btn_ReadScale").setType("Emphasized")
									that.getView().byId("id_btn_NextIngr").setEnabled(false)
								}
							}
						});	

			}
			else {
				PartialFlag = "";
			}

			if (continueFlag == "1") {

				var DestID = "";

				if(plant =="3278") {
					DestID = "MT_SCALES_ELST";
				}
				else if(plant =="3005") {
					DestID = "SCALES_KG";
				}
				else if(plant =="3414") {
					DestID = "SCALES_LL";
				}
				else if(plant =="3309") {
					DestID = "SCALES_PU";
				}

				var O_Weight;
				var TrgtWeight = this.getView().byId("txt_TarWeight").getValue();
				var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
				RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
				var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

				//document.getElementById("txt_ScaleWgt").style.background = "";
				this.getView().byId("id_btn_NextIngr").setType("Default");
				this.getView().byId("id_btn_NextIngr").setEnabled(false);
				this.getView().byId("id_btn_ReadManual").setType("Default");
				this.getView().byId("id_btn_ReadManual").setEnabled(false);

				if (plant !="3137") {
					if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
					{
						var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.005;
						UpTrgtWgt = UpperTrgtWeight;

						var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.005;
						LowTrgtWgt = LowerTrgtWeight;
					}
					else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
					{
						var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.01;
						UpTrgtWgt = UpperTrgtWeight;

						var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.01;
						LowTrgtWgt = LowerTrgtWeight;
					}

					else if (FormatTrgrtWgt > 5)
					{
						var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.05;
						UpTrgtWgt = UpperTrgtWeight;

						var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.05;
						LowTrgtWgt = LowerTrgtWeight;
					}

				}

				else {

					var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
					LowTrgtWgt = LowerTrgtWeight;

					var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;
					UpTrgtWgt = UpperTrgtWeight;

				} 
				if (this.getView().byId("txt_WeighMode").getValue() == "Blend")
				{
					if (CountBlend == counter && BlendName == this.getView().byId("txt_Blend").getValue())
					{
					}
					else if (CountBlend == counter && BlendName == "")
					{
					}
					else
					{
						sumBlendWeight = 0;
					}
				}

				if (sumBlendWeight == "0")
				{
					var FormatupperLmt = parseFloat(UpperTrgtWeight).toFixed(dp);
					var FormatLowerLmt = parseFloat(LowerTrgtWeight).toFixed(dp);
				}
				else
				{
					var FormatupperLmt = parseFloat(UpperTrgtWeight) + parseFloat(sumBlendWeight);
					var FormatLowerLmt = parseFloat(LowerTrgtWeight) + parseFloat(sumBlendWeight);

					var FormatupperLmt = parseFloat(FormatupperLmt).toFixed(dp);
					var FormatLowerLmt = parseFloat(FormatLowerLmt).toFixed(dp);
				}

				if (this.getView().byId("txt_ScaleWgt").getValue() == "")
				{

					var PCoConnectionFlag = parseInt(WebsocketConnectionFlag);

					if(PCoConnectionFlag == 1)
					{
						var Scale = this.getView().byId("weighScaleList").getSelectedKey();
						var GetWeighScaleReadingFromPCoModel = new sap.ui.model.json.JSONModel();
						GetWeighScaleReadingFromPCoModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighScaleReadingFromPCo&Param.1="+plant+"&Param.2="+resource+"&Param.3="+Scale+"&Content-Type=text/json", "", false);

						O_Weight = GetWeighScaleReadingFromPCoModel.getData().Rowsets.Rowset[0].Row[0].Value;


					}
					else {		

						var ReadWeightModel = new sap.ui.model.json.JSONModel();
						ReadWeightModelModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_ReadWeight&Param.1="+DestID+"&Param.2="+scalename+"&Param.3="+FormatLowerLmt+"&Param.4="+FormatupperLmt+"&Content-Type=text/json", "", false);

						O_Weight = ReadWeightModel.getData().Rowsets.Rowset[0].Row[0].O_Weight;

					}
				}
				else
				{
					if (isNaN(this.getView().byId("txt_ScaleWgt").getValue()))
					{
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_077"));	
					}
					else
					{
						O_Weight = this.getView().byId("txt_ScaleWgt").getValue();
					}
				}
				if (this.getView().byId("txt_WeighMode").getValue() == "Blend")
				{
					if (CountBlend == counter && BlendName == this.getView().byId("txt_Blend").getValue())
					{
						var SclWeight = parseFloat(O_Weight) - parseFloat(sumBlendWeight);
					}
					else if (CountBlend == counter && BlendName == "")
					{
						var SclWeight = parseFloat(O_Weight) - parseFloat(sumBlendWeight);
					}
					else
					{
						CountBlend = counter;
						sumBlendWeight = 0;
						var SclWeight = O_Weight;
					}
				}
				else
				{
					var SclWeight = parseFloat(O_Weight);
				}

				this.getView().byId("txt_ScaleWgt").setValue(parseFloat(SclWeight).toFixed(dp));


				if (isNaN(this.getView().byId("txt_ScaleWgt").getValue()) || this.getView().byId("txt_ScaleWgt").getValue()== 0)
				{
					MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_009"));
					this.getView().byId("txt_ScaleWgt").setValue("");
					this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
				}
				else
				{


					SclWeight = parseFloat(SclWeight).toFixed(dp);
					LowerTrgtWeight = parseFloat(LowerTrgtWeight).toFixed(dp)





					if (Number(SclWeight )>=Number( LowerTrgtWeight )&&Number(SclWeight) <= Number(UpperTrgtWeight) && weighType != "Partial")
					{
						BlendName = this.getView().byId("txt_Blend").getValue();
						if (hid_flag == "Auto")
						{
							this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
							//document.getElementById("txt_ScaleWgt").style.background = "#00FF00";
							this.getView().byId("id_btn_NextIngr").setType("Emphasized")
							this.getView().byId("id_btn_ReadScale").setType("Default")
							this.getView().byId("id_btn_NextIngr").setEnabled(true)
						}
						else
						{
							this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
							//document.getElementById("txt_ScaleWgt").style.background = "#00FF00";
							this.getView().byId("id_btn_ReadManual").setType("Emphasized")
							this.getView().byId("id_btn_ReadScale").setType("Default")
							this.getView().byId("id_btn_ReadManual").setEnabled(true)
						}

					}
					else if (weighType == "Partial" && SclWeight < FormatTrgrtWgt && SclWeight > 0)
					{
						BlendName = this.getView().byId("txt_Blend").getValue();
						if (hid_flag == "Auto")
						{
							this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
							this.getView().byId("id_btn_NextIngr").setType("Emphasized")
							this.getView().byId("id_btn_ReadScale").setType("Default")
							this.getView().byId("id_btn_NextIngr").setEnabled(true)
						}
						else
						{
							this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
							//document.getElementById("txt_ScaleWgt").style.background = "#00FF00";
							this.getView().byId("id_btn_ReadManual").setType("Emphasized")
							this.getView().byId("id_btn_ReadScale").setType("Default")
							this.getView().byId("id_btn_ReadManual").setEnabled(true)
						}

					}
					else
					{
						if (hid_flag == "Auto")
						{
							this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
							//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
							this.getView().byId("id_btn_NextIngr").setType("Default")
							this.getView().byId("id_btn_ReadScale").setType("Emphasized")
						}
						else
						{
							this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
							//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
							this.getView().byId("id_btn_ReadManual").setType("Default")
							this.getView().byId("id_btn_ReadScale").setType("Emphasized")
						}
					}
				}

				TargetFlag = "0";

			}

		},

		getBlendMatDetails: function(blend, itemno) {

			var dp = parseInt(ScaleDecimal);		
			currentMaterialModel = new sap.ui.model.json.JSONModel();
			currentMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=WeighHubUI5/QueryTemplate/SQLQ_GetMaterialByBlend&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+blend+"&Param.4="+itemno+"&Content-Type=text/json", "", false);
			//currentMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=Default/AP/SQLQ_GetMaterialByBlend&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+blend+"&Param.4="+itemno+"&Content-Type=text/json", "", false);

			this.getView().byId("txt_WeighMode").setValue("Blend");
		if(CommonUtility.getJsonModelRowCount(currentMaterialModel.getData())>0) {
			if (BlendType == "")
			{
				BlendType = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND;

			}

			if (BlendType != currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND)
			{
				resetFlag = 1;

			}
			
			else {

				resetFlag = 0;
			}

			MatCount = CommonUtility.getJsonModelRowCount(currentMaterialModel.getData());
			kits = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].KITS;
			counter = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].COUNTER;
			var nextCount= parseInt(counter) +1;
			var val= nextCount+"/"+kits;
			this.getView().byId("txt_Counter").setValue(val);

			scanhuFlag = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN;
			blendcode = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLENDCODE;

			var currmatBlendCode= blendcode;
			var criticalFlag=currmatBlendCode.indexOf("*");

			if(criticalFlag!="-1"){

				this.getView().byId("id_pageErrorMsg2").setVisible(true);
			}
			var currentMatAllergen = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].ALLERGEN;

			if(currentMatAllergen=="ALLERGEN"){
				this.getView().byId("id_pageErrorMsg3").setVisible(true);

			}

			this.enableHU();
			this.getView().byId("txt_Blend").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND);
			Component = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATNO;
			this.getView().byId("txt_CompDesc").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATTEXT);
			this.getView().byId("txt_GridUOM").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].UOM);
			var MatQty = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATQTY;
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;

			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}
		
			this.getView().byId("txt_TarWeight").setValue(parseFloat(matquantity).toFixed(dp));
			var removeZeroModel = new sap.ui.model.json.JSONModel();
			removeZeroModel.loadData("/XMII/Illuminator?QueryTemplate=ReuseLibrary/Common/Query Template/XACQ_RemoveZero&Param.1="+Component+"&Content-Type=text/json", "", false);
			this.getView().byId("txt_AbsComponent").setValue(removeZeroModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			//var getLatestBatchModel = new sap.ui.model.json.JSONModel();
			//removeZeroModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetLatestMaterialBatch&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+Component+"&Content-Type=text/json", "", false);
			this.SetBatch();

			var packingFlag = currmatBlendCode.indexOf("P");
			if(packingFlag!="-1"){		
				packingMat = 1;
			}
			if (CountBlend == counter && BlendName == this.getView().byId("txt_Blend").getValue())
			{
				if(packingFlag!="-1"){		
					var trgwt = this.getView().byId("txt_TarWeight").getValue();
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
				}	
				else{
					var trgwt = parseFloat(parseFloat(this.getView().byId("txt_TarWeight").getValue()) + parseFloat(sumBlendWeight));
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
					addweigh= 2;

				}
			}
			else if (CountBlend == counter && BlendName == "")
			{
				if(packingFlag!="-1"){		
					var trgwt = this.getView().byId("txt_TarWeight").getValue();
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
				}	
				else{
					var trgwt = parseFloat(parseFloat(this.getView().byId("txt_TarWeight").getValue()) + parseFloat(sumBlendWeight));
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
					addweigh= 2;
				}
			}
			else
			{
				var trgwt = this.getView().byId("txt_TarWeight").getValue();
				this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
			}
		}
			if (TargetFlag == "1")
			{
				TargetFlag = "2";
			}

			this.UpperLowerLimitValues();
			this.GaugeDialValues();
			this.enableMultipleBag();
		},

		getCurrentMatDetails: function(matno, itemno) {

			var dp = parseInt(ScaleDecimal);
			currentMaterialModel = new sap.ui.model.json.JSONModel();
			currentMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=WeighHubUI5/QueryTemplate/SQLQ_GetMaterialByMatNo&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+matno+"&Param.4="+itemno+"&Content-Type=text/json", "", false);
			this.getView().byId("txt_WeighMode").setValue("Single");
			MatCount = CommonUtility.getJsonModelRowCount(currentMaterialModel.getData());
			kits = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].KITS;
			counter = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].COUNTER;

			var nextCount= parseInt(counter) +1;
			var val= nextCount+"/"+kits;
			this.getView().byId("txt_Counter").setValue(val);

			blendcode = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLENDCODE;
			var currmatBlendCode = blendcode;
			var criticalFlag = currmatBlendCode.indexOf("*");

			if(criticalFlag!="-1"){
				this.getView().byId("id_pageErrorMsg2").setVisible(true);
			}

			var currentMatAllergen = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].ALLERGEN;
			if(currentMatAllergen=="ALLERGEN"){
				this.getView().byId("id_pageErrorMsg3").setVisible(true);

			}
			this.getView().byId("txt_Blend").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND);
			Component = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATNO;
			this.getView().byId("txt_CompDesc").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATTEXT);
			this.getView().byId("txt_GridUOM").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].UOM);
			var MatQty = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATQTY;
			scanhuFlag= currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN;

			this.enableHU();
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;
			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}

			this.getView().byId("txt_TarWeight").setValue(parseFloat(matquantity).toFixed(dp));
			var trgwt = this.getView().byId("txt_TarWeight").getValue();
			this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
			var removeZeroModel = new sap.ui.model.json.JSONModel();
			removeZeroModel.loadData("/XMII/Illuminator?QueryTemplate=ReuseLibrary/Common/Query Template/XACQ_RemoveZero&Param.1="+Component+"&Content-Type=text/json", "", false);
			this.getView().byId("txt_AbsComponent").setValue(removeZeroModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			this.SetBatch();	
			this.UpperLowerLimitValues();
			this.GaugeDialValues();

			if (TargetFlag == "1")
			{
				TargetFlag = "2";
			}

			this.enableMultipleBag();
			this.checkAvailability();	
/*****
			if(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN == "S" || currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN == "B"){

			this.getView().byId("td_select_batch").setSelectedKey(null)
			this.getView().byId("txt_selected_batch").setValue(""); 
			this.getView().byId("txt_Avail").setValue(""); 

			} *****/
		},

		UpperLowerLimitValues: function() {

			var SclWgt = parseFloat(this.getView().byId("txt_ScaleWgt").getValue());
			var dp = parseInt(ScaleDecimal);
			var TrgtWgt = this.getView().byId("txt_TargetWeight").getValue();
			var TrgtWeight = this.getView().byId("txt_TarWeight").getValue();
			var TarWeight = TrgtWeight.replace("," , ".");
			var FormatTrgrtWgt = parseFloat(TarWeight);


			if (hid_flag != "Auto")
			{
				if (plant !="3137")
				{

					if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
					{
						LowTolerance = parseFloat(FormatTrgrtWgt) - 0.005;
						UpTolerance = parseFloat(FormatTrgrtWgt) + 0.005;
					}

					else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
					{
						LowTolerance = parseFloat(FormatTrgrtWgt) - 0.01;
						UpTolerance = parseFloat(FormatTrgrtWgt) + 0.01;
					}

					else if (FormatTrgrtWgt > 5)
					{
						LowTolerance = parseFloat(FormatTrgrtWgt) - 0.05;
						UpTolerance = parseFloat(FormatTrgrtWgt) + 0.05;
					}

				}
				else {

					LowTolerance = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
					UpTolerance = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

				}
				LowTolerance = parseFloat(LowTolerance).toFixed(dp);
				UpTolerance = parseFloat(UpTolerance).toFixed(dp);
			}
			else
			{
				if (plant !="3137")
				{
					if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
					{
						LowTolerance = parseFloat(TrgtWgt) - 0.005;
						UpTolerance = parseFloat(TrgtWgt) + 0.005;
					}
					else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
					{
						LowTolerance = parseFloat(TrgtWgt)  - 0.01;
						UpTolerance = parseFloat(TrgtWgt) + 0.01;
					}
					else if (FormatTrgrtWgt > 5)
					{
						LowTolerance = parseFloat(TrgtWgt) - 0.05;
						UpTolerance = parseFloat(TrgtWgt)  + 0.05;
					}
				}

				else {

					LowTolerance = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
					UpTolerance = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

				} 
				LowTolerance = parseFloat(LowTolerance).toFixed(dp);
				UpTolerance = parseFloat(UpTolerance).toFixed(dp);
			}

			this.getView().byId("id_display_UpTrgtWgt").setValue(UpTolerance);
			this.getView().byId("id_display_LowTrgtWgt").setValue(LowTolerance);
		},

		GaugeDialValues: function() {

			var Flag = parseInt(gaugeDialFlag);
			if(Flag == 1)
			{

				var SclWgt = parseFloat(this.getView().byId("txt_ScaleWgt").getValue());
				var dp = parseInt(ScaleDecimal);
				var TrgtWgt = this.getView().byId("txt_TarWeight").getValue();
				var TarWeight = TrgtWgt.replace("," , ".");
				var FormatTrgrtWgt = parseFloat(TarWeight);

				if (hid_flag != "Auto")
				{
					if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
					{
						LowTolerance = (parseFloat(FormatTrgrtWgt) - 0.005).toFixed(dp);
						UpTolerance = (parseFloat(FormatTrgrtWgt) + 0.005).toFixed(dp);
						minval = (parseFloat(FormatTrgrtWgt) - 0.005 - 0.005).toFixed(dp);
						maxval = (parseFloat(FormatTrgrtWgt) + 0.005 + 0.005).toFixed(dp);
						this.GaugeDialTest();
					}

					else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
					{
						LowTolerance = (parseFloat(FormatTrgrtWgt) - 0.01).toFixed(dp);
						UpTolerance = (parseFloat(FormatTrgrtWgt) + 0.01).toFixed(dp);
						minval = (parseFloat(FormatTrgrtWgt) - 0.01 - 0.01).toFixed(dp);
						maxval = (parseFloat(FormatTrgrtWgt) + 0.01 + 0.01).toFixed(dp);
						this.GaugeDialTest();
					}

					else if (FormatTrgrtWgt > 5)
					{
						LowTolerance = (parseFloat(FormatTrgrtWgt) - 0.05).toFixed(dp);
						UpTolerance = (parseFloat(FormatTrgrtWgt) + 0.05).toFixed(dp);
						minval = (parseFloat(FormatTrgrtWgt) - 0.05 - 0.05).toFixed(dp);
						maxval = (parseFloat(FormatTrgrtWgt) + 0.05 + 0.05).toFixed(dp);
						this.GaugeDialTest();
					}

				}
				else
				{

					if (this.getView().byId("txt_TarWeight").getValue() == this.getView().byId("txt_TargetWeight").getValue())
					{

						if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.005 - 0.005).toFixed(dp);
							maxval = (parseFloat(TrgtWgt) + 0.005 + 0.005).toFixed(dp);
							LowTolerance = (parseFloat(TrgtWgt) - 0.005).toFixed(dp);
							UpTolerance = (parseFloat(TrgtWgt) + 0.005).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.01 - 0.01).toFixed(dp);
							maxval = (parseFloat(TrgtWgt) + 0.01 + 0.01).toFixed(dp);
							LowTolerance = (parseFloat(TrgtWgt)  - 0.01).toFixed(dp);
							UpTolerance = (parseFloat(TrgtWgt) + 0.01).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.05 - 0.05).toFixed(dp);
							maxval = (parseFloat(TrgtWgt) + 0.05 + 0.05).toFixed(dp);
							LowTolerance = (parseFloat(TrgtWgt) - 0.05).toFixed(dp);
							UpTolerance = (parseFloat(TrgtWgt)  + 0.05).toFixed(dp);
							this.GaugeDialTest();
						}

					}
					else
					{

						if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.005 - 0.005).toFixed(dp);
							maxval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.005 + 0.005).toFixed(dp);
							LowTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.005).toFixed(dp);
							UpTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.005).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.01 - 0.01).toFixed(dp);
							maxval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.01 + 0.01).toFixed(dp);
							LowTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.01).toFixed(dp);
							UpTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.01).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.05 - 0.05).toFixed(dp);
							maxval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.05 + 0.05).toFixed(dp);
							LowTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.05).toFixed(dp);
							UpTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.05).toFixed(dp);
							this.GaugeDialTest();
						}

					}
				}
			}
			else
			{
				this.getView().byId("gaugeDial").setVisible(false);
			}

		},

		enableMultipleBag: function () {

			var GetBagSizeOfMaterialModel = new sap.ui.model.json.JSONModel();
			GetBagSizeOfMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBagSizeOfMaterial&Param.1="+OrderId+"&Param.2="+Component+"&Content-Type=text/json", "", false);

			var Status = GetBagSizeOfMaterialModel.getData().Rowsets.Rowset[0].Row[0].Status;
			PredefinedBagSize = GetBagSizeOfMaterialModel.getData().Rowsets.Rowset[0].Row[0].BagSize;
			var TrgtWeight = this.getView().byId("txt_TarWeight").getValue();
			var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
			RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
			var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);


			if (Status == "S" && PredefinedBagSize<=FormatTrgrtWgt)
			{

				PreWeighedBagFlag=true;

				this.getView().byId("id_td_NumberOfBag").setVisible(true);
				if (PrevComponent!=Component){
					//document.getElementById("txt_NumberOfBag").value=1;
					this.getView().byId("txt_NumberOfBag").setValue("1");

				}
				this.getView().byId("td_txt_PreWeighedBagSize").setVisible(true);
				this.getView().byId("txt_PreWeighedBagSize").setValue(PredefinedBagSize);

				if(FormatTrgrtWgt % PredefinedBagSize != 0)
				{
					this.getView().byId("id_chk_partial").setSelected(true);
				}
				else {
					this.getView().byId("id_chk_partial").setSelected(false);
				}
			}
			else {
				this.getView().byId("id_td_NumberOfBag").setVisible(false);
				this.getView().byId("td_txt_PreWeighedBagSize").setVisible(false);
				PreWeighedBagFlag=false;
			}

			PrevComponent=Component;
		},

		checkAvailability: function() {

			var available_qty = this.getView().byId("txt_Avail").getValue();
			available_qty = available_qty.split(" ");

			var dp = parseInt(ScaleDecimal);

			if (available_qty[0] == "")
			{}
			else
			{
				var avail = parseFloat(available_qty[0]);
				var quantity_remain = avail -  this.getView().byId("txt_TarWeight").getValue();

		if (quantity_remain < 0)
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("yellowColor");
		else if (available_qty == 0)
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("redColor");
		else
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("nuetral");

			}

		},

		enableHU: function() {

			this.getView().byId("txt_selected_batch").setValue(this.getView().byId("td_select_batch").getSelectedKey())

			if(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN == "N"){

				this.getView().byId("id_btn_ScanHU").setVisible(false); 
				this.getView().byId("id_td_HUNumber").setVisible(false);
				this.getView().byId("td_display_selected_batch").setVisible(false); 
			}
			else if(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN == "S"){

				this.getView().byId("txt_HUNumber").setValue(""); 
				this.getView().byId("id_btn_ScanHU").setVisible(true); 
				this.getView().byId("id_td_HUNumber").setVisible(true);
				this.getView().byId("td_display_selected_batch").setVisible(true); 
				this.getView().byId("td_batch").setVisible(false); 
			}
			else if(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN == "B"){

				this.getView().byId("txt_HUNumber").setValue(""); 
				this.getView().byId("id_btn_ScanHU").setVisible(true); 
				this.getView().byId("id_td_HUNumber").setVisible(true);
				this.getView().byId("td_display_selected_batch").setVisible(false); 
				this.getView().byId("td_batch").setVisible(true); 
			}
			else{
				this.getView().byId("id_btn_ScanHU").setVisible(false); 
				this.getView().byId("id_td_HUNumber").setVisible(false);
				this.getView().byId("td_display_selected_batch").setVisible(false); 
				this.getView().byId("td_batch").setVisible(true); 
			}
		},

		GaugeDialTest: function() {

			var ScaleName = this.getView().byId("weighScaleList").getSelectedKey();

			var GetWeighScaleTagModel = new sap.ui.model.xml.XMLModel();
			GetWeighScaleTagModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWeighScaleTag&Param.1="+plant+"&Param.2="+resource+"&Param.3="+ScaleName+"&Content-Type=text/xml", "", false);
			var wsport = '';
			if(CommonUtility.getJsonModelRowCount(GetWeighScaleTagModel.getData()) > 0) {
				if(GetWeighScaleTagModel.getData().Rowsets.Rowset[0].Row[0] != null) {
					wsport = GetWeighScaleTagModel.getData().Rowsets.Rowset[0].Row[0].WSPORT;
				}
			}
			var GetHostNameModel = new sap.ui.model.xml.XMLModel();
			GetHostNameModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XMLQ_GetHostName&Content-Type=text/xml", "", false);
			var hostname = '';
			if(CommonUtility.getJsonModelRowCount(GetHostNameModel.getData()) > 0) {
				if(GetHostNameModel.getData().Rowsets.Rowset[0].Row[0] != null) {
					hostname = GetHostNameModel.getData().Rowsets.Rowset[0].Row[0].PropertyValue;
				}
			}
			var port = hostname+":"+wsport;
			//"/XMII/CM/GBL_WEIGHING/WeighScale_Graphics/HTML/Gauge.html?min=0.790&max=0.810&val=&lowlimit=0.795&highlimit=0.805&ScaleName=MET3334519&port=NEURQMIAPP001:"

			if(this.getView().byId("txt_ScaleWgt").getValue() == "") {
				var value = "";
				let sInspParams = "min="+minval+"&max="+maxval+"&val="
				+value+"&lowlimit="+LowTolerance+"&highlimit="+UpTolerance+"&ScaleName="
				+ScaleName+"&port="+port;
				var frame = this.getView().byId("id_frame_gauageDial");
				var  oFrameContent = frame .$()[0];
				let sBaseURL = "/XMII/CM/GBL_WEIGHING/WeighScale_Graphics/HTML/Gauge.html?";
				//if(resetChartType != undefined || resetChartType != null) {
				oFrameContent.setAttribute("src", sBaseURL+sInspParams);
				//}
			} else  {
				var frame = this.getView().byId("id_frame_gauageDial");
				var  oFrameContent = frame .$()[0];
				oFrameContent.setAttribute("src", ""); 
			}
		},

		ValidateInputs: function() {

			var SclWgt = parseFloat(this.getView().byId("txt_ScaleWgt").getValue());
			var LowTrgtWgt = parseFloat(LowTrgtWgt);
			var UpTrgtWgt = parseFloat(UpTrgtWgt);
			var dp = parseInt(ScaleDecimal);

			var TrgtWeight = this.getView().byId("txt_TarWeight").getValue();
			var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
			RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
			var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			if (plant!="3137")
			{

				if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.005;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.005;
				}

				else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.01;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.01;
				}

				else if (FormatTrgrtWgt > 5)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.05;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.05;
				}
			}
			else {


				LowTrgtWgt = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
				UpTrgtWgt = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

			}
			LowTrgtWgt = parseFloat(LowTrgtWgt).toFixed(dp);
			UpTrgtWgt = parseFloat(UpTrgtWgt).toFixed(dp);

			if (this.getView().byId("txt_ScaleWgt").getValue() == "")
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_005"));
			}
			else if (isNaN(this.getView().byId("txt_ScaleWgt").getValue()))
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_006"));
			}


			else if ((PreWeighedBagFlag!=false && this.getView().byId("txt_ScaleWgt").getValue()/PredefinedBagSize!=this.getView().byId("txt_NumberOfBag").getValue() )|| (PreWeighedBagFlag!=false &&  this.getView().byId("txt_ScaleWgt").getValue()%PredefinedBagSize!=0))
			{

				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_082"));

			}
			else if (this.getView().byId("td_select_batch").getSelectedItem() == null)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_007"));
			}

			else
			{

				if (PartialFlag == "Partial")
				{
					if (SclWgt < FormatTrgrtWgt && SclWgt > 0)
					{
						this.InsMatWeigh1();
						this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
						//document.getElementById("txt_ScaleWgt").style.background = "#FFFFFF";
						this.getView().byId("id_btn_NextIngr").setType("Default");
						this.getView().byId("id_btn_ReadScale").setType("Emphasized")
						this.getView().byId("id_btn_NextIngr").setEnabled(false)
					}
					else
					{
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_008"));
						this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
						//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
						this.getView().byId("id_btn_NextIngr").setType("Default");
						this.getView().byId("id_btn_ReadScale").setType("Emphasized")
						this.getView().byId("id_btn_NextIngr").setEnabled(false)

					}
				}
				else if (SclWgt < LowTrgtWgt || SclWgt > UpTrgtWgt)
				{
					MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_008"));
					this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
					//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
					this.getView().byId("id_btn_NextIngr").setType("Default");
					this.getView().byId("id_btn_ReadScale").setType("Emphasized")
					this.getView().byId("id_btn_NextIngr").setEnabled(false)
				}
				else
				{
					this.InsMatWeigh1();
					this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
					//document.getElementById("txt_ScaleWgt").style.background = "#FFFFFF";
					this.getView().byId("id_btn_NextIngr").setType("Default");
					this.getView().byId("id_btn_ReadScale").setType("Emphasized")
					this.getView().byId("id_btn_NextIngr").setEnabled(false)
				}

				this.UpperLowerLimitValues();	
				this.GaugeDialRecreate();
				this.GaugeDialValues();

			}
		},

		InsMatWeigh1: function() {

			var modorderid = this.getView().byId("txt_modOrderId").getValue();	
			var modMatNoStrip = this.getView().byId("txt_modMatNoStrip").getValue();	
			var GoodDesc = this.getView().byId("txt_GoodDesc").getValue();	
			var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();	
			var xt_UOM = this.getView().byId("txt_UOM").getValue();	
			var xt_gridUOM = this.getView().byId("txt_GridUOM").getValue();	
			var DueDate = this.getView().byId("txt_DueDate").getValue();	
			var WeighMode = this.getView().byId("txt_WeighMode").getValue();	
			var Seq = this.getView().byId("txt_Seq").getValue();	
			var Blend = this.getView().byId("txt_Blend").getValue();	
			var AbsComponent = this.getView().byId("txt_AbsComponent").getValue();	
			var CompDesc = this.getView().byId("txt_CompDesc").getValue();	
			var batchsel = this.getView().byId("td_select_batch").getSelectedKey();
			var weighlist = this.getView().byId("weighScaleList").getValue();	
			var counter = this.getView().byId("txt_Counter").getValue();
			var avail = this.getView().byId("txt_Avail").getValue();
			//var modorderid = this.getView().byId("txt_WeighMode").getValue();	
			//var modorderid = this.getView().byId("txt_Seq").getValue();	
			/****
			var weighDataModelPartial = new sap.ui.model.json.JSONModel();
			let weighDataPartial = {
					qs_desc:CompDesc,
					qs_matqty:PlannedQty,
					qs_uom:xt_UOM,
					qs_griduom:xt_gridUOM,
					qs_duedate:DueDate,
					qs_mattext:GoodDesc,
					qs_modorderid:modorderid,
					qs_modmatno:modMatNoStrip,
					qs_blend:Blend,
					qs_AbsComp:AbsComponent,
					qs_batch:batchsel,
					qs_weighl:weighlist,
					qs_count:counter,
					qs_avail:avail
			};	
			weighDataModelPartial.setData(weighDataPartial);
			sap.ui.getCore().setModel(weighDataModelPartial, "weighingDataModelPartial");
			 ****/
			//this.getView().byId("id_pageErrorMsg4").setVisible(false);

			var ItemCount = CommonUtility.getJsonModelRowCount(getWeighingMaterialModel.getData());
			var currentkitseq = "";
			var partialComponent = "";
			var dp = parseInt(ScaleDecimal);
			var CurrentPredefinedBagFlag=PreWeighedBagFlag;
			var Seq = this.getView().byId("txt_Seq").getValue();
			var Blend; 
			if(CommonUtility.getJsonModelRowCount(getWeighingMaterialModel.getData())>=(Seq-1)) {
			Blend = getWeighingMaterialModel.getData().Rowsets.Rowset[0].Row[Seq-1].Blend;
			}
			else {
				window.history.back(-1);
			}
			var selBatch = this.getView().byId("td_select_batch").getSelectedKey();

			var TotalKits = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].KITS;
			var Count = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].COUNTER;
			var MatNo = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATNO;
			var uom = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].UOM;
			var MatText = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATTEXT;
			var Blend = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND;
			var itemno = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].ITEMNO;

			var MatQty = this.getView().byId("txt_ScaleWgt").getValue();
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;
			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}
			if (parseInt(Count) < parseInt(TotalKits))
			{
				//var insertweighQObj = document.APLT_CMD_InsertWeigh.getQueryObject();
				var Bags;
				if (PreWeighedBagFlag==false){
					Bags="";

				}
				else {
					Bags=this.getView().byId("txt_NumberOfBag").getValue();
				}


				var InsertWeighingModel = new sap.ui.model.json.JSONModel();
				InsertWeighingModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_InsertWeighing&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+MatNo+"&Param.4="+selBatch+"&Param.5=1&Param.6="+matquantity+"&Param.7="+uom+"&Param.8="+MatText+"&Param.9="+Blend+"&Param.10=0&Param.11="+itemno+"&Param.12="+scalename+"&Param.13="+uname+"&Param.14="+Bags+"&Content-Type=text/json", "", false);

				currentkitseq = InsertWeighingModel.getData().Rowsets.Rowset[0].Row[0].KITSEQ;
			}

			if (PartialFlag == "Partial")
			{

				//var insPartialWeighQObj = document.APLT_CMD_InsPartial.getQueryObject();

				var partialMatQty = parseFloat(this.getView().byId("txt_TarWeight").getValue() - this.getView().byId("txt_ScaleWgt").getValue());

				partialComponent = MatNo;

				var partialQtyFormat = parseFloat(partialMatQty).toFixed(dp)

				var InsPartialMaterialModel = new sap.ui.model.json.JSONModel();
				InsPartialMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_InsPartialMaterial&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+MatNo+"&Param.5="+MatText+"&Param.6="+uom+"&Param.7="+partialQtyFormat+"&Param.8=0.00&Param.9="+this.getView().byId("txt_Counter").getValue()+"&Param.10="+this.getView().byId("txt_Blend").getValue()+"&Param.11="+itemno+"&Param.12="+currentkitseq+"&Content-Type=text/json", "", false);

			}

			if (Blend != "SINGLE")
			{

				if(packingMat =="1"){
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(MatQty));
				}

				else{
					sumBlendWeight = sumBlendWeight + parseFloat(MatQty);
					this.getView().byId("txt_TargetWeight").setValue(sumBlendWeight.toFixed(dp));
				}

				packingMat = 0;
				if (parseInt(Count) < parseInt(TotalKits))
				{
					if (parseInt(MatPosition) <= parseInt(MatCount))
					{
						var CurrNo = parseInt(Count) + 1;

						var UpdMatWeighModel = new sap.ui.model.json.JSONModel();
						UpdMatWeighModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdMatWeigh&Param.1="+CurrNo+"&Param.2="+TotalKits+"&Param.3="+CRId+"&Param.4="+OrderId+"&Param.5="+MatNo+"&Param.6="+itemno+"&Content-Type=text/json", "", false);

						var OutputFlag = parseInt(blendPrintFlag);
						if(OutputFlag == 1)
						{	
							if (MatPosition == parseInt(MatCount))
							{	

								if ((PreWeighedBagFlag==false && PartialFlag != "Partial") || PreWeighedBagFlag==true)
								{
									var Flag =parseInt(blendPrintPopupFlag);
									if(Flag == 1)
									{

										window.open('/XMII/CM/WeighHubUI5/webapp/irpt/BlendReport.irpt?qs_ordid=' + OrderId + '&qs_Blend=' + this.getView().byId("txt_Blend").getValue()+ '&qs_KitSeq=' + currentkitseq + '&qs_CompMat=' +Component, 'BlendReport', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');
									}

									else
									{
										var var1=this.getView().byId("txt_Blend").getValue();
										var var2=Component;
										var SendDataToThePrinterModel = new sap.ui.model.json.JSONModel();
										SendDataToThePrinterModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_AllBlendLabelPrint&Param.1="+OrderId+"&Param.2="+var1+"&Param.3="+currentkitseq+"&Param.4="+var2+"&Param.5=false&Param.6="+printerID+"&Content-Type=text/json", "", false);

									}

									var UpdateBlendPrintStatusModel = new sap.ui.model.json.JSONModel();
									UpdateBlendPrintStatusModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateBlendPrintStatus&Param.1="+plant+"&Param.2="+resource+"&Param.3="+OrderId+"&Param.4="+this.getView().byId("txt_Blend").getValue()+"&Param.5="+currentkitseq+"&Content-Type=text/json", "", false);

								}	
							}
						}
						//this.getView().byId("id_chk_partial").setSelected(false);
						var position = MatPosition;
						if (parseInt(MatPosition) < parseInt(MatCount-1))
						{
							MatPosition = parseInt(MatPosition) + 1;

						}
						else
						{
							MatPosition= 0;
						}

						if (parseInt(CurrNo) == parseInt(TotalKits))
						{
							if (parseInt(position) == parseInt(MatCount-1))
							{
								var currentSeq = parseInt(this.getView().byId("txt_Seq").getValue()) + parseInt(MatCount);

								if (parseInt(currentSeq) <= parseInt(ItemCount))
								{

									this.getView().byId("txt_Seq").setValue(eval(this.getView().byId("txt_Seq").getValue()) + eval(MatCount));
									this.getWeighingMaterial();

								}
								else
								{
									if (PartialFlag == "Partial"){
										PartialBackFlag=true;
									}
									else{
										this.GetBack();
									}
								}

							}
							else
							{
								this.getBlendMatDetails(Blend, itemno);
							}
						}
						else
						{
							this.getBlendMatDetails(Blend, itemno);
						}
					}
				}
				else
				{
					this.getView().byId("txt_Seq").setValue(parseInt(this.getView().byId("txt_Seq").getValue()) + parseInt(MatCount));
					this.getWeighingMaterial();
				}
			}

			else
			{
				if (parseInt(Count) < parseInt(TotalKits))
				{
					var CurrNo = parseInt(Count) + 1;

					var UpdCounterDataModel = new sap.ui.model.json.JSONModel();
					UpdCounterDataModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdMatWeigh&Param.1="+CurrNo+"&Param.2="+TotalKits+"&Param.3="+CRId+"&Param.4="+OrderId+"&Param.5="+MatNo+"&Param.6="+itemno+"&Content-Type=text/json", "", false);

					var OutputFlag = parseInt(blendPrintFlag);
					if(OutputFlag == 1)
					{
						if (MatPosition == parseInt(MatCount))
						{	


							if ((PreWeighedBagFlag==false && PartialFlag != "Partial") || PreWeighedBagFlag==true)
							{
								var Flag =parseInt(blendPrintPopupFlag);
								if(Flag == 1)
								{

									window.open('/XMII/CM/WeighHubUI5/webapp/irpt/BlendReport.irpt?qs_ordid=' + OrderId + '&qs_Blend=' + this.getView().byId("txt_Blend").getValue()+ '&qs_KitSeq=' + currentkitseq + '&qs_CompMat=' +Component, 'BlendReport', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');

								}

								else
								{

									var SendDataToThePrinterModel = new sap.ui.model.json.JSONModel();
									SendDataToThePrinterModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_AllBlendLabelPrint&Param.1="+OrderId+"&Param.2="+this.getView().byId("txt_Blend").getValue()+"&Param.3="+currentkitseq+"&Param.4="+Component+"&Param.5=false&Param.6="+printerID+"&Content-Type=text/json", "", false);

									var msg=SendDataToThePrinterModel.getData().Rowsets.Rowset[0].Row[Seq-1].O_MSG;

								}


								var UpdateBlendPrintStatusModel = new sap.ui.model.json.JSONModel();
								UpdateBlendPrintStatusModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateBlendPrintStatus&Param.1="+plant+"&Param.2="+resource+"&Param.3="+OrderId+"&Param.4="+this.getView().byId("txt_Blend").getValue()+"&Param.5="+currentkitseq+"&Content-Type=text/json", "", false);

							}	
						}
					}


					if (parseInt(CurrNo) == parseInt(TotalKits))
					{
						var currentSeq = parseInt(this.getView().byId("txt_Seq").getValue()) + parseInt(MatCount);
						if (parseInt(currentSeq) <= parseInt(ItemCount))
						{
							this.getView().byId("txt_Seq").setValue(parseInt(this.getView().byId("txt_Seq").getValue()) + parseInt(MatCount));
							this.getWeighingMaterial();
						}
						else
						{
							this.GetBack();
						}
					}
					else
					{
						this.getCurrentMatDetails(MatNo, itemno);
					}

				}
				else
				{
					this.getView().byId("txt_Seq").setValue(parseInt(this.getView().byId("txt_Seq").getValue()) + parseInt(MatCount));
					this.getWeighingMaterial();
				}
			}

			this.getView().byId("txt_ScaleWgt").setValue("");

			if (PreWeighedBagFlag==false){

				this.getView().byId("id_chk_partial").setSelected(false);
			}

			if (Component != gb_material.toString())
			{
				if (gb_material != "")
				{
					this.getView().byId("id_pageErrorMsg1").setVisible(true);
					this.getView().byId("id_pageErrorMsg2").setVisible(false);
				}
				gb_material = Component;
			}

			if (parseInt(id_hid_counter) >= parseInt(kits))
			{
				this.GetBack();
			}

			if (PartialFlag == "Partial")
			{

				var MatNo = MatNoStrip;
				var MatDesc = this.getView().byId("txt_GoodDesc").getValue();
				var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();
				var UoM = this.getView().byId("txt_UOM").getValue();
				var DueDate = this.getView().byId("txt_DueDate").getValue();
				var modOrderId = this.getView().byId("txt_modOrderId").getValue();
				var modMatNo = this.getView().byId("txt_modMatNoStrip").getValue();
				var carrysum = parseFloat(sumBlendWeight);
				var recvquantity = sap.ui.getCore().getModel("weighingDataModel").oData.qs_receiveqty;
				var quantitytorecv = sap.ui.getCore().getModel("weighingDataModel").oData.qs_toreceiveqty;
				var PopUp=true;


				if(CurrentPredefinedBagFlag == false)
				{
					//popupWindow = window.open("ReadWeightPartial.irpt?qs_crid=" + CRId + "&qs_msgid=" + MsgId + "&qs_ordid=" + OrderId + "&qs_carrysum=" + carrysum + "&qs_comp=" + partialComponent + "&qs_matno=" + MatNo + "&qs_matqty=" + PlannedQty + "&qs_uom=" + UoM + "&qs_duedate=" + DueDate + "&qs_mattext=" + MatDesc + "&qs_modorderid=" + modOrderId + "&qs_receiveqty=" + recvquantity + "&qs_toreceiveqty=" + quantitytorecv + "&qs_modmatno=" + modMatNo + "&qs_popupFlag=PopUp", "_blank", "directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=1152, height=700,top=20,left=0");
					var weighDataModelPartial = new sap.ui.model.json.JSONModel();
					let weighDataPartial = {
							qs_desc:modOrderId,
							qs_matqty:PlannedQty,
							qs_uom:UoM,
							qs_duedate:DueDate,
							qs_mattext:MatDesc,
							qs_modorderid:modOrderId,
							qs_modmatno:modMatNo,
							qs_blend:Blend,
							qs_AbsComp:AbsComponent,
							qs_batch:batchsel,
							qs_weighl:weighlist,
							qs_count:counter,
							qs_avail:avail,
							qs_popupFlag:PopUp,
							qs_carrysum:carrysum
					};	
					weighDataModelPartial.setData(weighDataPartial);
					sap.ui.getCore().setModel(weighDataModelPartial, "weighingDataModelPartial");

					if (!this.oPartialPopup) {
						this.oPartialPopup = sap.ui.xmlfragment("com.khc.weighhub.view.ReadWeightPartialDialog", this);

					}

					this.oPartialPopup.open();
				}
				else
				{
					var weighDataModelPartial = new sap.ui.model.json.JSONModel();
					let weighDataPartial = {
							qs_desc:modOrderId,
							qs_matqty:PlannedQty,
							qs_uom:UoM,
							qs_duedate:DueDate,
							qs_mattext:MatDesc,
							qs_modorderid:modOrderId,
							qs_modmatno:modMatNo,
							qs_blend:Blend,
							qs_AbsComp:AbsComponent,
							qs_batch:batchsel,
							qs_weighl:weighlist,
							qs_count:counter,
							qs_avail:avail,
							qs_popupFlag:PopUp
							//qs_carrysum:carrysum
					};	
					weighDataModelPartial.setData(weighDataPartial);
					sap.ui.getCore().setModel(weighDataModelPartial, "weighingDataModelPartial");
					//popupWindow = window.open("ReadWeightPartial.irpt?qs_crid=" + CRId + "&qs_msgid=" + MsgId + "&qs_ordid=" + OrderId + "&qs_comp=" + partialComponent + "&qs_matno=" + MatNo + "&qs_matqty=" + PlannedQty + "&qs_uom=" + UoM + "&qs_duedate=" + DueDate + "&qs_mattext=" + MatDesc + "&qs_modorderid=" + modOrderId + "&qs_receiveqty=" + recvquantity + "&qs_toreceiveqty=" + quantitytorecv + "&qs_modmatno=" + modMatNo + "&qs_popupFlag=PopUp", "_blank", "directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=1152, height=700,top=20,left=0");
					if (!this.oPartialPopup) {
						this.oPartialPopup = sap.ui.xmlfragment("com.khc.weighhub.view.ReadWeightPartialDialog", this);
						//this.oFileterPopover.setModel(this.getView().getModel());
					}

					this.oPartialPopup.open();
				}

			}

			addblendfrompartial = '0';
			this.clearValues();
		},

		GaugeDialRecreate: function() {

			var Flag = parseInt(gaugeDialFlag);

			if(Flag == 1)
			{				

				//document.getElementById("gaugedial").innerHTML="";

			}
			else
			{
				//document.getElementById("gaugedial").innerHTML="";
				//document.getElementById("gaugedial").style.display = 'block';
			}

		},

		SetAvail: function() {

			var path = this.getView().byId("td_select_batch").getSelectedItem().oBindingContexts.getBatchByMaterialData.sPath;
			var text_avail= getBatchByMaterialModel.getProperty(path+"/AVAIL")
			var avail_unit = text_avail+" "+this.getView().byId("txt_GridUOM").getValue();
			this.getView().byId("txt_Avail").setValue(avail_unit);
			this.checkAvailability();
		},
		ManScaleName : function() {
			scalename= this.getView().byId("weighScaleList").getSelectedKey();
			sessionStorage.setItem("CA_ScaleName", scalename);
			this.GaugeDialRecreate();
			this.GaugeDialTest();
		},
		ReadManual: function() {


			var ExtraFlag = "";
			var currentkitseq = "";
			var ItemCount = CommonUtility.getJsonModelRowCount(getWeighingMaterialModel.getData());
			var Seq = this.getView().byId("txt_Seq").getValue();
			var Blend = getWeighingMaterialModel.getData().Rowsets.Rowset[0].Row[Seq-1].Blend;
			var matposition = MatPosition;
			var selBatch = this.getView().byId("td_select_batch").getSelectedKey();

			for(var i=0; i<(CommonUtility.getJsonModelRowCount(currentMaterialModel.getData())); i++) {

				if(this.getView().byId("txt_AbsComponent").getValue() == parseInt(currentMaterialModel.getData().Rowsets.Rowset[0].Row[i].MATNO)){
					CurrSelRow= i;

				}
			}


			var TotalKits = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].KITS;
			var Count = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].COUNTER;
			var MatNo = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].MATNO;
			var uom = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].UOM;
			var MatText = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].MATTEXT;
			var Blend = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].BLEND;
			var itemno = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].ITEMNO;

			var MatQty = this.getView().byId("txt_ScaleWgt").getValue();
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;
			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}
			if (this.getView().byId("td_select_batch").getSelectedItem() == null)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_007"));
			}
			else {

				if(hid_eflag == 0){

					ExtraFlag = "0";
				}
				else if (hid_eflag == 1)
				{
					ExtraFlag = "1";
				}

				var Bags;
				if (PreWeighedBagFlag==false){
					Bags="";

				}
				else {
					Bags=this.getView().byId("txt_NumberOfBag").getValue();
				}

				var InsertWeighingModel = new sap.ui.model.json.JSONModel();
				InsertWeighingModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_InsertWeighing&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+MatNo+"&Param.4="+selBatch+"&Param.5=1&Param.6="+matquantity+"&Param.7="+uom+"&Param.8="+MatText+"&Param.9="+Blend+"&Param.10="+ExtraFlag+"&Param.11="+itemno+"&Param.12="+scalename+"&Param.13="+uname+"&Param.14="+Bags+"&Content-Type=text/json", "", false);

				if(CommonUtility.getJsonModelRowCount(InsertWeighingModel.getData())) {
					currentkitseq = InsertWeighingModel.getData().Rowsets.Rowset[0].Row[0].KITSEQ;
				}
				var CurrNo = parseInt(Count) + 1;
				var OutputFlag = parseInt(blendPrintFlag);
				if(OutputFlag == 1)
				{	
					if ((PreWeighedBagFlag==false && PartialFlag != "Partial") || PreWeighedBagFlag==true)
					{
						var Flag =parseInt(blendPrintPopupFlag);
						if(Flag == 1)
						{

							window.open('/XMII/CM/WeighHubUI5/webapp/irpt/BlendReport.irpt?qs_ordid=' + OrderId + '&qs_Blend=' + this.getView().byId("txt_Blend").getValue()+ '&qs_KitSeq=' + currentkitseq + '&qs_CompMat=' +Component, 'BinReport', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');
						}

						else
						{
							var var1=this.getView().byId("txt_Blend").getValue();
							var var2=Component;
							var SendDataToThePrinterModel = new sap.ui.model.json.JSONModel();
							SendDataToThePrinterModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_AllBlendLabelPrint&Param.1="+OrderId+"&Param.2="+var1+"&Param.3="+currentkitseq+"&Param.4="+var2+"&Param.5=false&Param.6="+printerID+"&Content-Type=text/json", "", false);

						}

						var UpdateBlendPrintStatusModel = new sap.ui.model.json.JSONModel();
						UpdateBlendPrintStatusModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateBlendPrintStatus&Param.1="+plant+"&Param.2="+resource+"&Param.3="+OrderId+"&Param.4="+this.getView().byId("txt_Blend").getValue()+"&Param.5="+currentkitseq+"&Content-Type=text/json", "", false);

					}	

				}

				if (PartialFlag == "Partial")
				{

					var partialMatQty = parseFloat(this.getView().byId("txt_TarWeight").getValue()).toFixed(4) - parseFloat(this.getView().byId("txt_ScaleWgt").getValue()).toFixed(4);
					var partialQtyFormat = parseFloat(partialMatQty).toFixed(4)

					var InsPartialMaterialModel = new sap.ui.model.json.JSONModel();
					InsPartialMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_InsPartialMaterial&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+MatNo+"&Param.5="+MatText+"&Param.6="+uom+"&Param.7="+partialQtyFormat+"&Param.8=0.00&Param.9="+this.getView().byId("txt_Counter").getValue()+"&Param.10="+this.getView().byId("txt_Blend").getValue()+"&Param.11="+itemno+"&Param.12="+currentkitseq+"&Content-Type=text/json", "", false);

				}

				if (hid_eflag == "0")
				{

					var UpdMatWeighModel = new sap.ui.model.json.JSONModel();
					UpdMatWeighModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdMatWeigh&Param.1="+CurrNo+"&Param.2="+TotalKits+"&Param.3="+CRId+"&Param.4="+OrderId+"&Param.5="+MatNo+"&Param.6="+itemno+"&Content-Type=text/json", "", false);

				}

				if (PartialFlag == "Partial")
				{

					var HMatNo = MatNoStrip;
					var MatDesc = this.getView().byId("txt_GoodDesc").getValue();
					var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();
					var UoM = this.getView().byId("txt_UOM").getValue();
					var DueDate = this.getView().byId("txt_DueDate").getValue();
					var modOrderId = this.getView().byId("txt_modOrderId").getValue();
					var modMatNo = this.getView().byId("txt_modMatNoStrip").getValue();
					var carrysum = parseFloat(this.getView().byId("txt_ScaleWgt").getValue()).toFixed(4);
					var recvquantity = sap.ui.getCore().getModel("weighingDataModel").oData.qs_receiveqty;
					var quantitytorecv = sap.ui.getCore().getModel("weighingDataModel").oData.qs_toreceiveqty;					

					/***********
					if(CurrentPredefinedBagFlag == false)
					{
						//popupWindow = window.open("ReadWeightPartial.irpt?qs_crid=" + CRId + "&qs_msgid=" + msgid + "&qs_ordid=" + OrderId + "&qs_carrysum=" + carrysum + "&qs_comp=" + MatNo + "&qs_matno=" + HMatNo + "&qs_matqty=" + PlannedQty + "&qs_uom=" + UoM + "&qs_duedate=" + DueDate + "&qs_mattext=" + MatDesc + "&qs_modorderid=" + modOrderId + "&qs_receiveqty=" + recvquantity + "&qs_toreceiveqty=" + quantitytorecv + "&qs_modmatno=" + modMatNo + "&qs_popupFlag=PopUp", "_blank", "directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=1152, height=700,top=20,left=0");					}
					if (!this.oPartialPopup) {
		            this.oPartialPopup = sap.ui.xmlfragment("com.khc.weighhub.view.ReadWeightPartial", this);

		          }

			this.oPartialPopup.open();
					}
						else
					{
							//popupWindow = window.open("ReadWeightPartial.irpt?qs_crid=" + CRId + "&qs_msgid=" + msgid + "&qs_ordid=" + OrderId + "&qs_comp=" + MatNo + "&qs_matno=" + HMatNo + "&qs_matqty=" + PlannedQty + "&qs_uom=" + UoM + "&qs_duedate=" + DueDate + "&qs_mattext=" + MatDesc + "&qs_modorderid=" + modOrderId + "&qs_receiveqty=" + recvquantity + "&qs_toreceiveqty=" + quantitytorecv + "&qs_modmatno=" + modMatNo + "&qs_popupFlag=PopUp", "_blank", "directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=1152, height=700,top=20,left=0");
					}
					 ***********/

					if (!this.oPartialPopup) {
						this.oPartialPopup = sap.ui.xmlfragment("com.khc.weighhub.view.ReadWeightPartial", this);

					}

					//this.oPartialPopup.open();
				}
				//this.getView().byId("id_chk_partial").setSelected(false);
				this.GetBack()
			}
		},

		clearValues: function() {

			this.getView().byId("txt_Avail").getCustomData()[0].setValue("nuetral");
			this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
			this.getView().byId("txt_ScaleWgt").setValue("");
			//this.getView().byId("txt_Avail").setValue("");
			this.getView().byId("txt_selected_batch").setValue("");
			//this.getView().byId("td_select_batch").setSelectedKey(null);
			this.getView().byId("id_chk_partial").setSelected(false);
			this.getView().byId("txt_NumberOfBag").setValue("1");
			this.getView().byId("id_pageErrorMsg3").setVisible(false);

			if(this.getView().byId("td_select_batch").getSelectedKey() ==""){
				this.getView().byId("txt_Avail").setValue("");
			}
			if(this.getView().byId("id_btn_NextIngr").getEnabled()){
				this.getView().byId("id_btn_NextIngr").setEnabled(false);	
				this.getView().byId("id_btn_NextIngr").setType("Default");

			}
			if(	this.getView().byId("id_btn_ReadManual").getEnabled()) {
				this.getView().byId("id_btn_ReadManual").setEnabled(false);
				this.getView().byId("id_btn_ReadManual").setType("Default");
			}
		},

		ScanHU: function() {

			this.getView().byId("td_select_batch").setSelectedKey(null);
			this.getView().byId("txt_selected_batch").setValue();
			this.getView().byId("txt_Avail").setValue();
			if(this.getView().byId("txt_HUNumber").getValue()) {

				var SSCC = this.getView().byId("txt_HUNumber").getValue();
				var Material = Component;

				var GetBatchNumByHUScanModel = new sap.ui.model.json.JSONModel();
				//GetBatchNumByHUScanModel.loadData("/XMII/Illuminator?QueryTemplate=Default/Muthu/weigh/XACQ_GetBatchNumByHUScan&Param.1="+SSCC+"&Param.2="+Material+"&Content-Type=text/json", "", false);
				GetBatchNumByHUScanModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchNumByHUScan&Param.1="+SSCC+"&Param.2="+Material+"&Content-Type=text/json", "", false);
				GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Batch;
				var Status = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Type;
				var message = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Message;
				var O_Batch = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Batch;
				var batchFlag=0;

				if (Status == "S")
				{
					var count = CommonUtility.getJsonModelRowCount(getBatchByMaterialModel.getData())
					for (var i = 0; i < count; i++)
					{
						if(O_Batch == getBatchByMaterialModel.getData().Rowsets.Rowset[0].Row[i].BATCH) {

							this.getView().byId("td_select_batch").setSelectedKey(O_Batch);
							this.getView().byId("txt_selected_batch").setValue(O_Batch);
							this.SetAvail();
							batchFlag=1;
							break;

						}

					}

					if(batchFlag !=1) {
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_072"));
					}

				}
				else
				{
					MessageBox.alert(message);
				}
			}

			else {

				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_081"));

			}

		},
		onClickDialpad: function(oEvent) {

			let sKey = oEvent.getSource().getText();
			let counter = this.getView().byId(currentfocusID).getValue();
			let newCounter = counter + sKey;
			this.getView().byId(currentfocusID).setValue(newCounter);

		},
		onCancelDialPad: function(oEvent) {

			this.getView().byId(currentfocusID).setValue("");

		},

		closeDialPad: function(oEvent) {

			this.getView().byId("dialpad").setVisible(false);

		},
		onAfterRendering: function() {

			var that = this;

			this.getView().byId("txt_ScaleWgt").addEventDelegate({
				onfocusin: function() {

					that.getView().byId("dialpad").setVisible(true);
					currentfocusID = "txt_ScaleWgt";

				}
			});
			this.getView().byId("txt_HUNumber").addEventDelegate({
				onfocusin: function() {

					that.getView().byId("dialpad").setVisible(true);
					currentfocusID = "txt_HUNumber";

				}
			});


		},


		/****** Partial Weighing Code Below******/


		afterPartialDialogOpen: function() {

			//sap.ui.getCore().byId("weighScaleList").setValue(this.getView().byId("weighScaleList").getValue());
			//sap.ui.getCore().byId("txt_Counter").setValue(this.getView().byId("txt_Counter").getValue());
			sap.ui.getCore().byId("td_select_batch").setSelectedKey(sap.ui.getCore().getModel("weighingDataModelPartial").oData.batchsel);
			sap.ui.getCore().byId("weighScaleList").setSelectedKey(sap.ui.getCore().getModel("weighingDataModelPartial").oData.qs_weighl);
			//popup = sap.ui.getCore().getModel("weighingDataModelPartial").oData.qs_popupFlag;

			sap.ui.getCore().byId("td_select_batch").setSelectedKey(null);			
			sap.ui.getCore().byId("id_btn_ReadScale").setType("Emphasized");
			sap.ui.getCore().byId("id_btn_NextIngr").setEnabled(false);
			sap.ui.getCore().byId("id_btn_NextIngr").setType("Default");
			this.SetBatchPartial();
			this.SetFlagCMDGetSelBatch();
			this.getGaugeDialFlagFromSharedMem();  /*****present function, last variable name different*****/
			this.getWeighingMaterialPartial();

			/******
			var PartialMaterialModel = new sap.ui.model.json.JSONModel();
			PartialMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetPartialMaterial&Param.1="+OrderId+"&Content-Type=text/json", "", false);

			if(isNaN(sap.ui.getCore().getModel("weighingDataModelPartial").oData.qs_carrysum)){

				sap.ui.getCore().byId("txt_TargetWeight").setValue(PartialMaterialModel.getData().Rowsets.Rowset[0].Row[0].MATQTY);

			}
			else {

				sap.ui.getCore().byId("txt_TargetWeight").setValue((PartialMaterialModel.getData().Rowsets.Rowset[0].Row[0].MATQTY)+sap.ui.getCore().getModel("weighingDataModelPartial").oData.qs_carrysum);

			}
			 ******/
		},

		SetFlagCMDGetSelBatch: function() {

			js_FlagCMDGetSelBatch = 1;
		},
		getWeighingMaterialPartial: function() {

			getPartialMaterialModel = new sap.ui.model.json.JSONModel();
			getPartialMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=WeighHubUI5/QueryTemplate/SQLQ_GetPartialMaterial&Param.1="+OrderId+"&Content-Type=text/json", "", false);

			var gridCount = CommonUtility.getJsonModelRowCount(getPartialMaterialModel.getData());

			if(gridCount>0){

				selectedRowVar = 0;

			}
			/****
			else if(popup){

				if (this.oPartialPopup) {
					this.oPartialPopup.close();

				}

			}
			 ****/
			else{
				this.oPartialPopup.close();

			}

			this.enableHUPartial();
			this.populateData();
			this.UpperLowerLimitValuesPartial();
			this.GaugeDialValues();  /*****present function*****/

		},
		enableHUPartial: function() {

			sap.ui.getCore().byId("txt_selected_batch").setValue(sap.ui.getCore().byId("td_select_batch").getSelectedKey())
			jQuery.ajax({
				url: "/XMII/Runner?Transaction=GBL_WEIGHING/BLS/BLS_GetMaterialForPartial&I_OrderID="+OrderId+"&I_CompMatno="+Component+"&OutputParameter=HUSCAN&Content-Type=text/xml",
				type : 'GET',
				async:false,
				success : function (xmlData) {

					HUSCAN = $(xmlData).find('HUSCAN').text();

				}
			});

			if(HUSCAN == "N"){

				sap.ui.getCore().byId("id_btn_ScanHU").setVisible(false); 
				sap.ui.getCore().byId("id_td_HUNumber").setVisible(false);
				sap.ui.getCore().byId("td_display_selected_batch").setVisible(false); 
			}
			else if(HUSCAN == "S"){

				sap.ui.getCore().byId("txt_HUNumber").setValue(""); 
				sap.ui.getCore().byId("id_btn_ScanHU").setVisible(true); 
				sap.ui.getCore().byId("id_td_HUNumber").setVisible(true);
				sap.ui.getCore().byId("td_display_selected_batch").setVisible(true); 
				sap.ui.getCore().byId("td_batch").setVisible(false); 
			}
			else if(HUSCAN == "B"){

				sap.ui.getCore().byId("txt_HUNumber").setValue(""); 
				sap.ui.getCore().byId("id_btn_ScanHU").setVisible(true); 
				sap.ui.getCore().byId("id_td_HUNumber").setVisible(true);
				sap.ui.getCore().byId("td_display_selected_batch").setVisible(false); 
				sap.ui.getCore().byId("td_batch").setVisible(true); 
			}
			else{
				sap.ui.getCore().byId("id_btn_ScanHU").setVisible(false); 
				sap.ui.getCore().byId("id_td_HUNumber").setVisible(false);
				sap.ui.getCore().byId("td_display_selected_batch").setVisible(false); 
				sap.ui.getCore().byId("td_batch").setVisible(true); 
			}
		},
		populateData: function() {

			var dp = parseInt(ScaleDecimal);
			var SelRow = selectedRowVar;
			if (CommonUtility.getJsonModelRowCount(getPartialMaterialModel.getData()) > 0) {
				Component = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATNO;
				sap.ui.getCore().byId("txt_AbsComponent").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATNO);
				sap.ui.getCore().byId("txt_CompDesc").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATTEXT);
				sap.ui.getCore().byId("txt_GridUOM").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].UOM);
				sap.ui.getCore().byId("txt_Counter").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].KITNO);
				sap.ui.getCore().byId("txt_TargetWeight").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY);
				sap.ui.getCore().byId("txt_TarWeight").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY);
				sap.ui.getCore().byId("txt_Blend").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].BLEND);
				sap.ui.getCore().byId("txt_ScaleWgt").setValue("");
				sap.ui.getCore().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");

				//sap.ui.getCore().byId("txt_TargetWeight").setValue((sap.ui.getCore().byId("txt_TargetWeight").getValue()).replace(",",".").toFixed(dp));
				//sap.ui.getCore().byId("txt_TarWeight").setValue(sap.ui.getCore().byId("txt_TarWeight").getValue().replace(",",".").toFixed(dp));

				if(isNaN(carrysum)) {

					sap.ui.getCore().byId("txt_TargetWeight").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY);

				}
				else {

					var ftarget = parseFloat(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY)+parseFloat(carrysum);
					sap.ui.getCore().byId("txt_TargetWeight").setValue(parseFloat(ftarget).toFixed(dp));
					sumBlendWeight1 = parseFloat(carrysum);
				}

				this.checkAppletToCallSetBatch();
			}
		},
		UpperLowerLimitValuesPartial: function() {

			//var SclWgt = parseFloat(sap.ui.getCore().byId("txt_ScaleWgt").getValue());
			var dp = parseInt(ScaleDecimal);
			var TrgtWgt = sap.ui.getCore().byId("txt_TargetWeight").getValue();
			var TrgtWeight = sap.ui.getCore().byId("txt_TarWeight").getValue();
			var TarWeight = TrgtWeight.replace("," , ".");
			var FormatTrgrtWgt = parseFloat(TarWeight);


			if (plant !="3137")
			{
				if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
				{
					LowTolerance = parseFloat(TrgtWgt) - 0.005;
					UpTolerance = parseFloat(TrgtWgt) + 0.005;
				}
				else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
				{
					LowTolerance = parseFloat(TrgtWgt)  - 0.01;
					UpTolerance = parseFloat(TrgtWgt) + 0.01;
				}
				else if (FormatTrgrtWgt > 5)
				{
					LowTolerance = parseFloat(TrgtWgt) - 0.05;
					UpTolerance = parseFloat(TrgtWgt)  + 0.05;
				}
			}

			else {

				LowTolerance = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
				UpTolerance = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

			} 
			LowTolerance = parseFloat(LowTolerance).toFixed(dp);
			UpTolerance = parseFloat(UpTolerance).toFixed(dp);

			sap.ui.getCore().byId("id_display_UpTrgtWgt").setValue(UpTolerance);
			sap.ui.getCore().byId("id_display_LowTrgtWgt").setValue(LowTolerance);
		},
		checkAppletToCallSetBatch: function()
		{

			if ( js_FlagBROBatch==1 &&  js_FlagCMDGetSelBatch==1 )
			{
				this.SetBatchPartial();
			}

		},		
		ReadWeightPartial: function(weighType) {

			var dp = parseInt(ScaleDecimal);

			PartialFlag = weighType;

			var DestID = "";

			if(plant =="3278") {
				DestID = "MT_SCALES_ELST";
			}
			else if(plant =="3005") {
				DestID = "SCALES_KG";
			}
			else if(plant =="3414") {
				DestID = "SCALES_LL";
			}
			else if(plant =="3309") {
				DestID = "SCALES_PU";
			}

			var O_Weight;
			var TrgtWeight = sap.ui.getCore().byId("txt_TarWeight").getValue();
			var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
			RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
			var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			//document.getElementById("txt_ScaleWgt").style.background = "";
			sap.ui.getCore().byId("id_btn_NextIngr").setType("Default");
			sap.ui.getCore().byId("id_btn_NextIngr").setEnabled(false);


			if (plant !="3137") {
				if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
				{
					var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.005;
					UpTrgtWgt = UpperTrgtWeight;

					var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.005;
					LowTrgtWgt = LowerTrgtWeight;
				}
				else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
				{
					var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.01;
					UpTrgtWgt = UpperTrgtWeight;

					var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.01;
					LowTrgtWgt = LowerTrgtWeight;
				}

				else if (FormatTrgrtWgt > 5)
				{
					var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.05;
					UpTrgtWgt = UpperTrgtWeight;

					var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.05;
					LowTrgtWgt = LowerTrgtWeight;
				}

			}

			else {

				var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
				LowTrgtWgt = LowerTrgtWeight;

				var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;
				UpTrgtWgt = UpperTrgtWeight;

			} 
			if (sap.ui.getCore().byId("txt_WeighMode").getValue() == "Blend")
			{
				if (CountBlend == counter && BlendName == sap.ui.getCore().byId("txt_Blend").getValue())
				{
				}
				else if (CountBlend == counter && BlendName == "")
				{
				}
				else
				{
					sumBlendWeight1 = 0;
				}
			}

			if (sumBlendWeight1 == "0")
			{
				var FormatupperLmt = parseFloat(UpperTrgtWeight).toFixed(dp);
				var FormatLowerLmt = parseFloat(LowerTrgtWeight).toFixed(dp);
			}
			else
			{
				var FormatupperLmt = parseFloat(UpperTrgtWeight) + parseFloat(sumBlendWeight1);
				var FormatLowerLmt = parseFloat(LowerTrgtWeight) + parseFloat(sumBlendWeight1);

				var FormatupperLmt = parseFloat(FormatupperLmt).toFixed(dp);
				var FormatLowerLmt = parseFloat(FormatLowerLmt).toFixed(dp);
			}

			if (sap.ui.getCore().byId("txt_ScaleWgt").getValue() == "")
			{

				var PCoConnectionFlag = parseInt(WebsocketConnectionFlag);

				if(PCoConnectionFlag == 1)
				{
					var Scale = sap.ui.getCore().byId("weighScaleList").getSelectedKey();
					var GetWeighScaleReadingFromPCoModel = new sap.ui.model.json.JSONModel();
					GetWeighScaleReadingFromPCoModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighScaleReadingFromPCo&Param.1="+plant+"&Param.2="+resource+"&Param.3="+Scale+"&Content-Type=text/json", "", false);

					O_Weight = GetWeighScaleReadingFromPCoModel.getData().Rowsets.Rowset[0].Row[0].Value;


				}
				else {		

					var ReadWeightModel = new sap.ui.model.json.JSONModel();
					ReadWeightModelModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_ReadWeight&Param.1="+DestID+"&Param.2="+scalename+"&Param.3="+FormatLowerLmt+"&Param.4="+FormatupperLmt+"&Content-Type=text/json", "", false);

					O_Weight = ReadWeightModel.getData().Rowsets.Rowset[0].Row[0].O_Weight;

				}
			}
			else
			{
				if (isNaN(sap.ui.getCore().byId("txt_ScaleWgt").getValue()))
				{
					MessageBox.alert("Please enter a number");	
				}
				else
				{
					O_Weight = sap.ui.getCore().byId("txt_ScaleWgt").getValue();
				}
			}

			var SclWeight = parseFloat(O_Weight) - parseFloat(sumBlendWeight1);


			sap.ui.getCore().byId("txt_ScaleWgt").setValue(parseFloat(SclWeight).toFixed(dp));


			if (isNaN(sap.ui.getCore().byId("txt_ScaleWgt").getValue()) || sap.ui.getCore().byId("txt_ScaleWgt").getValue()== 0)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_009"));
				sap.ui.getCore().byId("txt_ScaleWgt").setValue("");
			}
			else
			{
				if (SclWeight >= LowerTrgtWeight && SclWeight <= UpperTrgtWeight)
				{
					BlendName = sap.ui.getCore().byId("txt_Blend").getValue();

					sap.ui.getCore().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
					sap.ui.getCore().byId("id_btn_NextIngr").setType("Emphasized")
					sap.ui.getCore().byId("id_btn_ReadScale").setType("Default")
					sap.ui.getCore().byId("id_btn_NextIngr").setEnabled(true)

				}
				else
				{
					if (hid_flag == "Auto")
					{
						sap.ui.getCore().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
						//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
						sap.ui.getCore().byId("id_btn_NextIngr").setType("Default")
						sap.ui.getCore().byId("id_btn_ReadScale").setType("Emphasized")
					}
					else
					{
						sap.ui.getCore().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
						//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
						//sap.ui.getCore().byId("id_btn_ReadManual").setType("Default")
						sap.ui.getCore().byId("id_btn_ReadScale").setType("Emphasized")
					}
				}
			}

			TargetFlag = "0";



		},
		ValidateInputsPartial: function() {

			var SclWgt = parseFloat(sap.ui.getCore().byId("txt_ScaleWgt").getValue());
			var LowTrgtWgt = parseFloat(LowTrgtWgt);
			var UpTrgtWgt = parseFloat(UpTrgtWgt);

			var TrgtWeight = sap.ui.getCore().byId("txt_TarWeight").getValue();
			var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
			RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
			var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			if (plant!="3137")
			{

				if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.005;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.005;
				}

				else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.01;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.01;
				}

				else if (FormatTrgrtWgt > 0.5)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.05;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.05;
				}
			}
			else {


				LowTrgtWgt = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
				UpTrgtWgt = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

			}

			if (sap.ui.getCore().byId("txt_ScaleWgt").getValue() == "")
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_005"));
			}
			else if (isNaN(sap.ui.getCore().byId("txt_ScaleWgt").getValue()))
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_006"));
			}


			else if (sap.ui.getCore().byId("td_select_batch").getSelectedItem() == null)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_007"));
			}


			else if (SclWgt < LowTrgtWgt || SclWgt > UpTrgtWgt)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_008"));
				sap.ui.getCore().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
				//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
				sap.ui.getCore().byId("id_btn_NextIngr").setType("Default");
				sap.ui.getCore().byId("id_btn_ReadScale").setType("Emphasized")
				sap.ui.getCore().byId("id_btn_NextIngr").setEnabled(false)
			}
			else
			{
				this.InsMatWeigh1Partial();
				sap.ui.getCore().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
				//document.getElementById("txt_ScaleWgt").style.background = "#FFFFFF";
				sap.ui.getCore().byId("id_btn_NextIngr").setType("Default");
				sap.ui.getCore().byId("id_btn_ReadScale").setType("Emphasized")
				sap.ui.getCore().byId("id_btn_NextIngr").setEnabled(false)
			}

			this.UpperLowerLimitValuesPartial();	
			this.GaugeDialRecreate();
			this.GaugeDialValues();


		},
		InsMatWeigh1Partial: function() {

			sap.ui.getCore().byId("id_pageErrorMsg1").setVisible(false);

			var dp = parseInt(ScaleDecimal);
			//var Seq = sap.ui.getCore().byId("txt_Seq").getValue();
			var selBatch = sap.ui.getCore().byId("td_select_batch").getSelectedKey();

			CurrSelRow = selectedRowVar;
			var KitNo = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].KITNO;
			var MatNo = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].MATNO;
			var itemno = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].ITEMNO;

			var MatQty = sap.ui.getCore().byId("txt_ScaleWgt").getValue();
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;
			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}


			var UpdatePartialComsumedModel = new sap.ui.model.json.JSONModel();
			UpdatePartialComsumedModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdatePartialComsumed&Param.1="+matquantity+"&Param.2="+CRId+"&Param.3="+OrderId+"&Param.4="+MatNo+"&Param.5="+KitNo+"&Param.6="+selBatch+"&Param.7="+itemno+"&Content-Type=text/json", "", false);

			var InsWeighPartialKitModel = new sap.ui.model.json.JSONModel();
			InsWeighPartialKitModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_InsWeighPartialKit&Param.1="+plant+"&Param.2="+resource+"&Param.3="+OrderId+"&Param.4="+MatNo+"&Param.5="+itemno+"&Param.6="+KitNo+"&Content-Type=text/json", "", false);

			var message = InsWeighPartialKitModel.getData().Rowsets.Rowset[0].Row[0].Message;
			var Blend = InsWeighPartialKitModel.getData().Rowsets.Rowset[0].Row[0].Blend;
			var currentkitseq = InsWeighPartialKitModel.getData().Rowsets.Rowset[0].Row[0].KitSeq;

			var Flag =parseInt(blendPrintPopupFlag);
			if(Flag == 1)
			{

				window.open('/XMII/CM/WeighHubUI5/webapp/irpt/BlendReport.irpt?qs_ordid=' + OrderId + '&qs_Blend=' + sap.ui.getCore().byId("txt_Blend").getValue()+ '&qs_KitSeq=' + currentkitseq + '&qs_CompMat=' +MatNo, 'BinReport', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');
			}

			else
			{

				var SendDataToThePrinterModel = new sap.ui.model.json.JSONModel();
				SendDataToThePrinterModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_AllBlendLabelPrint&Param.1="+OrderId+"&Param.2="+Blend+"&Param.3="+currentkitseq+"&Param.4="+MatNo+"&Param.5=true&Param.6="+printerID+"&Content-Type=text/json", "", false);

			}

			var UpdateBlendPrintStatusModel = new sap.ui.model.json.JSONModel();
			UpdateBlendPrintStatusModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateBlendPrintStatus&Param.1="+plant+"&Param.2="+resource+"&Param.3="+OrderId+"&Param.4="+Blend+"&Param.5="+currentkitseq+"&Content-Type=text/json", "", false);



			this.getWeighingMaterialPartial();
			this.clearValuesPartial();

		},

		SetBatchPartial: function() {

			js_FlagBROBatch=1;

			carrysum = sap.ui.getCore().getModel("weighingDataModel").oData.qs_carrysum;

			var counterarray = counter.split("/");
			var counterval = counterarray[0];

			getBatchByMaterialModel = new sap.ui.model.json.JSONModel();
			var batchVar= sap.ui.getCore().byId("td_select_batch");
			//getBatchByMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchByMaterial&Param.1="+CRId+"&Param.2="+Component+"&Content-Type=text/xml", "", false);
			//sap.ui.getCore().setModel(getBatchByMaterialModel, "getBatchByMaterialData");

			getBatchByMaterialModel.attachRequestCompleted(
					function(){ 
						if(CommonUtility.getJsonModelRowCount(getBatchByMaterialModel.getData()) > 0){
							batchVar.setModel(getBatchByMaterialModel, "getBatchByMaterialData");
						}
					});
			getBatchByMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchByMaterial&Param.1="+CRId+"&Param.2="+Component+"&Content-Type=text/json", "", false);

			if(js_FlagCMDGetSelBatch == 1)
			{
				var getMatWeighedBatchModel = new sap.ui.model.json.JSONModel();
				getMatWeighedBatchModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetMatWeighedBatch&Param.1="+Component+"&Param.2="+OrderId+"&Param.3="+CRId+"&Content-Type=text/json", "", false);

				if (CommonUtility.getJsonModelRowCount(getMatWeighedBatchModel.getData()) > 0) {
					var DefBatch= getMatWeighedBatchModel.getData().Rowsets.Rowset[0].Row[0].BATCH;
					sap.ui.getCore().byId("td_select_batch").setSelectedKey(DefBatch);
					var path = sap.ui.getCore().byId("td_select_batch").getSelectedItem().oBindingContexts.getBatchByMaterialData.sPath;
					var text_avail= getBatchByMaterialModel.getProperty(path+"/AVAIL")
					var avail_unit= text_avail+" "+sap.ui.getCore().byId("txt_GridUOM").getValue();
					sap.ui.getCore().byId("txt_Avail").setValue(avail_unit);
				}
			}
		},
		clearValuesPartial: function() {


			sap.ui.getCore().byId("id_btn_ReadScale").setType("Emphasized");
			sap.ui.getCore().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
			//sap.ui.getCore().byId("txt_Avail").getCustomData()[0].setValue("nuetral");
			sap.ui.getCore().byId("txt_ScaleWgt").setValue("");
			sap.ui.getCore().byId("txt_Avail").setValue("");
			//sap.ui.getCore().byId("id_pageErrorMsg1").setVisible(false);
			//sap.ui.getCore().byId("td_select_batch").setSelectedKey(null);

			if(sap.ui.getCore().byId("id_btn_NextIngr").getEnabled()){
				sap.ui.getCore().byId("id_btn_NextIngr").setEnabled(false);	
				sap.ui.getCore().byId("id_btn_NextIngr").setType("Default");

			}

		},
		afterPartialDialogClose: function() {

			if(PartialBackFlag) {
				this.GetBack();
			}

		},
		closeDialog: function() {

			this.oPartialPopup.close();
		},

		SetAvailPartial: function() {

			var path = sap.ui.getCore().byId("td_select_batch").getSelectedItem().oBindingContexts.getBatchByMaterialData.sPath;
			var text_avail= getBatchByMaterialModel.getProperty(path+"/AVAIL")
			var avail_unit= text_avail+" "+sap.ui.getCore().byId("txt_GridUOM").getValue();
			sap.ui.getCore().byId("txt_Avail").setValue(avail_unit);

			var available_qty = sap.ui.getCore().byId("txt_Avail").getValue();
			available_qty = available_qty.split(" ");

			var dp = parseInt(ScaleDecimal);

			if (available_qty[0] == "")
			{}
			else
			{
				var avail = parseFloat(available_qty[0]);
				var quantity_remain = avail -  sap.ui.getCore().byId("txt_TarWeight").getValue();
/*****
		if (quantity_remain < 0)
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("yellowColor");
		else if (available_qty == 0)
			sap.ui.getCore().byId("txt_Avail").getCustomData()[0].setValue("redColor");
		else
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("nuetral");
*****/
			}

		},
		ScanHUPartial: function() {

			sap.ui.getCore().byId("txt_selected_batch").setValue();
			sap.ui.getCore().byId("txt_Avail").setValue();
			if(sap.ui.getCore().byId("txt_HUNumber").getValue()) {

				var SSCC = sap.ui.getCore().byId("txt_HUNumber").getValue();
				var Material = Component;

				var GetBatchNumByHUScanModel = new sap.ui.model.json.JSONModel();
				GetBatchNumByHUScanModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchNumByHUScan&Param.1="+SSCC+"&Param.2="+Material+"&Content-Type=text/json", "", false);
				GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Batch;
				var Status = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Type;
				var message = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Message;
				var O_Batch = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Batch;
				var batchFlag=0;


				if (Status == "S")
				{
					var count = CommonUtility.getJsonModelRowCount(getBatchByMaterialModel.getData())
					for (var i = 0; i < count; i++)
					{
						if(O_Batch == getBatchByMaterialModel.getData().Rowsets.Rowset[0].Row[i].BATCH) {

							sap.ui.getCore().byId("td_select_batch").setSelectedKey(O_Batch);
							sap.ui.getCore().byId("txt_selected_batch").setValue(O_Batch);
							this.SetAvailPartial();
							batchFlag = 1;
							break;

						}

		

					}
					if(batchFlag !=1) {
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_072"));
					}

				}
				else
				{
					MessageBox.alert(message);
				}
			}

			else {

				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_081"));

			}
		},
		onClickDialpadPartial: function(oEvent) {

			let sKey = oEvent.getSource().getText();
			let counter = sap.ui.getCore().byId(currentfocusID).getValue();
			let newCounter = counter + sKey;
			sap.ui.getCore().byId(currentfocusID).setValue(newCounter);

		},
		onCancelDialPadPartial: function(oEvent) {

			sap.ui.getCore().byId(currentfocusID).setValue("");

		},

		closeDialPadPartial: function(oEvent) {

			sap.ui.getCore().byId("dialpad").setVisible(false);

		},
		onAfterRenderingPartial: function() {

			var that = this;

			sap.ui.getCore().byId("txt_ScaleWgt").addEventDelegate({
				onfocusin: function() {

					sap.ui.getCore().byId("dialpad").setVisible(true);
					currentfocusID = "txt_ScaleWgt";

				}
			});
			sap.ui.getCore().byId("txt_HUNumber").addEventDelegate({
				onfocusin: function() {

					sap.ui.getCore().byId("dialpad").setVisible(true);
					currentfocusID = "txt_HUNumber";

				}
			});


		},

	});
});