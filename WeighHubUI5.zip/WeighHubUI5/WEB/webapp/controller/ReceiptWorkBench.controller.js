var resourceModel;
var userModel;
var that = this;
var worklistDataModel;
var checkConfirmParam;
var userList;
var setuser;
var userTxt;
var userKey;
var loginName;
var oTable;
var WeighedCount;
var Weighed;
var WeighlistCount;
var QnSelRow;
var QnSelectedRow;
var getPlantDetailsFromSharedMemoryObj;
sap.ui.define(["sap/ui/core/mvc/Controller",
		"sap/m/Button",
		"com/khc/weighhub/utils/UI_utilities",
		"com/khc/common/Script/CommonUtility",
		"com/khc/weighhub/model/formatter",
		"sap/m/MessageBox", "com/khc/weighhub/model/models"
	],
	function(Controller, Button, UI_utilities, CommonUtility, formatter, MessageBox, models) {

		"use strict";
		var plant;
		var resource;
		var resourceText;
		var projectName;
		var crdest;

		return Controller.extend("com.khc.weighhub.controller.ReceiptWorkBench", {
			formatter: formatter,
			onInit: function() {
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this._oRouter.getRoute("ReceiptWorkBench").attachPatternMatched(this._oRoutePatternMatched, this);
			},

			_oRoutePatternMatched: function(oEvent) {
				console.log("pattern match funtion");
				UI_utilities.weighPageOpened(this, "ReceiptWorkBench");
				// UI_utilities.qualityMenuBar();
				plant = sap.ui.getCore().getModel("session").oData.CA_Plant
				projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName
				crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest
				loginName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName
				resource = sap.ui.getCore().getModel("session").oData.CA_Resource

				this.getResources();
				this.getUsers();
				this.loadResrFromSession();
				this.getWorklistData();

			},

			getResources: function() {
				var resourceVar = this.getView().byId("resource");
				var resourceModel = models.createNewXMLModel(
					"com.khc.weighhub.controller.ReceiptWorkBench-->getResources-->XACQ_GetResrByPlant");

				resourceModel.attachRequestCompleted(
					function() {
						if ($(resourceModel.getData()).find("Row").length > 0) {
							resourceVar.setModel(resourceModel, "oresource");
						}
					});
				resourceModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetResrByPlant&Param.1=" + plant + "&d=" +
					new Date() + "&Content-Type=text/xml", "", false);

			},

			backToMenu: function(oEvent) {

				this.getView().byId("id_chk_confirm").setSelected("null")
				UI_utilities.setContainerBusyState(this, true);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("default");

			},

			getUsers: function() {

				console.log("in user function");
				var userVar = this.getView().byId("users");
				var userModel = models.createNewXMLModel(
					"com.khc.weighhub.controller.ReceiptWorkBench-->getUsers-->SQLQ_GetUserList");

				userModel.attachRequestCompleted(
					function() {
						if ($(userModel.getData()).find("Row").length > 0) {
							userVar.setModel(userModel, "ouser");
						}
					});
				userModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetUserList&Content-Type=text/xml", "", false);

			},

			getWorklistData: function() {

				var userParam;
				setuser = sessionStorage.getItem("CA_WeighFilterUser");
				oTable = this.getView().byId("id_quantity");

				if (setuser) {

					userParam = setuser;

				} else {

					userParam = "%";
				}

				if (this.getView().byId("id_chk_confirm").getSelected()) {
					console.log("checked")
					checkConfirmParam = loginName;
				} else {
					console.log("not checked")
					checkConfirmParam = "";
				}

				worklistDataModel = models.createNewJSONModel(
					"com.khc.weighhub.controller.ReceiptWorkBench-->getWorklistData-->XACQ_GetReceipt_Workbench");
				var params = "Param.1=" + resource + "&Param.2=1&Param.3=" + plant + "&Param.4=" + crdest + "&Param.5=" + userParam + "&Param.6=" +
					checkConfirmParam;
				var url = "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetReceipt_Workbench&" + params +
					"&Content-Type=text/json"
				worklistDataModel.loadData(encodeURI(url), "", false);
				sap.ui.getCore().setModel(worklistDataModel, "WorklistData");

				var getPlantDetailsFromSharedMemoryObj = models.createNewJSONModel(
					"com.khc.weighhub.controller.ReceiptWorkBench-->getWorklistData-->XACQ_GetPlantDetailsFromSharedMemory");
				getPlantDetailsFromSharedMemoryObj.loadData(
					"/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPlantDetailsFromSharedMemory&Param.1=" + plant +
					"&Content-Type=text/json", "", false);

				if (getPlantDetailsFromSharedMemoryObj.getData().Rowsets.Rowset[0].Row[0].Output == "1") {

					this.getView().byId("id_btn_Newprint").setVisible(true);
				}
			},

			loadResrFromSession: function() {

				this.getView().byId("resource").setSelectedKey(resource);
				this.getView().byId("users").insertItem(new sap.ui.core.Item({
					key: "All",
					text: "All"
				}), 0);

				if (sessionStorage.getItem("CA_WeighFilterUser")) {

					setuser = sessionStorage.getItem("CA_WeighFilterUser");
					this.getView().byId("users").setSelectedKey(setuser);
				} else {

					this.getView().byId("users").setSelectedKey("All");
				}
			},

			onClickBack: function(oEvent) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("WeighHome");
			},

			refreshGrid: function() {

				userList = this.getView().byId("users").getSelectedKey();

				if (userList == "All") {

					userList = "%"
				}

				if (this.getView().byId("id_chk_confirm").getSelected()) {
					checkConfirmParam = loginName;
					console.log("checked")
				} else {
					console.log("not checked")
					checkConfirmParam = "";
				}

				var params = "Param.1=" + resource + "&Param.2=0,1&Param.3=" + plant + "&Param.4=" + crdest + "&Param.5=" + userList + "&Param.6=" +
					checkConfirmParam;
				var url = "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetReceipt_Workbench&" + params +
					"&Content-Type=text/json"
				worklistDataModel.loadData(encodeURI(url), "", false);
				sap.ui.getCore().setModel(worklistDataModel, "WorklistData");

			},

			loadUserFromSession: function() {

				setuser = sessionStorage.getItem("CA_WeighFilterUser");
				console.log(setuser)
				if (setuser) {
					console.log("pass")
					this.getView().byId("users").setSelectedKey(setuser);
				} else {
					console.log("elsse")
					this.getView().byId("users").setSelectedKey("All");
				}

			},

			setUser: function() {
				console.log("inside setuser")
					//userTxt = this.getView().byId("users").getSelectedItem();
				userKey = this.getView().byId("users").getSelectedKey();

				sessionStorage.setItem("CA_WeighFilterUser", userKey);
				MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_063"));
			},

			printNewReport: function() {

				if (oTable.getSelectedItem()) {

					QnSelRow = oTable.getSelectedContextPaths()[0];
					QnSelectedRow = this.getView().getModel("WorklistData").getProperty(QnSelRow);

					var orderID = QnSelectedRow.ORDERID;
					var crID = QnSelectedRow.CRID;
					var matnr = QnSelectedRow.MATNR;
					var matxt = QnSelectedRow.MATTEXT;

					window.open('/XMII/CM/WeighHubUI5/webapp/irpt/PartialReportWithSSCC.irpt?qs_crid=' + crID + '&qs_ordid=' + orderID +
						'&qs_headmat=' + matnr + '&qs_headmattext=' + matxt, 'PartialReportWithSSCC',
						'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');

				} else {

					MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_068"));

				}

			},

			onClickNext: function() {

				oTable = this.getView().byId("id_quantity");

				if (oTable.getSelectedItem()) {

					QnSelRow = oTable.getSelectedContextPaths()[0];
					QnSelectedRow = this.getView().getModel("WorklistData").getProperty(QnSelRow);

					var orderID = QnSelectedRow.ORDERID;
					var crID = QnSelectedRow.CRID;

					var getWeighedCountByOrder = models.createNewJSONModel(
						"com.khc.weighhub.controller.ReceiptWorkBench-->onClickNext-->SQLQ_GetWeighedCountByOrder");
					getWeighedCountByOrder.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWeighedCountByOrder&Param.1=" +
						orderID + "&Param.2=" + crID + "&Content-Type=text/json", "", false);
					WeighedCount = getWeighedCountByOrder.getData().Rowsets.Rowset[0].Row[0].COUNT;

					var getCounterWeighList = models.createNewJSONModel(
						"com.khc.weighhub.controller.ReceiptWorkBench-->onClickNext-->SQLQ_GetCounterWeighList");
					getCounterWeighList.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetCounterWeighList&Param.1=" +
						orderID + "&Param.2=" + crID + "&Content-Type=text/json", "", false);
					Weighed = getCounterWeighList.getData().Rowsets.Rowset[0].Row[0].COUNTER;

					var getSetKitsResetKit = models.createNewJSONModel(
						"com.khc.weighhub.controller.ReceiptWorkBench-->onClickNext-->SQLQ_GetSetKitsResetKit");
					getSetKitsResetKit.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetSetKitsResetKit&Param.1=" +
						orderID + "&Param.2=" + crID + "&Content-Type=text/json", "", false);
					WeighlistCount = getSetKitsResetKit.getData().Rowsets.Rowset[0].Row[0].Count;

					var getPartialMaterial = models.createNewJSONModel(
						"com.khc.weighhub.controller.ReceiptWorkBench-->onClickNext-->SQLQ_GetPartialMaterial");
					getPartialMaterial.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetPartialMaterial&Param.1=" +
						orderID + "&Content-Type=text/json", "", false);

					if (QnSelectedRow.STATUS == 1) {
						if (CommonUtility.getJsonModelRowCount(getPartialMaterial.getData()) == 0) {
							if (WeighedCount != 0 && WeighlistCount == 1) {

								var weighDataModel = new sap.ui.model.json.JSONModel();
								let weighData = {
									MsgId: QnSelectedRow.MSGID,
									CRId: crID,
									OrderId: orderID,
									MatNo: QnSelectedRow.MATNR,
									MatDesc: QnSelectedRow.MATTEXT,
									PlannedQty: QnSelectedRow.MATQTY,
									UoM: QnSelectedRow.UOM,
									DueDate: QnSelectedRow.STARTDATE,
									ModOrderId: QnSelectedRow.ModORDERID,
									ModMatNo: QnSelectedRow.ModMATNR,
									ReceiveQty: QnSelectedRow.RECEIVEQTY,
									ToReceiveQty: QnSelectedRow.TORECEIVEQTY,
									weighed: Weighed
								};
								weighDataModel.setData(weighData);
								sap.ui.getCore().setModel(weighDataModel, "weighingDataModel");

								UI_utilities.setContainerBusyState(this, true);
								var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
								oRouter.navTo("ReceiptConfirmation");

							} else {

								MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_065"));
							}

						} else {
							MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_037"));
						}

					} else if (QnSelectedRow.STATUS == 2) {

						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_024"));
					} else {

						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_019"));
					}

				} else {

					MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_011"));

				}

			},
		});
	});