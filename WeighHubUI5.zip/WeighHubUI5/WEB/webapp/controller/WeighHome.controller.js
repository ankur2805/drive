var that=this;
var printerIP;
var printerName;
var Scalename;
var projectName;
var oModelScaleName;
sap.ui.define([ "sap/ui/core/mvc/Controller", 
	"com/khc/weighhub/utils/UI_utilities",
	"com/khc/common/Script/CommonUtility",
	"com/khc/weighhub/model/formatter", "com/khc/weighhub/model/models"], function(Controller,
			UI_utilities, CommonUtility,formatter, models) {
	"use strict";
	return Controller.extend("com.khc.weighhub.controller.WeighHome", {
		formatter:formatter,
		onInit : function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("WeighHome").attachPatternMatched(
					this._oRoutePatternMatched, this);
			this._oRouter.getRoute("default").attachPatternMatched(
					this._oRoutePatternMatched, this);
		},

		_oRoutePatternMatched : function(oEvent) {

			// To set the menu as selected, hide message ad remove busy
			UI_utilities.weighPageOpened(this,"WeighHome");

			projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
			this.updateScaleName();
		},




		onAfterRendering : function() {

			// To set the menu as selected, hide message ad remove busy
			//UI_utilities.menuOpened(this,"RepHome");

		},




		onChangeSettingsBT : function() {

			// Set the busy indicator until the page  load
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("WeighSessionSetting");
			sap.ui.getCore().getModel("oMenu").setProperty("/selectedMenu","WeighSessionSetting");
		},


		onClickRecieving : function() {

			// Set the busy indicator until the page  load
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ReceiptWorkBench");
		},

		onClickWeighing : function() {

			// Set the busy indicator until the page  load
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("WeighingOrderListNew");
		},

		onClickWeighingLog : function() {

			// Set the busy indicator until the page  load
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("WeighingReport");
		},

		checkLogBt : function(){
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("logRep");
		},


		updateScaleName : function() {

			var changeFlag = 0;
			var MachineIP= sap.ui.getCore().getModel("session").getData().Machine;
			var printerNM= sap.ui.getCore().getModel("session").getData().CA_PrinterName;
			var scaleNM= sap.ui.getCore().getModel("session").getData().CA_ScaleName;
			var printerID= sap.ui.getCore().getModel("session").getData().CA_PrinterID;
			var username = sap.ui.getCore().getModel("session").getData().CA_IllumLoginName;
			var plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
			var resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
			var crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
			var plantTxt = sap.ui.getCore().getModel("session").oData.CA_PlantText;
			var resrText = sap.ui.getCore().getModel("session").oData.CA_ResrText;
			var destText = sap.ui.getCore().getModel("session").oData.CA_CRDestText;

			 oModelScaleName = models.createNewJSONModel(
					"com.khc.weighhub.controller.WeighHome-->updateScaleName-->SQLQ_GetScaleName");
			oModelScaleName.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetScaleName&Param.1=" + MachineIP + "&Content-Type=text/json", "", false);

			if (CommonUtility.getJsonModelRowCount(oModelScaleName.getData()) > 0) {

				printerIP = oModelScaleName.getData().Rowsets.Rowset[0].Row[0].PRINTERIP;
				printerName = oModelScaleName.getData().Rowsets.Rowset[0].Row[0].PRINTERNAME;
				Scalename = oModelScaleName.getData().Rowsets.Rowset[0].Row[0].SCALENAME;
			}

			if(printerIP){

				if(printerID != printerIP) {
					changeFlag=1;
					console.log("changeflag in ip")
				}
				else if(printerNM != printerName) {
					changeFlag=1;
					console.log("changeflag in PN")
				}
				else if(scaleNM != Scalename) {
					changeFlag=1;
					console.log("iinside if SNM")
				}

			}


			if (changeFlag==1){


				let attrName = "CA_Plant~CA_Resource~CA_CRDest~CA_PlantText~CA_ResrText~CA_CRDestText~CA_PrinterID~CA_PrinterName~CA_ScaleName";
				let attrValue = plant+"~"+resource+"~"+crdest+"~"+plantTxt+"~"+resrText+"~"+destText+"~"+printerIP+"~"+printerName+"~"+Scalename;

				CommonUtility.setCustomAttributeValue(username,attrName,attrValue).then(function (sResult) {


					if(sResult==="success")	{

						sap.ui.getCore().getModel("session").setProperty("/CA_PrinterID", printerIP);
						sap.ui.getCore().getModel("session").setProperty("/CA_PrinterName", printerName);
						sap.ui.getCore().getModel("session").setProperty("/CA_ScaleName", Scalename);
						sap.ui.getCore().getModel("session").setProperty("/CA_Plant", plant);
						sap.ui.getCore().getModel("session").setProperty("/CA_Resource", resource);
						sap.ui.getCore().getModel("session").setProperty("/CA_CRDest", crdest);
						sap.ui.getCore().getModel("session").setProperty("/CA_PlantText", plantTxt);
						sap.ui.getCore().getModel("session").setProperty("/CA_ResrText", resrText);
						sap.ui.getCore().getModel("session").setProperty("/CA_CRDestText", destText);

						var oUserSessionData = JSON.parse(sessionStorage[username]);
						oUserSessionData["CA_PrinterID"] = printerIP;
						oUserSessionData["CA_PrinterName"] = printerName;
						oUserSessionData["CA_ScaleName"] = Scalename; 
						oUserSessionData["CA_Plant"] = plant;
						oUserSessionData["CA_Resource"] = resource;
						oUserSessionData["CA_CRDest"] = crdest;
						oUserSessionData["CA_PlantText"] = plantTxt;
						oUserSessionData["CA_ResrText"] = resrText;
						oUserSessionData["CA_CRDestText"] = destText;


						console.log(oUserSessionData)
						sessionStorage.setItem(username,JSON.stringify(oUserSessionData));

					}
				});;
			}

		},




	});

});