var WeighListData;
var oModelWeighingMaterial;
var js_FlagWeighingMaterial = 0;
var OrderId = "";
var crid = "";
var msgId = "";
var txt_DelQty;
var txt_QtyUpdFieldFlag = "";
var txt_ToRecQty;
var navtype="";
var eflag="";
sap.ui.define(["sap/ui/core/mvc/Controller",
        "com/khc/weighhub/utils/UI_utilities",
        "sap/m/MessageBox",
        "com/khc/common/Script/CommonUtility", "com/khc/weighhub/model/formatter", "com/khc/weighhub/model/models"
    ],
    function(Controller,
        UI_utilities, MessageBox, CommonUtility, formatter, models) {
        "use strict";
        var plant;
        var resource;
        var projectName;
        var userName;
        var crDest;


        return Controller.extend("com.khc.weighhub.controller.WeighingListNew1", {
            formatter: formatter,

            onInit: function() {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("WeighingListNew1").attachPatternMatched(
                    this._oRoutePatternMatched, this);


            },


            _oRoutePatternMatched: function(oEvent) {

                UI_utilities.weighPageOpened(this, "WeighingListNew1");

                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
               

                OrderId = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_ordid
                crid = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_crid
                msgId = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_msgid
              
		      this.getView().byId("id_btn_Newprint").setVisible(false);

                            this.getView().byId("id_td_BlendreprintTable").setVisible(false);
	   var oDisplayData = {
                        selectedOption: "EAVisibility"
                    };
                    var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
                    this.getView().setModel(oDisplayOptionModel, "displayOption");
		 this.loadData();
                this.getWeighingMaterial();
		  this.setHeaderVal();
            },
            ///////////// Loading Input Values//////////////
            loadData: function() {
                WeighListData = sap.ui.getCore().getModel("weighingNewDataModel").oData;

                this.getView().byId("txt_ModOrderId").setValue(WeighListData.qs_modorderid);
                this.getView().byId("txt_ModMatNoStrip").setValue(WeighListData.qs_modmatno);
                this.getView().byId("txt_GoodDesc").setValue(WeighListData.qs_mattext);
                this.getView().byId("txt_PlannedQty").setValue(WeighListData.qs_matqty);
                this.getView().byId("txt_UOM").setValue(WeighListData.qs_uom);
                this.getView().byId("txt_DueDate").setValue(WeighListData.qs_duedate);
                this.getView().byId("txt_RecQty").setValue(WeighListData.qs_receiveqty);

            },

            //////Input Values End here/////////////////          

            setHeaderVal: function() {
				var oModelCounterOrder = models.createNewJSONModel(
 					"com.khc.weighhub.controller.WeighingListNew1-->setHeaderVal-->SQLQ_GetDistinctCounterForOrder");
                oModelCounterOrder.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetDistinctCounterForOrder&Param.1=" + OrderId + "&Param.2=" + crid + "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelCounterOrder, "oWeighingCounterOrder");

                var KitCounter = oModelCounterOrder.getData().Rowsets.Rowset[0].Row[0].COUNTER;

                txt_DelQty = (oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row[0].Completed);
                this.getView().byId("txt_ReqQty").setValue(oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row[0].Kit)


                var ActaulBatchSize = oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row[0].ActualBatchSize;
                var CurrentBatchSize = oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row[0].CurrentBatchSize;
                var TotalReceivedQuantity = oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row[0].TotalReceivedQuantity;


                this.getView().byId("txt_NewDelQty").setValue(KitCounter);

                if (txt_QtyUpdFieldFlag != "updated") {
                    this.getView().byId("txt_RecQty").setValue(WeighListData.qs_receiveqty);
                    txt_ToRecQty = WeighListData.qs_toreceiveqty;
                } else {
                    this.getView().byId("txt_RecQty").setValue(parseInt(WeighListData.qs_receiveqty) + parseInt(WeighListData.qs_toreceiveqty));
                    txt_ToRecQty = "0";

                }
                if (this.getView().byId("txt_ReqQty").getValue() == this.getView().byId("txt_NewDelQty").getValue()) {
                    this.getView().byId("txt_NewToRecQty").setValue(this.getView().byId("txt_ReqQty").getValue())
                } else {
                    this.getView().byId("txt_NewToRecQty").setValue("0");
                }
                if (this.getView().byId("txt_UOM").getValue() != 'EA') {
		  this.getView().getModel("displayOption").setProperty("/selectedOption", "NonEAVisibility");

                    this.getView().byId("txt_NonEARecQty").setValue(TotalReceivedQuantity);

                    this.getView().byId("txt_NonEAReqQty").setValue(Number(this.getView().byId("txt_ReqQty").getValue()) * Number(CurrentBatchSize));
                    this.getView().byId("txt_NonEANewToRecQty").setValue(Number(this.getView().byId("txt_NewToRecQty").getValue()) * Number(CurrentBatchSize));
                    this.getView().byId("txt_NonEANewDelQty").setValue(Number(this.getView().byId("txt_NewDelQty").getValue()) * Number(CurrentBatchSize));

                }

            },
            /////////////on Press:Receive Button/////////////////////////          	
            getBinList: function() {

                this.getView().byId("id_btn_StartWeigh").setEnabled(false);
                this.getView().byId("id_btn_CompPack").setEnabled(false);
                this.getView().byId("id_btn_back").setEnabled(false);
                this.getView().byId("id_btn_print").setEnabled(false);


                var flag = 1;
	   if(CommonUtility.getJsonModelRowCount(oModelWeighingMaterial.getData()) >0) {
                var gObj = oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row;

                var count = gObj[0].Count;
                if (count != 0) {
                    for (var i = 0; i < gObj.length; i++) {
                        if (gObj[i].Count != count) {
                            flag = 0;
                        }
                    }


                    if (flag) {


                       // var OrderId = this.getView().byId("txt_ModOrderId").getValue();
                        var OrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_ordid

                       	var oModelMaterial = models.createNewJSONModel(
 							"com.khc.weighhub.controller.WeighingListNew1-->getBinList-->SQLQ_GetPartialMaterial");
                        oModelMaterial.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetPartialMaterial&Param.1=" + OrderId + "&Content-Type=text/json", "", false);
                        this.getView().setModel(oModelMaterial, "oMaterial");



                        //if(oModelMaterial.getData().find("Row").length == "0")
                        //if($(oModelMaterial.getData()).find("Row").length==0)
                        if (CommonUtility.getJsonModelRowCount(oModelMaterial.getData()) == 0)

                        {

                            this.OpenReceipt();
                        } else {

                            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_037"));
                        }

                    } else {

                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_015"));
                    }
                } else {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_016"));
                }
                }
                this.getView().byId("id_btn_StartWeigh").setEnabled(true);
               this.getView().byId("id_btn_CompPack").setEnabled(true);
                this.getView().byId("id_btn_back").setEnabled(true);
                this.getView().byId("id_btn_print").setEnabled(true);
             
            },
            OpenReceipt: function() {


               
            	var MsgId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_msgid
                var CRId =sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_crid

                var OrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_ordid


                var MatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_matno                  
                var MatDesc = this.getView().byId("txt_GoodDesc").getValue();

                var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();
                var UoM = this.getView().byId("txt_UOM").getValue();
                var DueDate = this.getView().byId("txt_DueDate").getValue();
                
                //var MatNo = this.getView().byId("txt_ModMatNoStrip").getValue();

                var MatDesc = this.getView().byId("txt_GoodDesc").getValue();
                var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();
                var UoM = this.getView().byId("txt_UOM").getValue();
                var DueDate = this.getView().byId("txt_DueDate").getValue();
                
                var Weighed = oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row[0].Count;
                var Curr_Kits = oModelWeighingMaterial.getData().Rowsets.Rowset[0].Row[0].Kit; 
                
                

                var modOrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modorderid
                var modMatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modmatno
                var qtyToRecv = txt_ToRecQty;
                var qtyRecv = this.getView().byId("txt_RecQty").getValue();
                var WBFlag = "WeighList";


                var weighDataModel = new sap.ui.model.json.JSONModel();
                let weighData = {
                    
                
                		CRId: CRId,
                    MsgId: MsgId,
                    OrderId: OrderId,
                    MatNo: MatNo,                  
                    MatDesc: MatDesc,
                    PlannedQty:PlannedQty,
                    UoM:UoM,
                    DueDate:DueDate,
                    ModOrderId:modOrderId,
                    ModMatNo:modMatNo,                   
                    
                    WBFlag: WBFlag,
                   weighed:Weighed,
                    ReceiveQty:qtyRecv,
                    ToReceiveQty:qtyToRecv,
                   
                };
                weighDataModel.setData(weighData);
                sap.ui.getCore().setModel(weighDataModel, "weighingDataModel");
                this._oRouter.navTo("ReceiptConfirmation");
            },

            //////////////table data Binding ////////////////////////////
            getWeighingMaterial: function() {


                OrderId = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_ordid
                crid = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_crid
                
				 oModelWeighingMaterial = models.createNewJSONModel(
 							"com.khc.weighhub.controller.WeighingListNew1-->getWeighingMaterial-->XACQ_GetWeighingMaterial");
                oModelWeighingMaterial.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighingMaterial&Param.1=" + crid + "&Param.2=" + OrderId + "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelWeighingMaterial, "oWeighingMaterial");
		//plant=plant.replaceAll("\\s", "");
               	var oModelSharedMemory = models.createNewJSONModel(
 							"com.khc.weighhub.controller.WeighingListNew1-->getWeighingMaterial-->XACQ_GetPlantDetailsFromSharedMemory");
                oModelSharedMemory.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPlantDetailsFromSharedMemory&Param.1=" +plant +"&Content-Type=text/json", "", false);
                if (oModelSharedMemory.getData().Rowsets.Rowset[0].Row != undefined) {
                    var OrerForInsp = oModelSharedMemory.getData().Rowsets.Rowset[0].Row[0];
                    var orderCount = oModelSharedMemory.getData().Rowsets.Rowset[0].Row.length;


                    if (orderCount != 0) {
                        var OutputFlag = OrerForInsp.Output;
                        if (OutputFlag == 1) {

                            this.getView().byId("id_btn_Newprint").setVisible(true);

                            this.getView().byId("id_td_BlendreprintTable").setVisible(true);
                        }
                    }
                }
            },


            ////////////Back to Page///////////////////////     
            DirectToMain: function() {

                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("WeighingOrderListNew");

            },

            ///onPress:Reprintbutton//////////////     

            onReprintClick: function() {
                var kitSeq = this.getView().byId("txt_KitSeq").getValue();
                var SelRow = this.getView().byId("Id_MaterialList").getSelectedContextPaths().length;

                if (SelRow != 0 && kitSeq == "") {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_073"));
                } else if (SelRow == 0 && kitSeq != "") {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_074"));
                } else if (SelRow != 0 && kitSeq != "") {
                    var QnSelRow = this.getView().byId("Id_MaterialList").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("oWeighingMaterial").getProperty(QnSelRow);
                    var Componentmat = NtSelectedRow.MatNo;
                    var BelndId = NtSelectedRow.Blend;
                    var OrderId = NtSelectedRow.OrderId;

                    var Url = '/XMII/CM/WeighHubUI5/webapp/irpt/BlendReport.irpt?qs_ordid=' + OrderId + '&qs_Blend=' + BelndId + '&qs_KitSeq=' + kitSeq + '&qs_CompMat=' + Componentmat;
                    window.open(Url, 'BlendReport');
                } else {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_075"));
                }


            },


            PrintReport: function() {

                var PartialWeigh = sap.ui.getCore().getModel("session").oData.CA_WHPartialWeigh
                if (PartialWeigh == 1) {
                    this.PrintPartial();
                } else if (PartialWeigh == 0) {
                    this.PrintBin();
                }
            },

            PrintNewReport: function() {
                var PartialWeigh = sap.ui.getCore().getModel("session").oData.CA_WHPartialWeigh
                if (PartialWeigh == 1) {
                    this.PrintNewPartial();
                } else if (PartialWeigh == 0) {
                    this.PrintBin();
                }
            },

	PrintNewPartial:function(){
  OrderId = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_ordid
  crid = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_crid
  var headermat = this.getView().byId("txt_ModMatNoStrip").getValue();
  var headermattext = this.getView().byId("txt_GoodDesc").getValue();
  
  var Url = '/XMII/CM/GBL_WEIGHING/IRPT/PartialReportWithSSCC.irpt?qs_crid=' + crid + '&qs_ordid=' + OrderId+ '&qs_headmat=' + headermat+ '&qs_headmattext=' + headermattext;
  window.open(Url,'PartialReportWithSSCC');
},
            PrintPartial: function() {


                OrderId = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_ordid
                crid = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_crid
                var headermat = this.getView().byId("txt_ModMatNoStrip").getValue();
                var headermattext = this.getView().byId("txt_GoodDesc").getValue();

                var Url = '/XMII/CM/GBL_WEIGHING/IRPT/PartialReport.irpt?qs_crid=' + crid + '&qs_ordid=' + OrderId + '&qs_headmat=' + headermat + '&qs_headmattext=' + headermattext;
                window.open(Url, 'PartialReport');
            },

            PrintBin: function() {

                OrderId = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_ordid
                crid = sap.ui.getCore().getModel("weighingNewDataModel").getData().qs_crid
                var Url = '/XMII/CM/GBL_WEIGHING/IRPT/BinReport.irpt?qs_crid=' + crid + '&qs_ordid=' + OrderId;
                window.open(Url, 'BinReport');
            },


            ////////////Redirects to Read Weigh Page for weighing of the Material ///
            ///- On CLick of Start Weighing, Manual & Extra Button //////////////////////////////////

            GotoWeigh1: function(navtype, eflag) {

                var SelRow = this.getView().byId("Id_MaterialList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("Id_MaterialList").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("oWeighingMaterial").getProperty(QnSelRow);

                    var NoofKits = NtSelectedRow.Kit;
                    var SelRowCount = NtSelectedRow.Count;

                    if (navtype != "Manual") {
                        if (NoofKits != 0) {
                            if (parseInt(SelRowCount) < parseInt(NoofKits) || eflag == 1) {
                                msgId = WeighListData.qs_msgid;
                                crid = WeighListData.qs_crid;

                                var OrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_ordid


                                var MatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_matno                  
                                var MatDesc = this.getView().byId("txt_GoodDesc").getValue();

                                var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();
                                var UoM = this.getView().byId("txt_UOM").getValue();
                                var DueDate = this.getView().byId("txt_DueDate").getValue();
                                
                                var modOrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modorderid
                                var modMatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modmatno


                                var Sequence = NtSelectedRow.Sequence;
                                var Blend = NtSelectedRow.Blend;
                                var Component = NtSelectedRow.MatNo;
                                var CompDesc = NtSelectedRow.MatTxt;
                                var Qty = NtSelectedRow.Quantity;
                                var Grid_Uom = NtSelectedRow.UOM;
                                var itemno = NtSelectedRow.ITEMNO;

                                var recvquantity = this.getView().byId("txt_RecQty").getValue();
                                var quantitytorecv = txt_ToRecQty;

                                var Mode = "";

                                if (Blend != "SINGLE") {
                                    Mode = "Blend";
                                } else {
                                    Mode = "Single";
                                }
                                var WeightTestModel = new sap.ui.model.json.JSONModel();
                                let weighingTest = {
                                   
					qs_crid:crid,
					qs_msgid:msgId,
					qs_ordid:OrderId,
					qs_matno:MatNo,
					qs_desc:CompDesc,
					qs_matqty:PlannedQty,
					qs_uom:UoM,
					qs_duedate:DueDate,
					qs_sequence:Sequence,
					qs_comp:Component,
					qs_qty:Qty,
					qs_griduom:Grid_Uom,
					qs_mattext:MatDesc,
					qs_modorderid:modOrderId,
					qs_modmatno:modMatNo,
					qs_mode:Mode,
					qs_navtype:navtype,
					qs_eflag:eflag,
					qs_itemno:itemno,
					qs_receiveqty:recvquantity,
					qs_toreceiveqty:quantitytorecv
                                    
                                };
                                WeightTestModel.setData(weighingTest);
                                sap.ui.getCore().setModel(WeightTestModel, "weighingDataModel");
			UI_utilities.setContainerBusyState(this,true);
                                this._oRouter.navTo("ReadWeightTest");


                            } else {

                                MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_012"));
                            }
                        } else {

                            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_013"));
                        }
                    } else {
                        if (parseInt(SelRowCount) < parseInt(NoofKits) || eflag == 1)

                        {
                        	msgId = WeighListData.qs_msgid;
                            crid = WeighListData.qs_crid;

                            var OrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_ordid


                            var MatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_matno                  
                            var MatDesc = this.getView().byId("txt_GoodDesc").getValue();

                            var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();
                            var UoM = this.getView().byId("txt_UOM").getValue();
                            var DueDate = this.getView().byId("txt_DueDate").getValue();
                            
                            var modOrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modorderid
                            var modMatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modmatno


                            var Sequence = NtSelectedRow.Sequence;
                            var Blend = NtSelectedRow.Blend;
                            var Component = NtSelectedRow.MatNo;
                            var CompDesc = NtSelectedRow.MatTxt;
                            var Qty = NtSelectedRow.Quantity;
                            var Grid_Uom = NtSelectedRow.UOM;
                            var itemno = NtSelectedRow.ITEMNO;

                            var recvquantity = this.getView().byId("txt_RecQty").getValue();
                            var quantitytorecv = txt_ToRecQty;

                            var Mode="";
                            if (Blend != "SINGLE") {
                                Mode = "Blend";
                            } else {
                                Mode = "Single";
                            }
                            //window.location
                            var WeightTestModel = new sap.ui.model.json.JSONModel();
                            let weighingTest = {
					qs_crid:crid,
					qs_msgid:msgId,
					qs_ordid:OrderId,
					qs_matno:MatNo,
					qs_desc:CompDesc,
					qs_matqty:PlannedQty,
					qs_uom:UoM,
					qs_duedate:DueDate,
					qs_sequence:Sequence,
					qs_comp:Component,
					qs_qty:Qty,
					qs_griduom:Grid_Uom,
					qs_mattext:MatDesc,
					qs_modorderid:modOrderId,
					qs_modmatno:modMatNo,
					qs_mode:Mode,
					qs_navtype:navtype,
					qs_eflag:eflag,
					qs_itemno:itemno,
					qs_receiveqty:recvquantity,
					qs_toreceiveqty:quantitytorecv
                            };
                            WeightTestModel.setData(weighingTest);
                            sap.ui.getCore().setModel(WeightTestModel, "weighingDataModel");
		UI_utilities.setContainerBusyState(this,true);
                            this._oRouter.navTo("ReadWeightTest");

                        } else {

                            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_012"));
                        }
                    }
                } else {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_014"));

                }
            },

            ////////////onclick of  GotoPartial button///////////// 

            GotoPartial: function() {
                var SelRow = this.getView().byId("Id_MaterialList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("Id_MaterialList").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("oWeighingMaterial").getProperty(QnSelRow);

                    msgId = WeighListData.qs_msgid;
                    crid = WeighListData.qs_crid;

                   var OrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_ordid
                   
                    var MatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_matno                  
                    var MatDesc = this.getView().byId("txt_GoodDesc").getValue();
                    
                    var PlannedQty = this.getView().byId("txt_PlannedQty").getValue();
                    var UoM = this.getView().byId("txt_UOM").getValue();
                    var DueDate = this.getView().byId("txt_DueDate").getValue();
                    
                    var modOrderId = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modorderid
                    var modMatNo = sap.ui.getCore().getModel("weighingNewDataModel").oData.qs_modmatno

                    var Component = NtSelectedRow.MatNo;

                    var recvquantity = this.getView().byId("txt_RecQty").getValue();
                    var quantitytorecv = txt_ToRecQty;

					var oModelPartial = models.createNewJSONModel(
 							"com.khc.weighhub.controller.WeighingListNew1-->GotoPartial-->SQLQ_GetPartialMaterial");
                    oModelPartial.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetPartialMaterial&Param.1=" + OrderId + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oModelPartial, "oPartial");

                    //if(oModelPartial.lenght > "0")
                    //(APLT_CMD_PartialCheck.getRowCount() > "0")

                    if (CommonUtility.getJsonModelRowCount(oModelPartial.getData()) > 0)


                    {

                        var ReadDataModel = new sap.ui.model.json.JSONModel();
                        let ReadData = {
                            qs_crid: crid,
                            qs_msgid: msgId,
                            qs_ordid: OrderId,
                            qs_comp: Component,
                            qs_matno: MatNo,
                            qs_matqty: PlannedQty,
                            qs_uom: UoM,
                            qs_duedate: DueDate,
                            qs_mattext: MatDesc,
                            qs_modorderid: modOrderId,
                            qs_receiveqty: recvquantity,
                            qs_toreceiveqty: quantitytorecv,
                            qs_modmatno: modMatNo,
                            //qs_popupFlag: NonPopUp,

                        };
                        ReadDataModel.setData(ReadData);
                        sap.ui.getCore().setModel(ReadDataModel, "weighingDataModel");
		UI_utilities.setContainerBusyState(this, true);
                        this._oRouter.navTo("ReadWeightPartial");




                    } else {

                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_038"));

                    }
                } else {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_011"));

                }
            }

        });
    });