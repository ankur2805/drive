sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.khc.weighhub.controller.App", {
     onInit : function(){
	console.log("In com.khc.rephub.controller.App.COntroller");
	// To set the style based on the device
        	//this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
        },
        
        menuSelected : function (oEvent) {
			/*this.getView().getModel().setDefaultBindingMode("OneWay");*/
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("mainMenu");
			
        }
        
        
      });
    });
  