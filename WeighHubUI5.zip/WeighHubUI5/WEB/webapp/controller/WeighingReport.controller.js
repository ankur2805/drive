var table1Visibility;
var table2Visibility;
var expTab1Visibility;
var expTab2Visibility;
var plant;
var resource;
var resrtext;
var fromDate;
var toDate;
var username;
var blendno;
var kitNum;
var orderId;
var sCurrentLocale;
var resourceText;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/khc/weighhub/utils/UI_utilities",
	"com/khc/common/Script/CommonUtility",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/Filter", "com/khc/weighhub/model/models"
], function(Controller, UI_utilities, CommonUtility, JSONModel, MessageBox, Filter, models) {

	return Controller.extend("com.khc.weighhub.controller.WeighingReport", {

		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("WeighingReport").attachPatternMatched(this._oRoutePatternMatched, this);
			console.log("on init function");

		},
		_oRoutePatternMatched: function(oEvent) {
			console.log("pattern match funtion");
			UI_utilities.weighPageOpened(this);
				UI_utilities.DisableDatePickerInput(this.getView().byId("ToDate"));
			UI_utilities.DisableDatePickerInput(this.getView().byId("fromDate"));
			this.getData();
		},

		getData: function() {

			plant = sap.ui.getCore().getModel("session").getData().CA_Plant;
			resource = sap.ui.getCore().getModel("session").getData().CA_Resource;
			resrtext = sap.ui.getCore().getModel("session").getData().CA_ResrText;

			var myView = this.getView();
			
			var oModel = models.createNewXMLModel(
				"com.khc.weighhub.controller.WeighingReport-->getData-->XACQ_GetPlant");
			oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_BatchHub/QueryTemplate/XACQ_GetPlant&Content-Type=text/xml", "", false);
			myView.setModel(oModel, "oPlant");
			var oModel = models.createNewXMLModel(
				"com.khc.weighhub.controller.WeighingReport-->getData-->XACQ_GetResrByPlant");
			oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_BatchHub/QueryTemplate/XACQ_GetResrByPlant&Param.1=" + plant +
				"&Content-Type=text/xml", "", false);
			myView.setModel(oModel, "oResource");

			var oModel = models.createNewXMLModel(
				"com.khc.weighhub.controller.WeighingReport-->getData-->SQLQ_GetOrderList");
			oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetOrderList&Param.1=" + plant + "&Param.2=" +
				resource + "&Content-Type=text/xml", "", false);
			myView.setModel(oModel, "oOrder");
			this.oSF = myView.byId("OrderId");

			sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();

			expTab1Visibility = this.getView().byId("ExpTable1");
			expTab1Visibility.setVisible(false);
			table1Visibility = this.getView().byId("ListTable1");
			table1Visibility.setVisible(false);
			expTab2Visibility = this.getView().byId("ExpTable2");
			expTab2Visibility.setVisible(false);
			table2Visibility = this.getView().byId("ListTable2");
			table2Visibility.setVisible(false);

			/******************* Get and Set Localization Start*********************************/

			var oGetUserDataModel = models.createNewXMLModel(
				"com.khc.weighhub.controller.WeighingReport-->getData-->PropertyAccessServlet(language)");
			oGetUserDataModel.loadData("/XMII/PropertyAccessServlet?mode=Retrieve&PropName=Language&Content-Type=text/xml", "", false);
			language = oGetUserDataModel.getProperty("/Rowset/Row/Value");

			oLocalization = new sap.ui.model.resource.ResourceModel({
				bundleUrl: "/XMII/CM/GBL_WEIGHING/Localization/" + language + ".properties"
			});

			this.getView().byId("panel1").setModel(oLocalization, "Localization");

			/******************* Get and Set Localization End**********************************/
		},

		validatePage: function() {
			var fromDate1 = this.getView().byId("fromDate").getValue();

			var toDate1 = this.getView().byId("ToDate").getValue();

			var validateOk = false;

			if (plant == "" || plant == null) {
				MessageBox.alert(oLocalization.getResourceBundle().getText("WTR_MSG_0001"));
			} else if (resource == "" || resource == null) {
				MessageBox.alert(oLocalization.getResourceBundle().getText("WTR_MSG_0002"));
			} else if ((fromDate1 == "" && toDate1 == "") || (fromDate1 == null && toDate1 == null) || (fromDate1 == "" && toDate1 == null) ||
				(fromDate1 == null && toDate1 == "")) {
				MessageBox.alert(oLocalization.getResourceBundle().getText("WTR_MSG_0003"));
			} else if ((fromDate1 != null && toDate1 == null) || (fromDate1 == null && toDate1 != null) || (fromDate1 != "" && toDate1 == "") ||
				(fromDate1 == "" && toDate1 != "")) {
				MessageBox.alert(oLocalization.getResourceBundle().getText("WTR_MSG_0003"));
			} else if (fromDate1 > toDate1) {
				MessageBox.alert(oLocalization.getResourceBundle().getText("WTR_MSG_0004"));
			} else {
				validateOk = true;
			}
			return validateOk;
		},

		onPressSubmit: function() {
			//var plant = this.getView().byId("Plant").getSelectedKey();
			//var resource = this.getView().byId("Resource").getSelectedKey();
			//var resrtext = this.getView().byId("Resource")._getSelectedItemText();
			var validateOk = this.validatePage();
			if (validateOk == true) {

				expTab1Visibility.setVisible(true);
				table1Visibility.setVisible(true);
				expTab2Visibility.setVisible(false);
				table2Visibility.setVisible(false);
				var myView = this.getView();
				fromDate = this.getView().byId("fromDate").getValue();
				toDate = this.getView().byId("ToDate").getValue();
				username = this.getView().byId("username").getValue();
				blendno = this.getView().byId("blendNo").getValue();
				kitNum = this.getView().byId("kitNo").getValue();
				orderId = this.getView().byId("OrderId").getValue();
				var oModel =models.createNewXMLModel(
				"com.khc.weighhub.controller.WeighingReport-->onPressSubmit-->SQLQ_GetWeighKitTable");
				let attrName = "CA_Plant~CA_Resource~CA_ResrText";
				let attrValue = plant + "~" + resource + "~" + resrtext;

				sap.ui.getCore().getModel("session").setProperty("/CA_Plant", plant);
				sap.ui.getCore().getModel("session").setProperty("/CA_Resource", resource);
				sap.ui.getCore().getModel("session").setProperty("/CA_ResrText", resrtext);

				//var oUserSessionData 
				//oUserSessionData["CA_Plant"] = plant;
				//oUserSessionData["CA_Resource"] = resource;
				//oUserSessionData["CA_ResrText"] = resrtext;

				if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (orderId ==
						"" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWeighKitTable&Param.1=" + plant + "&Param.2=" +
						resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Content-Type=text/xml", "", false);

				} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (
						orderId == "" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKitByUsername&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Content-Type=text/xml", "",
						false);
				} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
						orderId == "" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyBlendNo&Param.1=" + plant + "&Param.2=" +
						resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + blendno + "&Content-Type=text/xml", "", false);
				} else if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
						orderId == "" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWkByKitNo&Param.1=" + plant + "&Param.2=" +
						resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + kitNum + "&Content-Type=text/xml", "", false);
				} else if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (
						orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyOrderId&Param.1=" + plant + "&Param.2=" +
						resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + orderId + "&Content-Type=text/xml", "", false);
				} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
						orderId == "" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserNAndBlend&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Content-Type=text/xml", "",
						false);
				} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
						orderId == "" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserAndKitHu&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + kitNum +
						"&Content-Type=text/xml", "", false);
				} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (
						orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserAndOrder&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + orderId +
						"&Content-Type=text/xml", "", false);
				} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) && (
						orderId == "" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyBlendAndKitHu&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.6=" + kitNum + "&Content-Type=text/xml", "",
						false);
				} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
						orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWkByBlendAndOrder&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.6=" + orderId + "&Content-Type=text/xml", "",
						false);
				} else if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
						orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyKitHuAndOrder&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + kitNum + "&Param.6=" + orderId +
						"&Content-Type=text/xml", "", false);
				} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) &&
					(orderId == "" || orderId == null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserBlendKitHu&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.7=" + kitNum +
						"&Content-Type=text/xml", "", false);
				} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) && (
						orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyBlendKitHuOrder&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.6=" + kitNum + "&Param.7=" + orderId +
						"&Content-Type=text/xml", "", false);
				} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
						orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyKithuOrderUser&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + kitNum + "&Param.6=" + orderId +
						"&Param.7=" + username + "&Content-Type=text/xml", "", false);
				} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
						orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserBlendOrder&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + orderId + "&Param.6=" + username +
						"&Param.7=" + blendno + "&Content-Type=text/xml", "", false);
				} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) &&
					(orderId !== "" || orderId !== null)) {
					oModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserBlendKithuOrder&Param.1=" + plant +
						"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + blendno +
						"&Param.7=" + kitNum + "&Param.8=" + orderId + "&Content-Type=text/xml", "", false);
				}

				myView.setModel(oModel, "oTable");

			} else {

			}

		},

		onRowSelectionTable1: function() {

			if (this.getView().byId("ListTable1").getSelectedIndex() === -1) {
				table2Visibility.setVisible(false);
				expTab2Visibility.setVisible(false);
			} else {

				table2Visibility.setVisible(true);
				expTab2Visibility.setVisible(true);
				var oTable = this.getView().byId("ListTable1");
				var oModel = oTable.getModel("oTable");

				var index = oTable.getSelectedIndex();
				var rows = oTable.getRows();
				var blendId = oModel.getProperty("/Rowset/Row/" + index + "/BLENDID");
				var kitSeq = oModel.getProperty("/Rowset/Row/" + index + "/KITSEQ");
				var orderid2 = oModel.getProperty("/Rowset/Row/" + index + "/ORDERID");

				//oDetailTableModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_Getdetailweighkit&Param.1=" + plant +"&Param.2=" + resource +"&Param.3="+orderid2+"&Param.4="+kitSeq+"&Param.5="+blendId+"&Content-Type=text/xml", "", false);

				//Modified by maviya for partial
				var oDetailTableModel.loadData(
					"/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighKitDetailsFromWeighKitAndPartial&Param.1=" + plant +
					"&Param.2=" + resource + "&Param.3=" + orderid2 + "&Param.4=" + kitSeq + "&Param.5=" + blendId + "&Content-Type=text/xml", "",
					false);
				var oModel = this.getView().byId("ListTable2");
				oModel.setModel(oDetailTableModel, "oTable1");
			}
		},
		onPressExportTable1: function() {

			var myView = this.getView();
			//	 var plant = myView.byId("Plant").getSelectedKey();
			//       var resource = myView.byId("Resource").getSelectedKey();
			//       var fromDate = this.getView().byId("fromDate").getValue();
			//       var toDate = this.getView().byId("ToDate").getValue();
			//		var username = this.getView().byId("username").getValue();
			//		var blendno = this.getView().byId("blendNo").getValue();
			//		var kitNum = this.getView().byId("kitNo").getValue();
			//		var orderId = this.getView().byId("OrderId").getValue();

			if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (orderId ==
					"" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWeighKitTable&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Content-Type=text/csv", "_self");

			} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (
					orderId == "" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKitByUsername&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Content-Type=text/csv", "_self");
			} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
					orderId == "" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyBlendNo&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + blendno + "&Content-Type=text/csv", "_self");
			} else if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
					orderId == "" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWkByKitNo&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + kitNum + "&Content-Type=text/csv", "_self");
			} else if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (
					orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyOrderId&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + orderId + "&Content-Type=text/csv", "_self");
			} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
					orderId == "" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserNAndBlend&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + blendno +
					"&Content-Type=text/csv", "_self");
			} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
					orderId == "" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserAndKitHu&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + kitNum +
					"&Content-Type=text/csv", "_self");
			} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum == "" || kitNum == null) && (
					orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserAndOrder&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + orderId +
					"&Content-Type=text/csv", "_self");
			} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) && (
					orderId == "" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyBlendAndKitHu&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + blendno + "&Param.6=" + kitNum +
					"&Content-Type=text/csv", "_self");
			} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
					orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWkByBlendAndOrder&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + blendno + "&Param.6=" + orderId +
					"&Content-Type=text/csv", "_self");
			} else if ((username == "" || username == null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
					orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyKitHuAndOrder&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + kitNum + "&Param.6=" + orderId +
					"&Content-Type=text/csv", "_self");
			} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) &&
				(orderId == "" || orderId == null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserBlendKitHu&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + blendno + "&Param.7=" + kitNum +
					"&Content-Type=text/csv", "_self");
			} else if ((username == "" || username == null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) && (
					orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyBlendKitHuOrder&Param.1=" + plant +
					"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + blendno + "&Param.6=" + kitNum +
					"&Param.7=" + orderId + "&Content-Type=text/csv", "_self");
			} else if ((username !== "" || username !== null) && (blendno == "" || blendno == null) && (kitNum !== "" || kitNum !== null) && (
					orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyKithuOrderUser&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + kitNum + "&Param.6=" + orderId + "&Param.7=" + username +
					"&Content-Type=text/csv", "_self");
			} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum == "" || kitNum == null) && (
					orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserBlendOrder&Param.1=" + plant + "&Param.2=" +
					resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + orderId + "&Param.6=" + username + "&Param.7=" +
					blendno + "&Content-Type=text/csv", "_self");
			} else if ((username !== "" || username !== null) && (blendno !== "" || blendno !== null) && (kitNum !== "" || kitNum !== null) &&
				(orderId !== "" || orderId !== null)) {
				window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWKbyUserBlendKithuOrder&Param.1=" + plant +
					"&Param.2=" + resource + "&Param.3=" + fromDate + "&Param.4=" + toDate + "&Param.5=" + username + "&Param.6=" + blendno +
					"&Param.7=" + kitNum + "&Param.8=" + orderId + "&Content-Type=text/csv", "_self");
			}

		},
		onPressExportTable2: function() {
			var oTable = this.getView().byId("ListTable1");
			var oModel = oTable.getModel("oTable");

			var index = oTable.getSelectedIndex();
			var rows = oTable.getRows();
			var blendId = oModel.getProperty("/Rowset/Row/" + index + "/BLENDID");
			var kitSeq = oModel.getProperty("/Rowset/Row/" + index + "/KITSEQ");
			var orderid2 = oModel.getProperty("/Rowset/Row/" + index + "/ORDERID");
			//window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_Getdetailweighkit&Param.1=" + plant +"&Param.2=" + resource +"&Param.3="+orderid2+"&Param.4="+kitSeq+"&Content-Type=text/csv", "_self");

			//Modified by maviya for partial
			window.open("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighKitDetailsFromWeighKitAndPartial&Param.1=" +
				plant + "&Param.2=" + resource + "&Param.3=" + orderid2 + "&Param.4=" + kitSeq + "&Content-Type=text/csv", "_self");

		},

		statusFormat: function(value) {

			if (value != null) {
				var receipt;
				if (value == 1) {
					receipt = "Receipt";
				} else {
					receipt = "Weighed";
				}

				return receipt;

			}
			return value;
		},

		onSuggest: function(event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter([
						new Filter("ORDERID", function(sText) {
							return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						}),
						new Filter("ORDERID", function(sDes) {
							return (sDes || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						})
					], false)
				];
			}

			this.oSF.getBinding("suggestionItems").filter(aFilters);
			this.oSF.suggest();
		},

		getFormat: function(value) {

			if (value != null) {
				var value = value.replace(/^0+/, '');

				return value;

			}
			return value;
		},
		dateFormat: function(value) {

			if (value != null) {
				var date = new Date(value);
				var formattedDate = date.toLocaleString(sCurrentLocale);

				return formattedDate;
			}
			return value;
		},

		goBack: function() {
			//window.location.href="/XMII/CM/GBL_WEIGHING/IRPT/MainMenuWeighing.irpt";
			window.history.back();

		}

	});
});