var global ="";
var username="";
var plantid="";
var plantresr="";
var scalid="";
var printerrid="";
var bScaleIntegration = false;

var projectName ;

	sap.ui.define(["sap/ui/core/mvc/Controller",
		"com/khc/weighhub/utils/UI_utilities",
		"com/khc/weighhub/model/models",
		"com/khc/common/Script/CommonUtility"], 
	function(Controller,UI_utilities,models,CommonUtility) {
	"use strict";
	return Controller.extend("com.khc.weighhub.controller.WeighSessionSetting", {
		
		/**
		 * Called when a controller is instantiated and its View
		 * controls (if available) are already created. Can be used to
		 * modify the View before it is displayed, to bind event
		 * handlers and do other one-time initialization.
		 */
		onInit : function() {
			// Register the _oRoutePatternMatched methos, init will be
			// called only once
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// WeighHome is your Route name and set the menu key as the
			// same name
			this._oRouter.getRoute("WeighSessionSetting").attachPatternMatched(
					this._oRoutePatternMatched, this);


		},

		/**
		 * Called when the Routing is matched, 'WeighHome'
		 * 
		 */

		_oRoutePatternMatched : function(oEvent) {
			//Hide the messages and set busy to false
			UI_utilities.weighPageOpened(this,"WeighSessionSetting");
			projectName = sap.ui.getCore().getModel("session").getData().CA_ProjectName;
			this.loadScale();
			this.getPlantData();
			this.setInitialValues();
			this.setOldData();
			
		},

		/**
		 * Called when the View has been rendered (so its HTML is part
		 * of the document). Post-rendering manipulations of the HTML
		 * could be done here. This hook is the same one that SAPUI5
		 * controls get after being rendered.
		 */
		onAfterRendering : function() {
			// To set the menu as selected, hide message ad remove busy
			//UI_utilities.menuOpened(this,"WeighHome");

		},

		onSave:function(){

			var obj = this;
			var xmlHttp;
			var plant = this.getView().byId("PlantLoc").getSelectedKey();
			var resource = this.getView().byId("ResourceT").getSelectedKey();
			var workstation = this.getView().byId("WorkSt").getSelectedKey();
			var scale = this.getView().byId("ScaleNm").getSelectedKey();
			  var  printerId= this.getView().byId("PrinterNm").getSelectedKey();
			var planttext = this.getView().byId("PlantLoc")._getSelectedItemText();
			var resrtext = this.getView().byId("ResourceT")._getSelectedItemText();
			var worksttext = this.getView().byId("WorkSt")._getSelectedItemText();
			var printer = this.getView().byId("PrinterNm")._getSelectedItemText();
			var username = sap.ui.getCore().getModel("session").getData().CA_IllumLoginName;
			let  attrName = "CA_Plant~CA_Resource~CA_CRDest~CA_PlantText~CA_ResrText~CA_CRDestText~CA_ScaleName~CA_PrinterName~CA_PrinterID";
			let attrValue = plant+"~"+resource+"~"+workstation+"~"+planttext+"~"+resrtext+"~"+worksttext+"~"+scale+"~"+printer+"~"+printerId;
			var fetchData ="";
			var sScaleName = "";

			/*xmlHttp=new XMLHttpRequest();  
			alert("Plant : "+plant+", Resource : "+resource+", Work Station : "+workstation+", Scale : "+scale+", Printer : "+printer);*/

			if (plant!="" && resource!="" && workstation!="" )
			{
				var that = this;
				if(bScaleIntegration)	{
    	 
				var oScaleCombo = this.getView().byId("scaleName");
				sScaleName = oScaleCombo.getSelectedKey();
				//to do add the scale name validation
				if(!sScaleName){
	    		
				}
	    	
				 attrName = "CA_Plant~CA_Resource~CA_CRDest~CA_PlantText~CA_ResrText~CA_CRDestText~CA_ScaleName~CA_PrinterName~CA_PrinterID";
				 attrValue = attrValue+"~"+sScaleName;
				}
	 
				CommonUtility.setCustomAttributeValue(username,attrName,attrValue).then(function (sResult) {
				if(sResult==="success")	{

					sap.ui.getCore().getModel("session").setProperty("/CA_Plant", plant);
					sap.ui.getCore().getModel("session").setProperty("/CA_Resource", resource);
					sap.ui.getCore().getModel("session").setProperty("/CA_CRDest", workstation);
					sap.ui.getCore().getModel("session").setProperty("/CA_PlantText", planttext);
					sap.ui.getCore().getModel("session").setProperty("/CA_ResrText", resrtext);
					sap.ui.getCore().getModel("session").setProperty("/CA_CRDestText", worksttext);
					sap.ui.getCore().getModel("session").setProperty("/CA_ScaleName", scale);
					sap.ui.getCore().getModel("session").setProperty("/CA_PrinterName",printer);
					sap.ui.getCore().getModel("session").setProperty("/CA_PrinterID",printerId);
					
				// Update Local storage

					var oUserSessionData = JSON.parse(sessionStorage[username]);
					oUserSessionData["CA_Plant"] = plant;
					oUserSessionData["CA_Resource"] = resource;
					oUserSessionData["CA_CRDest"] = workstation;
					oUserSessionData["CA_PlantText"] = planttext;
					oUserSessionData["CA_ResrText"] = resrtext;
					oUserSessionData["CA_CRDestText"] = worksttext;
					oUserSessionData["CA_ScaleName"] = scale;
					oUserSessionData["CA_PrinterName"] = printer;
					oUserSessionData["CA_PrinterID"] = printerId;
					
					 if(bScaleIntegration)	{
						 
						 sap.ui.getCore().getModel("session").setProperty("/CA_ScaleName", sScaleName);
						 oUserSessionData["CA_ScaleName"] = sScaleName;
					 }
					
					sessionStorage.setItem(username,JSON.stringify(oUserSessionData));
					
					// Show Success Message in the screen
					sap.ui.getCore().getModel("oMessage").setProperty("/message","Values updated");
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
					
					// to navigate back to home screen
					setTimeout(function(){ that.onBack(); 
					}, 2000);
				
				}
					else{
				 
				 	sap.ui.getCore().getModel("oMessage").setProperty("/message","Error while updating the values");
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Error")
					}
				});;
			}

			else
			{
			//alert("Select values for Plant, Resource and Work Station");
				// Show Success Message in the screen
				sap.ui.getCore().getModel("oMessage").setProperty("/message","Select values for Plant, Resource andWork Station");
				sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
				sap.ui.getCore().getModel("oMessage").setProperty("/type","Error");
			} 
			//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				//oRouter.navTo("WeighHome");
				
				this.UpdateIPList(); 	
		},
		
		
		UpdateIPList:function() {
			
		var printerIP = sap.ui.getCore().getModel("session").getData().CA_PrinterID;
		var printerName = sap.ui.getCore().getModel("session").getData().CA_PrinterName;
		var Scalename=sap.ui.getCore().getModel("session").getData().CA_ScaleName;
		var MachineIP =sap.ui.getCore().getModel("session").getData().Machine;
		
			var oModelSessionSetting = models.createNewJSONModel(
					"com.khc.weighhub.controller.WeighSessionSetting-->UpdateIPList-->SQLQ_GetScaleName");
		oModelSessionSetting.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetScaleName&Param.1=" + MachineIP+ "&Content-Type=text/json", "", false);
		//this.getView().setModel(oModelSessionSetting,"oSessionSetting");
		
		if(CommonUtility.getJsonModelRowCount(oModelSessionSetting.getData())!= 0) {
		var oSessionSetting = oModelSessionSetting.getData().Rowsets.Rowset[0].Row[0];
			
		var ConfigPrinterIP = oSessionSetting.PRINTERIP;
		 
		 if(ConfigPrinterIP!=""){
		
		var oModelSessionSettingUP = models.createNewJSONModel(
					"com.khc.weighhub.controller.WeighSessionSetting-->UpdateIPList-->SQLQ_UpdateIPList");
		oModelSessionSettingUP.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateIPList&Param.1=" + printerIP + "&Param.2=" + printerName + "&Param.3=" + Scalename + "&Param.4=" + MachineIP+"&Content-Type=text/json", "", false);
		
					sap.ui.getCore().getModel("oMessage").setProperty("/message","Values updated");
					sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",true);
					sap.ui.getCore().getModel("oMessage").setProperty("/type","Success");
		 }
		}
		 
		},
			/**
			 * to open the help document
			 */

		onHelp:function(){
			UI_utilities.OpenHelpFileSingle("Changesettings");
		},

		onBack:function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("WeighHome");
			//window.location.replace("/XMII/CM/NL_ELS_HUB_SAPUi5/webapp/index.irpt#/WeighHome");
			//location.reload();
		},

		getPlantData:function(oEvent){
			
			var oModel1 = new sap.ui.model.xml.XMLModel();
			var oModel1 = models.createNewXMLModel(
					"com.khc.weighhub.controller.WeighSessionSetting-->getPlantData-->XACQ_GetPlant");
			oModel1.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetPlant&content-type=text/xml", "", false);
			var oPlant = this.getView().byId("PlantLoc");
			oPlant.setModel(oModel1, "DropDown");
			this.getView().byId("PlantLoc").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Plant);
			this.onPlantChange();
		},

		onPlantChange:function(){
			plantid = this.getView().byId("PlantLoc").getSelectedKey();
			var oModel2 = models.createNewXMLModel(
					"com.khc.weighhub.controller.WeighSessionSetting-->onPlantChange-->XACQ_GetResrByPlant");
			oModel2.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetResrByPlant&Param.1=" + plantid + "&content-type=text/xml", "", false);
			var oResourceNm = this.getView().byId("ResourceT");
			oResourceNm.setModel(oModel2, "DropDownResource");
			this.getView().byId("ResourceT").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Resource);

			// call the GBL_WEIGHING/QueryTemplate/XACQ_GetPrinterListByPlant by passing the plant and set the printer model

			//plantid = this.getView().byId("PlantLoc").getSelectedKey();
			var oModel4 = models.createNewXMLModel(
					"com.khc.weighhub.controller.WeighSessionSetting-->onPlantChange-->XACQ_GetPrinterListByPlant");
			oModel4.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPrinterListByPlant&Param.1=" + plantid + "&content-type=text/xml", "", false);
			var oPrinterNm = this.getView().byId("PrinterNm");
			oPrinterNm.setModel(oModel4, "oPrinter");
			this.getView().byId("PrinterNm").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_PrinterID);
	
			this.onResourceChange();
			//this.onWorkStationChange();
		},

		onResourceChange:function(oEvent3){
			plantid = this.getView().byId("PlantLoc").getSelectedKey();
			plantresr = this.getView().byId("ResourceT").getSelectedKey();
			var oModel3 = models.createNewXMLModel(
					"com.khc.weighhub.controller.WeighSessionSetting-->onResourceChange-->XACQ_GetCRDestByResr");
			
			oModel3.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetCRDestByResr&Param.1=" + plantid + "&Param.2=" + plantresr + "&content-type=text/xml", "", false);
			var oWorkSt = this.getView().byId("WorkSt");
			oWorkSt.setModel(oModel3, "DropDownWortSt");
			this.getView().byId("WorkSt").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_CRDest);

		},

		loadScale:function(){
			
			scalid = this.getView().byId("ScaleNm").getSelectedKey();
			this.getView().byId("ScaleNm").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_ScaleName);
			var oModel2 = models.createNewXMLModel(
					"com.khc.weighhub.controller.WeighSessionSetting-->loadScale-->XACQ_GetWeighScaleList");
			oModel2.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighScaleList&content-type=text/xml", "", false);;
			var scalName = this.getView().byId("ScaleNm");
			scalName.setModel(oModel2, "oScale");
			this.getView().byId("ScaleNm").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_ScaleName);
			},

		setInitialValues:function(){
			plantid = this.getView().byId("PlantLoc").getSelectedKey();
			plantresr = this.getView().byId("ResourceT").getSelectedKey();
			scalid = this.getView().byId("ScaleNm").getSelectedKey();
			printerrid = this.getView().byId("PrinterNm").getSelectedKey();

		},
	
		setOldData:function(){
			this.getView().byId("PlantLoc").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Plant);
			this.getView().byId("ResourceT").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Resource);
			this.getView().byId("WorkSt").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_CRDest);
			this.getView().byId("PrinterNm").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_PrinterID);
			this.getView().byId("ScaleNm").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_ScaleName);

		}

	});

});

//# sourceURL=http://khuscsapgib00.mykft.net:50000/XMII/CM/WeighHubUI5/webapp/controller/WeighSessionSetting.controller.js?eval