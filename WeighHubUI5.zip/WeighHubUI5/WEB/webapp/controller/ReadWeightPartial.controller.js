var plant;
var resource;
var printerID;
var scalename;
var CRId;
var msgid;
var Component;
var OrderId;
var counter;
var MatNoStrip;
var ScaleDecimal;
var addweigh=1;
var gb_material="";
var addblendfrompartial;
var PartialFlag;
var kits;
var packingMat;
var minval;
var maxval;
var LowTolerance;
var UpTolerance;
var hid_flag;
var MatCount;
var scanhuFlag;
var sumBlendWeight = 0;
var TargetFlag = 0;
var blendcode;
var BackFlag = 0;
var resetFlag = 0;
var CountBlend = 0;
var BlendType ="";
var BlendName = "";
var blendPrintFlag;
var gaugeDialFlag;
var MatPosition=0;
var UpTrgtWgt;
var LowTrgtWgt;
var blendPrintPopupFlag;
var PCoWebSocketFlag;
var getWeighingMaterialModel;
var currentMaterialModel;
var getWeighingMaterialModel;
var getBatchByMaterialModel;
var CurrSelRow =0;
var uname;
var id_hid_counter;
var hid_eflag;
var js_FlagBROBatch = 0;
var js_FlagCMDGetSelBatch = 0;
var getPartialMaterialModel;
var selectedRowVar;
var HUSCAN;
var carrysum;
var currentfocusID;
sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/Button",
	"com/khc/weighhub/utils/UI_utilities",
	"com/khc/common/Script/CommonUtility",
	"com/khc/weighhub/model/formatter",
	"sap/m/MessageBox"
	],
	function(Controller,Button,UI_utilities,CommonUtility,formatter,MessageBox) {

	"use strict";
	var plant;
	var resource;

	return Controller.extend("com.khc.weighhub.controller.ReadWeightTest", {
		formatter:formatter,
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("ReadWeightPartial").attachPatternMatched(this._oRoutePatternMatched, this);
			console.log("on init function");	
		},

		_oRoutePatternMatched: function(oEvent) {
			console.log("pattern match funtion");
			UI_utilities.weighPageOpened(this, "ReadWeightPartial");
			/**************
			var qs_crid="100000000012514705";
			var qs_msgid="255201";
			var qs_ordid="000001952834";
			var qs_matno="000000000053969214";
			var qs_desc="77 Spice";
			var qs_matqty=100;
			var qs_uom="EA";
			var qs_duedate="2023-04-13";
			var qs_sequence=1;
			var qs_comp="000000000015003568";
			var qs_qty="5.17";
			var qs_griduom="KG";
			var qs_mattext="94 SPICE KIT,RAVIOLI IN T/S MJ";
			var qs_modorderid="1952834";
			var qs_modmatno="53969214";
			var qs_mode="Blend";
			var qs_navtype="Auto";
			var qs_eflag;
			var qs_itemno="0010";
			var qs_receiveqty=1;
			var qs_toreceiveqty=-1;

			var weighDataModel = new sap.ui.model.json.JSONModel();
			let weighData = {
					qs_crid:qs_crid,
					qs_msgid:qs_msgid,
					qs_ordid:qs_ordid,
					qs_matno:qs_matno,
					qs_desc:qs_desc,
					qs_matqty:qs_matqty,
					qs_uom:qs_uom,
					qs_duedate:qs_duedate,
					qs_sequence:qs_sequence,
					qs_comp:qs_comp,
					qs_qty:qs_qty,
					qs_griduom:qs_griduom,
					qs_mattext:qs_mattext,
					qs_modorderid:qs_modorderid,
					qs_modmatno:qs_modmatno,
					qs_mode:qs_mode,
					qs_navtype:qs_navtype,
					qs_eflag:qs_eflag,
					qs_itemno:qs_itemno,
					qs_receiveqty:qs_receiveqty,
					qs_toreceiveqty:qs_toreceiveqty
			};	
			weighDataModel.setData(weighData);
			sap.ui.getCore().setModel(weighDataModel, "weighingDataModel");
			 **********/

			Component = sap.ui.getCore().getModel("weighingDataModel").oData.qs_comp;
			this.getView().byId("id_btn_ReadScale").setType("Emphasized");
			this.clearValues();
			this.SetBatch();

			this.SetFlagCMDGetSelBatch();
			this.SetScaleName();
			this.getGaugeDialFlagFromSharedMem();
			this.getWeighingMaterial();

		},

		SetBatch: function() {

			js_FlagBROBatch=1;
			MatPosition=0;
			plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
			ScaleDecimal = sap.ui.getCore().getModel("session").oData.CA_ScaleDecimal;
			uname = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
			scalename = sap.ui.getCore().getModel("session").oData.CA_ScaleName;
			printerID =sap.ui.getCore().getModel("session").oData.CA_PrinterID; 
			resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
			MatNoStrip = sap.ui.getCore().getModel("weighingDataModel").oData.qs_matno;
			msgid = sap.ui.getCore().getModel("weighingDataModel").oData.qs_msgid;
			CRId = sap.ui.getCore().getModel("weighingDataModel").oData.qs_crid;

			OrderId = sap.ui.getCore().getModel("weighingDataModel").oData.qs_ordid;
			hid_flag = sap.ui.getCore().getModel("weighingDataModel").oData.qs_navtype;
			counter = this.getView().byId("txt_Counter").getValue();
			id_hid_counter = sap.ui.getCore().getModel("weighingDataModel").oData.qs_counter;
			hid_eflag = sap.ui.getCore().getModel("weighingDataModel").oData.qs_eflag;
			carrysum = sap.ui.getCore().getModel("weighingDataModel").oData.qs_carrysum;

			var counterarray = counter.split("/");
			var counterval = counterarray[0];

			getBatchByMaterialModel = new sap.ui.model.json.JSONModel();
			var batchVar= this.getView().byId("td_select_batch");
			//getBatchByMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchByMaterial&Param.1="+CRId+"&Param.2="+Component+"&Content-Type=text/xml", "", false);
			//sap.ui.getCore().setModel(getBatchByMaterialModel, "getBatchByMaterialData");

			getBatchByMaterialModel.attachRequestCompleted(
					function(){ 
						if(CommonUtility.getJsonModelRowCount(getBatchByMaterialModel.getData()) > 0){
							batchVar.setModel(getBatchByMaterialModel, "getBatchByMaterialData");
						}
					});
			getBatchByMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchByMaterial&Param.1="+CRId+"&Param.2="+Component+"&Content-Type=text/json", "", false);

			if(js_FlagCMDGetSelBatch == 1)
			{
				var getMatWeighedBatchModel = new sap.ui.model.json.JSONModel();
				getMatWeighedBatchModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetMatWeighedBatch&Param.1="+Component+"&Param.2="+OrderId+"&Param.3="+CRId+"&Content-Type=text/json", "", false);

				if (CommonUtility.getJsonModelRowCount(getMatWeighedBatchModel.getData()) > 0) {
					var DefBatch= getMatWeighedBatchModel.getData().Rowsets.Rowset[0].Row[0].BATCH;
					this.getView().byId("td_select_batch").setSelectedKey(DefBatch);
					var path = this.getView().byId("td_select_batch").getSelectedItem().oBindingContexts.getBatchByMaterialData.sPath;
					var text_avail= getBatchByMaterialModel.getProperty(path+"/AVAIL")
					var avail_unit= text_avail+" "+this.getView().byId("txt_GridUOM").getValue();
					this.getView().byId("txt_Avail").setValue(avail_unit);
				}
			}
		},

		SetScaleName: function() {

			var GetWeighScaleListModel = new sap.ui.model.xml.XMLModel();
			GetWeighScaleListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighScaleList&Content-Type=text/xml", "", false);
			sap.ui.getCore().setModel(GetWeighScaleListModel, "GetWeighScaleListData");
			this.getView().byId("weighScaleList").setSelectedKey(this.getView().byId("weighScaleList").getKeys()[0]);
		},

		getGaugeDialFlagFromSharedMem: function() {

			var getPlantDetailsFromSharedMemoryModel = new sap.ui.model.json.JSONModel();
			getPlantDetailsFromSharedMemoryModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPlantDetailsFromSharedMemory&Param.1="+plant+"&Content-Type=text/json", "", false);
			blendPrintFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].Output;
			gaugeDialFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].Output_flag;
			blendPrintPopupFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].O_Flag;
			PCoWebSocketFlag= getPlantDetailsFromSharedMemoryModel.getData().Rowsets.Rowset[0].Row[0].WebSocket_Output_Flag;

		},

		getWeighingMaterial: function() {

			getPartialMaterialModel = new sap.ui.model.json.JSONModel();
			getPartialMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=WeighHubUI5/QueryTemplate/SQLQ_GetPartialMaterial&Param.1="+OrderId+"&Content-Type=text/json", "", false);

			var gridCount = CommonUtility.getJsonModelRowCount(getPartialMaterialModel.getData());

			if(gridCount>0){

				selectedRowVar = 0;

			}

			else{
				this.GetBack();
			}

			this.enableHU();
			this.populateData();
			this.UpperLowerLimitValues();
			this.GaugeDialValues();

		},

		GetBack: function() {
			/*********
			//var qs_mattext=this.getView().byId("txt_GoodDesc").getValue();
			//var qs_matqty=this.getView().byId("txt_PlannedQty").getValue();
			//var qs_uom=this.getView().byId("txt_UOM").getValue();
			//var qs_duedate=this.getView().byId("txt_DueDate").getValue();
			var qs_modmatno=this.getView().byId("txt_modMatNoStrip").getValue();
			var qs_modorderid=this.getView().byId("txt_modOrderId").getValue();
			//var qs_receiveqty=this.getView().byId("txt_RecQty").getValue();
			var qs_toreceiveqty=this.getView().byId("txt_ToRecQty").getValue();

			var weighNewModel = new sap.ui.model.json.JSONModel();
			let weighNewData = {
					qs_msgid:msgid,  
					qs_crid:CRId,
					qs_ordid:OrderId,
					qs_matno:MatNoStrip,
					qs_modmatno:qs_modmatno,
					qs_mattext:qs_mattext,
					qs_modorderid:qs_modorderid,
					qs_matqty:qs_matqty,
					qs_uom:qs_uom,  
					qs_duedate:qs_duedate,
					qs_receiveqty:qs_receiveqty,  
					qs_toreceiveqty:qs_toreceiveqty

			};
			weighNewModel.setData(weighNewData);
			sap.ui.getCore().setModel(weighNewModel, "weighingNewDataModel");
			 *********/
			BackFlag = 1;
			UI_utilities.setContainerBusyState(this,true);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("WeighingListNew1");

		},

		ReadWeight: function(weighType) {

			var dp = parseInt(ScaleDecimal);

			PartialFlag = weighType;

			var DestID = "";

			if(plant =="3278") {
				DestID = "MT_SCALES_ELST";
			}
			else if(plant =="3005") {
				DestID = "SCALES_KG";
			}
			else if(plant =="3414") {
				DestID = "SCALES_LL";
			}
			else if(plant =="3309") {
				DestID = "SCALES_PU";
			}

			var O_Weight;
			var TrgtWeight = this.getView().byId("txt_TarWeight").getValue();
			var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
			RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
			var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			//document.getElementById("txt_ScaleWgt").style.background = "";
			this.getView().byId("id_btn_NextIngr").setType("Default");
			this.getView().byId("id_btn_NextIngr").setEnabled(false);


			if (plant !="3137") {
				if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
				{
					var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.005;
					UpTrgtWgt = UpperTrgtWeight;

					var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.005;
					LowTrgtWgt = LowerTrgtWeight;
				}
				else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
				{
					var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.01;
					UpTrgtWgt = UpperTrgtWeight;

					var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.01;
					LowTrgtWgt = LowerTrgtWeight;
				}

				else if (FormatTrgrtWgt > 5)
				{
					var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + 0.05;
					UpTrgtWgt = UpperTrgtWeight;

					var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - 0.05;
					LowTrgtWgt = LowerTrgtWeight;
				}

			}

			else {

				var LowerTrgtWeight = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
				LowTrgtWgt = LowerTrgtWeight;

				var UpperTrgtWeight = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;
				UpTrgtWgt = UpperTrgtWeight;

			} 
			if (this.getView().byId("txt_WeighMode").getValue() == "Blend")
			{
				if (CountBlend == counter && BlendName == this.getView().byId("txt_Blend").getValue())
				{
				}
				else if (CountBlend == counter && BlendName == "")
				{
				}
				else
				{
					sumBlendWeight = 0;
				}
			}

			if (sumBlendWeight == "0")
			{
				var FormatupperLmt = parseFloat(UpperTrgtWeight).toFixed(dp);
				var FormatLowerLmt = parseFloat(LowerTrgtWeight).toFixed(dp);
			}
			else
			{
				var FormatupperLmt = parseFloat(UpperTrgtWeight) + parseFloat(sumBlendWeight);
				var FormatLowerLmt = parseFloat(LowerTrgtWeight) + parseFloat(sumBlendWeight);

				var FormatupperLmt = parseFloat(FormatupperLmt).toFixed(dp);
				var FormatLowerLmt = parseFloat(FormatLowerLmt).toFixed(dp);
			}

			if (this.getView().byId("txt_ScaleWgt").getValue() == "")
			{

				var PCoConnectionFlag = parseInt(PCoWebSocketFlag);

				if(PCoConnectionFlag == 1)
				{
					var Scale = this.getView().byId("weighScaleList").getSelectedKey();
					var GetWeighScaleReadingFromPCoModel = new sap.ui.model.json.JSONModel();
					GetWeighScaleReadingFromPCoModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighScaleReadingFromPCo&Param.1="+plant+"&Param.2="+resource+"&Param.3="+Scale+"&Content-Type=text/json", "", false);

					O_Weight = GetWeighScaleReadingFromPCoModel.getData().Rowsets.Rowset[0].Row[0].Value;


				}
				else {		

					var ReadWeightModel = new sap.ui.model.json.JSONModel();
					ReadWeightModelModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_ReadWeight&Param.1="+DestID+"&Param.2="+scalename+"&Param.3="+FormatLowerLmt+"&Param.4="+FormatupperLmt+"&Content-Type=text/json", "", false);

					O_Weight = ReadWeightModel.getData().Rowsets.Rowset[0].Row[0].O_Weight;

				}
			}
			else
			{
				if (isNaN(this.getView().byId("txt_ScaleWgt").getValue()))
				{
					MessageBox.alert("Please enter a number");	
				}
				else
				{
					O_Weight = this.getView().byId("txt_ScaleWgt").getValue();
				}
			}

			var SclWeight = parseFloat(O_Weight) - parseFloat(sumBlendWeight);


			this.getView().byId("txt_ScaleWgt").setValue(parseFloat(SclWeight).toFixed(dp));


			if (isNaN(this.getView().byId("txt_ScaleWgt").getValue()) || this.getView().byId("txt_ScaleWgt").getValue()== 0)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_009"));
				this.getView().byId("txt_ScaleWgt").setValue("");
				this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
			}
			else
			{
				if (SclWeight >= LowerTrgtWeight && SclWeight <= UpperTrgtWeight)
				{
					BlendName = this.getView().byId("txt_Blend").getValue();

					this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
					this.getView().byId("id_btn_NextIngr").setType("Emphasized")
					this.getView().byId("id_btn_ReadScale").setType("Default")
					this.getView().byId("id_btn_NextIngr").setEnabled(true)

				}
				else
				{
					if (hid_flag == "Auto")
					{
						this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
						//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
						this.getView().byId("id_btn_NextIngr").setType("Default")
						this.getView().byId("id_btn_ReadScale").setType("Emphasized")
					}
					else
					{
						this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
						//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
						//this.getView().byId("id_btn_ReadManual").setType("Default")
						this.getView().byId("id_btn_ReadScale").setType("Emphasized")
					}
				}
			}

			TargetFlag = "0";



		},

		getBlendMatDetails: function(blend, itemno) {

			var dp = parseInt(ScaleDecimal);		
			currentMaterialModel = new sap.ui.model.json.JSONModel();
			currentMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetMaterialByBlend&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+blend+"&Param.4="+itemno+"&Content-Type=text/json", "", false);

			this.getView().byId("txt_WeighMode").setValue("Blend");

			if (BlendType == "")
			{
				BlendType = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND;

			}
			if (BlendType != currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND)
			{
				resetFlag = 1;

			}
			else {

				resetFlag = 0;
			}

			MatCount = CommonUtility.getJsonModelRowCount(currentMaterialModel.getData());
			kits = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].KITS;
			counter = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].COUNTER;
			var nextCount= parseInt(counter) +1;
			var val= nextCount+"/"+kits;
			this.getView().byId("txt_Counter").setValue(val);

			scanhuFlag = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].HUSCAN;
			blendcode = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLENDCODE;

			var currmatBlendCode= blendcode;
			var criticalFlag=currmatBlendCode.indexOf("*");

			if(criticalFlag!="-1"){

				this.getView().byId("id_pageErrorMsg2").setVisible();
			}
			var currentMatAllergen = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].ALLERGEN;

			if(currentMatAllergen=="ALLERGEN"){
				this.getView().byId("id_pageErrorMsg3").setVisible();

			}

			this.enableHU();
			this.getView().byId("txt_Blend").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND);
			Component = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATNO;
			this.getView().byId("txt_CompDesc").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATTEXT);
			this.getView().byId("txt_GridUOM").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].UOM);
			var MatQty = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATQTY;
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;

			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}

			this.getView().byId("txt_TarWeight").setValue(parseFloat(matquantity).toFixed(dp));
			var removeZeroModel = new sap.ui.model.json.JSONModel();
			removeZeroModel.loadData("/XMII/Illuminator?QueryTemplate=ReuseLibrary/Common/Query Template/XACQ_RemoveZero&Param.1="+Component+"&Content-Type=text/json", "", false);
			this.getView().byId("txt_AbsComponent").setValue(removeZeroModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			//var getLatestBatchModel = new sap.ui.model.json.JSONModel();
			//removeZeroModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetLatestMaterialBatch&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+Component+"&Content-Type=text/json", "", false);
			this.SetBatch();

			var packingFlag = currmatBlendCode.indexOf("P");
			if(packingFlag!="-1"){		
				packingMat = 1;
			}
			if (CountBlend == counter && BlendName == this.getView().byId("txt_Blend").getValue())
			{
				if(packingFlag!="-1"){		
					var trgwt = this.getView().byId("txt_TarWeight").getValue();
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
				}	
				else{
					var trgwt = parseFloat(parseFloat(this.getView().byId("txt_TarWeight").getValue()) + parseFloat(sumBlendWeight));
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
					addweigh= 2;

				}
			}
			else if (CountBlend == counter && BlendName == "")
			{
				if(packingFlag!="-1"){		
					var trgwt = this.getView().byId("txt_TarWeight").getValue();
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
				}	
				else{
					var trgwt = parseFloat(parseFloat(this.getView().byId("txt_TarWeight").getValue()) + parseFloat(sumBlendWeight));
					this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
					addweigh= 2;
				}
			}
			else
			{
				var trgwt = this.getView().byId("txt_TarWeight").getValue();
				this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
			}
			if (TargetFlag == "1")
			{
				TargetFlag = "2";
			}

			this.UpperLowerLimitValues();
			this.GaugeDialValues();
			this.enableMultipleBag();
		},
		/***** Commented function
		getCurrentMatDetails: function(matno) {

			var dp = parseInt(ScaleDecimal);
			currentMaterialModel = new sap.ui.model.json.JSONModel();
			currentMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetMaterialByMatNo&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+matno+"&Content-Type=text/json", "", false);
			this.getView().byId("txt_WeighMode").setValue("Single");
			MatCount = CommonUtility.getJsonModelRowCount(currentMaterialModel.getData());
			kits = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].KITS;
			counter = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].COUNTER;

			var nextCount= parseInt(counter) +1;
			var val= nextCount+"/"+kits;
			this.getView().byId("txt_Counter").setValue(val);

			this.getView().byId("txt_Blend").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].BLEND);
			Component = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATNO;
			this.getView().byId("txt_CompDesc").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATTEXT);
			this.getView().byId("txt_GridUOM").setValue(currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].UOM);
			var MatQty = currentMaterialModel.getData().Rowsets.Rowset[0].Row[MatPosition].MATQTY;

			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;
			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}

			this.getView().byId("txt_TarWeight").setValue(parseFloat(matquantity).toFixed(dp));
			var trgwt = this.getView().byId("txt_TarWeight").getValue();
			this.getView().byId("txt_TargetWeight").setValue(parseFloat(trgwt).toFixed(dp));
			var removeZeroModel = new sap.ui.model.json.JSONModel();
			removeZeroModel.loadData("/XMII/Illuminator?QueryTemplate=ReuseLibrary/Common/Query Template/XACQ_RemoveZero&Param.1="+Component+"&Content-Type=text/json", "", false);
			this.getView().byId("txt_AbsComponent").setValue(removeZeroModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			this.SetBatch();	
			this.GaugeDialValues();

			if (TargetFlag == "1")
			{
				TargetFlag = "2";
			}

			this.checkAvailability();	
		},
		 *****/
		UpperLowerLimitValues: function() {

			//var SclWgt = parseFloat(this.getView().byId("txt_ScaleWgt").getValue());
			var dp = parseInt(ScaleDecimal);
			var TrgtWgt = this.getView().byId("txt_TarWeight").getValue();
			var TarWeight = TrgtWgt.replace("," , ".");
			var FormatTrgrtWgt = parseFloat(TarWeight);


			if (plant !="3137")
			{
				if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
				{
					LowTolerance = parseFloat(TrgtWgt) - 0.005;
					UpTolerance = parseFloat(TrgtWgt) + 0.005;
				}
				else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
				{
					LowTolerance = parseFloat(TrgtWgt)  - 0.01;
					UpTolerance = parseFloat(TrgtWgt) + 0.01;
				}
				else if (FormatTrgrtWgt > 5)
				{
					LowTolerance = parseFloat(TrgtWgt) - 0.05;
					UpTolerance = parseFloat(TrgtWgt)  + 0.05;
				}
			}

			else {

				LowTolerance = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
				UpTolerance = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

			} 
			LowTolerance = parseFloat(LowTolerance).toFixed(dp);
			UpTolerance = parseFloat(UpTolerance).toFixed(dp);

			this.getView().byId("id_display_UpTrgtWgt").setValue(UpTolerance);
			this.getView().byId("id_display_LowTrgtWgt").setValue(LowTolerance);
		},

		GaugeDialValues: function() {

			var Flag = parseInt(gaugeDialFlag);
			if(Flag == 1)
			{

				var SclWgt = parseFloat(this.getView().byId("txt_ScaleWgt").getValue());
				var dp = parseInt(ScaleDecimal);
				var TrgtWgt = this.getView().byId("txt_TarWeight").getValue();
				var TarWeight = TrgtWgt.replace("," , ".");
				var FormatTrgrtWgt = parseFloat(TarWeight);

				if (hid_flag != "Auto")
				{
					if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
					{
						LowTolerance = (parseFloat(FormatTrgrtWgt) - 0.005).toFixed(dp);
						UpTolerance = (parseFloat(FormatTrgrtWgt) + 0.005).toFixed(dp);
						minval = (parseFloat(FormatTrgrtWgt) - 0.005 - 0.005).toFixed(dp);
						maxval = (parseFloat(FormatTrgrtWgt) + 0.005 + 0.005).toFixed(dp);
						this.GaugeDialTest();
					}

					else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
					{
						LowTolerance = (parseFloat(FormatTrgrtWgt) - 0.01).toFixed(dp);
						UpTolerance = (parseFloat(FormatTrgrtWgt) + 0.01).toFixed(dp);
						minval = (parseFloat(FormatTrgrtWgt) - 0.01 - 0.01).toFixed(dp);
						maxval = (parseFloat(FormatTrgrtWgt) + 0.01 + 0.01).toFixed(dp);
						this.GaugeDialTest();
					}

					else if (FormatTrgrtWgt > 5)
					{
						LowTolerance = (parseFloat(FormatTrgrtWgt) - 0.05).toFixed(dp);
						UpTolerance = (parseFloat(FormatTrgrtWgt) + 0.05).toFixed(dp);
						minval = (parseFloat(FormatTrgrtWgt) - 0.05 - 0.05).toFixed(dp);
						maxval = (parseFloat(FormatTrgrtWgt) + 0.05 + 0.05).toFixed(dp);
						this.GaugeDialTest();
					}

				}
				else
				{

					if (this.getView().byId("txt_TarWeight").getValue() == this.getView().byId("txt_TargetWeight").getValue())
					{

						if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.005 - 0.005).toFixed(dp);
							maxval = (parseFloat(TrgtWgt) + 0.005 + 0.005).toFixed(dp);
							LowTolerance = (parseFloat(TrgtWgt) - 0.005).toFixed(dp);
							UpTolerance = (parseFloat(TrgtWgt) + 0.005).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.01 - 0.01).toFixed(dp);
							maxval = (parseFloat(TrgtWgt) + 0.01 + 0.01).toFixed(dp);
							LowTolerance = (parseFloat(TrgtWgt)  - 0.01).toFixed(dp);
							UpTolerance = (parseFloat(TrgtWgt) + 0.01).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.05 - 0.05).toFixed(dp);
							maxval = (parseFloat(TrgtWgt) + 0.05 + 0.05).toFixed(dp);
							LowTolerance = (parseFloat(TrgtWgt) - 0.05).toFixed(dp);
							UpTolerance = (parseFloat(TrgtWgt)  + 0.05).toFixed(dp);
							this.GaugeDialTest();
						}

					}
					else
					{

						if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.005 - 0.005).toFixed(dp);
							maxval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.005 + 0.005).toFixed(dp);
							LowTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.005).toFixed(dp);
							UpTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.005).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.01 - 0.01).toFixed(dp);
							maxval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.01 + 0.01).toFixed(dp);
							LowTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.01).toFixed(dp);
							UpTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.01).toFixed(dp);
							this.GaugeDialTest();
						}

						else if (FormatTrgrtWgt > 5)
						{
							minval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.05 - 0.05).toFixed(dp);
							maxval = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.05 + 0.05).toFixed(dp);
							LowTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) - 0.05).toFixed(dp);
							UpTolerance = (parseFloat(this.getView().byId("txt_TargetWeight").getValue()) + 0.05).toFixed(dp);
							this.GaugeDialTest();
						}

					}
				}
			}
			else
			{
				//this.getView().byId("gaugedial").setVisible(true);
			}

		},

		enableMultipleBag: function () {

			var GetBagSizeOfMaterialModel = new sap.ui.model.json.JSONModel();
			GetBagSizeOfMaterialModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBagSizeOfMaterial&Param.1="+OrderId+"&Param.2="+Component+"&Content-Type=text/json", "", false);

			var Status = GetBagSizeOfMaterialModel.getData().Rowsets.Rowset[0].Row[0].Status;
			PredefinedBagSize = GetBagSizeOfMaterialModel.getData().Rowsets.Rowset[0].Row[0].BagSize;
			var TrgtWeight = this.getView().byId("txt_TarWeight").getValue();
			var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
			RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
			var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);


			if (Status == "S" && PredefinedBagSize<=FormatTrgrtWgt)
			{

				PreWeighedBagFlag=true;

				document.getElementById("id_td_NumberOfBag").style.display = 'block';
				document.getElementById("id_NumberOfBag").style.display = 'block';
				if (PrevComponent!=Component){
					document.getElementById("txt_NumberOfBag").value=1;

					this.getView().byId("txt_PreWeighedBagSize").setVisible(true);
				}
			}
			else {

				PreWeighedBagFlag=false;
			}

			PrevComponent=Component;
		},

		checkAvailability: function() {

			var available_qty = this.getView().byId("txt_Avail").getValue();
			available_qty = available_qty.split(" ");

			var dp = parseInt(ScaleDecimal);

			if (available_qty[0] == "")
			{}
			else
			{
				var avail = parseFloat(available_qty[0]);
				var quantity_remain = avail -  this.getView().byId("txt_TarWeight").getValue();

		if (quantity_remain < 0)
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("yellowColor");
		else if (available_qty == 0)
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("redColor");
		else
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("nuetral");

			}
			

		},

		enableHU: function() {

			this.getView().byId("txt_selected_batch").setValue(this.getView().byId("td_select_batch").getSelectedKey())
			jQuery.ajax({
				url: "/XMII/Runner?Transaction=GBL_WEIGHING/BLS/BLS_GetMaterialForPartial&I_OrderID="+OrderId+"&I_CompMatno="+Component+"&OutputParameter=HUSCAN&Content-Type=text/xml",
				type : 'GET',
				async:false,
				success : function (xmlData) {

					HUSCAN = $(xmlData).find('HUSCAN').text();

				}
			});

			if(HUSCAN == "N"){

				this.getView().byId("id_btn_ScanHU").setVisible(false); 
				this.getView().byId("id_td_HUNumber").setVisible(false);
				this.getView().byId("td_display_selected_batch").setVisible(false); 
			}
			else if(HUSCAN == "S"){

				this.getView().byId("txt_HUNumber").setValue(""); 
				this.getView().byId("id_btn_ScanHU").setVisible(true); 
				this.getView().byId("id_td_HUNumber").setVisible(true);
				this.getView().byId("td_display_selected_batch").setVisible(true); 
				this.getView().byId("td_batch").setVisible(false); 
			}
			else if(HUSCAN == "B"){

				this.getView().byId("txt_HUNumber").setValue(""); 
				this.getView().byId("id_btn_ScanHU").setVisible(true); 
				this.getView().byId("id_td_HUNumber").setVisible(true);
				this.getView().byId("td_display_selected_batch").setVisible(false); 
				this.getView().byId("td_batch").setVisible(true); 
			}
			else{
				this.getView().byId("id_btn_ScanHU").setVisible(false); 
				this.getView().byId("id_td_HUNumber").setVisible(false);
				this.getView().byId("td_display_selected_batch").setVisible(false); 
				this.getView().byId("td_batch").setVisible(true); 
			}
		},

		GaugeDialTest: function() {

			var ScaleName = this.getView().byId("weighScaleList").getSelectedKey();

			var GetWeighScaleTagModel = new sap.ui.model.xml.XMLModel();
			GetWeighScaleTagModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetWeighScaleTag&Param.1="+plant+"&Param.2="+resource+"&Param.3="+ScaleName+"&Content-Type=text/xml", "", false);

			//var wsport = GetWeighScaleTagModel.getData().Rowsets.Rowset[0].Row[0].WSPORT;
			var GetHostNameModel = new sap.ui.model.xml.XMLModel();
			GetHostNameModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XMLQ_GetHostName&Content-Type=text/xml", "", false);
			//var hostname = GetHostNameModel.getData().Rowsets.Rowset[0].Row[0].PropertyValue;
			//var port = hostname+":"+wsport;


		},

		ValidateInputs: function() {

			var SclWgt = parseFloat(this.getView().byId("txt_ScaleWgt").getValue());
			var LowTrgtWgt = parseFloat(LowTrgtWgt);
			var UpTrgtWgt = parseFloat(UpTrgtWgt);

			var TrgtWeight = this.getView().byId("txt_TarWeight").getValue();
			var RemoveDecimalModel = new sap.ui.model.json.JSONModel();
			RemoveDecimalModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_RemoveDecimal&Param.1="+TrgtWeight+"&Content-Type=text/json", "", false);
			var FormatTrgrtWgt = parseFloat(RemoveDecimalModel.getData().Rowsets.Rowset[0].Row[0].O_Number);

			if (plant!="3137")
			{

				if (FormatTrgrtWgt >= 0 && FormatTrgrtWgt <= 1)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.005;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.005;
				}

				else if (FormatTrgrtWgt > 1 && FormatTrgrtWgt <= 5)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.01;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.01;
				}

				else if (FormatTrgrtWgt > 0.5)
				{
					LowTrgtWgt = parseFloat(FormatTrgrtWgt) - 0.05;
					UpTrgtWgt = parseFloat(FormatTrgrtWgt) + 0.05;
				}
			}
			else {


				LowTrgtWgt = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
				UpTrgtWgt = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

			}

			if (this.getView().byId("txt_ScaleWgt").getValue() == "")
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_005"));
			}
			else if (isNaN(this.getView().byId("txt_ScaleWgt").getValue()))
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_006"));
			}


			else if (this.getView().byId("td_select_batch").getSelectedItem() == null)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_007"));
			}


			else if (SclWgt < LowTrgtWgt || SclWgt > UpTrgtWgt)
			{
				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_008"));
				this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
				//document.getElementById("txt_ScaleWgt").style.background = "#FF0000";
				this.getView().byId("id_btn_NextIngr").setType("Default");
				this.getView().byId("id_btn_ReadScale").setType("Emphasized")
				this.getView().byId("id_btn_NextIngr").setEnabled(false)
			}
			else
			{
				this.InsMatWeigh1();
				this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
				//document.getElementById("txt_ScaleWgt").style.background = "#FFFFFF";
				this.getView().byId("id_btn_NextIngr").setType("Default");
				this.getView().byId("id_btn_ReadScale").setType("Emphasized")
				this.getView().byId("id_btn_NextIngr").setEnabled(false)
			}

			this.UpperLowerLimitValues();	
			this.GaugeDialRecreate();
			this.GaugeDialValues();


		},

		InsMatWeigh1: function() {

			this.getView().byId("id_pageErrorMsg4").setVisible(false);

			var dp = parseInt(ScaleDecimal);
			//var Seq = this.getView().byId("txt_Seq").getValue();
			var selBatch = this.getView().byId("td_select_batch").getSelectedKey();

			CurrSelRow = selectedRowVar;
			var KitNo = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].KITNO;
			var MatNo = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].MATNO;
			var itemno = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].ITEMNO;

			var MatQty = this.getView().byId("txt_ScaleWgt").getValue();
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;
			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}


			var UpdatePartialComsumedModel = new sap.ui.model.json.JSONModel();
			UpdatePartialComsumedModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdatePartialComsumed&Param.1="+matquantity+"&Param.2="+CRId+"&Param.3="+OrderId+"&Param.4="+MatNo+"&Param.5="+KitNo+"&Param.6="+selBatch+"&Param.7="+itemno+"&Content-Type=text/json", "", false);

			var InsWeighPartialKitModel = new sap.ui.model.json.JSONModel();
			InsWeighPartialKitModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_InsWeighPartialKit&Param.1="+plant+"&Param.2="+resource+"&Param.3="+OrderId+"&Param.4="+MatNo+"&Param.5="+itemno+"&Param.6="+KitNo+"&Content-Type=text/json", "", false);

			var message = InsWeighPartialKitModel.getData().Rowsets.Rowset[0].Row[0].Message;
			var Blend = InsWeighPartialKitModel.getData().Rowsets.Rowset[0].Row[0].Blend;
			var currentkitseq = InsWeighPartialKitModel.getData().Rowsets.Rowset[0].Row[0].KitSeq;

			var Flag =parseInt(blendPrintPopupFlag);
			if(Flag == 1)
			{

				window.open('/XMII/CM/WeighHubUI5/webapp/irpt/BlendReport.irpt?qs_ordid=' + OrderId + '&qs_Blend=' + this.getView().byId("txt_Blend").getValue()+ '&qs_KitSeq=' + currentkitseq + '&qs_CompMat=' +MatNo, 'BinReport', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');
			}

			else
			{

				var SendDataToThePrinterModel = new sap.ui.model.json.JSONModel();
				SendDataToThePrinterModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_AllBlendLabelPrint&Param.1="+OrderId+"&Param.2="+Blend+"&Param.3="+currentkitseq+"&Param.4="+MatNo+"&Param.5=true&Param.6="+printerID+"&Content-Type=text/json", "", false);

			}

			var UpdateBlendPrintStatusModel = new sap.ui.model.json.JSONModel();
			UpdateBlendPrintStatusModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateBlendPrintStatus&Param.1="+plant+"&Param.2="+resource+"&Param.3="+OrderId+"&Param.4="+Blend+"&Param.5="+currentkitseq+"&Content-Type=text/json", "", false);



			this.getWeighingMaterial();


		},

		GaugeDialRecreate: function() {

			var Flag = parseInt(gaugeDialFlag);

			if(Flag == 1)
			{				

				//document.getElementById("gaugedial").innerHTML="";

			}
			else
			{
				//document.getElementById("gaugedial").innerHTML="";
				//document.getElementById("gaugedial").style.display = 'block';
			}

		},

		SetAvail: function() {

			var path = this.getView().byId("td_select_batch").getSelectedItem().oBindingContexts.getBatchByMaterialData.sPath;
			var text_avail= getBatchByMaterialModel.getProperty(path+"/AVAIL")
			var avail_unit= text_avail+" "+this.getView().byId("txt_GridUOM").getValue();
			this.getView().byId("txt_Avail").setValue(avail_unit);
			this.checkAvailability();

		},
		/***** Commented function
		ReadManual: function() {


			var ExtraFlag = "";

			var ItemCount = CommonUtility.getJsonModelRowCount(getWeighingMaterialModel.getData());
			var Seq = this.getView().byId("txt_Seq").getValue();
			var Blend = getWeighingMaterialModel.getData().Rowsets.Rowset[0].Row[Seq-1].Blend;
			var matposition = MatPosition;
			var selBatch = this.getView().byId("td_select_batch").getSelectedKey();

			for(var i=0; i<(CommonUtility.getJsonModelRowCount(currentMaterialModel.getData())); i++) {

				if(this.getView().byId("txt_AbsComponent").getValue() == parseInt(currentMaterialModel.getData().Rowsets.Rowset[0].Row[i].MATNO)){
					CurrSelRow= i;

				}
			}


			var TotalKits = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].KITS;
			var Count = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].COUNTER;
			var MatNo = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].MATNO;
			var uom = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].UOM;
			var MatText = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].MATTEXT;
			var Blend = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].BLEND;
			//var itemno = currentMaterialModel.getData().Rowsets.Rowset[0].Row[CurrSelRow].ITEMNO;

			var MatQty = this.getView().byId("txt_ScaleWgt").getValue();
			MatQty=MatQty.toString();
			var matqtyarray = MatQty.split(",");
			var matquantity;
			if (matqtyarray.length > 1)
			{
				matquantity = matqtyarray[0] + "." + matqtyarray[1];
			}
			else
			{
				matquantity = MatQty;
			}
			if(hid_eflag == 0){

				ExtraFlag = "0";
			}
			else if (hid_eflag == 1)
			{
				ExtraFlag = "1";
			}

			var InsertWeighingModel = new sap.ui.model.json.JSONModel();
			InsertWeighingModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_InsertWeighing&Param.1="+CRId+"&Param.2="+OrderId+"&Param.3="+MatNo+"&Param.4="+selBatch+"&Param.5=1&Param.6="+matquantity+"&Param.7="+uom+"&Param.8="+MatText+"&Param.9="+Blend+"&Param.10="+ExtraFlag+"&Content-Type=text/json", "", false);

			if(CommonUtility.getJsonModelRowCount(InsertWeighingModel.getData())) {
				currentkitseq = InsertWeighingModel.getData().Rowsets.Rowset[0].Row[0].KITSEQ;
			}
			var CurrNo = parseInt(Count) + 1;

			if (hid_eflag == "0")
			{

				var UpdMatWeighModel = new sap.ui.model.json.JSONModel();
				UpdMatWeighModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdMatWeigh&Param.1="+CurrNo+"&Param.2="+TotalKits+"&Param.3="+CRId+"&Param.4="+OrderId+"&Param.5="+MatNo+"&Content-Type=text/json", "", false);

			}

			this.GetBack()

		},
		 *****/
		clearValues: function() {

			this.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
			this.getView().byId("txt_Avail").getCustomData()[0].setValue("nuetral");
			this.getView().byId("txt_ScaleWgt").setValue("");
			this.getView().byId("txt_Avail").setValue("");

			if(this.getView().byId("id_btn_NextIngr").getEnabled()){
				this.getView().byId("id_btn_NextIngr").setEnabled(false);	
				this.getView().byId("id_btn_NextIngr").setType("Default");

			}
			//if(	this.getView().byId("id_btn_ReadManual").getEnabled()) {
			//	this.getView().byId("id_btn_ReadManual").setEnabled(false);
			//	this.getView().byId("id_btn_ReadManual").setType("Default");
			//}
		},

		ScanHU: function() {

			this.getView().byId("txt_selected_batch").setValue();
			this.getView().byId("txt_Avail").setValue();
			if(this.getView().byId("txt_HUNumber").getValue()) {

				var SSCC = this.getView().byId("txt_HUNumber").getValue();
				var Material = Component;

				var GetBatchNumByHUScanModel = new sap.ui.model.json.JSONModel();
				GetBatchNumByHUScanModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetBatchNumByHUScan&Param.1="+SSCC+"&Param.2="+Material+"&Content-Type=text/json", "", false);
				GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Batch;
				var Status = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Type;
				var message = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Message;
				var O_Batch = GetBatchNumByHUScanModel.getData().Rowsets.Rowset[0].Row[0].Batch;
				var batchFlag=0;

	
				if (Status == "S")
				{
					var count = CommonUtility.getJsonModelRowCount(getBatchByMaterialModel.getData())
					for (var i = 0; i < count; i++)
					{
						if(O_Batch == getBatchByMaterialModel.getData().Rowsets.Rowset[0].Row[i].BATCH) {

							this.getView().byId("td_select_batch").setSelectedKey(O_Batch);
							this.getView().byId("txt_selected_batch").setValue(O_Batch);
							this.SetAvail();
							batchFlag=1;
							break;

						}

					}
					if(batchFlag !=1) {
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_072"));
					}
				}
				else
				{
					MessageBox.alert(message);
				}
			}

			else {

				MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_081"));

			}

		},

		SetFlagCMDGetSelBatch: function() {

			js_FlagCMDGetSelBatch = 1;
		},

		populateData: function() {

			var dp = parseInt(ScaleDecimal);
			var SelRow = selectedRowVar;
			if(CommonUtility.getJsonModelRowCount(getPartialMaterialModel.getData()) > 0) {
			Component = getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATNO;
			this.getView().byId("txt_AbsComponent").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATNO);
			this.getView().byId("txt_CompDesc").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATTEXT);
			this.getView().byId("txt_GridUOM").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].UOM);
			this.getView().byId("txt_Counter").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].KITNO);
			this.getView().byId("txt_TargetWeight").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY);
			this.getView().byId("txt_TarWeight").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY);
			this.getView().byId("txt_Blend").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].BLEND);
			this.getView().byId("txt_ScaleWgt").setValue("");

			//this.getView().byId("txt_TargetWeight").setValue((this.getView().byId("txt_TargetWeight").getValue()).replace(",",".").toFixed(dp));
			//this.getView().byId("txt_TarWeight").setValue(this.getView().byId("txt_TarWeight").getValue().replace(",",".").toFixed(dp));

			if(isNaN(carrysum)) {

				this.getView().byId("txt_TargetWeight").setValue(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY);

			}
			else {

				var ftarget = parseFloat(getPartialMaterialModel.getData().Rowsets.Rowset[0].Row[SelRow].MATQTY)+parseFloat(carrysum);
				this.getView().byId("txt_TargetWeight").setValue(parseFloat(ftarget).toFixed(dp));
				sumBlendWeight = parseFloat(carrysum);
			}
			//this.UpperLowerLimitValues();	
			this.checkAppletToCallSetBatch();
			}
		},

		checkAppletToCallSetBatch: function()
		{

			if ( js_FlagBROBatch==1 &&  js_FlagCMDGetSelBatch==1 )
			{
				this.SetBatch();
			}

		},
		onClickDialpad: function(oEvent) {

			let sKey = oEvent.getSource().getText();
			let counter = this.getView().byId(currentfocusID).getValue();
			let newCounter = counter + sKey;
			this.getView().byId(currentfocusID).setValue(newCounter);

		},
		onCancelDialPad: function(oEvent) {

			this.getView().byId(currentfocusID).setValue("");

		},

		closeDialPad: function(oEvent) {

			this.getView().byId("dialpad").setVisible(false);

		},
		onAfterRendering: function() {

			var that = this;

			this.getView().byId("txt_ScaleWgt").addEventDelegate({
				onfocusin: function() {

					that.getView().byId("dialpad").setVisible(true);
					currentfocusID = "txt_ScaleWgt";

				}
			});
			this.getView().byId("txt_HUNumber").addEventDelegate({
				onfocusin: function() {

					that.getView().byId("dialpad").setVisible(true);
					currentfocusID = "txt_HUNumber";

				}
			});


		},
	});
});