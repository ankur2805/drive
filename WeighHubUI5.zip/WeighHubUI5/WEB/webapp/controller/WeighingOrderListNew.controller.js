sap.ui
    .define(
        [ "sap/ui/core/mvc/Controller", "com/khc/weighhub/utils/UI_utilities", "sap/m/MessageBox",
            "com/khc/common/Script/CommonUtility", "com/khc/weighhub/model/formatter", "com/khc/weighhub/model/models" ],
        function(Controller, UI_utilities, MessageBox, CommonUtility, formatter, models) {
          "use strict";
          var plant;
          var resource;
          var projectName;
          var userName;
          var crDest;
          var bInitial = true;
          return Controller
              .extend(
                  "com.khc.weighhub.controller.WeighingOrderListNew",
                  {
                    formatter : formatter,

                    onInit : function() {
                      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                      this._oRouter.getRoute("WeighingOrderListNew").attachPatternMatched(this._oRoutePatternMatched, this);
                    },

                    onAfterRendering : function() {

                      var that = this;
                      // Add event delegate to open dialpad on focus
                      this.getView().byId("id_txt_AdjustQty").addEventDelegate({
                        onfocusin : function() {
                          if (!bInitial) {
                            that.getView().byId("dialpad").setVisible(true);
                          } else {

                            bInitial = false;
                          }
                        }
                      });

                    },
                    _oRoutePatternMatched : function(oEvent) {

                      UI_utilities.weighPageOpened(this, "WeighingOrderListNew");
                      bInitial = true;

                      plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                      resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                      projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                      userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                      crDest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

                      this.filterTaskSelection("0,1");

                    },

                    /*
                     * getWorklistData: function() { var oModelOrderList =
                     * models.createNewJSONModel(
                     * "com.khc.weighhub.controller.WeighingOrderListNew-->getWorklistData-->XACQ_GetWeighing_OrderList");
                     * var sParams = "&Param.1=" + plant + "&Param.2=" +
                     * resource + "&Param.3=" + crDest + "&Param.4=" + "0,1" +
                     * "&Param.5=" + "1";
                     * oModelOrderList.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighing_OrderList&"
                     * +sParams+ "&Content-Type=text/json", "", false);
                     * this.getView().setModel(oModelOrderList, "oOrderList"); },
                     */

                    DirectToMain : function(oEvent) {

                      UI_utilities.setContainerBusyState(this, true);
                      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                      oRouter.navTo("default");

                    },

                    filterWeighList : function() {
                      this.filterTaskSelection('0,1');
                    },

                    filterWeigh : function() {
                      this.filterTaskSelection('1');
                    },

                    filterWeighhub : function() {
                      this.filterTaskSelection('0');
                    },

                    filterCompletedOrderWeighList : function() {
                      this.filterTaskSelection('2');
                    },

                    // Filter as per button selection

                    filterTaskSelection : function(statuscode) {
                      // Get the table Binding to apply filters
                      var oModelOrderList = models
                          .createNewJSONModel("com.khc.weighhub.controller.WeighingOrderListNew-->filterTaskSelection-->XACQ_GetWeighing_OrderList");
                      var sParams = "&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crDest + "&Param.4="
                          + statuscode + "&Param.5=" + "1";
                      oModelOrderList.loadData(
                          "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighing_OrderList&" + sParams
                              + "&Content-Type=text/json", "", false);
                      this.getView().setModel(oModelOrderList, "oOrderList");
                    },

                    AdjustKits : function() {
                      var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;
                      if (SelRow != 0) {
                        var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                        var NtSelectedRow = this.getView().getModel("oOrderList").getProperty(QnSelRow);
                        var Status = NtSelectedRow.STATUS;
                        var CRId = NtSelectedRow.CRID;
                        var orderId = NtSelectedRow.ORDERID;
                        var ReqQty = NtSelectedRow.REQQTY;
                        var MatQty = NtSelectedRow.MATQTY;
                        var AdjustKitsNo = this.getView().byId("id_txt_AdjustQty").getValue();

                        var NewMatQty = parseInt(MatQty) + parseInt(AdjustKitsNo);

                        if (AdjustKitsNo == "" || AdjustKitsNo == null || isNaN(NewMatQty)) {
                          // alert(document.getElementById("id_msg_alert17").innerHTML);
                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_042"));
                        } else if (NewMatQty <= 0) {
                          // alert(document.getElementById("id_msg_alert18").innerHTML);
                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_043"));
                        } else {
                          // document.getElementById("txt_adjustKit").value =
                          // "";
                          var oModelOrderKits = models
                              .createNewJSONModel("com.khc.weighhub.controller.WeighingOrderListNew-->AdjustKits-->XACQ_UpdAdjustOrderKits");
                          var sParams = "&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crDest + "&Param.4="
                              + orderId + "&Param.5=" + NewMatQty + "&Param.6=" + CRId + "&Param.7=" + AdjustKitsNo;
                          oModelOrderKits.loadData(
                              "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_UpdAdjustOrderKits&" + sParams
                                  + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelOrderKits, "oOrderKits");
                          this.getView().byId("id_txt_AdjustQty").value = "";
                          this.filterTaskSelection("0,1");
                        }
                      } else {
                        // alert(document.getElementById("id_msg_alert2").innerHTML);
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_011"));
                      }
                    },

                    /** ********************************************************************************************************************************************************************************** */
                    // Keyboard inputs
                    /** ********************************************************************************************************************************************************************************** */
                    onClickDialpad : function(oEvent) {

                      let sKey = oEvent.getSource().getText();
                      let bottleneckCounter = this.getView().byId("id_txt_AdjustQty").getValue();
                      let newBottleneckCounter = bottleneckCounter + sKey;
                      this.getView().byId("id_txt_AdjustQty").setValue(newBottleneckCounter);

                    },

                    onCancelDialPad : function(oEvent) {

                      this.getView().byId("id_txt_AdjustQty").setValue("");

                    },

                    closeDialPad : function(oEvent) {

                      this.getView().byId("dialpad").setVisible(false);

                    },

                    DirectToPackingProp : function() {
                      var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;
                      if (SelRow != 0) {

                        var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                        var NtSelectedRow = this.getView().getModel("oOrderList").getProperty(QnSelRow);
                        var Status = NtSelectedRow.STATUS;
                        if (Status == 0) {

                          var MsgId = NtSelectedRow.MSGID;
                          var CRId = NtSelectedRow.CRID;
                          var OrderId = NtSelectedRow.ORDERID;
                          var MatNo = NtSelectedRow.MATNR;
                          var MatDesc = NtSelectedRow.MATTEXT;
                          var PlannedQty = NtSelectedRow.MATQTY;
                          var UoM = NtSelectedRow.UOM;
                          var DueDate = NtSelectedRow.STARTDATE;

                          var ModOrderId = NtSelectedRow.ModORDERID;
                          var ModMatNo = NtSelectedRow.ModMATNR;
                          var ReceiveQty = NtSelectedRow.RECEIVEQTY;
                          var ToReceiveQty = NtSelectedRow.TORECEIVEQTY;

                          var NewWeighedQty = NtSelectedRow.NEWWEIGHED;
                          var NewToReceiveQty = NtSelectedRow.NEWTORECEIVEQTY;
                          var NewToWeighQty = NtSelectedRow.SETTOWEIGH;

                          var today = new Date();
                          var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                          var currentStartDate = date + 'T' + time;

                          var oModelStartLog = models
                              .createNewJSONModel("com.khc.weighhub.controller.WeighingOrderListNew-->DirectToPackingProp-->SQLQ_UpdateStartLog");
                          var XParams = "&Param.1=" + CRId + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + OrderId
                              + "&Param.5=" + 1 + "&Param.6=" + currentStartDate + "&Param.7=" + userName;
                          oModelStartLog.loadData(
                              "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateStartLog&" + XParams
                                  + "&Content-Type=text/json", "", false);
                          this.getView().setModel(oModelStartLog, "oStartLog");
                          this.filterTaskSelection("0,1");

                          var packingproposalModel = new sap.ui.model.json.JSONModel();
                          let sID = {
                            qs_crid : CRId,
                            qs_msgid : MsgId,
                            qs_ordid : OrderId,
                            qs_matno : MatNo,

                            qs_mattext : MatDesc,
                            qs_matqty : PlannedQty,
                            qs_uom : UoM,
                            qs_duedate : DueDate,

                            qs_modmatnr : ModMatNo,
                            qs_modorderid : ModOrderId,
                            qs_receiveqty : ReceiveQty,
                            qs_toreceiveqty : ToReceiveQty,

                            qs_newweighedqty : NewWeighedQty,
                            qs_newtoreceiveqty : NewToReceiveQty,
                            qs_newsettoweighqty : NewToWeighQty,

                          }
                          packingproposalModel.setData(sID)
                          sap.ui.getCore().setModel(packingproposalModel, "packingproposalParam")

                          this._oRouter.navTo("WeighPackingProposalNew");

                        } else if (Status == 2) {

                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_023"));
                        } else {

                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_017"));
                        }
                      } else {

                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_011"));

                      }
                    },

                    // continue button

                    PackPropContinue : function() {

                      var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;

                      if (SelRow != 0) {
                        var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                        var NtSelectedRow = this.getView().getModel("oOrderList").getProperty(QnSelRow);
                        var Status = NtSelectedRow.STATUS;
                        // var RemainQty =
                        // this.getView().getModel("oOrderList").getProperty(QnSelRow);

                        if (Status == 1) {

                          var MsgId = NtSelectedRow.MSGID;
                          var CRId = NtSelectedRow.CRID;
                          var OrderId = NtSelectedRow.ORDERID;
                          var MatNo = NtSelectedRow.MATNR;
                          var MatDesc = NtSelectedRow.MATTEXT;
                          var PlannedQty = NtSelectedRow.MATQTY;
                          var UoM = NtSelectedRow.UOM;
                          var DueDate = NtSelectedRow.STARTDATE;

                          var ModOrderId = NtSelectedRow.ModORDERID;
                          var ModMatNo = NtSelectedRow.ModMATNR;
                          var ReceiveQty = NtSelectedRow.RECEIVEQTY;
                          var ToReceiveQty = NtSelectedRow.TORECEIVEQTY;
                          var NewWeighedQty = NtSelectedRow.NEWWEIGHED;
                          var NewToReceiveQty = NtSelectedRow.NEWTORECEIVEQTY;
                          var NewToWeighQty = NtSelectedRow.SETTOWEIGH;

                          var packingproposalModel = new sap.ui.model.json.JSONModel();
                          let sID = {
                            qs_crid : CRId,
                            qs_msgid : MsgId,
                            qs_ordid : OrderId,
                            qs_matno : MatNo,

                            qs_mattext : MatDesc,
                            qs_matqty : PlannedQty,
                            qs_uom : UoM,
                            qs_duedate : DueDate,

                            qs_modmatnr : ModMatNo,
                            qs_modorderid : ModOrderId,
                            qs_receiveqty : ReceiveQty,
                            qs_toreceiveqty : ToReceiveQty,

                            qs_newweighedqty : NewWeighedQty,
                            qs_newtoreceiveqty : NewToReceiveQty,
                            qs_newsettoweighqty : NewToWeighQty,

                          }
                          packingproposalModel.setData(sID)
                          sap.ui.getCore().setModel(packingproposalModel, "packingproposalParam")

                          this._oRouter.navTo("WeighPackingProposalNew");

                        } else if (Status == 2) {

                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_024"));
                        } else {
                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_019"));
                        }
                      } else {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_011"));
                      }
                    },

                    // //////// On Click event of Discard Button - Discards the
                    // Order and Updates the order status to Discarded
                    // ///////////////////////////
                    DiscRecipe : function() {
                      var that = this;

                      MessageBox
                          .show(
                              sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_041"),
                              {
                                icon : MessageBox.Icon.INFORMATION,
                                title : "Confirm ",
                                actions : [ MessageBox.Action.OK, MessageBox.Action.Cancel ],
                                onClose : function(sButton) {
                                  if (sButton === MessageBox.Action.OK) {
                                    var SelRow = that.getView().byId("Id_QuntityList").getSelectedContextPaths().length;

                                    if (SelRow != 0) {
                                      var QnSelRow = that.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                                      var NtSelectedRow = that.getView().getModel("oOrderList").getProperty(QnSelRow);
                                      var Status = NtSelectedRow.STATUS;

                                      var RowStat = NtSelectedRow.STATUS;
                                      var CRId = NtSelectedRow.CRID;
                                      var orderId = NtSelectedRow.ORDERID;

                                      if (RowStat == 1) {

                                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_020"));
                                      } else if (RowStat == 2) {

                                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_025"));
                                      } else {

                                        // var answereos =
                                        // MessageBox.confirm(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_035"));
                                        MessageBox
                                            .show(
                                                sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_035"),
                                                {
                                                  icon : MessageBox.Icon.INFORMATION,
                                                  title : "Confirm ",
                                                  actions : [ MessageBox.Action.OK, MessageBox.Action.Cancel ],
                                                  onClose : function(sButton) {
                                                    if (sButton === MessageBox.Action.OK) {

                                                      var oModelRecipeDiscard = models
                                                          .createNewJSONModel("com.khc.weighhub.controller.WeighingOrderListNew-->DiscRecipe-->XACQ_ControlRecipeDiscard");
                                                      var rParams = "Param.1=" + CRId + "&Param.2=" + orderId + "&Param.3="
                                                          + plant + "&Param.4=" + resource + "&Param.5=" + userName;
                                                      oModelRecipeDiscard.loadData(
                                                          "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_ControlRecipeDiscard&"
                                                              + rParams + "&Content-Type=text/json", "", false);
                                                      that.getView().setModel(oModelRecipeDiscard, "oRecipeDiscard");

                                                      MessageBox.alert(sap.ui.getCore().getModel("i18n")
                                                          .getProperty("WS_MSG_021"));

                                                      that.filterTaskSelection("0,1");
                                                    }

                                                  }

                                                })
                                      }
                                    } else {

                                      MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_022"));

                                    }

                                  }
                                }
                              })

                    },

                    // ///////////// Completes the Order ans changes the status
                    // to completed //////////////////////

                    CloseOrderComp : function() {

                      var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;

                      if (SelRow != 0) {
                        var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                        var NtSelectedRow = this.getView().getModel("oOrderList").getProperty(QnSelRow);
                        var RowStat = NtSelectedRow.STATUS;

                        var CRId = NtSelectedRow.CRID;
                        var orderId = NtSelectedRow.ORDERID;
                        var ReqQty = NtSelectedRow.REQQTY;
                        var MatQty = NtSelectedRow.MATQTY;

                        if (RowStat != 1) {

                          MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_026"));
                        } else {

                          if (ReqQty != 0) {
                            var that = this;
                            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_033"), {             
                              title : "Alert ",
                              actions : [ MessageBox.Action.OK ],
                              onClose : function(sButton) {
                                if (sButton === "OK") {
                                  that.CloseOrder(CRId, orderId);
                                }
                              }
                            });
                          } else {
                            this.CloseOrder(CRId, orderId);
                          }

                        }

                      } else {

                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_028"));
                      }
                    },

                    CloseOrder : function(CRId, orderId) {
                      var that = this;
                      MessageBox
                          .show(
                              sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_034"),
                              {
                                icon : MessageBox.Icon.INFORMATION,
                                title : "Confirm ",
                                actions : [ MessageBox.Action.OK, MessageBox.Action.CANCEL ],
                                onClose : function(sButton) {
                                  if (sButton === "OK") {
                                    // alert("Inside ok")
                                    var oModelRecipeClose = models
                                        .createNewJSONModel("com.khc.weighhub.controller.WeighingOrderListNew-->CloseOrderComp-->XACQ_ControlRecipeClose");
                                    var YParams = "&Param.1=" + CRId + "&Param.2=" + orderId + "&Param.3=" + plant + "&Param.4="
                                        + resource + "&Param.5=" + userName;
                                    oModelRecipeClose.loadData(
                                        "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_ControlRecipeClose&"
                                            + YParams + "&Content-Type=text/json", "", false);
                                    that.getView().setModel(oModelRecipeClose, "oRecipeClose");

                                    var today = new Date();
                                    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                                    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                                    var currentEndDate = date + 'T' + time;

                                    var oModelEndLog = models
                                        .createNewJSONModel("com.khc.weighhub.controller.WeighingOrderListNew-->CloseOrderComp-->SQLQ_UpdateEndLog");
                                    var ZParams = "&Param.1=" + CRId + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4="
                                        + orderId + "&Param.5=" + 2 + "&Param.6=" + currentEndDate + "&Param.7=" + userName;
                                    oModelEndLog.loadData(
                                        "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdateEndLog&" + ZParams
                                            + "&Content-Type=text/json", "", false);
                                    that.getView().setModel(oModelEndLog, "oEndLog");

                                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_027"));
                                    that.filterTaskSelection("0,1");
                                  }
                                }
                              });

                    }

                  });
        });