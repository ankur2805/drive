var numHU;
var barcodeperHU;
var idperkit;
var weighedVar;
var formatDate;
var batchdate;
var shelflife;
var matno;
var modmatno;
var packingListModel;
var js_LoadPackingList = 0;
var js_LoadPackingListGrid = 0;
var SharedMemHUtoKit;
var CurrentBatchSize;
var generateBatchModel;
var batno;
var oTable;
var OrderBatchSize;
var KitBatchSize;
var SharedMemHUtoKit;
var modorderID;
var currentfocusID;
var userid;
var PartialDisplayFlag;
var scalename;
sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/m/Button",
   "com/khc/weighhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility",
   "com/khc/weighhub/model/formatter",
   "sap/m/MessageBox", "com/khc/weighhub/model/models"
   ],
   function(Controller, Button, UI_utilities, CommonUtility, formatter, MessageBox, models) {

   "use strict";
   var plant;
   var resource;
   var projectName;
   var orderID;
   var crId;
   var printerId;
   var printerName;
   var autoBatchCountFlag;
   var partialDisplayFlag;

   return Controller.extend("com.khc.weighhub.controller.ReceiptConfirmation", {
      formatter: formatter,
      onInit: function() {
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         this._oRouter.getRoute("ReceiptConfirmation").attachPatternMatched(this._oRoutePatternMatched, this);

      },

      _oRoutePatternMatched: function(oEvent) {
         UI_utilities.weighPageOpened(this, "ReceiptConfirmation");

         plant = sap.ui.getCore().getModel("session").oData.CA_Plant
         resource = sap.ui.getCore().getModel("session").oData.CA_Resource
         orderID = sap.ui.getCore().getModel("weighingDataModel").oData.OrderId
         modorderID = sap.ui.getCore().getModel("weighingDataModel").oData.ModOrderId
         crId = sap.ui.getCore().getModel("weighingDataModel").oData.CRId
         matno = sap.ui.getCore().getModel("weighingDataModel").oData.MatNo
         modmatno = sap.ui.getCore().getModel("weighingDataModel").oData.ModMatNo
         printerId = sap.ui.getCore().getModel("session").oData.CA_PrinterID
         printerName = sap.ui.getCore().getModel("session").oData.CA_PrinterName
         autoBatchCountFlag = sap.ui.getCore().getModel("session").oData.CA_WHAutoBatchCountFlag
         userid = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName
         scalename = sap.ui.getCore().getModel("session").oData.CA_ScaleName
         PartialDisplayFlag = sap.ui.getCore().getModel("session").oData.CA_WHPartialWeigh

         this.clearData();
         this.getView().byId("dialpad").setVisible(false);
         this.onLoad();
      },

      onChangePrintSettings: function() {

         this.getView().byId("vBox_BatchDetails").setVisible(false);
         this.getView().byId("vBox_PackingList").setVisible(false);
         this.getView().byId("vBox_PrintSettings").setVisible(true);

         this.getView().byId("txt_barcode").setValue(barcodeperHU);
         this.getView().byId("txt_labelsperkit").setValue(idperkit);
         this.getView().byId("printerID").setSelectedKey(printerId);
      },

      onChangeBatchCoding: function() {

         this.getView().byId("vBox_PackingList").setVisible(false);
         this.getView().byId("vBox_PrintSettings").setVisible(false);
         this.getView().byId("vBox_BatchDetails").setVisible(true);
      },

      onLoad: function() {

         var lineIdListModel = models.createNewXMLModel(
         "com.khc.weighhub.controller.ReceiptConfirmation-->onLoad-->SQLQ_GetLineIdByPlant");
         lineIdListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetLineIdByPlant&Param.1=" + plant +
               "&Content-Type=text/xml", "", false);
         sap.ui.getCore().setModel(lineIdListModel, "LineListData");
         this.getView().byId("lineCode").setSelectedKey(resource)
         js_LoadPackingList = 1;
         js_LoadPackingListGrid = 1;
         packingListModel = models.createNewJSONModel(
         "com.khc.weighhub.controller.ReceiptConfirmation-->onLoad-->XACQ_GetHUListForReceipt");
         //packingListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetHUListForReceipt&Param.1="+plant+"&Param.2="+resource+"&Param.3="+orderID+"&Content-Type=text/json", "", false);
         //sap.ui.getCore().setModel(packingListModel, "PackingListData");

         var printerListModel = models.createNewXMLModel(
         "com.khc.weighhub.controller.ReceiptConfirmation-->onLoad-->XACQ_GetPrinterListByPlant");
         printerListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPrinterListByPlant&Param.1=" + plant +
               "&Content-Type=text/xml", "", false);
         sap.ui.getCore().setModel(printerListModel, "PrinterListData");

         this.GetBatch();
         this.GetOrderDetails();
         this.GetCurrentBatchSize();
         this.GetLabelCount();
         this.GetSharedMemHUtoKit();
      },

      GetLabelCount: function() {

         var getLabelModel = models.createNewJSONModel(
         "com.khc.weighhub.controller.ReceiptConfirmation-->GetLabelCount-->SQLQ_GetLabelCount");
         getLabelModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetLabelCount&Param.1=" + crId +
               "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + orderID + "&Content-Type=text/json", "", false);
         sap.ui.getCore().setModel(getLabelModel, "getLabelData");

         weighedVar = this.getView().byId("txt_QtyToReceive").getValue()
         numHU = Math.ceil(weighedVar / getLabelModel.getData().Rowsets.Rowset[0].Row[0].FULLPALLETQTY);
         this.getView().byId("txt_no_of_hu").setValue(numHU);

         barcodeperHU = getLabelModel.getData().Rowsets.Rowset[0].Row[0].HUCOUNT
         idperkit = getLabelModel.getData().Rowsets.Rowset[0].Row[0].IDCOUNT

         var ordprintid = getLabelModel.getData().Rowsets.Rowset[0].Row[0].PRINTERID

         if (ordprintid == "---" || ordprintid == "") {

         } else {

            printerId = getLabelModel.getData().Rowsets.Rowset[0].Row[0].PRINTERID
            printerName = getLabelModel.getData().Rowsets.Rowset[0].Row[0].PRINTERNAME
            this.getView().byId("txt_printid").setValue(printerName);
         }

         var no_of_barcodelabel = barcodeperHU * this.getView().byId("txt_no_of_hu").getValue();
         this.getView().byId("txt_no_of_barcodelabel").setValue(no_of_barcodelabel);

         var no_of_idlabel = idperkit * weighedVar;
         this.getView().byId("txt_no_of_idlabel").setValue(no_of_idlabel);
      },

      onClickBack: function(oEvent) {
         //var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         //oRouter.navTo("ReceiptWorkBench");
         window.history.back(-1);
      },

      GetBatch: function() {
         let dt = new Date();
         formatDate = CommonUtility.getCurrentDateTime(dt);
         generateBatchModel = models.createNewJSONModel(
         "com.khc.weighhub.controller.ReceiptConfirmation-->GetBatch-->XACQ_GenerateBatch");
         generateBatchModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GenerateBatch&Param.1=" + plant +
               "&Param.2=" + resource + "&Param.3=" + formatDate + "&Param.4=" + autoBatchCountFlag + "&Content-Type=text/json", "", false);
         sap.ui.getCore().setModel(generateBatchModel, "generateBatchData");

         this.getView().byId("txt_BatchNumber").setValue(generateBatchModel.getData().Rowsets.Rowset[0].Row[0].O_Batch);
         this.getView().byId("txt_ICT").setValue(formatDate);
         batchdate = formatDate;
         var batchCounter = generateBatchModel.getData().Rowsets.Rowset[0].Row[0].O_Batch
         this.getView().byId("txt_batchcounter").setValue(batchCounter.slice(7, 10));
      },

      PackList: function() {

         if (parseInt(this.getView().byId("txt_no_of_hu").getValue()) < Math.ceil(parseInt(weighedVar) / parseInt(this.getView().byId(
         "txt_FullPalletQty").getValue()))) {

            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_054"));
         } else {

            var validation = this.ValidateField("OnPack");
            if (!validation) {
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_046"));
            } else {

               var batchdate = this.getView().byId("txt_ICT").getValue()
               var calculateHUPackingListModel = models.createNewJSONModel(
               "com.khc.weighhub.controller.ReceiptConfirmation-->PackList-->XACQ_CalculateHUPackingList");
               var qt_recieve = this.getView().byId("txt_QtyToReceive").getValue()
               var txt_no_hu = this.getView().byId("txt_no_of_hu").getValue()
               var full_pallet_qty = this.getView().byId("txt_FullPalletQty").getValue()
               calculateHUPackingListModel.loadData(
                     "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_CalculateHUPackingList&Param.1=" + plant + "&Param.2=" + crId +
                     "&Param.3=" + orderID + "&Param.4=" + qt_recieve + "&Param.5=" + txt_no_hu + "&Param.6=" + resource + "&Param.7=" + matno +
                     "&Param.8=" + batchdate + "&Param.9=" + shelflife + "&Param.10=" + full_pallet_qty + "&Content-Type=text/json", "", false);
               sap.ui.getCore().setModel(calculateHUPackingListModel, "calculateHUPackingListData");
               js_LoadPackingList = 1;

               packingListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetHUListForReceipt&Param.1=" + plant +
                     "&Param.2=" + resource + "&Param.3=" + orderID + "&Content-Type=text/json", "", false);
               sap.ui.getCore().setModel(packingListModel, "PackingListData");

               this.getView().byId("txt_UpdateHUQTP").setValue("");

            }
         }

         this.getView().byId("vBox_PrintSettings").setVisible(false);
         this.getView().byId("vBox_BatchDetails").setVisible(false);
         this.getView().byId("vBox_PackingList").setVisible(true);

      },

      ValidateField: function(update) {

         if (update == "Pack") {

            var returnvalue = this.ValidateNumber(this.getView().byId("txt_UpdateHUQTP").getValue())

            if (returnvalue)
               return true;
            else
               return false;
         }

         if (update == "OnPack") {
            var returnvalue = this.ValidateNumber(this.getView().byId("txt_no_of_hu").getValue());
            if (returnvalue)
               return true;
            else
               return false;
         }

         if (update == "Batch") {

            var BatchCounter = this.getView().byId("txt_batchcounter").getValue();
            var BatchLength = BatchCounter.length;
            var returnvalue = this.ValidateNumber(BatchCounter);

            if (returnvalue) {
               if (BatchLength != 3) {
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_049"));
                  return false;
               } else if (BatchCounter > 999) {
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_049"));
                  return false;
               } else
                  return true;

            }

         } else if (update == "Print") {
            var returnvalue = this.ValidateNumber(this.getView().byId("txt_barcode").getValue());

            if (!returnvalue) {
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_051"));
               this.getView().byId("txt_barcode").setValue("");
               return false;
            } else {
               var returnvalue = this.ValidateNumber(this.getView().byId("txt_labelsperkit").getValue());
               if (!returnvalue) {
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_052"));
                  this.getView().byId("txt_labelsperkit").setValue("");
                  return false;
               } else
                  return true;
            }
         } else if (update == "Receive") {
            var returnvalue = this.ValidateNumber(this.getView().byId("txt_no_of_hu").getValue());

            if (returnvalue) {

               var BatchCounter = this.getView().byId("txt_batchcounter").getValue();
               var BatchLength = BatchCounter.length;
               var returnvalue = this.ValidateNumber(BatchCounter);
               if (returnvalue) {
                  if ((BatchLength < 3) || (BatchCounter > 999)) {
                     MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_049"));
                     return false;
                  } else {
                     var no_of_barcode = this.getView().byId("txt_no_of_barcodelabel").getValue();
                     if (no_of_barcode == "0") {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_053"));
                        return false;
                     } else return true;
                  }

               } else {
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_050"));
                  return false;
               }
            } else {
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_046"));
               return false;
            }
         }

      },

      ValidateNumber: function(value) {

         value.replaceAll(" ", "");
         if (value == "") {
            return false;
         } else if (value < 0) {
            return false;
         } else if (isNaN(value)) {
            return false;
         } else if (value.indexOf(".") == -1) {
            return true;
         } else return false;

      },

      GetOrderDetails: function() {

         if (js_LoadPackingList == 1 && js_LoadPackingListGrid == 1) {

            var dt = new Date();
            var TodayDate = CommonUtility.getCurrentDateTime(dt);

            var GetOrderDetailsForReceiptModel = models.createNewJSONModel(
            "com.khc.weighhub.controller.ReceiptConfirmation-->GetOrderDetails-->SQLQ_GetOrderDetailsForReceipt");
            GetOrderDetailsForReceiptModel.loadData(
                  "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetOrderDetailsForReceipt&Param.1=" + plant + "&Param.2=" +
                  resource + "&Param.3=" + crId + "&Param.4=" + orderID + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(GetOrderDetailsForReceiptModel, "GetOrderDetailsForReceiptData");

            var huVal = Math.ceil(this.getView().byId("txt_QtyToReceive").getValue()) / GetOrderDetailsForReceiptModel.getData().Rowsets.Rowset[
               0].Row[0].FULLPALLETQTY;
            this.getView().byId("txt_no_of_hu").setValue(huVal);
            shelflife = GetOrderDetailsForReceiptModel.getData().Rowsets.Rowset[0].Row[0].SHELFLIFE;
            this.getView().byId("txt_FullPalletQty").setValue(GetOrderDetailsForReceiptModel.getData().Rowsets.Rowset[0].Row[0].FULLPALLETQTY);

            js_LoadPackingList = 1;
            var CalculateHUPackingListModel = models.createNewJSONModel(
            "com.khc.weighhub.controller.ReceiptConfirmation-->GetOrderDetails-->XACQ_CalculateHUPackingList");
            CalculateHUPackingListModel.loadData(
                  "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_CalculateHUPackingList&Param.1=" + plant + "&Param.2=" + crId +
                  "&Param.3=" + orderID + "&Param.4=" + this.getView().byId("txt_QtyToReceive").getValue() + "&Param.5=" + Math.ceil(this.getView()
                        .byId("txt_no_of_hu").getValue()) + "&Param.6=" + resource + "&Param.7=" + matno + "&Param.8=" + TodayDate + "&Param.9=" +
                        shelflife + "&Param.10=" + this.getView().byId("txt_FullPalletQty").getValue() + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(CalculateHUPackingListModel, "CalculateHUPackingListData");

            packingListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetHUListForReceipt&Param.1=" + plant +
                  "&Param.2=" + resource + "&Param.3=" + orderID + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(packingListModel, "PackingListData");
         } else {
            setTimeout(function() {
               this.GetOrderDetails();
            }, 1000);
         }
      },

      calculateBarcode: function() {

         var quantityPerHUFlag = 1;

         if (this.getView().byId("txt_uom").getValue() != "EA" && SharedMemHUtoKit == "EQUALPALLET") {
            var maxQuantityPerHU = Math.floor(parseInt(this.getView().byId("txt_QtyToReceive").getValue()) / parseInt(this.getView().byId(
            "txt_no_of_hu").getValue())) + (parseInt(this.getView().byId("txt_QtyToReceive").getValue()) % parseInt(this.getView().byId(
            "txt_no_of_hu").getValue()));
            var quantityPerHU = maxQuantityPerHU * parseInt(CurrentBatchSize);
            if (quantityPerHU > parseInt(this.getView().byId("txt_FullPalletQty").getValue())) {
               quantityPerHUFlag = 0;
            }
         }

         if (parseInt(this.getView().byId("txt_no_of_hu").getValue()) > parseInt(this.getView().byId("txt_QtyToReceive").getValue()) ||
               parseInt(this.getView().byId("txt_no_of_hu").getValue()) == 0) {
            this.getView().byId("txt_no_of_hu").setValue("");
            MessageBox.alert("Number of HU Cannot be greater than Receive Quantity");

         } else if (quantityPerHUFlag == 0) {
            this.getView().byId("txt_no_of_hu").setValue("");
            MessageBox.alert("Qualtity per HU cannot be greater than Full Pallet Quantity");
         } else {

            var setval = barcodeperHU * this.getView().byId("txt_no_of_hu").getValue()
            this.getView().byId("txt_no_of_barcodelabel").setValue(setval);
         }
      },

      UpdatePrinterSettings: function() {

         var validation = this.ValidateField("Print");
         if (!validation) {

         } else {

            barcodeperHU = this.getView().byId("txt_barcode").getValue();
            idperkit = this.getView().byId("txt_labelsperkit").getValue();

            var selItem = this.getView().byId("printerID").getSelectedItem().mProperties.text;
            var UpdHUWeighOrderListModel = models.createNewJSONModel(
            "com.khc.weighhub.controller.ReceiptConfirmation-->UpdatePrinterSettings-->SQLQ_UpdHUWeighOrderList");
            UpdHUWeighOrderListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdHUWeighOrderList&Param.1=" +
                  crId + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + orderID + "&Param.5=" + barcodeperHU + "&Param.6=" +
                  idperkit + "&Param.7=" + this.getView().byId("printerID").getSelectedKey() + "&Param.8=" + selItem + "&Content-Type=text/json",
                  "", false);
            sap.ui.getCore().setModel(UpdHUWeighOrderListModel, "UpdHUWeighOrderListData");

            this.getView().byId("txt_no_of_barcodelabel").setValue(this.getView().byId("txt_barcode").getValue() * this.getView().byId(
            "txt_no_of_hu").getValue())
            this.getView().byId("txt_no_of_idlabel").setValue(this.getView().byId("txt_labelsperkit").getValue() * this.getView().byId(
            "txt_QtyToReceive").getValue())
            this.getView().byId("txt_printid").setValue(selItem)
            printerId = this.getView().byId("printerID").getSelectedKey()
            this.getView().byId("vBox_PrintSettings").setVisible(false);
            this.getView().byId("id_btn_receive").setEnabled(true);
         }
      },

      UpdateBatchCode: function() {

         if (this.ValidateField('Batch')) {

            generateBatchModel = models.createNewJSONModel(
            "com.khc.weighhub.controller.ReceiptConfirmation-->UpdateBatchCode-->XACQ_GenerateBatch");
            generateBatchModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GenerateBatch&Param.1=" + plant +
                  "&Param.2=" + resource + "&Param.3=" + this.getView().byId("txt_ICT").getValue() + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(generateBatchModel, "generateBatchData");

            var batchCounter = generateBatchModel.getData().Rowsets.Rowset[0].Row[0].O_Batch
            batno = batchCounter.slice(0, 7) + this.getView().byId("txt_batchcounter").getValue()
            this.getView().byId("txt_BatchNumber").setValue(batchCounter.slice(0, 7) + this.getView().byId("txt_batchcounter").getValue())
            batchdate = this.getView().byId("txt_ICT").getValue();

         }

      },

      addDate: function() {

         let dateTime = this.getView().byId("txt_ICT").getValue();
         let date = new Date(dateTime);
         date.setDate(date.getDate() + 1);
         let formatedDate = CommonUtility.getCurrentDateTime(date);
         this.getView().byId("txt_ICT").setValue(formatedDate);
         this.validateFuture();
      },

      reduceDate: function() {
         let dateTime = this.getView().byId("txt_ICT").getValue();
         let date = new Date(dateTime);
         date.setDate(date.getDate() - 1);
         let formatedDate = CommonUtility.getCurrentDateTime(date);
         this.getView().byId("txt_ICT").setValue(formatedDate);
      },

      onClickDialpad: function(oEvent) {

         let sKey = oEvent.getSource().getText();
         let counter = this.getView().byId(currentfocusID).getValue();
         let newCounter = counter + sKey;
         this.getView().byId(currentfocusID).setValue(newCounter);

      },
      onCancelDialPad: function(oEvent) {

         this.getView().byId(currentfocusID).setValue("");

      },

      closeDialPad: function(oEvent) {

         this.getView().byId("dialpad").setVisible(false);

      },

      onAfterRendering: function() {

         var that = this;

         this.getView().byId("txt_no_of_hu").addEventDelegate({
            onfocusin: function() {

               that.getView().byId("dialpad").setVisible(true);
               currentfocusID = "txt_no_of_hu";

            }
         });

         this.getView().byId("txt_batchcounter").addEventDelegate({
            onfocusin: function() {

               that.getView().byId("dialpad").setVisible(true);
               currentfocusID = "txt_batchcounter";

            }
         });

         this.getView().byId("txt_labelsperkit").addEventDelegate({
            onfocusin: function() {

               that.getView().byId("dialpad").setVisible(true);
               currentfocusID = "txt_labelsperkit";

            }
         });

         this.getView().byId("txt_barcode").addEventDelegate({
            onfocusin: function() {

               that.getView().byId("dialpad").setVisible(true);
               currentfocusID = "txt_barcode";

            }
         });

         this.getView().byId("txt_barcode").addEventDelegate({
            onfocusin: function() {

               that.getView().byId("dialpad").setVisible(true);
               currentfocusID = "txt_barcode";

            }
         });

         this.getView().byId("txt_UpdateHUQTP").addEventDelegate({
            onfocusin: function() {

               that.getView().byId("dialpad").setVisible(true);
               currentfocusID = "txt_UpdateHUQTP";

            }
         });
      },

      ChangeBatchByDate: function() {

         generateBatchModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GenerateBatch&Param.1=" + plant +
               "&Param.2=" + resource + "&Param.3=" + this.getView().byId("txt_ICT").getValue() + "&Content-Type=text/json", "", false);
         sap.ui.getCore().setModel(generateBatchModel, "generateBatchData");
         var batchCounter = generateBatchModel.getData().Rowsets.Rowset[0].Row[0].O_Batch
         this.getView().byId("txt_batchcounter").setValue(batchCounter.slice(7, 10));
         this.validateFuture();
      },

      validateFuture: function() {
         var current_date = this.getView().byId("txt_ICT").getDateValue();
         //    current_date=CommonUtility.getCurrentDateTime(current_date)
         var TodayDate = new Date();
         //TodayDate= CommonUtility.getCurrentDateTime(TodayDate)
         if (current_date > TodayDate) {

            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_060"));
            this.getView().byId("txt_ICT").setValue(CommonUtility.getCurrentDateTime(TodayDate))
         }

      },

      PopulateQTP: function() {
         oTable = this.getView().byId("id_tab_PackList");
         var SelRow = oTable.getSelectedContextPaths()[0];
         var QnSelectedRow = this.getView().getModel("PackingListData").getProperty(SelRow);
         this.getView().byId("txt_UpdateHUQTP").setValue(QnSelectedRow.QTYTOPACK)
      },

      UpdateHUQTP: function() {
         oTable = this.getView().byId("id_tab_PackList");
         if (parseInt(this.getView().byId("txt_UpdateHUQTP").getValue()) > parseInt(this.getView().byId("txt_FullPalletQty").getValue())) {
            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_058") + " i.e. " + this.getView().byId("txt_FullPalletQty")
                  .getValue());
         } else if (oTable.getSelectedItem()) {
            var validation = this.ValidateField("Pack");
            if (!validation) {
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_001"));
               this.getView().byId("txt_UpdateHUQTP").setValue("");
            } else {

               var SelRow = oTable.getSelectedContextPaths()[0];
               var QnSelectedRow = this.getView().getModel("PackingListData").getProperty(SelRow);
               var QTP = QnSelectedRow.QTYTOPACK;
               var HUNum = QnSelectedRow.HUSERIAL;

               var UpdQtyToPackForHUModel = models.createNewJSONModel(
               "com.khc.weighhub.controller.ReceiptConfirmation-->UpdateHUQTP-->SQLQ_UpdQtyToPackForHU");
               UpdQtyToPackForHUModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdQtyToPackForHU&Param.1=" +
                     HUNum + "&Param.2=" + orderID + "&Param.3=" + matno + "&Param.4=" + this.getView().byId("txt_UpdateHUQTP").getValue() +
                     "&Content-Type=text/json", "", false);
               sap.ui.getCore().setModel(UpdQtyToPackForHUModel, "UpdQtyToPackForHUData");

               packingListModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetHUListForReceipt&Param.1=" + plant +
                     "&Param.2=" + resource + "&Param.3=" + orderID + "&Content-Type=text/json", "", false);
               sap.ui.getCore().setModel(packingListModel, "PackingListData");
               this.getView().byId("txt_UpdateHUQTP").setValue("");
            }
         } else {
            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_059"));
         }
         oTable.removeSelections(true);
      },

      GetCurrentBatchSize: function() {
         if (this.getView().byId("txt_uom").getValue() != "EA") {

            var GetWeighOrderBatchSizeModel = models.createNewJSONModel(
            "com.khc.weighhub.controller.ReceiptConfirmation-->GetCurrentBatchSize-->SQLQ_UpdQtyToPackForHU");
            GetWeighOrderBatchSizeModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdQtyToPackForHU&Param.1=" +
                  orderID + "&Param.2=" + plant + "&Param.3=" + resource + "&Content-Type=text/json", "", false);

         if(CommonUtility.getJsonModelRowCount(GetWeighOrderBatchSizeModel.getData())>0) {
            OrderBatchSize = GetWeighOrderBatchSizeModel.getData().Rowsets.Rowset[0].Row[0].ORDERBATCHSIZE
            KitBatchSize = GetWeighOrderBatchSizeModel.getData().Rowsets.Rowset[0].Row[0].CURRENTBATCHSIZE
            this.getView().byId("txt_QtyToReceive").setVisible(false);
            this.getView().byId("txt_QtyToReceiveNonEA").setVisible(true);
            this.getView().byId("txt_QtyToReceiveNonEA").setValue(KitBatchSize * this.getView().byId("txt_QtyToReceive").getValue());
         }
         }
      },

      GetSharedMemHUtoKit: function() {
         var SharedMemReceiptHUToKitDistributionModel = models.createNewJSONModel(
         "com.khc.weighhub.controller.ReceiptConfirmation-->GetSharedMemHUtoKit-->XACQ_SharedMemReceiptHUToKitDistribution");
         SharedMemReceiptHUToKitDistributionModel.loadData(
               "/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_SharedMemReceiptHUToKitDistribution&Content-Type=text/json", "",
               false);

         SharedMemHUtoKit = SharedMemReceiptHUToKitDistributionModel.getData().Rowsets.Rowset[0].Row[0].O_S_ReceiptHUToKitDistribution;
      },

      Receive: function() {
         //UI_utilities.setContainerBusyState(this, true);
         var validation = this.ValidateField("Receive");
         if (!validation) {

            this.getView().byId("id_btn_receive").setEnabled(false);
         } else if (this.getView().byId("txt_printid").getValue() == "" || this.getView().byId("txt_printid").getValue() == "---" || this.getView()
               .byId("txt_printid").getValue() == "0") {

            this.getView().byId("id_btn_receive").setEnabled(false);
            UI_utilities.setContainerBusyState(this, false);
            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_055"));
         } else {
            var count = 0;
            var rowCount = packingListModel.getData().Rowsets.Rowset[0].Row.length;
            var pckqty;
            for (var i = 0; i < rowCount; i++) {
               pckqty = parseInt(packingListModel.getData().Rowsets.Rowset[0].Row[i].QTYTOPACK);
               count = count + pckqty;
            }

            if (count != this.getView().byId("txt_QtyToReceive").getValue()) {
               //UI_utilities.setContainerBusyState(this,true);
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_047"));
            } else {
               UI_utilities.setContainerBusyState(this, true);
               var assignHUNumberModel = models.createNewJSONModel(
               "com.khc.weighhub.controller.ReceiptConfirmation-->Receive-->XACQ_AssignHUNumber");
               var that=this;
/*****
                                          assignHUNumberModel.attachRequestSent(
                                                function() {
                                                   //UI_utilities.setContainerBusyState(this, true);
                                                   that.setBusy();
                                                }
                                       );
*****/
               assignHUNumberModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_AssignHUNumber&Param.1=" + plant +
                     "&Param.2=" + resource + "&Param.3=" + crId + "&Param.4=" + orderID + "&Param.5=" + shelflife + "&Param.6=" + batchdate +
                     "&Content-Type=text/json", "", false);
               sap.ui.getCore().setModel(assignHUNumberModel, "assignHUNumberData");

               if (assignHUNumberModel.getData().Rowsets.Rowset[0].Row[0].ReturnCode != 1) {
                  UI_utilities.setContainerBusyState(this, false);
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_056"));

               } else {
                  var batch = this.getView().byId("txt_BatchNumber").getValue();
                  var expiry = "";

                  var kits = this.getView().byId("txt_QtyToReceive").getValue();
                  var materialtext = "";
                  var printername = "";
                  var sscc = "";

                  var sysid = sap.ui.getCore().getModel("session").oData.CA_Server;
                  var paramBatch = this.getView().byId("txt_BatchNumber").getValue();
                  var paramqty = this.getView().byId("txt_QtyToReceive").getValue();
/*****
               sap.ui.getCore().getModel("oMessage").setProperty("/message", "Data Loading");
               sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
               sap.ui.getCore().getModel("oMessage").setProperty("/type", "Warning");
*****/
               UI_utilities.setContainerBusyState(that, true);
                  var createWeighLabelModel = models.createNewJSONModel(
                  "com.khc.weighhub.controller.ReceiptConfirmation-->Receive-->XACQ_CreateWeighLabel");
 	      var that = this;
                  createWeighLabelModel.attachRequestCompleted(
                              function() {
                                UI_utilities.setContainerBusyState(that, false);
                                sap.ui.getCore().setModel(createWeighLabelModel, "createWeighLabelData");
                                if (createWeighLabelModel.getData().Rowsets.Rowset[0].Row[0].O_PrintStatus != 1) {

                                  var msg1 = sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_048");
                                  MessageBox.alert( msg1, {
                                     icon: MessageBox.Icon.INFORMATION,
                                     title: "Message from webpage",
                                     actions: [MessageBox.Action.OK],
                                     onClose: function() {

                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_057");
                                        //var that = this;
                                        MessageBox.confirm(
                                              msg, {
                                                 icon: MessageBox.Icon.INFORMATION,
                                                 title: "Message from webpage",
                                                 actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                                 onClose: function(oAction) {
                                                    if (oAction === "OK") {

                                                       var createGRModel = models.createNewJSONModel(
                                                       "com.khc.weighhub.controller.ReceiptConfirmation-->Receive-->XACQ_CreateGR");
                                                       createGRModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_CreateGR&Param.1=" + plant +
                                                             "&Param.2=" + resource + "&Param.3=" + crId + "&Param.4=" + orderID + "&Param.5=" + paramBatch + "&Param.6=" + paramqty + "&Param.7=" + userid +
                                                             "&Param.8=" + batchdate + "&Content-Type=text/json", "", false);
                                                       sap.ui.getCore().setModel(createGRModel, "createGRData");

                                                       var completeAndPackModel = models.createNewJSONModel(
                                                       "com.khc.weighhub.controller.ReceiptConfirmation-->Receive-->XACQ_CompleteAndPack");
                                                       completeAndPackModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_CompleteAndPack&Param.1=" +
                                                             plant + "&Param.2=" + resource + "&Param.3=" + orderID + "&Param.4=" + crId + "&Param.5=" + userid + "&Param.6=" +
                                                             scalename + "&Content-Type=text/json", "", false);
                                                       sap.ui.getCore().setModel(completeAndPackModel, "completeAndPackData");

                                                       that.PrintReport();
                                                       that.onClickBack();
                                                 }
                                              }
                                     });

                                  }                    

                               }              

                                  );

                            }
                                        
                              });
                  setTimeout(function (){    
                          
                  createWeighLabelModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_CreateWeighLabel&Param.1=" +
                        batch + "&Param.4=" + kits + "&Param.5=" + barcodeperHU + "&Param.6=" + matno + "&Param.8=" + orderID + "&Param.9=" + plant +
                        "&Param.10=" + printerId + "&Param.11=" + printerName + "&Param.12=" + resource + "&Param.14=" + sysid + "&Param.16=" +
                        idperkit + "&Param.17=" + userid + "&Content-Type=text/json", "", false);
  },500) ;                
                  

/******


                                          createWeighLabelModel.attachRequestSent(
                                                function() {
                                                   //UI_utilities.setContainerBusyState(this, true);
                                                   that.setBusy();
                                                }
                                       );
******/
                  sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);

                  //++++++++++++

            }

         }
      }
   },

   PrintReport: function() {

      if (PartialDisplayFlag == 1) {
         this.PrintPartial();
      } else if (PartialDisplayFlag == 0) {
         this.PrintBin();
      }
   },

   PrintBin: function() {

      window.open('/XMII/CM/WeighHubUI5/webapp/irpt/BinReport.irpt?qs_crid=' + crId + '&qs_ordid=' + orderID, 'BinReport',
      'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');

   },

   PrintPartial: function() {

      var headermattext = this.getView().byId("txt_desc").getValue();
      window.open('/XMII/CM/WeighHubUI5/webapp/irpt/PartialReport.irpt?qs_crid=' + crId + '&qs_ordid=' + orderID + '&qs_headmat=' +
            modmatno + '&qs_headmattext=' + headermattext, 'PartialReport',
      'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');
   },

   clearData: function() {

      this.getView().byId("txt_no_of_hu").setValue("");
      this.getView().byId("vBox_PrintSettings").setVisible(false);
      this.getView().byId("vBox_BatchDetails").setVisible(false);
      this.getView().byId("txt_UpdateHUQTP").setValue("");
      this.getView().byId("vBox_PackingList").setVisible(true);
      this.getView().byId("id_btn_receive").setEnabled(true);
   },
   setBusy: function() {
      UI_utilities.setContainerBusyState(this, true);
   },
});
});