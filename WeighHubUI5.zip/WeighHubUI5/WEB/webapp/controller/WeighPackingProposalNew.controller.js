var projectName;
var plant;
var resource;
var TotalKits;
var gb_SetKitVal;
var AvailBatch;
var gb_matno;
var gb_packPropGridLoad = 0;
var gb_batchSizeCmdLoad = 0;
var gb_packPropCmdLoad = 0;
var gb_CurrentBatchSize;
var gb_batch = 1;
//var txt_ReqQty="";
var id_txt_BinReq = "";
var sIDParam;
//var txt_ActualBatch;
//var txt_NonEANewDelQty;
//var txt_NonEANewToRecQty;
//var txt_NonEARecQty;
var id_txt_BinReq;
var txt_DelQty;
var id_hid_nokits;
var OrderId;
 var Crid;
var bInitial = true;

sap.ui.define([
            "sap/ui/core/mvc/Controller",
            "sap/ui/model/json/JSONModel",
            "com/khc/weighhub/utils/UI_utilities",
            "sap/m/MessageBox",
	"com/khc/weighhub/model/formatter",
            "com/khc/common/Script/CommonUtility",
	"com/khc/weighhub/model/models"
        ], function(Controller, JSONModel, UI_utilities, MessageBox, formatter,CommonUtility,models) {
            "use strict";
        
            return Controller.extend("com.khc.weighhub.WeighPackingProposalNew", {formatter:formatter,
                onInit: function() {
                    // Register the _oRoutePatternMatched methos, init will be
                    // called only once
                    this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    // WeighHome is your Route name and set the menu key as the
                    // same name
                    this._oRouter.getRoute("WeighPackingProposalNew").attachPatternMatched(
                        this._oRoutePatternMatched, this);
                },

                _oRoutePatternMatched: function(oEvent) {
                    //Hide the messages and set busy to false
                    UI_utilities.weighPageOpened(this, "WeighPackingProposalNew");
                    plant = sap.ui.getCore().getModel("session").getData().CA_Plant;
                    resource = sap.ui.getCore().getModel("session").getData().CA_Resource;

                    var oDisplayData = {
                        selectedOption: "EAVisibility"
                    };
                    var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
                    this.getView().setModel(oDisplayOptionModel, "displayOption");

                    projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                    this.loadData();
                    this.getPackingPropInitial();
                    this.getKitsPerBin();
                    this.getStock();
                    //this.getPackingProp();
                },

                onAfterRendering: function() {
                    var that = this;
                    // To set the menu as selected, hide message ad remove busy
                    //UI_utilities.menuOpened(this,"WeighHome");
                    this.getView().byId("id_txt_Kits").addEventDelegate({
                        onfocusin: function() {
			if (!bInitial) {
                            that.getView().byId("dialpad").setVisible(true);
			}
			else{
				bInitial=false;
			}
                        }
                    });

                },
                /***********************************On Load -  to set All Input boxes****************************************************************************************/
                loadData: function() {
                    sIDParam = sap.ui.getCore().getModel("packingproposalParam").oData;
                    this.getView().byId("txt_ModOrderId").setValue(sIDParam.qs_modorderid);
                    this.getView().byId("txt_ModMatNoStrip").setValue(sIDParam.qs_modmatnr);
                    this.getView().byId("txt_GoodDesc").setValue(sIDParam.qs_mattext);
                    this.getView().byId("txt_PlannedQty").setValue(sIDParam.qs_matqty);
                    this.getView().byId("txt_NewDelQty").setValue(sIDParam.qs_newweighedqty);
                    this.getView().byId("txt_ReqQty").setValue("");
                    this.getView().byId("txt_RecQty").setValue(sIDParam.qs_receiveqty);
                    this.getView().byId("txt_NewToRecQty").setValue(sIDParam.qs_newtoreceiveqty);
                    this.getView().byId("txt_UOM").setValue(sIDParam.qs_uom);
                    this.getView().byId("txt_DueDate").setValue(sIDParam.qs_duedate);
		  this.getView().byId("id_btn_SetAllKits").setVisible(true);
                        this.getView().byId("id_btn_Set1Kits").setVisible(true);
		Crid = sIDParam.qs_crid;
                   OrderId = sIDParam.qs_ordid;
                },

                /********************************** On Load- Calculates Kits Required per Bin ***************************************************************/

                getKitsPerBin: function() {
                   
                    var oModelKitsPerBin =models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->getKitsPerBin-->XACQ_GetKitsPerBin");
                    oModelKitsPerBin.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetKitsPerBin&Param.1=" + Crid + "&Param.2=" + OrderId + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oModelKitsPerBin, "oKitsPerBinDetails");
                },

                /********************************* On Load - Populates Packing Proposal Grid based on No. of Kits Required for the Order *******************************************************/

                getPackingPropnew: function(i) {
                    var ModMatNo = sIDParam.qs_modmatnr;
                    var MatDesc = sIDParam.qs_mattext;
                    var msgid = sIDParam.qs_msgid;

 		var oModelProposalList=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->getPackingPropnew-->XACQ_GetPackingProposal");
                    oModelProposalList.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPackingProposal&Param.1=" + plant + "&Param.2=" + Crid + "&Param.3=" + OrderId + "&Param.4=" + resource + "&Param.5=" + i + "&Param.6=" + msgid + "&Param.7=" + ModMatNo + "&Param.8=" + MatDesc + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oModelProposalList, "oProposaldetails");
                    
 					var oModelProBinCount=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->getPackingPropnew-->XACQ_CalculateProposalBin");
                    oModelProBinCount.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_CalculateProposalBin&Param.1=" + Crid + "&Param.2=" + OrderId + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oModelProBinCount, "oBatchbinDetails");

                    id_txt_BinReq = oModelProBinCount.getData().Rowsets.Rowset[0].Row[0].O_BinCount
                    this.getView().byId("txt_ReqQty").setValue(i);


                    /////////////////////////////// Update Event function for Grid Applet - Populates Data for Total Kits, Total Delivered & Total Required //////////

                    this.setHeaderVal();
                },

                /**************************************  Update Mat Qty Based on Adjusted Batch Size  *********************************************/

                SetKitBatch: function() {
                    var KitBatch = this.getView().byId("id_txt_KitBatch").getValue()

                    if (isNaN(KitBatch)) {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_001"));
                        this.getView().byId("id_txt_KitBatch").setValue("0");
                    } else {
		var sActualBatch =  this.getView().byId("txt_ActualBatch").getValue();
                        var oModelUpdateMatQtyOnBatchSize = new sap.ui.model.json.JSONModel();
                        oModelUpdateMatQtyOnBatchSize.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_UpdateMatQtyOnBatchSize&Param.1=" + OrderId + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + sActualBatch + "&Param.5=" + KitBatch + "&Content-Type=text/json", "", false);
                        this.getView().setModel(oModelUpdateMatQtyOnBatchSize, "oUpdateMatQtyOnBatchSizedetails");

                        gb_CurrentBatchSize = KitBatch;
                        this.getPackingPropInitial();
                    }
                },

                /********************** Creation Event of the Packing Proposal Grid -  Populates Material List data for the Order ************************/

                getPackingPropInitial: function() {
                    this.getView().byId("id_btn_StartWeigh").setEnabled(false);
                    var ModMatNo = sIDParam.qs_modmatnr;
                    var MatDesc = sIDParam.qs_mattext;
                    var msgid = sIDParam.qs_msgid;

 		var oModelProposal=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->getPackingPropInitial-->SQLQ_GetSetKit");
                    oModelProposal.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetSetKit&Param.1=" + Crid + "&Param.2=" + OrderId + "&Content-Type=text/json", "", false);

                    var SetKitVal = oModelProposal.getData().Rowsets.Rowset[0].Row[0].KITS

                    if (this.getView().byId("txt_UOM").getValue() != "EA") {
                        gb_SetKitVal = SetKitVal;
  		this.getView().byId("id_btn_StartWeigh").setEnabled(true);
                        this.getView().getModel("displayOption").setProperty("/selectedOption", "NonEAVisibility");
                        this.getView().byId("id_btn_SetKitBatchSize").setEnabled(true);

 		var oModelBatchProposal=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->getPackingPropInitial-->XACQ_GetWeighOrderBatchSizeAndReceived");
                        oModelBatchProposal.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighOrderBatchSizeAndReceived&Param.1=" + OrderId + "&Param.2=" + plant + "&Param.3=" + resource + "&content-type=text/json", "", false);

                        if (CommonUtility.getJsonModelRowCount(oModelBatchProposal.getData()) != 0) {
                            var oBatchProposal = oModelBatchProposal.getData().Rowsets.Rowset[0].Row[0];

                            var OrderBatchSize = oBatchProposal.ORDERBATCHSIZE;
                            var KitBatchSize = oBatchProposal.CURRENTBATCHSIZE;
                            var TotalReceived = oBatchProposal.TOTALRECEIVED;
                    
                        this.getView().byId("txt_ActualBatch").setValue(OrderBatchSize);
                        this.getView().byId("id_txt_KitBatch").setValue("0");
                        gb_CurrentBatchSize = KitBatchSize;

                       // this.getView().byId("txt_NewDelQty").setVisible(false);
                        //this.getView().byId("txt_RecQty").setVisible(false);
                        //this.getView().byId("txt_NewToRecQty").setVisible(false);
                        //this.getView().byId("txt_ReqQty").setVisible(false);
                        this.getView().byId("id_btn_SetAllKits").setVisible(false);
                        this.getView().byId("id_btn_Set1Kits").setVisible(false);
                       // this.getView().byId("txt_NonEARecQty").setVisible(true);
                       // this.getView().byId("txt_NonEANewDelQty").setVisible(true);
                        //this.getView().byId("txt_NonEANewToRecQty").setVisible(true);
                       // this.getView().byId("txt_NonEAReqQty").setVisible(true);

                        this.getView().byId("txt_NonEANewDelQty").setValue(Number(this.getView().byId("txt_NewDelQty").getValue()) * Number(KitBatchSize));
                          this.getView().byId("txt_NonEANewToRecQty").setValue(Number(this.getView().byId("txt_NewToRecQty").getValue()) * Number(KitBatchSize));
                        this.getView().byId("txt_NonEARecQty").setValue(TotalReceived);
		}
                        if (SetKitVal != 0) {
                            this.getView().byId("id_btn_SetKitBatchSize").setEnabled(false);
                            //this.getView().byId("id_btn_SetKitBatchSize").className= "pageButtonUI5Disable";
                         this.getView().byId("txt_NonEAReqQty").setValue(Number(this.getView().byId("txt_ReqQty").getValue()) * Number(gb_CurrentBatchSize));
                        } else {
                           this.getView().byId("txt_NonEAReqQty").setValue(Number(this.getView().byId("txt_PlannedQty").getValue()) - Number(this.getView().byId("txt_NonEARecQty").getValue()));
                        }
                    }

                    /************************** check the UoM and Allow user to set Batch Size if UoM is not EA  **************/

                    this.getView().byId("id_txt_Kits").setValue(oModelProposal.getData().Rowsets.Rowset[0].Row[0].KITS);
                    this.getView().byId("txt_ReqQty").setValue(oModelProposal.getData().Rowsets.Rowset[0].Row[0].KITS);


                    this.getPackingPropnew(SetKitVal);
                    /*var oModelProposalList= new sap.ui.model.json.JSONModel();
                    oModelProposalList.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetPackingProposal&Param.1="+plant+"&Param.2="+Crid+"&Param.3="+OrderId+"&Param.4="+resource+"&Param.5="+SetKitVal+"&Param.6="+msgid+"&Param.7="+ModMatNo+"&Param.8="+MatDesc+"&Content-Type=text/json", "", false);
                    this.getView().setModel(oModelProposalList, "oProposaldetails");
                    	
                    var oModelProBinCount= new sap.ui.model.json.JSONModel();
                    oModelProBinCount.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_CalculateProposalBin&Param.1="+Crid+"&Param.2="+OrderId+"&Content-Type=text/json", "", false);
                    	 this.getView().setModel(oModelProBinCount, "oBatchbinDetails");
                    
                    id_txt_BinReq= oModelProBinCount.getData().Rowsets.Rowset[0].Row[0].O_BinCount*/
                    this.getKitsPerBin();
                    this.getView().byId("id_btn_StartWeigh").setEnabled(true);

                },

                /********************************** On CLick Event of SET Kits Button - Assigns no. of Kits Required to complete the Order *****************************************************************************************************/

                GetCompKits: function() {
                    TotalKits = parseInt(this.getView().byId("id_txt_Kits").getValue());
                    this.GetTotalKits(TotalKits)
                },
                GetSet1Kits: function() {

                    this.GetTotalKits("1")

                },
                GetSetAllKits: function() {
                    TotalKits = parseInt(this.getView().byId("txt_PlannedQty").getValue()) - parseInt(txt_DelQty);
                    this.GetTotalKits(TotalKits)
                },
                /*********************************************************************************************************************************************/
                GetTotalKits: function(KitNum) {
                    this.getView().byId("id_btn_StartWeigh").setEnabled(false);
                    var ModMatNo = sIDParam.qs_modmatnr;
                    var MatDesc = sIDParam.qs_mattext;
                    var msgid = sIDParam.qs_msgid;
                    TotalKits = KitNum

                    if (gb_batch == 1) {
                     var oModelMinKit=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->GetTotalKits-->XACQ_GetMinKit");
                        oModelMinKit.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetMinKit&Param.1=" + plant + "&Param.2=" + Crid + "&Param.3=" + OrderId + "&Param.4=" + resource + "&Param.5=" + TotalKits + "&Param.6=" + msgid + "&Param.7=" + ModMatNo + "&Param.8=" + MatDesc + "&Content-Type=text/json", "", false);
                        this.getView().setModel(oModelMinKit, "oMinKitdetails");

                        if (CommonUtility.getJsonModelRowCount(oModelMinKit.getData()) != 0) {
                            var kitrowcount = oModelMinKit.KITS
                            if (kitrowcount != 0) {
                                var MinKitVal = oModelMinKit.getData().Rowsets.Rowset[0].Row[0].KITS
                                let msg = sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_031") + " " + MinKitVal + " " + sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_036");
                                MessageBox.alert(msg);
                            }
                        } else {
                    		var oModelSetKit=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->GetTotalKits-->SQLQ_GetSetKit");
                            oModelSetKit.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetSetKit&Param.1=" + Crid + "&Param.2=" + OrderId + "&Content-Type=text/json", "", false);
                            this.getView().setModel(oModelSetKit, "oSetKitdetails");
                            var SetKitVal = oModelSetKit.getData().Rowsets.Rowset[0].Row[0].KITS

                            if (isNaN(TotalKits)) {
                                MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_001"));
                            } else if (parseInt(TotalKits) != TotalKits) {
                                MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_002"));
                            } else if (SetKitVal != 0) {
                                MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_003"));
                            } else if (TotalKits <= 0) {
                                MessageBox.alert("Please enter a valid number");
                            } else if (parseInt(this.getView().byId("txt_ReqQty").getValue()) < parseInt(TotalKits)) {
                                var that = this;
                                var msg = this.getView().getModel("i18n").getProperty("WS_MSG_040")
                                MessageBox.warning(
                                    msg, {
                                        icon: MessageBox.Icon.WARNING,
                                        title: "Message from webpage",
                                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                        onClose: function(oAction) {
                                            if (oAction === "OK") {
                                                that.updateWeighList(TotalKits);
                                            } //end of if condition endofShift
				else{
				       that.getView().byId("id_btn_SetKitBatchSize").setEnabled(true);
				}
                                        }

                                    });
                             }else{
                                   this.updateWeighList(TotalKits);
                             } 
                        }	
                     }else {
                                let msg = sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_029") + " " + gb_matno + ". " + sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_030");
                                MessageBox.alert(msg);
                            }
                    },

                            updateWeighList: function(TotalKits) {
                    			var oModelTotalKits=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->updateWeighList-->SQLQ_UpdWeighList");
                                oModelTotalKits.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdWeighList&Param.1=" + TotalKits + "&Param.2=" + OrderId + "&Param.3=" + Crid + "&Content-Type=text/json", "", false);
                                this.getView().setModel(oModelTotalKits, "oTotalKitsdetails");
                              id_hid_nokits=TotalKits
                                this.getPackingPropnew(TotalKits);
                                this.getKitsPerBin();

                                this.getView().byId("id_txt_Kits").setValue(TotalKits);
                                this.getView().byId("txt_ReqQty").setValue(TotalKits);
                                /**************************	check the UoM and If Not EA show Quantity not Kit Count ****************/

                                if (this.getView().byId("txt_UOM").getValue() != "EA") {
                                    this.getView().byId("txt_NonEAReqQty").setValue(Number(this.getView().byId("txt_ReqQty").getValue()) * Number(gb_CurrentBatchSize));
                                    gb_SetKitVal = Number(this.getView().byId("txt_ReqQty").getValue());
                                }
                                this.getView().byId("id_btn_StartWeigh").setEnabled(true);
                                this.getView().byId("id_btn_SetKitBatchSize").setEnabled(false);
                        
                            },
                          
                        /*********************************************************************************************************************************************/
                        ResetKits: function() {
                                
                    			var oModelSetKit=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->ResetKits-->SQLQ_GetSetKit");
                                oModelSetKit.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetSetKit&Param.1=" + Crid + "&Param.2=" + OrderId + "&Content-Type=text/json", "", false);
                                this.getView().setModel(oModelSetKit, "oSetKitdetails");

                                if (CommonUtility.getJsonModelRowCount(oModelSetKit.getData()) != 0) {
                                    var SetKitVal = oModelSetKit.getData().Rowsets.Rowset[0].Row[0].KITS
                                    TotalKits = this.getView().byId("id_txt_Kits").getValue()
                                }
                               
                    			var oModelSetKitsResetKit=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->ResetKits-->SQLQ_GetSetKitsResetKit");
                                oModelSetKitsResetKit.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetSetKitsResetKit&Param.1=" + OrderId + "&Param.2=" + Crid + "&Content-Type=text/json", "", false);
                                this.getView().setModel(oModelSetKitsResetKit, "oSetKitsresetKitdetails");

                                var ResetChkCount = oModelSetKitsResetKit.getData().Rowsets.Rowset[0].Row[0].Count

                    			var oModelDistCounterReset=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->ResetKits-->SQLQ_GetDistinctCounterReset");
                                oModelDistCounterReset.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_GetDistinctCounterReset&Param.1=" + OrderId + "&Param.2=" + Crid + "&Content-Type=text/json", "", false);
                                this.getView().setModel(oModelDistCounterReset, "oDistCounterRestdetails");
                                var CurrentCounter;
                                if (CommonUtility.getJsonModelRowCount(oModelDistCounterReset.getData()) != 0) {
                                    CurrentCounter = oModelDistCounterReset.getData().Rowsets.Rowset[0].Row[0].COUNTER
                                }

                                if (ResetChkCount != 1) {
                                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_044"));
                                } else if (SetKitVal == CurrentCounter) {
                                    MessageBox.alert("Set No. of Kits weighed already. Cannot Reset");
                                } else {
                                   
                    			var oModelUpdWeighListResetKits=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->ResetKits-->SQLQ_UpdWeighListResetKits");
                                    oModelUpdWeighListResetKits.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_UpdWeighListResetKits&Param.1=" + OrderId + "&Param.2=" + Crid + "&Param.3=" + CurrentCounter + "&Content-Type=text/json", "", false);
                                    this.getView().setModel(oModelUpdWeighListResetKits, "oUpdWeighListResetKitsdetails");

                                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_045"));
                                    this.getView().byId("id_txt_Kits").setValue("");
                                
                                gb_SetKitVal = 0;
                                this.getPackingPropInitial();
		      }

                            },



                            /********************** Creation Event function for populating the Material Batch data in HNZ_BATCH Table *******************/

                            getStock: function() {
                               
                    			var oModelAvailableBatch=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->getStock-->SQLQ_ChkMatStockinPSA");
                                oModelAvailableBatch.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/SQLQ_ChkMatStockinPSA&Param.1=" + Crid + "&Param.2=" + resource + "&Param.3=" + OrderId + "&Content-Type=text/json", "", false);
                                this.getView().setModel(oModelAvailableBatch, "oTotalKitsdetails");

                                if (CommonUtility.getJsonModelRowCount(oModelAvailableBatch.getData()) != 0) {

                                    AvailBatch = oModelAvailableBatch.getData().Rowsets.Rowset[0].Row[0].BATCH
                                    gb_matno = oModelAvailableBatch.getData().Rowsets.Rowset[0].Row[0].MATNO


                                    if (AvailBatch != "---") {
                                        gb_batch = 1;
                                        this.getView().byId("id_Kits_Bin").setVisible(true);
                                    } else {
                                        gb_batch = 0;
                                        this.getView().byId("id_Kits_Bin").setVisible(false);
                                    }
                                }
                            },
                            /**************************** On Click event of Back to Worklist Button - Redirects to WeighingOrderListNew.irpt page ********************************************************************************/
                            /*  onGetBack : function(oEvent) {
		 UI_utilities.setContainerBusyState(this, true);
            	    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
              	  oRouter.navTo("WeighingOrderListNew");
		}, */

                            onGetBack: function(oEvent) {
                                UI_utilities.setContainerBusyState(this, true);
                               var ToReceiveQty=sIDParam.qs_toreceiveqty;
  			let that=this;
                                if (ToReceiveQty > 0) {
                                    var msg = this.getView().getModel("i18n").getProperty("WS_MSG_064")
                                    sap.m.MessageBox.warning(
                                        msg, {
                                            icon: MessageBox.Icon.WARNING,
                                            title: "Message from webpage",
                                            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                            onClose: function(oAction) {
                                                if (oAction === "OK") {
                                               that._oRouter.navTo("WeighingOrderListNew");
                                                } else {
                                                    UI_utilities.setContainerBusyState(that, false);
                                                }
                                            }
                                        });
                                } else {
                                    this._oRouter.navTo("WeighingOrderListNew");
                                }
                            },
                            //////////////////// On Click Event function for button - Print Report - Generates an HTML Report for the Material Packing Proposal  ////////////////


                            onPrintReport: function() {
                                if (gb_batch == 1) {
                   
                                    var ModMatNo = sIDParam.qs_modmatnr;
                                    var MatDesc = sIDParam.qs_mattext;
                                    var msgid = sIDParam.qs_msgid;
			if(id_hid_nokits==undefined){id_hid_nokits=""}
                                    var NoKits =id_hid_nokits;


                                    var Url = '/XMII/CM/WeighHubUI5/webapp/irpt/PackPropReport.irpt?qs_crid=' + Crid + '&qs_ordid=' + OrderId + '&qs_msgid=' + msgid + '&qs_NoKits=' + NoKits + '&qs_matno=' + ModMatNo + '&qs_MatDesc=' + MatDesc+'&CA_Plant='+plant+'&CA_Resource='+resource;
                                    window.open(Url, 'PackingProposalReport', 'width=1152,height=864,scrollbars=no,resizable=no,status=yes,location=yes,left=0,top=0');
                                } else {
                                    let msg = sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_029") + " " + gb_matno + ". " + sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_030");
                                    MessageBox.alert(msg);
                                }
                            },

                            /********************** Update Event function for Grid Applet - Populates Data for Total Kits, Total Delivered & Total Required **********************************/

                            setHeaderVal: function() {

                    	var oModelDelKit=models.createNewJSONModel("com.khc.weighhub.WeighPackingProposalNew-->setHeaderVal-->XACQ_GetWeighingMaterial");
                                oModelDelKit.loadData("/XMII/Illuminator?QueryTemplate=GBL_WEIGHING/QueryTemplate/XACQ_GetWeighingMaterial&Param.1=" + Crid + "&Param.2=" + OrderId + "&Content-Type=text/json", "", false);
                                this.getView().setModel(oModelDelKit, "oDelKitdetails");

                                this.getView().byId("txt_ReqQty").setValue(oModelDelKit.getData().Rowsets.Rowset[0].Row[0].Kit);

                                txt_DelQty = oModelDelKit.getData().Rowsets.Rowset[0].Row[0].Completed;

                                /////////////// Begin Change for getting req quantity //////////////////////

                                if (this.getView().byId("txt_ReqQty").getValue() == 0) {
                                   this.getView().byId("txt_ReqQty").setValue(this.getView().byId("txt_PlannedQty").getValue() - txt_DelQty);
                                }
		 

                                ///////////////	End Change for getting req quantity   ////////////////

                                /**************************  to check the UoM and If Not EA show Quantity not Kit Count*************/

                                if (this.getView().byId("txt_UOM").getValue() != "EA") {
                                    if (gb_SetKitVal != 0) {
                                        this.getView().byId("txt_NonEAReqQty").setValue(Number(this.getView().byId("txt_ReqQty").getValue()) * Number(gb_CurrentBatchSize));
                                    } else {

                                        this.getView().byId("txt_NonEAReqQty").setValue(Number(this.getView().byId("txt_PlannedQty").getValue()) - Number(this.getView().byId("txt_NonEARecQty").getValue()));
                                    }
                                }
                            },


                            /*************************************************************************************************************************************************************************************/
                            //Keyboard inputs
                            /*************************************************************************************************************************************************************************************/

                            onClickDialpad: function(oEvent) {

                                let sKey = oEvent.getSource().getText();
                                let bottleneckCounter = this.getView().byId("id_txt_Kits").getValue();
                                let newBottleneckCounter = bottleneckCounter + sKey;
                                this.getView().byId("id_txt_Kits").setValue(newBottleneckCounter);

                                //this.CalculateOutput();

                            },

                            onCancelDialPad: function(oEvent) {

                                this.getView().byId("id_txt_Kits").setValue("");
                                //this.getView().byId("actualOutInterval").setValue("0");

                            },

                            closeDialPad: function(oEvent) {

                                this.getView().byId("dialpad").setVisible(false);

                            },

                            /****************** On Click Event of Next Weighing Button - Redirects to WeighingListNew1.irpt page **********************************************************************/

                            OnClickNext: function() {

                                if (gb_batch == 1) {

                                    var weighNewModel = new sap.ui.model.json.JSONModel();
                                    let weighNewData = {
                                        qs_msgid: sIDParam.qs_msgid,
                                        qs_crid: sIDParam.qs_crid,
                                        qs_ordid: sIDParam.qs_ordid,
                                        qs_matno: sIDParam.qs_matno,
                                        qs_modmatno: sIDParam.qs_modmatnr,
                                        qs_mattext: sIDParam.qs_mattext,
                                        qs_modorderid: sIDParam.qs_modorderid,
                                        qs_matqty: sIDParam.qs_matqty,
                                        qs_uom: sIDParam.qs_uom,
                                        qs_duedate: sIDParam.qs_duedate,
                                        qs_receiveqty: sIDParam.qs_receiveqty,
                                        qs_toreceiveqty: sIDParam.qs_toreceiveqty

                                    };
                                    weighNewModel.setData(weighNewData);
                                    sap.ui.getCore().setModel(weighNewModel, "weighingNewDataModel");

                                    UI_utilities.setContainerBusyState(this, true);
                                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                                    oRouter.navTo("WeighingListNew1");
                                } else {
                                    let msg = sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_029") + " " + gb_matno + ". " + sap.ui.getCore().getModel("i18n").getProperty("WS_MSG_030");
                                    MessageBox.alert(msg);
                                }
                            }


                    });
            });