sap.ui.define(["com/khc/common/Script/CommonUtility"], function(CommonUtility) {
    "use strict";
	return {


	/**
	 * called from controller once the weighPageOpened
	 */
	weighPageOpened : function (oController,sKey) {
		sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",false);
		this.setContainerBusyState(oController,false);

	},
	
	/**
	 *  to set the busy state of the component
	 */
		setContainerBusyState: function(oController, bState ){
			
			var oContainer = oController.getOwnerComponent().oContainer;
			oContainer.setBusy(bState);
			
		},


		/**
		 * to open the help file
		 */
	 OpenHelpFileSingle : function (bookmark)
		{
			var helpfile = sap.ui.getCore().getModel("session").getProperty("/CA_HelpFileName");;

			var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#"+bookmark;

			window.open(Url, 'InspectionPointSPC', 'width=1050,height=800,scrollbars=yes,left=10,top=10,resizable=yes,status=yes,location=no');
		},

/**********************************************************************************************************/
	//Disable the datepicker input box
/*************************************************************************************************************/	
DisableDatePickerInput:function(oDatePicker){

		oDatePicker.addEventDelegate({
			onAfterRendering: function(){
		var oDateInner = this.$().find('.sapMInputBaseInner');
				var oID = oDateInner[0].id;
				$('#'+oID).attr("disabled", "disabled"); 
			}},oDatePicker);
}
/*************************************************************************************************************/	

}
   	});   


