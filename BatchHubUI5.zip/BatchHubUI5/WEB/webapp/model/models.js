sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device"
], 
    /**
     * provide app-view type models (as in the first "V" in MVVC)
     * 
     * @param {typeof sap.ui.model.json.JSONModel} JSONModel
     * @param {typeof sap.ui.Device} Device
     * 
     * @returns {Function} createDeviceModel() for providing runtime info for the device the UI5 app is running on
     */
    function (JSONModel, Device) {
        "use strict";

        return {
        	
        	/**
        	 * Device model
        	 */
            createDeviceModel: function () {
                var oModel = new JSONModel(Device);
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            } ,
            
            /**
			 * To return the initial alert  model, to show the alert messages 
			 */
			createAlertModel :function(){
			
				 var oAlertModel = new sap.ui.model.json.JSONModel();
				 var oAlertData = {message:"", running:false,alertFlag:0,state:"positive"};
				 oAlertModel.setData(oAlertData);
				 return oAlertModel;
			},
			
			 /**
			 * To return the initial Menu  model and set the selected Menu
			 */
			createMenuModel :function(){
			
				 var oMenuModel = new sap.ui.model.json.JSONModel();
				 var omenuData = {selectedMenu:"RepHome", previousMenu:"RepHome"};
				 oMenuModel.setData(omenuData);
				 return oMenuModel;
			},
			
			/**
			 * To return the initial message model, to show the messages on the page
			 */
			createMessageModel :function(){
			
				 var oMessageModel = new sap.ui.model.json.JSONModel();
				 var oMsgData = {message:"",type:"Success",showMessage:false};
				 oMessageModel.setData(oMsgData);
				 return oMessageModel;
			},
			/**
			 * To save the data of main page when coming back from child pages
			 */
			createRedirectFromChildPage:function(){
			
				 var oRediectFromChildPageModel = new sap.ui.model.json.JSONModel();
				 let oMsgData = {Parent_Page:false};
				oRediectFromChildPageModel.setData(oMsgData);
				 return oRediectFromChildPageModel;
			},
			
			/**
			 * TO create the user session Model, if browser session exist prepare the model from session data, else prepare the model from .iirpt
			 */
			createSessionModel:function(){ 
				var uname = document.getElementById("id_hid_uname").value;
				
				
				  	     
				
				var oSessionModel = new sap.ui.model.json.JSONModel();
				
				// Check local storage exist for the user, if yes prepare the model from local storage
				var bLoadFromServer = true;
					if(localStorage[uname+"_BATCH"]){
						
						var oUserSessionData = JSON.parse(localStorage[uname+"_BATCH"]);
						
						if(Object.keys(oUserSessionData).length>0){
						
							bLoadFromServer = false;
							oSessionModel.setData(oUserSessionData);
							
						}
					}
				
					if(bLoadFromServer) {
						
						
					        var plant = document.getElementById("id_hid_plant").value;
					        var resource = document.getElementById("id_hid_resr").value;
					        var workStation = document.getElementById("id_hid_crdest").value;
					        var resourceText  = document.getElementById("id_txt_resrtxt").value;
					        var workStationTxt  = document.getElementById("id_txt_crdesttxt").value;
					        var plantText = document.getElementById("id_hid_planttxt").value;
					        var projectname = document.getElementById("id_hid_projectname").value;

							var sServerName = document.getElementById("id_hid_server").value;
							var sManualFlag = document.getElementById("id_hid_manual").value;
							var sManualURL = document.getElementById("id_hid_manualURL").value;
						   	 var sScaleName = document.getElementById("id_hid_scalename").value;
							var sRoles =  document.getElementById("id_hid_uroles").value;
							var shelpFile =  document.getElementById("id_hid_HelpFile").value;
							var sManualName =  document.getElementById("id_hid_manualName").value;
							var sTwoStageFlag=document.getElementById("id_hid_twoStagFlag").value;
							var numFormat=document.getElementById("id_hid_NumFormat").value;
							var language=document.getElementById("id_hid_lan").value;
							var scaGRBlockFlag=document.getElementById("id_hid_grblock").value;
							var sHACCPSign2Role =document.getElementById("id_hid_HACCPSign2Role").value;
							var batchProjectname = document.getElementById("id_hid_batchprojectname").value;
					        var caunit = document.getElementById("id_hid_prdunit").value;
					        var SignRole = document.getElementById("id_txt_SignRole").value;
					        var BatchVerifyFlag = document.getElementById("id_txt_BatchVerifyFlag").value;
						var BHPartialWeigh = document.getElementById("id_txt_BHPartialWeigh").value;
						var ScaleDecimal = document.getElementById("id_txt_ScaleDecimal").value;
			 				 
					var aPropertyDetails = {
											CA_Server : sServerName,
											CA_manualMasterFlag : sManualFlag,
											CA_ManualMasterURL : sManualURL,
											CA_Plant : plant,
											CA_Resource : resource,
											CA_CRDest : workStation,
											CA_IllumLoginName : uname,
											CA_ProjectName : projectname,
											CA_GRBlockFlag:scaGRBlockFlag,
											CA_ResrText : resourceText,
											CA_PlantText : plantText,
											CA_CRDestText : workStationTxt,
											CA_ScaleName:sScaleName,
											IllumLoginRoles:sRoles,
											CA_HelpFileName:shelpFile,
											CA_ManualName:sManualName,
											CA_TwoStageFlag:sTwoStageFlag,
										  CA_NumFormat:numFormat,
											Language:language,
											HACCPSign2Role:sHACCPSign2Role,
											CA_BatchProjectName:batchProjectname,
										 CA_Unit :caunit,
										 CA_SignSecondLevelRole :SignRole,
										 CA_BatchVerifyFlag :BatchVerifyFlag,
										CA_BHPartialWeigh :	BHPartialWeigh,
										CA_ScaleDecimal : ScaleDecimal
										}; 
							oSessionModel.setData(aPropertyDetails);
							
							// Write user dependent data to local storage as json string, example, project name is not user dependent
							localStorage.setItem(uname+"_BATCH",JSON.stringify(aPropertyDetails));
					}
					
					console.log(bLoadFromServer, oSessionModel.getData());
					return oSessionModel;
					
			        

		},
       /*********************************************************************************************************************************************************************************/
 		createQualityMenuBarModel :function(){
			
				 var oQualityMenuBarModel = new sap.ui.model.json.JSONModel();
				 let oMsgData = {MenuBar:""};
				oQualityMenuBarModel.setData(oMsgData);
				 return oQualityMenuBarModel;
			},
			
			/**
			 * return a new JSON model and create the failure handler, which will refresh the screen
			 */
			createNewJSONModel : function(sMessage) {
		    	  
		    	  var oNewJsonModel = new sap.ui.model.json.JSONModel();
		  		
		  		
		  		oNewJsonModel.attachRequestFailed(function(event){
		  			
		  			sap.m.MessageBox.error("Exception Occured in - "+sMessage+" , Page will refresh, please contact your Administrator");
		  			
		  			 setTimeout(function(){ window.location.reload(); }, 3000);
		  		});
		  		
		  		return oNewJsonModel;
		    	  
		    	  
		      },
		      
		      createNewXMLModel : function(sMessage) {
		    	  
		    	  var oNewXMLModel = new sap.ui.model.xml.XMLModel();
		  		
		  		
		    	  oNewXMLModel.attachRequestFailed(function(event){
		  			
		    		  sap.m.MessageBox.error("Exception Occured in - "+sMessage+" , Page will refresh, please contact your Administrator");
		    		  setTimeout(function(){ window.location.reload(); }, 3000);
		    		  
		    		  
		  		  		});
		  		
		  		return oNewXMLModel;
		    	  
		    	  
		      },
        	
	
    };
});