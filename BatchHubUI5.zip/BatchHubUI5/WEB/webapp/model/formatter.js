sap.ui.define([], function() {
    "use strict";
    return {

        fnTrimLeadingZeros: function(value) {




            if (value) {

                //	value =  value.replace(/^0+/, '');

                value = value.replace(/\b0+/g, '')

                return value;
            } else {
                return value;
            }
        },

	fnGetLogTypeImage: function(LOGTYPE){
				
				
				
				console.log("fnGetStatusImage  "+status);
				if(LOGTYPE==="E"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
				}
				if(LOGTYPE==="S"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
								}
				if(LOGTYPE==="W"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
				}
				if(LOGTYPE==="I"){
					
							return '/XMII/CM/ReuseLibraryUI5/Common/css/blue.png';
				}
				else{
							return '/XMII/CM/ReuseLibraryUI5/Common/css/magenta.png';
				}
				
			},


        fnGetStatusImage: function(status) {




            if (status.replace(/^\D+/g, '') > 0) {


                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            } else {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }
        },
        //Quality Notif start
        fnQualityNotifStatusImage: function(status) {
	if(status<2){ 
                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
		}
	else if(status>1){ 
                return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
	}
/*if(status<=2){ 
                return 'css/green.png';
}
else if(status<=2&&status>=1){ 
                return 'css/red.png';
}*/

         /*   if (status == 1) {
                return 'css/green.png';
            } else {
                return 'css/red.png';
            }*/
        },
        //Quality Notif End
        //insception Point
        fnPhaseDueTimeStatusImage: function(status) {
        

            if (status == "G") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            }
            if (status == "R") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            }
            if (status == "Y") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }
        },


   fnDirectIssueStatusImage: function(status) {
        

            if (status == "1") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            }
            if (status == "0") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }
        },
        fnInspPointStatus: function(Eval  ) {
             var insp5=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0005") 
             var insp4=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0004")  
        
            if (Eval == "Fail") {
                return insp5
            } else if (Eval == "Pass") { 
                    return insp4
            }
        },
        fnInspPointColor: function(Eval, PassColor) {
           
            if(Eval==null){Eval=""}   
	
            if (Eval == "Fail") {
                return "RED"
            } else if (Eval == "Pass") {
                if (PassColor == "G") {
                    return "GREEN"
                } else if (PassColor == "Y") {
                    return "YELLOW"
                }

            }
	else{
		return Eval;
	}

        },//dlt
	fntoString:function(value){
		if(value==null){
		 value='';
		return value;
		}
		else{
		return value.toString();
		}
	},
        fnInspOrderPointColor: function(Eval, PassColor) {
           // console.log(Eval + "-" + PassColor)
                
                return "RED"
             

        },//dlt

 fnoGetInspDisplayResultColor: function(Eval) {
            console.log(Eval);
               
           if (Eval == "Accepted" ) {
                    return "GREEN";
            } else  if(Eval == "Rejected") {
                   return "RED";
            } else {
	         return "GREY";
	}
        },

 fnGetEvalBckColor: function(Eval) {
            console.log(Eval);
               
           if (Eval == "Pass" || Eval == "Running") {
                    return "GREEN";
            } else  if(Eval == "Fail" || Eval == "Closed") {
                   return "RED";
            } else {
	         return "YELLOW";
	}
        },
 fnGetStatusBckColor: function(Status) {
            console.log(Status);
               
           if (Status == "Completed") {
                    return "Completed";
            } else  if(Status == "%") {
                   return "%";
            } else if(Status == "Not Started") {
	         return "Not Started";
	} else if(Status == "Partly Finish"){
	         return "Partly Finish";
	}
        },
        fnInspPointGetEval: function(Eval) {
		if(Eval==null){Eval=""}
             var insp1=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0001") 
             var insp2=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0002") 
             var insp3=sap.ui.getCore().getModel("i18n").getProperty("HUB_INSP_0003") 
            
            if (Eval == "Completed") {
                return insp1
            } else if (Eval == "Not Started") { 
                return insp2 
            } else if (Eval == "Partly Finish") { 
                return insp3
            }
	else{
		return Eval;
	}

        },
        //insception Point End
        //insceptionSubmit Start

        fnvaluationImgSrc: function(VALUATION) { 
         

            if (VALUATION == "R") {
                return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            } else if (VALUATION == "A") { 
                return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            } 

        },
        
        //insception Point End

        productionButtonVisibility: function(sPageName) {


            if (sPageName === "BatchMainMenuOperator" || sPageName === "MainMenuSupervisor") {

                return true;
            } else {

                return false;
            }

        },

        MaintenanceButtonVisibility: function(sPageName) {
            if (sPageName === "BatchMainMenuOperator" || sPageName === "MainMenuSupervisor") {
                return true;
            } else {

                return false;
            }
        },

        AnalysisButtonVisibility: function(sPageName) {
            if (sPageName === "BatchMainMenuOperator" || sPageName === "MainMenuSupervisor" || sPageName === "MainMenuPrdViewer" || sPageName === "MainMenuInspector") {
                return true;
            } else {

                return false;
            }
        },
	fnPhaseDueTimeStatusImageDisplay: function(Lights) {
		console.log(Lights)
           		if (Lights == "G") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            }
            	if (Lights == "R") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            }
            	if (Lights == "Y") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }

	},

	fnStatusBackground: function(Status) {
		console.log(Status)
           		if (Status == "Completed") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
            }
            	if (Status == "%") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/red.png';
            }
            	if (Status == "Not started") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
            }
            	if (Status == "Partly Finish") {
                	return '/XMII/CM/ReuseLibraryUI5/Common/css/lightgreen.png';
            }
	},
        CheckLogButtonVisibility: function(sPageName) {
            if (sPageName === "BatchMainMenuOperator" || sPageName === "MainMenuSupervisor" || sPageName === "MainMenuInspector") {
                return true;
            } else {

                return false;
            }
        },

        NcLineButtonVisibility: function(sPageName) {

            if (sPageName === "BatchMainMenuOperator") {
                return true;
            } else {

                return false;
            }

        },

        ShiftReviewButtonVisibility: function(sPageName) {

            if (sPageName === "MainMenuSupervisor" || sPageName === "MainMenuPrdViewer") {
                return true;
            } else {

                return false;
            }
        },

	ProdHomeNewButtonVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return false;
          		  } else {
             		   return true;
           		 }
        },

	ProdHomeResourceVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return true;
          		  } else {
             		   return false;
           		 }
        	},

ProdHomeMenuBarVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return false;
          		  } else {
             		   return true;
           		 }
        },

ProdHomeMenuBarPrdViewerVisibility: function(role) {

          	 	 if (role === "MainMenuPrdViewer") {
               		 return true;
          		  } else {
             		   return false;
           		 }
        },
fnGetInspDisplayResult: function(parent_page,result,displayResult) {

	console.log(parent_page);

	if (parent_page === "InspPointOrderViewer") {
                return result;
            } else {

                return displayResult;
            }        
        },
/***************************Menu Bar visibility -Quality*************************************************************************************************************************/
/*ProductionQualityMenuBar:function(sPageName){
	if(sPageName==="ProductionQuality1"){
	  return true;
	}
	else{
	  return false;
	}
}*/

/*BatchProdDispatch Start*/
     fnGetStatus: function(status) {
		if(status==null){status="";}
             var running=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0070") 
             var Dispatched=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0069") 
             var Complete=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0071") 
            
            if (status == "Running") {
                return running;
            } else if (status == "Dispatched" ||status == "Scheduled") { 
                return Dispatched
            } else if (status == "Complete") { 
                return Complete
            }
	else{
		return status;
	}

        }, 

fuGetBatchListStatus:function(status){
		   var running=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0070") 
             var scheduled=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0069") 
             var complete=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0071") 
		
		if(status=="1"){
			return running;
		}
		else if(status=="0"){
			return scheduled;
		}
		else{
			return complete;
		}
	},
/*BatchProdDispatch End*/
/*BatchCampaign Start*/
 fnGetPhaseStatus: function(status) {
		if(status==null){status=""}
             var NotStarted=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0066") 
             var Started=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0067") 
             var Complete=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0068") 
            
            if (status == "Not Started") {
                return NotStarted;
            } else if (status == "Started" ) { 
                return Started
            } else if (status == "Complete") { 
                return Complete
            }
	else{
		return status;
	}

        }, 
/*BatchCampaign End*/

/*BatchOEMatTipping Start*/

 fnBatchFlag:function(TipFlag) {

	if (TipFlag <= "0") {
		return '/XMII/CM/ReuseLibraryUI5/Common/css/yellowlight.png';
        }
        	if (TipFlag > "0" && TipFlag <=1) {
            	return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
        }
        	
        },
/*BatchOEMatTipping End*/

/*BatchOEMatIdentification Start*/

 fnBatchValFlag:function(ValFlag) {
       if (ValFlag < 1) {
		return '/XMII/CM/ReuseLibraryUI5/Common/css/green.png';
        }
        	if (ValFlag = 1) {
            	
		return '/XMII/CM/ReuseLibraryUI5/Common/css/yellow.png';
        }
        	
        },
    /*BatchOEMatIdentification End*/

 fnBatchOEEColor:function(Availability) {

	if(Availability>=80){
            return "Green";
        	}
	else(Availability<80)
	     return "Red";
	
        },

        fnPhaseStatusColorCamp: function(PHASESTATUS) {
		if(PHASESTATUS==null){PHASESTATUS=""}
             var cview1=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0066") 
             var cview2=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0067") 
             var cview3=sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0068") 
            
            if (PHASESTATUS == "Complete") {
                return cview3
            } else if (PHASESTATUS == "Not Started") { 
                return cview1 
            } else if (PHASESTATUS == "Started") { 
                return cview2
            }
	else{
		return PHASESTATUS;
	}

        },
         
    fnBatchPlantstatus:function(Status){
      if(Status=="R"){
        return "Green";
      }
      else if (Status == "F" ) { 
        return "Red";
    } else if (Status == "I") { 
        return "FF9900";
    }
    else if (Status == "L") { 
      return "Blue";
  }
    else{
      return "Yellow";
    }
    }
        
    }
});
