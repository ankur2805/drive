sap.ui.define(["com/khc/common/Script/CommonUtility","com/khc/batchhub/model/models"], function(CommonUtility,models) {
    "use strict";
	return {

	
	/**
	 * called from controller once the non production page opened
	 */
	batchPageOpened : function (oController,sKey) {

		sap.ui.getCore().getModel("oMessage").setProperty("/showMessage",false);
		sap.ui.getCore().getModel("oMenu").setProperty("/selectedMenu",sKey);
				
		this.setContainerBusyState(oController,false);
		
	},

	
	/**
	 * called from controller once the user clicked the menu
	 */
	
	openMenu : function (oRouter,oController, sKey) {
		
		// check the session is still alive, if not it will throw exception
		var oDummyModel =models.createNewXMLModel("com.khc.batchhub.utils.UI_utilities.js-->openMenu-->"+sKey);
		oDummyModel.loadData("/XMII/PropertyAccessServlet?mode=Retrieve&PropName=Language&Content-Type=text/xml","",false);
		
		if( sKey !== "help" && oRouter.oHashChanger.hash  != sKey)	{

			
			this.setContainerBusyState(oController,true);
			oRouter.navTo(sKey);
		}
		
		if( sKey === "BatchIdentification")	{

			 var incResSubmitModel = new sap.ui.model.json.JSONModel();
                        let sID = { };
                        incResSubmitModel.setData(sID);
			
					
			   sap.ui.getCore().setModel(incResSubmitModel, "BatchIdentParams");
		}
		
	},
	

	/**********************************************************************************************************/
		//Set Busy Icon during Page load
	/*************************************************************************************************************/	

	
	/**
	 *  to set the busy state of the component
	 */
		setContainerBusyState: function(oController, bState ){
			
			var oContainer = oController.getOwnerComponent().oContainer;
			oContainer.setBusy(bState);
			
		},
		

		/**
		 * to open the help file
		 */
	 OpenHelpFileSingle : function (bookmark)
		{
			var helpfile = sap.ui.getCore().getModel("session").getProperty("/CA_HelpFileName");;

			var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#"+bookmark;

			window.open(Url, 'InspectionPointSPC', 'width=1050,height=800,scrollbars=yes,left=10,top=10,resizable=yes,status=yes,location=no');
		},




	/**
	 * To display the alert message on production screen
	 */
		showAlertOnProduction : function () {
			
   			if(sap.ui.getCore().getModel("oAlert").getProperty("/running")){
				var that = this;
				setTimeout(function(){ that.showAlert(); }, 30000);

			}
			
		},

		/**
   		 * to show the current status of the production and confirmation due alert
   		 */
   		showAlert	: function () {
   			
   				
   				var iAlertFlag = sap.ui.getCore().getModel("oAlert").getProperty("/alertFlag");
   				
   				var oCurrenttime = new Date();
   				var sCurrentDT = CommonUtility.getCurrentDateTime(oCurrenttime);
   				var sPlant = sap.ui.getCore().getModel("session").getProperty("/CA_Plant");
   				var sResource = sap.ui.getCore().getModel("session").getProperty("/CA_Resource");
   				var sWorkstation = sap.ui.getCore().getModel("session").getProperty("/CA_CRDest");
   				
   				var msg1 = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0143");
   				var msg2 = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0144");
   				var msg3 = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0145");
   				var msg4 = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0146");
   				var msg5 = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0147");
   				//parameters to BLS
   				var params = "I_CurrentDT="+sCurrentDT+"&I_Plant="+sPlant+"&I_Resr="+sResource+"&I_Crdest="+sWorkstation+"&I_MSG1="+msg1+"&I_MSG2="+msg2+"&I_MSG3="+msg3+"&I_MSG4="+msg4+"&I_MSG5="+msg5;
   				
   			// check the session is still alive, if not it will throw exception
   				var oModel =models.createNewXMLModel("Session Expired, com.khc.batchhub.utils.UI_utilities.js-->showAlert");
   					oModel.attachRequestCompleted(function(){
   					
   					var oData = oModel.getData()
   					var sResult = $(oData).find("O_Time").text();
						if(sResult)	{
   						var aResult = sResult.split("T");
   						var sState;
   						sap.ui.getCore().getModel("oAlert").setProperty("/message",aResult[0]);
   		   				
   						if(aResult[1]=="A"){
   							sState = "positive";
   						}
   						else	{
   							
   							// to show alternate colors
   							if(iAlertFlag==0)	{
   								iAlertFlag = 1;
   								sState = "negative1";
   								}
   							else	{
   								iAlertFlag=0;
   								sState = "negative0";

   								}
   							
   							}						
   							sap.ui.getCore().getModel("oAlert").setProperty("/alertFlag",iAlertFlag);
   							sap.ui.getCore().getModel("oAlert").setProperty("/state",sState);							
   						}
   					
   				});
   				
   			oModel.loadData("/XMII/Runner?Transaction=NL_ELS_HUB/BLS/BLS_GetNextIntervalConfTime&"+params+"&content-type=text/xml&OutputParameter=O_Time","",false);
   		   				
   			this.showAlertOnProduction();
   			
   		},
   		
		/**
   		 * to open the manual master
   		 */
   		OpenManualMaster:function() {
   			
   			var url = sap.ui.getCore().getModel("session").getProperty("/CA_ManualMasterURL");

   			window.open(url, 'ManualMaster', 'width=1050,height=800,scrollbars=yes,left=10,top=10,resizable=yes,status=yes,location=no');
   		},
   		
   		/**
   		 * to set the long text for the order and operation
   		 */
   		setOrderPahseLongText:function(oView,sId,sLanguage,sOrderID,sPlant,sPhase,sProjectName){
   			

   			var sParams = "Param.1="+sLanguage+"&Param.2="+sOrderID+"&Param.3="+sPhase+"&Param.4="+sPlant;
   			//var sParams = "Param.1="+sLanguage+"&Param.2=000001004506&Param.3=&Param.4=3300";
   			jQuery.ajax({
   				url: "/XMII/Illuminator?QueryTemplate="+sProjectName+"/QueryTemplate/XACQ_GetLongText&"+sParams+"&content-type=text/xml",
   			            type : 'GET',
   				async:false,
   			      	success : function (xmlData) {
   			      		
   			      		var longtext = $(xmlData).find("Row").text();
   			      		
   			      		// Below logic is copied from RepOrderInstructionPopUp.js
   			      		longtext = longtext.replace(/&lt;/gi, "<");
   			      		longtext = longtext.replace(/&gt;/gi, ">");

   			      		var result = longtext.match(/(!@)/g);
   			      		var splt = longtext.split("!@");

   			      		var k=0;
   			      		if(result != null)
   			      		{
   			      			for(var i=0;i<result.length;i++)
   			      			{
   			      				k=longtext.indexOf(result[i], k);
   			      		
   			      				k += result[i].length;

   			      				if(i%2 != 0)
   			      				{
   			      					splt[i] = '<A HREF="'+splt[i]+'" target="_blank"'+'>'+splt[i]+'</A>';
   			      				}
   			      			
   			      				if(i==result.length-1)
   			      				{
   			      				//document.getElementById("instruction").innerHTML = "<b>"+splt.join(" ")+"</b>";
   			      					longtext = "<b>"+splt.join(" ")+"</b>";
   			      					oView.byId(sId).setContent(longtext);
   			      				}
   			      			}
   			      		}
   			      		else
   			      		{
   			      			//document.getElementById("instruction").innerHTML = longtext;
   			      			oView.byId(sId).setContent(longtext);
   			      		}		
   			      	},
   			      	error : function (errorData2) {
   			      		console.log(errorData2);
   			      	}
   				});
   			
   		},
   		
   	/**
   	 * called from the analysis pages, to set the from date to date, based on the frequency selection
   	 */	
   	 setDateFromFrequency: function(oView,selectedRadioBtn,fromTimeID, toTimeID) {
			
			
			var fromTimeValue = "";
			var toTimeValue = "";
			
			var fromDate = new Date();
			var toDate = new Date();
			
			 if (selectedRadioBtn === 1) {
				
				fromDate.setDate(fromDate.getDate() - 1);;
				toDate.setDate(toDate.getDate() - 1);
				
			} else if (selectedRadioBtn === 2) {
				
				fromDate.setDate(fromDate.getDate() - 7);
				
			} else if (selectedRadioBtn === 3) {
				
				fromDate.setMonth(fromDate.getMonth() - 1);
				
			}
			 
			
				var fromDateprt =  CommonUtility.getCurrentDateTime(fromDate).split(" ");
				var toDateprt =  CommonUtility.getCurrentDateTime(toDate).split(" ");
				var fromTimeValue = fromDateprt[0] + " 00:00:00";
				var toTimeValue = toDateprt[0] + " 23:59:59";
			
			oView.byId(fromTimeID).setValue(fromTimeValue);
			oView.byId(toTimeID).setValue(toTimeValue);
		},

   		

/**********************************************************************************************************/
	
/*************************************************************************************************************/	
qualityMenuBar:function(){
	if(sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuPrdViewer"){
		sap.ui.getCore().getModel("oQualityMenuBar").setProperty("/MenuBar", "ProductionViewerQuality");	
	}
	else if(sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuInspector" || sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuSupervisor" || sap.ui.getCore().getModel("role").getProperty("/role") === "RepMainMenuOperator"){
		sap.ui.getCore().getModel("oQualityMenuBar").setProperty("/MenuBar", "CommonQualityMenuBar");	
	}

	/*else if(sap.ui.getCore().getModel("role").getProperty("/role") === "RepMainMenuOperator"){
		sap.ui.getCore().getModel("oQualityMenuBar").setProperty("/MenuBar", "ProductionQuality");	
	}
	else if(sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuSupervisor"){
		sap.ui.getCore().getModel("oQualityMenuBar").setProperty("/MenuBar", "SupervisorQuality");	
	}*/
	else if(sap.ui.getCore().getModel("role").getProperty("/role") === "MainMenuQualityOperator"){
		sap.ui.getCore().getModel("oQualityMenuBar").setProperty("/MenuBar", "QualityOperator");	
	}

},
/**********************************************************************************************************/
	//Disable the datepicker input box
/*************************************************************************************************************/	
DisableDatePickerInput:function(oDatePicker){

		oDatePicker.addEventDelegate({
			onAfterRendering: function(){
		var oDateInner = this.$().find('.sapMInputBaseInner');
				var oID = oDateInner[0].id;
				$('#'+oID).attr("disabled", "disabled"); 
			}},oDatePicker);
},
/*************************************************************************************************************/	
OpenHelpFile:function(menuid)
{ 
	//var menuid = applet.getPropertyValue("MenuTDId");
	var helpfile =  sap.ui.getCore().getModel("session").oData.CA_HelpFileName;

	if(menuid=="id_td_endshift"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Prodnhome";
	}
	else if(menuid=="id_td_startshift"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Startshift";
	}
	else if(menuid=="id_td_startorder"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Prodnschedule";
	}
	else if(menuid=="id_td_downtime"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Linestatus";
	}
	else if(menuid=="id_td_linestatus"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Linestatus";
	}
	else if(menuid=="id_td_endIntv"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Confirmation";
	}
	else if(menuid=="id_td_inspres"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Resultentry";
	}
	else if(menuid=="id_td_qualnot"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Qn";
	}
	else if(menuid=="id_td_spc"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Resultentry";
	}
	else if(menuid=="id_td_scrapnew"){
		var Url = "/XMII/CM/NL_ELS_HUB/Resource/"+helpfile+"#Scrap";
	}


	window.open(Url, 'InspectionPointSPC', 'width=1050,height=800,scrollbars=yes,left=10,top=10,resizable=yes,status=yes,location=no');
	
}

}
   	});   


