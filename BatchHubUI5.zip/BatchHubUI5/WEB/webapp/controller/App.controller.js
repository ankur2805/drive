sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.khc.batchhub.controller.App", {
     onInit : function(){
        },
        
        menuSelected : function (oEvent) {
			/*this.getView().getModel().setDefaultBindingMode("OneWay");*/
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("mainMenu");
			
        }
        
        
      });
    });
  