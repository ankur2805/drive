sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/m/MessageBox", "com/khc/batchhub/utils/UI_utilities",
    "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models"
], function(Controller, Filter, MessageBox,
    UI_utilities, CommonUtility, models) {

    var plant;
    var resource;
    var projectName;
    var userName;
    var crdest;
    var crid;
    var resrtxt;

    var RunningOrderForExec1;
    var BatchPhaseList;

    var selBatchPhaseList;
    var selRowbatchphaseList;

    var selRunningOrderForExec;
    var selRowRunOrderForExec;

    var SetFirstRowFlag;

    var xmiiCommand;
    var oDigitalSignatureModel;
    var that;

    /* Call Parent function from fragment */
    var isNextPhaseW = false,
        issetnextrowW = false,
        ischangeBatchOrdStatW = false;

    /*hidden elements*/
    var hid_phasestatus;
    var hid_SetFirstRowFlag;
    var hid_ordid = "";
    var hid_crid = "";
    var hid_msgid = "",
        txt_RunBatch = "",
        txt_MatNo = "";
    var hid_SetFirstRowFlag, hid_phase, hid_phasetext, hid_opr, hid_endphase, hid_phasestatus, hid_ActBatchSize = "";

    var oBatchExecuteController;
    return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder", {
        onInit: function() {
            oBatchExecuteController = this;
            var oContent = {
                isPhaseLong: false,
                content: "",
            };
            var oContModel = new sap.ui.model.json.JSONModel(oContent);
            sap.ui.getCore().setModel(oContModel, "oPhaseLongText");



            var oData = {
                oFragMentPath: 'BatchInspectionPoint',
                hid_phasestatus: "",
                hid_SetFirstRowFlag: "1",
                hid_ordid: "",
                hid_crid: "",
                hid_msgid: "",
                txt_RunBatch: "",
                txt_MatNo: "",
                hid_phase: "",
                hid_opr: "",
                hid_phasetext: "",
                hid_endphase: "",
                hid_ActBatchSize: "",
                hid_PlannedTime: "",
                hid_UOM: "",
                hid_StartTime: "",
                txt_GoodDesc: "",
                txt_Duration: "",
                txt_Order: "",
                txt_OrdNoStrip: "",
                txt_MatNostrip: "",
                selRowBatchPhaseList: "",
                currentTextKey: "",
                txt_punit: "",
                txt_shift: "",
                shiftname: "",
                teamID: "",
                starttime: "",
                endtime: "",
                shiftid: "",
            };
            var oDestModel = new sap.ui.model.json.JSONModel(oData);
            sap.ui.getCore().setModel(oDestModel, "BatchExecOrderFragment");

            //model For Dynamic Nested Views
            var oData = {
                InspectionPage: false,
                InspectionSubmitPage: false,
                InspectHACCPPage: false,
                InspectSPCChartDashboard: false,
                BatchMaterialWeighing: false,
                BatchMaterialExtraWeigh: false,
                BFMaterialWeighing: false,
                BatchBFMatPreparation: true,
            };
            var oDestModel = new sap.ui.model.json.JSONModel(oData);
            sap.ui.getCore().setModel(oDestModel, "BatchInspectionScreenView");


            var oMessageModel = new sap.ui.model.json.JSONModel();
            var oMsgData = {
                message: "",
                type: "Success",
                showMessage: false
            };
            oMessageModel.setData(oMsgData);
            sap.ui.getCore().setModel(oMessageModel, "oPageMessage");

            this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            this._oRouter.getRoute("BatchExecuteOrder").attachPatternMatched(this._oRoutePatternMatched, this);
        },

        _oRoutePatternMatched: function(oEvent) {

            // Hide the messages and set busy to false
            UI_utilities.batchPageOpened(this, "BatchExecuteOrder");
            UI_utilities.setContainerBusyState(this, true);

            sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", false);


            this.getView().byId("id_btn_start").setEnabled(true)
            this.getView().byId("id_btn_prevOrder").setEnabled(true)
            this.getView().byId("id_btn_nextOrder").setEnabled(true)
            this.getView().byId("id_btn_prevPhase").setEnabled(true)
            this.getView().byId("id_btn_nextPhase").setEnabled(true)
            this.getView().byId("txt_complete").setEnabled(true)

            this.loadData();
            this.getRunnningShift();
            this.getOrderDetails();
            this.setFirstOrder();

            this.getPhaseHiddenGrid();
            this.setFirstRow();
            this.setFlagShiftDetails();
            this.GeneratePUnitMenu();

            this.setEndphase();


            if (!this.DigitalSignaturePopup) {
                this.DigitalSignaturePopup = sap.ui.xmlfragment("com.khc.batchhub.view.Fragments.BatchOEDigitalSignature", this);

            }

            //  this.DigitalSignaturePopup.open();
            this.BatchOEDigitalSignature_buttonDisable();
            this.showHiddenFields();

            this.GetPhaseScreen();
            UI_utilities.setContainerBusyState(this, false);
        },
        menuSelected: function(oEvent) {

            // Navigate the the selected menu page

            var sKey = oEvent.getParameters().key;
            UI_utilities.openMenu(this._oRouter, this, sKey);

        },
        getRunnningShift: function() {
            var dt = new Date();
            var TodayDate = getCurrentDateTime(dt);

            var oModelShift = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchOrderWorkList-->getRunnningShift-->XACQ_GetRunningShift");
            var tparams = "Param.1=" + plant + "&Param.2=" + resource;
            oModelShift.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningShift&" + tparams +
                "&Content-Type=text/json", "", false);
            this.getView().setModel(oModelShift, "oShift");

            if (CommonUtility.getJsonModelRowCount(oModelShift.getData()) != 0) {
                var oModelShiftData = oModelShift.getData().Rowsets.Rowset[0].Row[0]

                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_shift", oModelShiftData.SHIFTNAME)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/shiftname", oModelShiftData.SHIFTNAME)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/teamID", oModelShiftData.TEAMID)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/startTime", oModelShiftData.STARTTIME)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/endtime", oModelShiftData.ENDTIME)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/shiftid", oModelShiftData.SHIFTID)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/startTime", oModelShiftData.STARTTIME)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/startTime", oModelShiftData.STARTTIME)



            }
        },
        loadData: function() {
            plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
            resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
            crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
            projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
            userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
            resrtxt = sap.ui.getCore().getModel("session").oData.CA_ResrText;
            if (sap.ui.getCore().getModel("BatchExecuteOrderParams")) {
                var hid_ordid = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_orderid;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_ordid", hid_ordid)

                var txt_RunBatch = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_batch
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_RunBatch", txt_RunBatch)

            }
        },

        SelectKettle: function(KettleId) {

            //UI_utilities.setContainerBusyState(this,true);
            this.getView().byId("id_btn_start").setEnabled(true)
            this.getView().byId("id_btn_prevOrder").setEnabled(true)
            this.getView().byId("id_btn_nextOrder").setEnabled(true)
            this.getView().byId("id_btn_prevPhase").setEnabled(true)
            this.getView().byId("id_btn_nextPhase").setEnabled(true)
            this.getView().byId("txt_complete").setEnabled(true)

            selBatchPhaseList = '';
            var count = CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("oButton").getData())
            for (var i = 0; i < count; i++) {
                var ObuttonData = sap.ui.getCore().getModel("oButton").getData().Rowsets.Rowset[0].Row[i];
                if (ObuttonData.PRDUNIT == KettleId) {
                    this.getView().byId("buttonList").getItems()[i].addStyleClass("RunningButtonList")
                } else
                    this.getView().byId("buttonList").getItems()[i].removeStyleClass("RunningButtonList")
            }

            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/qs_selprdunit", KettleId);
            sap.ui.getCore().getModel("BatchExecuteOrderParams").setProperty("/qs_selprdunit", KettleId);


            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_SetFirstRowFlag", "1");
  
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_RunBatch", "")
 
            RunningOrderForExec1 = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->SelectKettle-->XACQ_GetRunningOrderForExec");
            var pUnit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;;
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" +
                KettleId;

            RunningOrderForExec1.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrderForExec&" +
                params + "&Content-Type=text/json", "", false);


            this.setFirstOrder()
            this.getPhaseHiddenGrid();
            this.setFirstRow();
            this.GetPhaseScreen();
            if (CommonUtility.getJsonModelRowCount(BatchPhaseList.getData()) != 0) {
                this.getView().byId("id_btn_prevOrder").setEnabled(true)
                this.getView().byId("id_btn_nextOrder").setSelected(true)
                this.getView().byId("id_btn_prevPhase").setSelected(true)
                this.getView().byId("id_btn_nextPhase").setSelected(true)
            } else {
                this.getView().byId("id_btn_prevOrder").setEnabled(false)
                this.getView().byId("id_btn_nextOrder").setSelected(false)
                this.getView().byId("id_btn_prevPhase").setSelected(false)
                this.getView().byId("id_btn_nextPhase").setSelected(false)
            }

            // UI_utilities.setContainerBusyState(this,false);
        },
        getOrderDetails: function() {

            RunningOrderForExec1 = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->getOrderDetails-->XACQ_GetRunningOrderForExec");
            var pUnit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_punit", pUnit);
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" +
                pUnit;

            RunningOrderForExec1.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrderForExec&" +
                params + "&Content-Type=text/json", "", false);

        },
        getPhaseHiddenGrid: function() {


            BatchPhaseList = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->getPhaseHiddenGrid-->XACQ_GetBatchPhaseByOrder");
            var pUnit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;
            var hid_ordid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");
            var runbatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch"); //txt_RunBatch;
            var params = "Param.1=" + runbatch + "&Param.2=" + hid_ordid + "&Param.3=" + pUnit + "&Param.4=" +
                resource + "&Param.5=" + plant;

            BatchPhaseList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetBatchPhaseByOrder&" +
                params + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(BatchPhaseList, " BatchPhaseListData");
            this.setFirstRow();
        },
        setFirstOrder: function() {
            if (CommonUtility.getJsonModelRowCount(RunningOrderForExec1.getData()) > 0) {
                var RowCount = CommonUtility.getJsonModelRowCount(RunningOrderForExec1.getData());
                var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
                var batch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch"); //txt_RunBatch;
                var gridObj = RunningOrderForExec1.getData().Rowsets.Rowset[0].Row;

                if (batch != "" && orderid != "") {
                    for (var i = 0; i < RowCount; i++) {
                        if (gridObj[i].RUNBATCH == batch && gridObj[i].ORDERID == orderid) {
                            gridObj = gridObj[i];
                            selRowRunOrderForExec = i;
                            // selectedRow = i;
                            break;
                        }
                    }
                } else {
                    gridObj = gridObj[0];
                    selRowRunOrderForExec = 0;
                }
                selRunningOrderForExec = gridObj;
                this.getView().byId("txt_GoodDesc").setValue(gridObj.MATTEXT);
                this.getView().byId("txt_Duration").setValue(gridObj.DURATION);
                this.getView().byId("txt_Order").setValue(gridObj.DISPLAYBATCH);
                this.getView().byId("txt_OrdNoStrip").setValue(gridObj.ORDERSTRIP);
                this.getView().byId("txt_MatNostrip").setValue(gridObj.MATNRSTRIP);


                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_GoodDesc", gridObj.MATTEXT);
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_Duration", gridObj.DURATION);
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_Order", gridObj.DISPLAYBATCH);
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_OrdNoStrip", gridObj.ORDERSTRIP);
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_MatNostrip", gridObj.MATNRSTRIP);


                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_crid", gridObj.CRID);
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_msgid", gridObj
                    .MSGID); // used in BatchOEDigitalSignature
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_RunBatch", gridObj.RUNBATCH)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_ordid", gridObj.ORDERID)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_MatNo", gridObj.MATNR)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_ActBatchSize", gridObj.ACTUALBATCHSIZE)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_PlannedTime", gridObj.PLANNEDTIME)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_UOM", gridObj.UOM)
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_StartTime", gridObj.STARTDATE)


            } else {

                this.getView().byId("txt_GoodDesc").setValue("");
                this.getView().byId("txt_Duration").setValue("");
                this.getView().byId("txt_Order").setValue("");
                this.getView().byId("txt_OrdNoStrip").setValue("");
                this.getView().byId("txt_MatNostrip").setValue("");
                this.getView().byId("txt_currentphase").setValue("");
                this.getView().byId("txt_nextphase").setValue("");
                this.getView().byId("txt_prevphase").setValue("");
                this.getView().byId("id_btn_start").setEnabled(false)
                this.getView().byId("id_btn_prevOrder").setEnabled(false)
                this.getView().byId("id_btn_nextOrder").setEnabled(false)
                this.getView().byId("id_btn_prevPhase").setEnabled(false)
                this.getView().byId("id_btn_nextPhase").setEnabled(false)
                this.getView().byId("txt_complete").setEnabled(false)


            }


        },
        setFirstRow: function() {
            var active = 0;
            var selectedRow = 0;
            var currRow = 0;
            if (CommonUtility.getJsonModelRowCount(BatchPhaseList.getData()) > 0) {

                var oBatchPhaseList = BatchPhaseList.getData().Rowsets.Rowset[0].Row;

                for (var i = 0; i < oBatchPhaseList.length; i++) {
                    if (oBatchPhaseList[i].STATUS == 1) {
                        selectedRow = i;
                        active = 1;
                        break;
                    }
                }

                if (active == 0) {
                    for (var j = 0; j < oBatchPhaseList.length; j++) {
                        if (oBatchPhaseList[j].STATUS == 0) {
                            selectedRow = j;
                            break;
                        }
                    }
                }
                selBatchPhaseList = oBatchPhaseList[selectedRow];
                selRowbatchphaseList = selectedRow;
                currRow = selectedRow;
                var nextRow = currRow + 1;

                if (currRow > 0) {
                    var prevRow = currRow - 1;
                    this.getView().byId("txt_prevphase").setValue(oBatchPhaseList[prevRow].PHASE + " " + oBatchPhaseList[prevRow]
                        .PHASETEXT);

                } else {
                    this.getView().byId("txt_prevphase").setValue("");
                }
                var hid_phase = oBatchPhaseList[selectedRow].PHASE;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phase", hid_phase)

                var hid_phasetext = oBatchPhaseList[selectedRow].PHASETEXT;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phasetext", hid_phasetext)

                var hid_opr = oBatchPhaseList[selectedRow].OPR;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_opr", hid_opr)

                var hid_phasestatus = oBatchPhaseList[selectedRow].STATUS;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phasestatus", hid_phasestatus)

                this.getView().byId("txt_currentphase").setValue(oBatchPhaseList[selectedRow].PHASE + " " + oBatchPhaseList[selectedRow]
                    .PHASETEXT);
                if (oBatchPhaseList[nextRow])
                    this.getView().byId("txt_nextphase").setValue(oBatchPhaseList[nextRow].PHASE + " " + oBatchPhaseList[nextRow]
                        .PHASETEXT);

                if (oBatchPhaseList[selectedRow].STATUS == "0") {
                    this.getView().byId("id_btn_start").setEnabled(true)
                } else {
                    this.getView().byId("id_btn_start").setEnabled(false)
                }

                if (oBatchPhaseList[selectedRow].STATUS == "2") {
                    this.getView().byId("txt_complete").setSelected(true)
                    this.getView().byId("txt_complete").setEnabled(true)
                } else {
                    this.getView().byId("txt_complete").setSelected(false)
                    this.getView().byId("txt_complete").setEnabled(true)
                }
            }




            //  this.GetPhaseScreen(); 26
        },
        GetPhaseScreen: function() {


            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/selRowBatchPhaseList", selRowbatchphaseList)


            var txt_Order = this.getView().byId("txt_Order").getValue();
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_Order", txt_Order);

            sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectionPage", false)
            sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectionSubmitPage", false)
            sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectHACCPPage", false)

            var fragmentPath = "BatchOEUnSupported";
            if (selBatchPhaseList != null) {
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/currentTextKey", selBatchPhaseList.TEXTKEY)
                if (selBatchPhaseList.TEXTKEY == "WEIGH") {
                    //document.getElementById("id_hid_weighkey").value = "WEIGH";
                    fragmentPath = "BatchOEMatPreparation";
                } else if (selBatchPhaseList.TEXTKEY == "CWEIGH") {
                    //document.getElementById("id_hid_weighkey").value = "CWEIGH";
                    fragmentPath = "BatchOEMatPreparation";
                } else if (selBatchPhaseList.TEXTKEY == "QACHK" || selBatchPhaseList.TEXTKEY == "QACHKL" || selBatchPhaseList.TEXTKEY ==
                    "QACHKF" || selBatchPhaseList.TEXTKEY == "CCP1" || selBatchPhaseList.TEXTKEY == "CCP2") {
                    fragmentPath = "BatchInspectionPoint";
                } else if (selBatchPhaseList.TEXTKEY == "INSWRK" || selBatchPhaseList.TEXTKEY == "INSWRKF" || selBatchPhaseList.TEXTKEY ==
                    "INSWRKL") {
                    fragmentPath = "BatchOEInstruction";
                } else if (selBatchPhaseList.TEXTKEY == "ADDMANV") {
                    fragmentPath = "BatchOEMatIdentification";
                } else if (selBatchPhaseList.TEXTKEY == "ADDMAN") {
                    fragmentPath = "BatchOEMatTipping";
                } else if (selBatchPhaseList.TEXTKEY == "GRIM") {
                    fragmentPath = "BatchOEDischarge";
                } else if (selBatchPhaseList.TEXTKEY == "TIP-SM" || selBatchPhaseList.TEXTKEY == "TIP-NM" || selBatchPhaseList.TEXTKEY ==
                    "TIP-NC" || selBatchPhaseList.TEXTKEY == "TIP-SC") {
                    fragmentPath = "BatchOETipHub";
                } else if (selBatchPhaseList.TEXTKEY == "WEIGHBF") {
                    fragmentPath = "BatchBFMatPreparation";
                } else {
                    fragmentPath = "BatchOEUnSupported";
                }
            }
            //  fragmentPath = "BatchOETipHub"; //need to remove
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/oFragMentPath", fragmentPath)
            this.fragmentonload(fragmentPath);
        },
        setFlagShiftDetails: function() {


            var TodayDate = CommonUtility.getCurrentDateTime(new Date());

            var APLT_CMD_ShiftDetails = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->setFlagShiftDetails-->XACQ_GetRunningShift");

            var params = "Param.1=" + plant + "&Param.2=" + resource;

            APLT_CMD_ShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningShift&" +
                params + "&Content-Type=text/json", "", false);


            if (CommonUtility.getJsonModelRowCount(APLT_CMD_ShiftDetails.getData()) > 0) {

                var shiftDetails = APLT_CMD_ShiftDetails.getData().Rowsets.Rowset[0].Row[0];

 
                if (shiftDetails.ENDTIME && TodayDate >= shiftDetails.ENDTIME) {
                    var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0073");
                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

                }

            } else {
                var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

            }
        },
        setEndphase: function() {

            var APLT_CMD_GetEndPhase = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->setEndphase-->SQLQ_GetEndPhase");

            var pUnit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;
            var ordid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); // hid_ordid;
            var runbatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch"); //txt_RunBatch;

            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + runbatch + "&Param.4=" + ordid + "&Param.5=" + pUnit;

            APLT_CMD_GetEndPhase.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetEndPhase&" +
                params + "&Content-Type=text/json", "", false);


            if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetEndPhase.getData()) > 0) {

                var getEndPhase = APLT_CMD_GetEndPhase.getData().Rowsets.Rowset[0].Row;

                var hid_endphase = getEndPhase.PHASE;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_endphase", hid_endphase)


            }


        },
        GeneratePUnitMenu: function() {
            
            this.getView().byId("txt_currentphase").addStyleClass("CurrentPhase")
            var count = CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("oButton").getData());
            var KettleId = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;
            for (var i = 0; i < count; i++) {
                var ObuttonData = sap.ui.getCore().getModel("oButton").getData().Rowsets.Rowset[0].Row[i];
                if (ObuttonData.PRDUNIT == KettleId) {
                    this.getView().byId("buttonList").getItems()[i].addStyleClass("RunningButtonList")
                } else
                    this.getView().byId("buttonList").getItems()[i].removeStyleClass("RunningButtonList")
            }
        },
        PrevOrder: function() {
            var totalrow = CommonUtility.getJsonModelRowCount(RunningOrderForExec1.getData());
            var currentRow = selRowRunOrderForExec;
            var prevrow = currentRow - 1;

            if (prevrow >= 0) {
                this.setnextorder(prevrow);
                this.GetPhaseScreen();
            } else {
                var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0008");
                MessageBox.error(sAlertMsg, {
                    title: "Error",
                });
            }

        },
        NextOrder: function() {

            var totalrow = CommonUtility.getJsonModelRowCount(RunningOrderForExec1.getData()) - 1;
            var currentRow = selRowRunOrderForExec;
            var nextrow = currentRow + 1;

            if (nextrow <= totalrow) {
                this.setnextorder(nextrow);
                this.GetPhaseScreen();

            } else {
                var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0009");
                MessageBox.error(sAlertMsg, {
                    title: "Error",
                });
            }


        },
        setnextorder: function(i) {

            var gridObj = RunningOrderForExec1.getData().Rowsets.Rowset[0].Row[i];
            selRunningOrderForExec = gridObj;
            selRowRunOrderForExec = i;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/qs_batch", gridObj.RUNBATCH)

            var hid_ordid = gridObj.ORDERID;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_ordid", hid_ordid)

            this.getView().byId("txt_GoodDesc").setValue(gridObj.MATTEXT);
            this.getView().byId("txt_Duration").setValue(gridObj.DURATION);
            this.getView().byId("txt_Order").setValue(gridObj.DISPLAYBATCH);
            this.getView().byId("txt_OrdNoStrip").setValue(gridObj.ORDERSTRIP);
            this.getView().byId("txt_MatNostrip").setValue(gridObj.MATNRSTRIP);

            var oData = {
                txt_GoodDesc: gridObj.MATTEXT,
                txt_Duration: gridObj.DURATION,
                txt_Order: gridObj.DISPLAYBATCH,
                txt_OrdNoStrip: gridObj.ORDERSTRIP,
                txt_MatNostrip: gridObj.MATNRSTRIP

            };
            var oDestModel = new sap.ui.model.json.JSONModel(oData);
            sap.ui.getCore().setModel(oDestModel, "BatchExecOrderParams");

            var txt_RunBatch = gridObj.RUNBATCH;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_RunBatch", txt_RunBatch)

            var hid_crid = gridObj.CRID;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_crid", hid_crid);
            var txt_MatNo = gridObj.MATNR;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/txt_MatNo", txt_MatNo)

            var hid_ActBatchSize = gridObj.ACTUALBATCHSIZE;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_ActBatchSize", hid_ActBatchSize)

            var hid_msgid = gridObj.MSGID; // used in BatchOEDigitalSignature
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_msgid", hid_msgid);

            var hid_PlannedTime = gridObj.PLANNEDTIME;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_PlannedTime", hid_PlannedTime)

            var hid_StartTime = gridObj.STARTDATE;
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_StartTime", hid_StartTime)


            this.getPhaseHiddenGrid();
            this.setFlagShiftDetails();

        },
        NextPhase: function() {


            var totalrow = CommonUtility.getJsonModelRowCount(BatchPhaseList.getData()) - 1;
            var currentRow = selRowbatchphaseList;
            var nextrow = currentRow + 1;
            var selprdunit = selBatchPhaseList.PRDUNIT;

            if (nextrow <= totalrow) {
                this.setnextrow(nextrow, '1');
                if (isNextPhaseW) {
                    isNextPhaseW = false;
                    ischangeBatchOrdStatW = true;
                    this.changeBatchOrdStat();
                }
            } else {
                this.LastPhaseComplete();
            }
        },

        NextPhaseW: function() {


            var totalrow = CommonUtility.getJsonModelRowCount(BatchPhaseList.getData()) - 1;
            var currentRow = selRowbatchphaseList;
            var nextrow = currentRow + 1;
            var selprdunit = selBatchPhaseList.PRDUNIT;

            if (nextrow <= totalrow) {
                issetnextrowW = true;
                this.setnextrow(nextrow, '1');

                ischangeBatchOrdStatW = true;
                this.changeBatchOrdStat();

                issetnextrowW = false;
                ischangeBatchOrdStatW = false;
                isNextPhaseW = false
            } else {
                this.LastPhaseComplete();
            }
        },
        PrevPhase: function() {
            var totalrow = CommonUtility.getJsonModelRowCount(BatchPhaseList.getData());
            var currentRow = selRowbatchphaseList;
            var prevrow = currentRow - 1;

            if (prevrow >= 0) {
                this.setnextrow(prevrow, '0');
            } else {
                var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0005");
                MessageBox.error(sAlertMsg, {
                    title: "Error",
                });
            }
        },
        setnextrow: function(i, j) {
            var that = oBatchExecuteController;
            var checkbox = that.getView().byId("txt_complete").getSelected();
            var nextFlag = "1";
            var phasestatus = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus"); //hid_phasestatus;
            var completeStatus;
            if (j == 1 && phasestatus != "1" && checkbox) {
                if (phasestatus != "2") {
                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0067");
                    MessageBox.error(sAlertMsg);
                    nextFlag = "0";
                }
            } else if (j == 1 && phasestatus == "1") {
                nextFlag = "0";
                if (checkbox) {
                    completeStatus = that.completePhase();
                    if (completeStatus == "1") {
                        //hid_SetFirstRowFlag = "0";
                        sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_SetFirstRowFlag", "0");

                        that.getView().byId("txt_complete").setSelected(true)
                        that.getView().byId("txt_complete").setEnabled(false)
                        nextFlag = "1";
                    } else
                        nextFlag = "0";
                } else {
                    if (issetnextrowW) {
                        issetnextrowW = false;
                        completeStatus = that.completePhase();
                        if (completeStatus == "1") {
                            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_SetFirstRowFlag", "0");
                        }
                        completeStatus = "1";
                        nextFlag = "1";
                    } else {
                        nextFlag = "0";
                        var that = that;
                        var msg = that.getView().getModel("i18n").getProperty("BATCH_MSG_0010")
                        MessageBox.confirm(
                            msg, {
                                icon: MessageBox.Icon.WARNING,
                                title: "Confirm",
                                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                onClose: function(oAction) {
                                    if (oAction === "OK") {
                                        nextFlag = "1";
                                        completeStatus = that.completePhase();
                                        if (completeStatus == "1") {
                                            //hid_SetFirstRowFlag = "0";
                                            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_SetFirstRowFlag",
                                                "0");
                                            that.setNextRowDetails(i, j, checkbox, nextFlag, phasestatus, completeStatus);

                                        }
                                    } else {
                                        completeStatus = "1";
                                        nextFlag = "1";
                                        that.setNextRowDetails(i, j, checkbox, nextFlag, phasestatus, completeStatus);
                                    }
                                }
                            });
                    }
                }
            }

            that.setNextRowDetails(i, j, checkbox, nextFlag, phasestatus, completeStatus);


        },
        setNextRowDetails: function(i, j, checkbox, nextFlag, phasestatus, completeStatus) {
            var that = oBatchExecuteController;
            if (j == 1 && phasestatus == "1" && completeStatus == "1") {
                that.getPhaseHiddenGrid();

                var gridObj = BatchPhaseList.getData().Rowsets.Rowset[0].Row[i];
                selBatchPhaseList = gridObj;
                selRowbatchphaseList = i;
                if (i > 0) {
                    var prebatchphaseList = BatchPhaseList.getData().Rowsets.Rowset[0].Row[i - 1];
                    that.getView().byId("txt_prevphase").setValue(prebatchphaseList.PHASE + " " + prebatchphaseList.PHASETEXT);
                } else
                    that.getView().byId("txt_prevphase").setValue("");

                that.getView().byId("txt_currentphase").setValue(selBatchPhaseList.PHASE + " " + selBatchPhaseList.PHASETEXT);
                var totalrow = CommonUtility.getJsonModelRowCount(BatchPhaseList.getData()) - 1;
                if (i < totalrow) {
                    var nextbatchphaseList = BatchPhaseList.getData().Rowsets.Rowset[0].Row[i + 1];
                    that.getView().byId("txt_nextphase").setValue(nextbatchphaseList.PHASE + " " + nextbatchphaseList.PHASETEXT);
                } else
                    that.getView().byId("txt_nextphase").setValue("");
                var hid_phase = selBatchPhaseList.PHASE;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phase", hid_phase)

                var hid_phasetext = selBatchPhaseList.PHASETEXT;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phasetext", hid_phasetext)

                var hid_opr = selBatchPhaseList.OPR;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_opr", hid_opr)

                var hid_phasestatus = selBatchPhaseList.STATUS;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phasestatus", hid_phasestatus);
                that.GetPhaseScreen();

                if (selBatchPhaseList.STATUS == "0") {
                    that.getView().byId("id_btn_start").setEnabled(true)
                } else {
                    that.getView().byId("id_btn_start").setEnabled(false)
                }

                if (selBatchPhaseList.STATUS == "2") {
                    that.getView().byId("txt_complete").setSelected(true)
                    that.getView().byId("txt_complete").setEnabled(true)
                } else {
                    that.getView().byId("txt_complete").setSelected(false)
                    that.getView().byId("txt_complete").setEnabled(true)
                }
            } else if (nextFlag == "1") {

                that.getPhaseHiddenGrid();

                selBatchPhaseList = BatchPhaseList.getData().Rowsets.Rowset[0].Row[i];
                selRowbatchphaseList = i;
                var totalrow = CommonUtility.getJsonModelRowCount(BatchPhaseList.getData()) - 1;

                if (i > 0) {
                    var prebatchphaseList = BatchPhaseList.getData().Rowsets.Rowset[0].Row[i - 1];
                    that.getView().byId("txt_prevphase").setValue(prebatchphaseList.PHASE + " " + prebatchphaseList.PHASETEXT);
                } else
                    that.getView().byId("txt_prevphase").setValue("");
                that.getView().byId("txt_currentphase").setValue(selBatchPhaseList.PHASE + " " + selBatchPhaseList.PHASETEXT);
                if (i < totalrow) {
                    var nextbatchphaseList = BatchPhaseList.getData().Rowsets.Rowset[0].Row[i + 1];
                    that.getView().byId("txt_nextphase").setValue(nextbatchphaseList.PHASE + " " + nextbatchphaseList.PHASETEXT);
                } else
                    that.getView().byId("txt_nextphase").setValue("");
                var hid_phase = selBatchPhaseList.PHASE;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phase", hid_phase)

                var hid_phasetext = selBatchPhaseList.PHASETEXT;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phasetext", hid_phasetext)

                var hid_opr = selBatchPhaseList.OPR;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_opr", hid_opr)

                var hid_phasestatus = selBatchPhaseList.STATUS;
                sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phasestatus", hid_phasestatus);

                that.GetPhaseScreen();

                if (selBatchPhaseList.STATUS == "0") {
                    that.getView().byId("id_btn_start").setEnabled(true)
                } else {

                    that.getView().byId("id_btn_start").setEnabled(false)
                }

                if (selBatchPhaseList.STATUS == "2") {
                    that.getView().byId("txt_complete").setSelected(true)
                    that.getView().byId("txt_complete").setEnabled(true)
                } else {
                    that.getView().byId("txt_complete").setSelected(false)
                    that.getView().byId("txt_complete").setEnabled(true)
                }
            }

            var hid_phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //
            var hid_endphase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_endphase"); //

            if (hid_endphase == hid_phase) {
                var btnText = sap.ui.getCore().getModel("i18n").getProperty("BATCH_BTN_0039");
                that.getView().byId("id_btn_nextPhase").setText(btnText)
                //  document.getElementById("id_btn_nextPhase").value = document.getElementById("id_btn_complete").innerHTML;
            } else if (hid_endphase != hid_phase) {
                var btnText = sap.ui.getCore().getModel("i18n").getProperty("BATCH_BTN_0049");
                that.getView().byId("id_btn_nextPhase").setText(btnText)
                //  document.getElementById("id_btn_nextPhase").value = document.getElementById("id_btn_nxtphase").innerHTML;
            }


            that.setFlagShiftDetails();
        },
        LastPhaseComplete: function() {
            var that = oBatchExecuteController;
            var checkbox = that.getView().byId("txt_complete").getSelected();
            var nextFlag = "1";
            var phasestatus = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus"); //hid_phasestatus;
            var completeStatus;

            if (phasestatus != "1" && checkbox) {
                if (phasestatus != "2") {
                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0067");
                    MessageBox.error(sAlertMsg);
                    nextFlag = "0";
                }
            } else if (phasestatus == "1") {
                if (checkbox) {
                    completeStatus = that.completePhase();
                    if (completeStatus == "1") {
                        sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_SetFirstRowFlag", "0");

                        //hid_SetFirstRowFlag = "0";

                        that.getView().byId("txt_complete").setSelected(true)
                        that.getView().byId("txt_complete").setEnabled(false)

                        that.changeBatchOrdStat();

                        UI_utilities.setContainerBusyState(that, true);
                        setTimeout(function() {
                            that._oRouter.navTo("BatchOrderWorkList");
                        }, 500);
                    }
                } else if (!(checkbox)) {
                    completeStatus = that.completePhase();
                    if (completeStatus == "1") {
                        // hid_SetFirstRowFlag = "0";
                        sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_SetFirstRowFlag", "0");


                        that.getView().byId("txt_complete").setSelected(true)
                        that.getView().byId("txt_complete").setEnabled(false)

                        that.changeBatchOrdStat();

                        UI_utilities.setContainerBusyState(that, true);
                        setTimeout(function() {
                            that._oRouter.navTo("BatchOrderWorkList");
                        }, 500);
                    }
                }
            } else {
                var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0067");
                MessageBox.error(sAlertMsg);
            }

        },
        completePhase: function() {
            var checkActionFlag = "0";
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
            var prdunit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;

            var OrdBatch = this.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];

            var currentDT = CommonUtility.getCurrentDateTime(new Date());

            var js_TextKey = selBatchPhaseList.TEXTKEY;

            if (js_TextKey == "WEIGH" || js_TextKey == "CWEIGH") {

                var APLT_CMD_GetActionFlag = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchExecuteOrder-->completePhase-->SQLQ_GetBatchPhaseActionFlag");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + orderid + "&Param.5=" +
                    phase + "&Param.6=" + Batch;

                APLT_CMD_GetActionFlag.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/SQLQ_GetBatchPhaseActionFlag&" +
                    params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetActionFlag.getData()) > 0) {
                    var oData = APLT_CMD_GetActionFlag.getData().Rowsets.Rowset[0].Row[0];

                    var actionFlag = oData.ACTIONFLAG;
                    if (actionFlag == "1") {
                        checkActionFlag = "1";
                    } else {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0069");
                        MessageBox.error(sAlertMsg);
                    }
                }




            } else if (js_TextKey == "GRIM") {

                var APLT_CMD_GetActionFlag = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchExecuteOrder-->completePhase-->SQLQ_GetBatchPhaseActionFlag");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + orderid + "&Param.5=" +
                    phase + "&Param.6=" + Batch;

                APLT_CMD_GetActionFlag.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/SQLQ_GetBatchPhaseActionFlag&" +
                    params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetActionFlag.getData()) > 0) {
                    var oData = APLT_CMD_GetActionFlag.getData().Rowsets.Rowset[0].Row[0];

                    var actionFlag = oData.ACTIONFLAG;
                    if (actionFlag == "1") {
                        checkActionFlag = "1";
                    } else {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0070");
                        MessageBox.error(sAlertMsg);
                    }
                }
            } else if (js_TextKey == "ADDMAN" || js_TextKey == "ADDMANV") {

                var APLT_CMD_GetActionFlag = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchExecuteOrder-->completePhase-->SQLQ_GetBatchPhaseActionFlag");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + orderid + "&Param.5=" +
                    phase + "&Param.6=" + Batch;

                APLT_CMD_GetActionFlag.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/SQLQ_GetBatchPhaseActionFlag&" +
                    params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetActionFlag.getData()) > 0) {
                    var oData = APLT_CMD_GetActionFlag.getData().Rowsets.Rowset[0].Row[0];

                    var actionFlag = oData.ACTIONFLAG;
                    if (actionFlag == "1") {
                        checkActionFlag = "1";
                    } else {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0098");
                        MessageBox.error(sAlertMsg);
                    }
                }
            } else {
                checkActionFlag = "1";
            }



            if (checkActionFlag == "1") {

                var APLT_CMD_EndPhase = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchExecuteOrder-->completePhase-->XACQ_EndPhase");
                var params = "Param.1=" + currentDT + "&Param.2=" + "1" + "&Param.3=" + plant + "&Param.4=" + resource +
                    "&Param.5=" + orderid + "&Param.6=" + Batch + "&Param.7=" + phase + "&Param.8=" + prdunit;

                APLT_CMD_EndPhase.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_EndPhase&" +
                    params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(APLT_CMD_EndPhase.getData()) > 0) {
                    var oData = APLT_CMD_EndPhase.getData().Rowsets.Rowset[0].Row[0];

                    var message = oData.O_Message;
                    if (message == "S") {
                        this.getView().byId("id_btn_start").setEnabled(false)
                        return 1;
                        this.PrintLabel();

                        if (js_TextKey == "CWEIGH") {
                            var APLT_CMD_EndPhaseCWeigh = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchExecuteOrder-->completePhase-->XACQ_EndPhaseCWeigh");
                            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + phase +
                                "&Param.5=" + currentDT;

                            APLT_CMD_EndPhaseCWeigh.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_EndPhaseCWeigh&" +
                                params + "&Content-Type=text/json", "", false);

                        }
                    } else if (message == "E") {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0068");
                        MessageBox.error(sAlertMsg);
                        return 0;
                    }
                }

            } else {
                return 0;
            }
        },
        changeBatchOrdStat: function() {
            var that = oBatchExecuteController;
            var batch = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_batch;
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); // hid_ordid;
            var crid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_crid"); //hid_crid;

            var totalrow = CommonUtility.getJsonModelRowCount(BatchPhaseList.getData())
            var flag = 0;
            var hid_phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");
            for (var i = 0; i < totalrow; i++) {
                var ogridObj = BatchPhaseList.getData().Rowsets.Rowset[0].Row[i];
                var selstatus = ogridObj.STATUS;
                if (selstatus == 1 || selstatus == 0) {
                    if (ischangeBatchOrdStatW) {
                        flag = 1;
                        break;
                    } else {
                        if (ogridObj.PHASE != hid_phase) {
                            flag = 1;
                            break;
                        }
                    }
                }
            }

            if (flag == 0) {
                var APLT_CMD_CompleteOrder = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchExecuteOrder-->changeBatchOrdStat-->XACQ_CompleteOrder");
                var params = "Param.1=" + crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + crdest +
                    "&Param.5=" + orderid + "&Param.6=" + batch + "&Param.7=" + userName;

                APLT_CMD_CompleteOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CompleteOrder&" +
                    params + "&Content-Type=text/json", "", false);

                if (ischangeBatchOrdStatW) {
                    ischangeBatchOrdStatW = false;

                    UI_utilities.setContainerBusyState(that, true);
                    setTimeout(function() {
                        that._oRouter.navTo("BatchOrderWorkList");
                    }, 500);
                }
            }

        },
        start: function() {
            var that = oBatchExecuteController;
            that.getView().byId("txt_complete").setSelected(false)
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");

            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");
            var prdunit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;

            var oper = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_opr");

            var OrdBatch = that.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
            var dt = new Date();
            var currentDT = CommonUtility.getCurrentDateTime(new Date());
            var crid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_crid"); //hid_crid;


            var APLT_CMD_StartButton = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->start-->XACQ_StartPhase");
            var params = "Param.1=" + currentDT + "&Param.2=" + "1" + "&Param.3=" + plant + "&Param.4=" + resource +
                "&Param.5=" + orderid + "&Param.6=" + Batch + "&Param.7=" + phase + "&Param.8=" + prdunit + "&Param.9=" + oper +
                "&Param.10=" + crid + "&Param.11=" + userName;

            APLT_CMD_StartButton.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_StartPhase&" +
                params + "&Content-Type=text/json", "", false);

            if (CommonUtility.getJsonModelRowCount(APLT_CMD_StartButton.getData()) > 0) {
                var oData = APLT_CMD_StartButton.getData().Rowsets.Rowset[0].Row[0];

                var type = oData.Type;


                if (type == "S") {
                    that.getView().byId("id_btn_start").setEnabled(false)
                    hid_phasestatus = "1";
                    sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_phasestatus", "1")
                    var currentTextKey = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/currentTextKey")

                    if (currentTextKey == "WEIGH" || currentTextKey == "CWEIGH") {
                        
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatPreparation").buttonDisable();

                        var APLT_GRI_MatPrepList = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchExecuteOrder-->start-->XACQ_GetMatPrepListByPhase");
                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid +
                            "&Param.5=" + Batch;

                        APLT_GRI_MatPrepList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetMatPrepListByPhase&" +
                            params + "&Content-Type=text/json", "", false);
                        if (CommonUtility.getJsonModelRowCount(APLT_GRI_MatPrepList.getData()) > 0) {
                            var oData = APLT_GRI_MatPrepList.getData().Rowsets.Rowset[0].Row[0];

                            if (oData.BOM == "") {
                                myframe.document.getElementById("id_btn_confirm").disabled = false;
                            }
                        }

                    } else if (currentTextKey == "QACHK" || currentTextKey == "QACHKF" || currentTextKey == "QACHKL" ||
                        currentTextKey == "CCP1" || currentTextKey == "CCP2") {
                         
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectionPoint").buttonDisable();
                    } else if (currentTextKey == "ADDMANV") {
                         
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatIdentification")
                            .BatchOEMatButtonDisable();

                    } else if (currentTextKey == "ADDMAN") { 
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatTipping").BatchOEEbuttonDisable();

                    } else if (currentTextKey == "GRIM") { 
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEDischarge").BatchOEDischargebuttonDisable();
                    } else if (currentTextKey == "TIP-SM" || currentTextKey == "TIP-NM" || currentTextKey ==
                        "TIP-NC" || currentTextKey == "TIP-SC") {
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOETipHub").buttonDisable();
                    } else if (currentTextKey == "WEIGHBF") {
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchBFMatPreparation").buttonDisable();
                    }
                  

                } else if (type == "E") {
                    var message = oData.Message;
                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0116");
                    MessageBox.error(sAlertMsg + " " + message);
                }
            }
        },
        Restart: function() {
            var checkbox = this.getView().byId("txt_complete").getSelected();
            var phasestatus = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus"); //hid_phasestatus;

            if (phasestatus == 2) {
                if (checkbox) {} else {
                    var that = this;
                    var msg = this.getView().getModel("i18n").getProperty("BATCH_MSG_0066")
                    MessageBox.confirm(
                        msg, {
                            icon: MessageBox.Icon.WARNING,
                            title: "Confirm",
                            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                            onClose: function(oAction) {
                                if (oAction === "OK") {
                                    that.start();
                                } else {
                                    that.getView().byId("txt_complete").setSelected(true)
                                }
                            }
                        });


                }
            }
        },
        PrintLabel: function() {

        },

        /*Fragment - BatchInspection - SkipPHase () - logic added here*/

        skipphase: function() {
            var that = oBatchExecuteController;
            this.start();
            that.getView().byId("txt_complete").setSelected(true);
            this.NextPhase();
        },
        /*Fragment - BatchInspection  End*/

        /*Fragment On load calling method*/
        fragmentonload: function(fragmentPath) {
            sap.ui.getCore().getModel("oPhaseLongText").setProperty("/isPhaseLong", false)

            if (fragmentPath == "BatchOEMatPreparation") {
                // this.onLoadBatchOEMatPreparaion();
                sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatPreparation").onLoadBatchOEMatPreparation();

            } else if (fragmentPath == "BatchInspectionPoint") {
                //  this.onLoadBatchInspectionPoint();
                sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectionPoint").onLoadBatchInspectionPoint();

            } else if (fragmentPath == "BatchOEInstruction") {
                this.onLoadBatchOEInstruction();
            } else if (fragmentPath == "BatchOEMatIdentification") {
                //this.onLoadBatchOEMatIdentification();
                sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatIdentification")
                    .onLoadBatchOEMatIdentification();
            } else if (fragmentPath == "BatchOEMatTipping") {
                //       this.onLoadBatchOEMatTipping();
                sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatTipping").onLoadBatchOEMatTipping();
            } else if (fragmentPath == "BatchOEDischarge") {
                //  this.onLoadBatchOEDischarget();
                sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEDischarge").onLoadBatchOEDischarge();
            } else if (fragmentPath == "BatchOEDigitalSignature") {

            } else if (fragmentPath == "BatchOETipHub") {
                //  this.onLoadBatchOETipHub();
                sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOETipHub").onLoadBatchOETipHub();
            } else if (fragmentPath == "BatchBFMatPreparation") {
                sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchBFMatPreparation").onLoadBatchBFMatPreparation();
            }


        },
        /* End PhaseLongetext */

        setPhaseLongText: function(sLanguage, sOrderID, sPlant, sPhase, sProjectName) {
            sap.ui.getCore().getModel("oPhaseLongText").setProperty("/isPhaseLong", true)


            var sParams = "Param.1=" + sLanguage + "&Param.2=" + sOrderID + "&Param.3=" + sPhase + "&Param.4=" + sPlant;
            jQuery.ajax({
                url: "/XMII/Illuminator?QueryTemplate=" + sProjectName + "/QueryTemplate/XACQ_GetLongText&" + sParams +
                    "&content-type=text/xml",
                type: 'GET',
                async: false,
                success: function(xmlData) {

                    var longtext = $(xmlData).find("Row").text();

                    // Below logic is copied from RepOrderInstructionPopUp.js
                    longtext = longtext.replace(/&lt;/gi, "<");
                    longtext = longtext.replace(/&gt;/gi, ">");

                    var result = longtext.match(/(!@)/g);
                    var splt = longtext.split("!@");

                    var k = 0;
                    if (result != null) {
                        for (var i = 0; i < result.length; i++) {
                            k = longtext.indexOf(result[i], k);

                            k += result[i].length;

                            if (i % 2 != 0) {
                                splt[i] = '<A HREF="' + splt[i] + '" target="_blank"' + '>' + splt[i] + '</A>';
                            }

                            if (i == result.length - 1) {
                                //document.getElementById("instruction").innerHTML = "<b>"+splt.join(" ")+"</b>";
                                longtext = "<b>" + splt.join(" ") + "</b>";
                                //oView.byId(sId).setContent(longtext);
                                sap.ui.getCore().getModel("oPhaseLongText").setProperty("/content", longtext)


                            }
                        }
                    } else {
                        //document.getElementById("instruction").innerHTML = longtext;
                        //oView.byId(sId).setContent(longtext);
                        sap.ui.getCore().getModel("oPhaseLongText").setProperty("/content", longtext)


                    }
                },
                error: function(errorData2) {
                    console.log(errorData2);
                }
            });

        },
        /* Add PhaseLongetext */

        /*Fragment On load calling method End*/
        /*Fragment - BatchOEMatIdentification Start*/
        onLoadBatchOEMatIdentification: function() {
            this.GetMatIdenList();
        },
        GetMatIdenList: function() {
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
            var OrdBatch = this.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];

            var oModelPhase = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->GetMatIdenList-->XACQ_GetMatIdenListByPhase");
            var sparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid + "&Param.5=" + Batch;
            oModelPhase.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMatIdenListByPhase&" + sparams +
                "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(oModelPhase, "oPhase");
        },

        //*************************** Selection event for table**************************//
        getContDetails: function() {

            var aSelectedRowPath = this.getView().byId("MatIdenList_tbl_id").getSelectedContextPaths();
            var oExecutionTable = sap.ui.getCore().getModel("oModelPhase");
            if (aSelectedRowPath.length > 0) {
                let sPath = aSelectedRowPath[0];
                this.getView().byId("txt_id_Component").setValue(oExecutionTable.getProperty(sPath + '/BOMMOD'));
                this.getView().byId("txt_id_Description").setValue(oExecutionTable.getProperty(sPath + '/BOMTEXT'));
                this.getView().byId("txt_id_Quantity").setValue(oExecutionTable.getProperty(sPath + '/BOMQT'));
                this.getView().byId("txt_id_UOM").setValue(oExecutionTable.getProperty(sPath + '/BOMUOM'));
                this.getView().byId("txt_id_Batch").setValue(oExecutionTable.getProperty(sPath + '/BATCHID'));

            }
        },

        //*********** On Click event of Verify Button - Check the container entered for the material and verifiesit with the actual coantiner for the material *******// 

        identifyMaterial: function() {

            var RowNo = this.getView().byId("MatIdenList_tbl_id").getSelectedContextPaths().length;

            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
            var OrdBatch = this.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
            var connum = this.getView().byId("txt_id_Container").getValue();
            var directFlag = "";

            if (RowNo != 0) {
                let sPath = this.getView().byId("MatIdenList_tbl_id").getSelectedContextPaths()[0];
                var oExecutionTable = sap.ui.getCore().getModel("oModelPhase");
                directFlag = oExecutionTable.getProperty(sPath + '/DIRECTISSUE');




                if (connum == "") {
                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0064 "));
                } else {
                    var oModelCheckContainer = models.createNewJSONModel(
                        "com.khc.batchhub.controller.ReprintLabel-->identifyMaterial-->SQLQ_CheckContainerByBatch");
                    var cparams = "Param.1=" + plant + "&Param.2=" + orderid + "&Param.3=" + Batch + "&Param.4=" + connum;
                    oModelCheckContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/SQLQ_CheckContainerByBatch&" + cparams + "&Content-Type=text/json", "", false);



                    if (CommonUtility.getJsonModelRowCount(oModelCheckContainer.getData()) == 0) {

                        if (directFlag == "Y") {


                            var bom = oExecutionTable.getProperty(sPath + '/BOM');
                            var bomqty = oExecutionTable.getProperty(sPath + '/BOMQTY');
                            var uom = oExecutionTable.getProperty(sPath + '/UOM');


                            var oModelDirectMaterial = models.createNewJSONModel(
                                "com.khc.batchhub.controller.ReprintLabel-->identifyMaterial-->XACQ_VerifyDirectMaterial");
                            var Mparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + Batch +
                                "&Param.5=" + connum + "&Param.6=" + bom + "&Param.7=" + bomqty + "&Param.8=" + uom + "&Param.9=" + connum;
                            oModelDirectMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_VerifyDirectMaterial&" + Mparams + "&Content-Type=text/json", "", false);

                            //alert(document.APLT_CMD_VerifyDirectMaterial.getFirstValue('O_Return'));
                            if (CommonUtility.getJsonModelRowCount(oModelDirectMaterial.getData()) != 0) {
                                MessageBox.alert(oModelDirectMaterial.getData().Rowsets.Rowset[0].Row[0].O_Return)
                            }

                            this.getView().byId("txt_id_Container").setValue("");
                        } else {
                            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065 "));
                        }
                    } else {

                        var oModelVerifyMaterial = models.createNewJSONModel(
                            "com.khc.batchhub.controller.ReprintLabel-->identifyMaterial-->XACQ_VerifyMaterial");
                        var Vparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + Batch +
                            "&Param.5=" + connum;
                        oModelVerifyMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_VerifyMaterial&" + Vparams + "&Content-Type=text/json", "", false);
                        this.getView().setModel(oModelVerifyMaterial, "oVerifyMaterial");

                        this.getView().byId("txt_id_Container").setValue("");
                    }
                }
            }
            this.GetMatIdenList();
        },
        buttonDisable: function() {
            var hid_phasestatus = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
            if (hid_phasestatus == "1") {
                this.getView().byId("id_btn_viewinstruct").setEnabled(true)
                this.getView().byId("id_btn_verify").setEnabled(true)
            } else {
                this.getView().byId("id_btn_viewinstruct").setEnabled(false)
                this.getView().byId("id_btn_verify").setEnabled(false)
                this.getView().byId("id_btn_verify").setEnabled(false)
            }

        },
        CheckGoToTip: function() {
            var oTable = sap.ui.getCore().getModel("oPhase").getData()
            var tablerowcount = CommonUtility.getJsonModelRowCount(oTable)
            var hid_phasestatus = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
            if (tablerowcount != 0) {
                if (hid_phasestatus == "1") {
                    for (var i = 0; i < tablerowcount; i++) {
                        var valflag = oTable.Rowsets.Rowset[0].Row[i].VALFLAG
                        if (valflag != 1) {
                            this.getView().byId("id_btn_verify").setEnabled(true)
                            this.getView().byId("id_btn_test_tip").setEnabled(false)
                            break;
                        } else {
                            this.getView().byId("id_btn_verify").setEnabled(false)
                            this.getView().byId("id_btn_test_tip").setEnabled(true)
                        }
                    }
                }
            }
        },


        /*Fragment - BatchOEMatIdentification  End*/
 
        /*Fragment - BatchOEDigitalSignature  Start*/


        //*************** Populates the Signature Details for the phase *****************//

        GetSignDetails: function() {

            //var orderid = parent.document.getElementById("id_hid_ordid").value;
            //var phase = parent.document.getElementById("id_hid_phase").value;
            //var OrdBatch = parent.document.getElementById("txt_Order").value;

            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
            var OrdBatch = this.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];

            var oModelSignatureDetails = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->GetSignDetails-->SQLQ_GetSignatureDetails");
            var sparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + orderid + "&Param.5=" + phase +
                "&Param.6=" + Batch;
            oModelSignatureDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetSignatureDetails&" +
                sparams + "&Content-Type=text/json", "", false);
            sap.ui.getCore().getModel(oModelSignatureDetails, "oSignatureDetails");



            if (CommonUtility.getJsonModelRowCount(oModelSignatureDetails.getData()) != 0) {
                var odatasigndetails = oModelSignatureDetails.getData().Rowsets.Rowset[0].Row[0]
                this.getView().byId("txt_reason").setValue(odatasigndetails.REASON1);
                this.getView().byId("txt_timeStamp").setValue(odatasigndetails.SIG1DATE);
                this.getView().byId("txt_timeStamp2").setValue(odatasigndetails.SIG2DATE);

                this.getView().byId("id_btn_DigiSign").setEnabled(false)
            }
        },

        //*************** Populates the Phase intsruction *****************//

        SetInstruction: function() {

            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
            var id_hid_crid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_crid"); //hid_crid;
            var id_hid_msgid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_msgid"); //hid_msgid;
            var oModelLongText = models.createNewJSONModel(
                "com.khc.batchhub.controller.BatchExecuteOrder-->SetInstruction-->XACQ_GetPhaseLongText");
            var lparams = "Param.1=" + id_hid_crid + "&Param.2=" + id_hid_msgid + "&Param.3=" + orderid + "&Param.4=" + phase;
            oModelLongText.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetPhaseLongText&" + lparams +
                "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(oModelLongText, "oLongText");

            if (CommonUtility.getJsonModelRowCount(oModelLongText.getData()) != 0) {

                var oLongText = oModelLongText.getData().Rowsets.Rowset[0].Row[0];
                this.getView().byId("id_ta_Notes").setValue(oLongText.O_PhaseLongText);
                var fulltext = oLongText.O_PhaseLongText;

                var result = fulltext.match(/(!@)/g);
                var splt = fulltext.split("!@");

                var k = 0;
                if (result != null) {
                    for (var i = 0; i < result.length; i++) {
                        k = fulltext.indexOf(result[i], k);

                        k += result[i].length;

                        if (i % 2 != 0) {
                            splt[i] = '<A HREF="' + splt[i] + '" target="_blank"' + '>' + splt[i] + '</A>';
                        }

                        if (i == result.length - 1) {
                            fulltext = "<b>" + splt.join(" ") + "</b>";
                        }
                    }
                } else {
                    fulltext = oLongText.O_PhaseLongText;
                }

                if (fulltext != "") {
                    var ReasonSignEnd = fulltext.indexOf(" ");
                    this.getView().byId("txt_reason").setValue(fulltext.substr(0, ReasonSignEnd));
                    this.getView().byId("id_ta_Notes").setValue(fulltext.substr(ReasonSignEnd));
                }
            }
        },



        showHiddenFields: function() {

            if (selBatchPhaseList.TEXTKEY == "SIG01" || selBatchPhaseList.TEXTKEY == "SIG02") {
                this.getView().byId("txt_id_password").setVisible(false);
                this.getView().byId("txt_id_password2").setVisible(false);
                this.getView().byId("txt_id_userid").setVisible(true);
                this.getView().byId("txt_id_reasnsig").setVisible(true);
                this.getView().byId("txt_id_time").setVisible(true);
                this.getView().byId("txt_id_userid1").setVisible(false);
                this.getView().byId("txt_id_reasnsig1").setVisible(false);
                this.getView().byId("txt_id_time1").setVisible(false);

            } else if (selBatchPhaseList.TEXTKEY == "SIG03") {
                this.getView().byId("txt_password").setVisible(false);
                this.getView().byId("txt_password2").setVisible(false);
                this.getView().byId("txt_userid").setVisible(true);
                this.getView().byId("txt_reasnsig").setVisible(true);
                this.getView().byId("txt_time").setVisible(true);
                this.getView().byId("txt_userid1").setVisible(true);
                this.getView().byId("txt_reasnsig1").setVisible(true);
                this.getView().byId("txt_time1").setVisible(true);
            }
        },




        //*************** Disables the Button till the phase is started *****************//

        BatchOEDigitalSignature_buttonDisable: function() {
            var hid_phasestatus = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
            if (hid_phasestatus == "1") {
                this.getView().byId("id_btn_DigiSign").setEnabled(true);

            } else {
                this.getView().byId("id_btn_DigiSign").setEnabled(false);
            }
        },



        //***************** On Click event of Record Signature button - Send SIGN Process message to SAP *******************//    

        VerifyDigiSign: function() {
            that = this;
            var dt = new Date();
            var currentDT = getCurrentDateTime(dt);
            var textkey = BatchPhaseList.getData().Rowsets.Rowset[0].Row[0].TEXTKEY;
            var OrdBatch = this.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
            var hid_ordid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");
            var hid_crid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_crid");

            var hid_phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");
            var hid_opr = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_opr");

            xmiiCommand = new com.sap.xmii.chart.hchart.i5Command(projectName + "/QueryTemplate/XACQ_DigitalSignature", projectName +
                "/DisplayTemplate/CMD_VerifyDigitalSignature", this.VerifyDigiSignCommand);

            xmiiCommand.getQueryObject().setParameter("Param.1", plant);
            xmiiCommand.getQueryObject().setParameter("Param.2", resource);
            xmiiCommand.getQueryObject().setParameter("Param.3", hid_crid);
            xmiiCommand.getQueryObject().setParameter("Param.4", hid_ordid);
            xmiiCommand.getQueryObject().setParameter("Param.5", hid_opr);
            xmiiCommand.getQueryObject().setParameter("Param.6", hid_phase);
            xmiiCommand.getQueryObject().setParameter("Param.7", "Digital Signature");
            xmiiCommand.getQueryObject().setParameter("Param.8", textkey);
            xmiiCommand.getQueryObject().setParameter("Param.9", userName);
            xmiiCommand.getQueryObject().setParameter("Param.10", this.getView().byId("txt_user").getValue());
            xmiiCommand.getQueryObject().setParameter("Param.11", "");
            xmiiCommand.getQueryObject().setParameter("Param.12", crdest);
            xmiiCommand.getQueryObject().setParameter("Param.13", Batch);
            xmiiCommand.getQueryObject().setParameter("Param.14", this.getView().byId("txt_reason").getValue());
            xmiiCommand.getQueryObject().setParameter("Param.15", this.getView().byId("txt_reason2").getValue());
            xmiiCommand.getQueryObject().setParameter("Param.16", currentDT);
            xmiiCommand.getQueryObject().setParameter("Param.17", currentDT);

            if (textkey == "SIG03") {
                if (this.getView().byId("txt_user").getValue() != "" && this.getView().byId("txt_user2").getValue() != "") {

                    xmiiCommand.getQueryObject().setParameter("Param.11", this.getView().byId("txt_user2").getValue());

                    xmiiCommand.setCommandAudit(true)
                    var role = sap.ui.getCore().getModel("session").getProperty("/CA_SignSecondLevelRole");
                    xmiiCommand.getCommandObject().setCommandRole2(role);

                    if (xmiiCommand.getCommandAudit()) {
                        xmiiCommand.executeCommand();
                        xmiiCommand.registerCommandCompletionEventHandler(this.onExecuteDigiSignCommand);
                    }

                } else {
                    alert("Enter name in the User Field");
                }
            } else if (textkey == "SIG01") {
                if (this.getView().byId("txt_user").getValue() != "") {

                    xmiiCommand.setCommandAudit(true)
                    if (xmiiCommand.getCommandAudit()) {
                        xmiiCommand.executeCommand();
                        xmiiCommand.registerCommandCompletionEventHandler(this.onExecuteDigiSignCommand);
                    }


                } else {
                    alert("Enter Name in the user field");
                }
            } else if (textkey == "SIG02") {
                if (this.getView().byId("txt_user").getValue() != "") {

                    xmiiCommand.setCommandAudit(true)
                    if (xmiiCommand.getCommandAudit()) {
                        xmiiCommand.executeCommand();
                        xmiiCommand.registerCommandCompletionEventHandler(this.onExecuteDigiSignCommand);
                    }
                } else {
                    alert("Enter Name in the user field");
                }
            }
        },

        onExecuteDigiSignCommand: function() {

            if (xmiiCommand.getFirstValue("Type") == "S") {
                var sMatTippMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0025");
                sap.ui.getCore().getModel("oMessage").setProperty("/message", sMatTippMsg);
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");
                that.GetSignDetails();
            }

        },

        /*Fragment - BatchOEDigitalSignature  End*/
         

        /*Fragment - BatchOEInstruction  Start*/
        onLoadBatchOEInstruction: function() {
            var sLanguage = sap.ui.getCore().getModel("session").oData.CA_language;
            var selPhase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
            //document.getElementById("textframe").src ="BatchPhaseInstructionPopUp.irpt?qs_plant="+plant + '&qs_ordid=' + orderid + '&qs_phase=' + selPhase;

            var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
            var oView = this.getView();
            var sID = "BatchOEInstructionIinstruction";
            // UI_utilities.setOrderPahseLongText(oView, sID, sLanguage, orderid, plant, selPhase, projectName);
            sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder").setPhaseLongText(sLanguage, orderid, plant, selPhase,
                projectName);

        },
        /*Fragment - BatchOEInstruction  End*/

        /*Fragment - onLoadBatchInspectionPoint  Start*/
        onLoadBatchInspectionPoint: function() {
            this.getPhaseDetails();
        },

        getPhaseDetails: function() {

            var date = CommonUtility.getCurrentDateTime(new Date());

            // getOrder Details count

            var oPhasesNextTime = models
                .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningOrder-->XACQ_GetPhaseNextTime");

            var params = "Param.1=" + inSplot1 + "&Param.2=" + insporder + "&Param.3=" + plant + "&Param.4=" + resource +
                "&Param.5=" + date + "&Param.6=" + crid;
            oPhasesNextTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                "/QueryTemplate/XACQ_GetPhaseNextTime_ALL&" + params + "&Content-Type=text/json", "", false);

            sap.ui.getCore().setModel(null, "PhasesNextTime");
            sap.ui.getCore().setModel(oPhasesNextTime, "PhasesNextTime");

            // this.autoRefreshTable();

        },

        GetInspectPoints: function() {

            var that = this;
            var SelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;

            if (SelRow != 0) {
                var QnSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                var phase = NtSelectedRow.Phase;

                // getOrder Details count

                var InspectPointList = models
                    .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->GetInspectPoints-->XACQ_GetInspectionPoints");

                var insplot = id_txt_insplot;
                var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource;
                InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);

                sap.ui.getCore().setModel(null, "InspectPointList");
                sap.ui.getCore().setModel(InspectPointList, "InspectPointList");

            }

        },
        getTodayDate: function() {

            var that = this;
            var SelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;

            if (SelRow != 0) {
                var QnSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                var phase = NtSelectedRow.Phase;
                if (phase != "") {
                    var currentDT = CommonUtility.getCurrentDateTime(new Date());

                    var js_insplot = id_txt_insplot;

                    var AddInspPoint = models
                        .createNewJSONModel("com.khc.batchhub.controller.BatchExecuteOrder-->getTodayDate-->SQLQ_InsInspectPoint");

                    var params = "Param.2=" + "NA" + "&Param.3=" + js_insplot + "&Param.4=" + phase + "&Param.6=" + currentDT +
                        "&Param.10=0&Param.11=" + plant + "&Param.12=" + resource + "&Param.13=" + "0";

                    AddInspPoint.attcheReques
                    AddInspPoint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsInspectPoint&" +
                        params + "&Content-Type=text/json", "", false);

                    this.GetInspectPoints();

                    this.openSPCCharts();

                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0014"));

                }

            }

        },

        /*Fragment - onLoadBatchInspectionPoint  End*/
        loadBatchOrderWorkList: function() {
            var that = this;
            UI_utilities.setContainerBusyState(that, true);
            setTimeout(function() {
                that._oRouter.navTo("BatchOrderWorkList");
            }, 500);

            // this._oRouter.navTo("BatchOrderWorkList");

        }

    });
});