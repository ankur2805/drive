sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models", "com/khc/batchhub/model/formatter"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter) {
        var that;
        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var txt_shift;
        var id_hid_shiftstart;
        var id_hid_shiftend;
        var oModelCampaigns


        return Controller.extend("com.khc.batchhub.controller.BatchStartCampaign", {
            formatter: formatter,
            onInit: function() {

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchStartCampaign").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },

            _oRoutePatternMatched: function(oEvent) {

                //Hide the messages and set busy to false
                //UI_utilities.nonProductionPageOpened(this);
                UI_utilities.batchPageOpened(this, "BatchStartCampaign");

                var oData = {
                    validDestination: "true",

                };
                var oDestModel = new sap.ui.model.json.JSONModel(oData);
                this.getView().setModel(oDestModel, "destModel");

                this.getRouterDetails();
                this.GetCampList();
                this.setFlagShiftDetails();
                this.getView().byId("QuntityListscrollContainer").scrollTo(0, 0, 0);

            },

            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },

            getRouterDetails: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                txt_shift = sap.ui.getCore().getModel("session").oData.txt_shift;
            },
            ///creation event-1
            GetCampList: function() {
                var oModelCampaigns = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartCampaign-->GetCampList-->XACQ_GetScheduledCampaigns");
                var sparams = "Param.1=" + resource + "&Param.2=" + plant + "&Param.3=" + crdest;
                oModelCampaigns.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetScheduledCampaigns&" +
                    sparams + "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelCampaigns, "oCampaigns");
            },

            //creation event -2


            setFlagShiftDetails: function() {
                var dt = new Date();
                var TodayDate = getCurrentDateTime(dt);

                var oModelShift = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartCampaign-->setFlagShiftDetails-->XACQ_GetRunningShift");
                var tparams = "Param.1=" + plant + "&Param.2=" + resource;
                oModelShift.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningShift&" + tparams +
                    "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelShift, "oShift");

                if (CommonUtility.getJsonModelRowCount(oModelShift.getData()) != 0) {
                    txt_shift = oModelShift.getData().Rowsets.Rowset[0].Row[0].SHIFTNAME
                    id_hid_shiftstart = oModelShift.getData().Rowsets.Rowset[0].Row[0].STARTTIME
                    id_hid_shiftend = oModelShift.getData().Rowsets.Rowset[0].Row[0].ENDTIME

                    if (TodayDate >= id_hid_shiftend) {
                        this.getView().getModel("destModel").setProperty("/validDestination", "false")

                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0073");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                    }


                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0026");
                    sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

                    this.getView().getModel("destModel").setProperty("/validDestination", "false")

                }


            },
            //  // back to main page
            DirectToMain: function(oEvent) {

                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("default");

            },

            //BatchOrderWorkList

            DirectToBatchList: function(oEvent) {

                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchOrderWorkList");

            },

            /// On press of Hold button///
            HoldCampaign: function() {

                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("oCampaigns").getProperty(QnSelRow);
                    var Status = NtSelectedRow.STATUS;

                    if (Status == 1) {
                        var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                        var NtSelectedRow = this.getView().getModel("oCampaigns").getProperty(QnSelRow);
                        var orderId = NtSelectedRow.ORDERID;
                        if (orderId != "---") {
                            var oModelUpCampaign = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchStartCampaign-->HoldCampaign-->SQLQ_UpdHoldCampaign");
                            var dparams = "Param.1=" + resource + "&Param.2=" + orderId;
                            oModelUpCampaign.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/SQLQ_UpdHoldCampaign&" + dparams + "&Content-Type=text/json", "", false);
                            this.getView().setModel(oModelUpCampaign, "oUpCampaign");
                            this.GetCampList();
                        } else {
                            // alert(document.getElementById("id_msg_alert1").innerHTML);
                            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0027"));
                        }
                    } else {
                        //alert(document.getElementById("id_msg_alert2").innerHTML);
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0028"));
                    }
                } else {
                    //alert(document.getElementById("id_msg_alert3").innerHTML);
                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0029"));
                }

            },


            StartCampaign: function() {
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("oCampaigns").getProperty(QnSelRow);
                    var SelStatus = NtSelectedRow.STATUS;

                    if (SelStatus == 0 || SelStatus == 4) {
                        var orderId = NtSelectedRow.ORDERID;
                        var oModelStartCamp = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchStartCampaign-->StartCampaign-->SQLQ_UpdStartCampaign");
                        var cparams = "Param.1=" + resource + "&Param.2=" + orderId;
                        oModelStartCamp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_UpdStartCampaign&" +
                            cparams + "&Content-Type=text/json", "", false);
                        this.GetCampList();
                    } else if (SelStatus == 1) {
                        //alert(document.getElementById("id_msg_alert4").innerHTML);
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0030"));

                    } else if (SelStatus == 2) {
                        // alert(document.getElementById("id_msg_alert5").innerHTML);
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0031"));

                    } else {
                        // alert(document.getElementById("id_msg_alert6").innerHTML);
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0032"));

                    }
                } else {
                    //alert(document.getElementById("id_msg_alert7").innerHTML);
                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0033"));

                }
            },

            OpenBatchIdent: function() {
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;

                var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("oCampaigns").getProperty(QnSelRow);
                    var js_campaign = NtSelectedRow.ORDERID;
                    var js_campaignstrip = NtSelectedRow.ModORDERID;
                    var js_material = NtSelectedRow.MATNR;
                    var js_materialstrip = NtSelectedRow.ModMATNR;
                    var js_mattext = NtSelectedRow.MATTEXT;
                    js_mattext = js_mattext.replace(/%/gi, "%25");

                    var js_reqbatch = NtSelectedRow.BATCHCOUNT;
                    var js_actbatch = NtSelectedRow.ACTBATCH;
                    var campstat = NtSelectedRow.STATUS;
                    if (js_campaign != "---") {
                        if (campstat == 1 || campstat == 4) {
                            var oData = {
                                qs_campaign: js_campaign,
                                qs_campaignstrip: js_campaignstrip,
                                qs_material: js_material,
                                qs_materialstrip: js_materialstrip,
                                qs_mattext: js_mattext,
                                qs_reqbatch: js_reqbatch,
                            };
                            var oDestModel = new sap.ui.model.json.JSONModel(oData);
                            sap.ui.getCore().setModel(oDestModel, "BatchIdentParams");
                            this._oRouter.navTo("BatchIdentification");

                        } else if (campstat == 0) {
                            var oModelStartCampaign = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchStartCampaign-->OpenBatchIdent-->SQLQ_UpdStartCampaign");
                            var kparams = "Param.1=" + resource + "&Param.2=" + js_campaign;
                            oModelStartCampaign.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/SQLQ_UpdStartCampaign&" + kparams + "&Content-Type=text/json", "", false);
                            this.getView().setModel(oModelStartCampaign, "oHoldCampaign");
                            //window.location
                            var oData = {
                                qs_campaign: js_campaign,
                                qs_campaignstrip: js_campaignstrip,
                                qs_material: js_material,
                                qs_materialstrip: js_materialstrip,
                                qs_mattext: js_mattext,
                                qs_reqbatch: js_reqbatch,
                            };
                            var oDestModel = new sap.ui.model.json.JSONModel(oData);
                            sap.ui.getCore().setModel(oDestModel, "BatchIdentParams");
                            this._oRouter.navTo("BatchIdentification");
                        } else {

                            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0114"));

                        }
                    } else {

                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0034"));

                    }
                } else {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0035"));

                }
            },


            EndCampaign: function() {

                var CRId = "";
                var SelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths().length;
                if (SelRow != 0) {

                    var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("oCampaigns").getProperty(QnSelRow);
                    var SelStatus = NtSelectedRow.STATUS;
                    var scheduledate = NtSelectedRow.SCHEDATE;

                    if (SelStatus == 1) {
                        var QnSelRow = this.getView().byId("Id_QuntityList").getSelectedContextPaths()[0];
                        var NtSelectedRow = this.getView().getModel("oCampaigns").getProperty(QnSelRow);
                        var SelStatus = NtSelectedRow.STATUS;
                        var scheduledate = NtSelectedRow.SCHEDATE;

                        var that = this;
                        var msg = this.getView().getModel("i18n").getProperty("BATCH_MSG_0087")
                        MessageBox.confirm(
                            msg, {
                                icon: MessageBox.Icon.WARNING,
                                title: "Message from webpage",
                                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                onClose: function(oAction) {
                                    if (oAction === "OK") {
                                        var orderId = NtSelectedRow.ORDERID;
                                        var CRID1 = NtSelectedRow.CRID;
                                        var oModelEndCampaign = models.createNewJSONModel(
                                            "com.khc.batchhub.controller.BatchStartCampaign-->EndCampaign-->XACQ_EndCampaign");
                                        var eparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + CRID1 + "&Param.4=" +
                                            crdest + "&Param.5=" + orderId + "&Param.6=" + userName;
                                        oModelEndCampaign.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                            "/QueryTemplate/XACQ_EndCampaign&" + eparams + "&Content-Type=text/json", "", false);
                                        that.getView().setModel(oModelEndCampaign, "oHoldCampaign");
                                        that.GetCampList();
                                    }
                                }
                            });
                    } else {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0037"));

                    }
                } else {
                    // alert(document.getElementById("id_msg_alert12").innerHTML);
                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0038"));
                }
            },

        });
    });