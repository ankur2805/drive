sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility",
        "com/khc/batchhub/model/models",
        "com/khc/batchhub/model/formatter"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter) {

        var that;
        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var txt_shift;
        var id_hid_shiftstart;
        var id_hid_shiftend;
        var oModelCampaigns;
        var id_hid_selorder;

        return Controller.extend("com.khc.batchhub.controller.BatchPlantView", {
            formatter: formatter,
            onInit: function() {

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchPlantView").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },

            _oRoutePatternMatched: function(oEvent) {

                //Hide the messages and set busy to false 
                //    UI_utilities.batchPageOpened(this, "home");
                UI_utilities.batchPageOpened(this, "BatchPlantView");

                this.getRouterDetails();
                this.GetOEEData();
            },

            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },

            getRouterDetails: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                txt_shift = sap.ui.getCore().getModel("session").oData.txt_shift;
            },

            GetOEEData: function() {
                var currenttime = new Date();
                var currentDT = getCurrentDateTime(currenttime);
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;

                var oModelPlantList = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchPlantView-->GetOEEData-->XACQ_PlantView");
                var sparams = "Param.1=" + plant + "&Param.2=" + currentDT;
                oModelPlantList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_PlantView&" + sparams +
                    "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelPlantList, "oPlantList");

            },

            onHelp: function() {
                UI_utilities.OpenHelpFileSingle("PlantView");
            },



        });
    });