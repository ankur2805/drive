sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models) {
        return Controller.extend("com.khc.batchhub.controller.BatchLineStatus", {
            onInit: function() {

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchLineStatus").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },

            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },
            _oRoutePatternMatched: function(oEvent) {
                //Hide the messages and set busy to false

                UI_utilities.batchPageOpened(this, "home");
                UI_utilities.batchPageOpened(this, "BatchLineStatus");
                UI_utilities.DisableDatePickerInput(this.getView().byId("startDateTime"));
                UI_utilities.DisableDatePickerInput(this.getView().byId("endDateTime"));

                this.getView().byId("endDateTime").setValue("");
                var oLineStatusData = {
                    activeShiftFlag: false,
                    openDownTimeFlag: false,
                    failureReasonFlag: false,
                    classifyFlag: false
                };
                var oLineStatusJSONModel = new sap.ui.model.json.JSONModel(oLineStatusData);
                this.getView().setModel(oLineStatusJSONModel, "lineStatus");

                var oDurationData = {
                    showDuration: false,
                    duration: ""
                };
                var oDurationModel = new sap.ui.model.json.JSONModel(oDurationData);
                sap.ui.getCore().setModel(oDurationModel, "duration");

                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;

                this.getLSReasonList();
                this.getRunningShift();

            },
            //on Load get the Line Status reason list
            /*****************************************************************************************************************************************************************************************/
            getLSReasonList: function() {

                var oModelLSReasonList = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchLineStatus-->getLSReasonList-->XACQ_GetLSReasonList");
                oModelLSReasonList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetLSReasonList&Param.1=" +
                    plant + "&Param.2=" + resource + "&Param.3=&Content-Type=text/json", "", false);
                this.getView().setModel(oModelLSReasonList, "oLSReasonList");
            },
            //on Load get the running shift details
            /*****************************************************************************************************************************************************************************************/
            getRunningShift: function() {


                var oModelRunningShiftDetails = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchLineStatus-->getRunningShift-->XACQ_GetRunningShift");

                var that = this;
                oModelRunningShiftDetails.attachRequestCompleted(
                    function() {

                        that.getView().setModel(oModelRunningShiftDetails, "oRunningShiftList");
                        if (CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData()) > 0) {

                            that.getView().getModel("lineStatus").setProperty("/activeShiftFlag", true);

                            var oRunningShiftData = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
                            shiftname = oRunningShiftData.SHIFTNAME;
                            shiftStartTime = oRunningShiftData.STARTTIME;
                            shiftEndTime = oRunningShiftData.ENDTIME;
                            
                            shiftId = oRunningShiftData.SHIFTID;
                            teamId = oRunningShiftData.TEAMID;

                            that.getOpenDowntime();

                        } else {

                            that.getView().getModel("lineStatus").setProperty("/activeShiftFlag", false);
                            var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                            sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                        }

                    });



                oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetRunningShift&Param.1=" + plant + "&Param.2=" + resource + "&Content-Type=text/json", "", false);

            }, //on Load get open Downtime details
            /*****************************************************************************************************************************************************************************************/
            getOpenDowntime: function() {


                this.clearAll();

                var oModelGetDowntime = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchLineStatus-->getOpenDowntime-->SQLQ_GetDownTime");

                var currentDT = CommonUtility.getCurrentDateTime(new Date());

                var that = this;
                oModelGetDowntime.attachRequestCompleted(
                    function() {

                        that.getView().setModel(oModelGetDowntime, "oDowntime");
                        if (CommonUtility.getJsonModelRowCount(oModelGetDowntime.getData()) > 0) {

                            sap.ui.getCore().getModel("duration").setProperty("/showDuration", true);

                            that.getView().getModel("lineStatus").setProperty("/openDownTimeFlag", true);

                            oDownTimeData = oModelGetDowntime.getData().Rowsets.Rowset[0].Row[0];
                            // DTSTART = 12/30/2022 18:00:00
                            var sStartDate = oDownTimeData.DTSTART;
                            var oStartDate = new Date(sStartDate);
                            sDTStartDateFormatted = CommonUtility.getCurrentDateTime(oStartDate);
                            that.getView().byId("startDateTime").setValue(sDTStartDateFormatted);

                            if (shiftStartTime > sDTStartDateFormatted) {

                                that.getView().byId("startDateTime").setValue(shiftStartTime);
                                sDTStartDateFormatted = shiftStartTime;
                            }

                            that.getView().byId("endDateTime").setValue(currentDT);
                            that.getView().byId("notes").setValue(oDownTimeData.SNTEXT);

                            var sReasonType = oDownTimeData.TYPE;
                            that.getView().byId("reason-" + sReasonType).setSelected(true);

                            that.filterReasonCodesForType(sReasonType);

                            // check if any maintenance notif is raised for this downtime from hnz_maintnot table using mndtlinkid.
                            if (sReasonType === 'F') {

                                var sMNID = oDownTimeData.MNID;

                                that.getLinkedMNForDT(sMNID);

                            }


                            that.SetCounterDisp();

                            //To do, select the reason code for the failure
                            that.setDTReasonRow(sReasonType, oDownTimeData.CATCODE, oDownTimeData.EQUITYPE);

                        } else {

                            that.getView().getModel("lineStatus").setProperty("/openDownTimeFlag", false);
                            sap.ui.getCore().getModel("duration").setProperty("/showDuration", false);

                            that.clearDTInput();

                            that.getView().byId("startDateTime").setValue(currentDT);


                        }

                        that.getShiftNoteList();

                    });


                oModelGetDowntime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetDownTime&Param.1=" +
                    plant + "&Param.2=" + resource + "&Content-Type=text/json", "", false);

            },
            //on Load get the Shift Note Details
            /*****************************************************************************************************************************************************************************************/
            getShiftNoteList: function() {

                var oModelShiftNoteList = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchLineStatus-->getShiftNoteList-->XACQ_GetShiftNoteDetailsV2");

                let sParamsUpdate = "Param.1=" + plant + "&Param.2=" + resource;
                oModelShiftNoteList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetShiftNoteDetailsV2&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftStartTime +
                    "&Param.4=" + shiftEndTime + "&Content-Type=text/json", "", false);

                sap.ui.getCore().setModel(oModelShiftNoteList, "oShiftNoteList");

            },
            //Clear the input fields
            /*****************************************************************************************************************************************************************************************/
            clearDTInput: function() {

                this.getView().byId("category").setValue("");
                this.getView().byId("reason").setValue("");
                this.getView().byId("notes").setValue("");
                this.getView().byId("notification").setValue("");
                this.getView().byId("workorder").setValue("");
            },

            clearAll: function() {

                this.clearDTInput();
                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                sap.ui.getCore().getModel("duration").setProperty("/showDuration", "");
                this.getView().getModel("lineStatus").setProperty("/openDownTimeFlag", false);
                this.getView().getModel("lineStatus").setProperty("/failureReasonFlag", false);

                this.getView().byId("notes").setValue("");
                var currentDT = CommonUtility.getCurrentDateTime(new Date());
                this.getView().byId("startDateTime").setValue(currentDT);
                this.getView().byId("endDateTime").setValue("");
                this.getView().byId("reason-X").setSelected(true);
                this.filterReasonCodesForType("");




            },
            /**************************************************************************************************************************************************************************************/
            // Use to show the downtime duration.
            /*****************************************************************************************************************************************************************************************/
            SetCounterDisp: function() {
                var currenttime = new Date();
                var currentDT = CommonUtility.getCurrentDateTime(currenttime);
                var OpenDTStart = this.getView().byId("startDateTime").getValue();
                if (OpenDTStart) {
                    jQuery.ajax({
                        url: "/XMII/Runner?Transaction=NL_ELS_HUB/BLS/BLS_GetTimeCounter&I_CurrentDT=" + currentDT + "&I_OpenDTStart=" +
                            OpenDTStart + "&OutputParameter=O_Time&Content-Type=text/xml",
                        type: 'GET',
                        async: false,
                        success: function(xmlData) {

                            var sDuration = $(xmlData).find('O_Time').text();
                            if (sDuration) {

                                sap.ui.getCore().getModel("duration").setProperty("/duration", sDuration);
                            } else {
                                sap.ui.getCore().getModel("duration").setProperty("/duration", "");

                            }
                        }
                    });

                    this.SetDelay();
                } else {
                    sap.ui.getCore().getModel("duration").setProperty("/duration", "");
                    sap.ui.getCore().getModel("duration").getProperty("/false")

                }
            },

            /**************************************************************************************************************************************************************************************/
            // Set duration counter
            /*****************************************************************************************************************************************************************************************/
            SetDelay: function() {
                if (sap.ui.getCore().getModel("duration").getProperty("/showDuration")) {
                    var that = this;
                    setTimeout(function() {
                        that.SetCounterDisp();
                    }, 60000);
                }
            },

            /**************************************************************************************************************************************************************************************/
            //Get the Linked Maintainance for downtime
            /*****************************************************************************************************************************************************************************************/
            getLinkedMNForDT: function(sMNID) {

                var oModelLinkedMN = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchLineStatus-->getLinkedMNForDT-->SQLQ_GetLinkedMNForDT");

                var that = this;
                oModelLinkedMN.attachRequestCompleted(
                    function() {

                        if (CommonUtility.getJsonModelRowCount(oModelLinkedMN.getData()) > 0) {

                            let oMNData = oModelLinkedMN.getData().Rowsets.Rowset[0].Row[0];
                            that.getView().byId("notification").setValue(oMNData.MNOTIF);
                            that.getView().byId("workorder").setValue(oMNData.WORKORD);
                        }
                    });

                oModelLinkedMN.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetLinkedMNForDT&Param.1=" +
                    plant + "&Param.2=" + resource + "&Param.3=" + sMNID + "&Content-Type=text/json", "", false);
            },

            /**************************************************************************************************************************************************************************************/
            // Filter reason list table as per reason type
            /*****************************************************************************************************************************************************************************************/
            filterReasonCodesForType: function(sType) {


                PopulateDTFlag = 1;
                // Get the table Binding to apply filters
                var oTable = this.getView().byId("reasonListTableId");
                var oBinding = oTable.getBinding("items");
                // Array to combine filters
                var aFilters = [];
                //STATUS is the json property, EQ is filter operator, "statuscode" is the value to Filter
                if (sType) {
                    aFilters.push(
                        new Filter([new Filter("TCODE", "EQ", sType)])
                    );
                }

                oBinding.filter(aFilters);
            }, //Populate the category and reason as per the reason selected
            /*****************************************************************************************************************************************************************************************/
            reasonSelected: function() {


                var aSelectedRowPath = this.getView().byId("reasonListTableId").getSelectedContextPaths();
                var oLSReasonListModel = this.getView().getModel("oLSReasonList");


                if (aSelectedRowPath.length > 0) {

                    let sPath = aSelectedRowPath[0];
                    var SADesc = oLSReasonListModel.getProperty(sPath + '/SADESC');
                    var TDesc = oLSReasonListModel.getProperty(sPath + '/TDESC');

                    var TCode = oLSReasonListModel.getProperty(sPath + '/TCODE');

                    this.getView().byId("category").setValue(TDesc);
                    this.getView().byId("reason").setValue(SADesc);

                    if (TCode == "F") {
                        this.getView().getModel("lineStatus").setProperty("/failureReasonFlag", true);
                    } else {

                        this.getView().getModel("lineStatus").setProperty("/failureReasonFlag", false);

                    }



                } else {
                    this.getView().byId("category").setValue("");
                    this.getView().byId("reason").setValue("");
                    sap.ui.getCore().getModel("duration").setProperty("/failureReasonFlag", false);

                }


            },
            DTRowSelected: function() {
              this.getView().byId("startDateTime").setEnabled(true);
              this.getView().byId("endDateTime").setEnabled(true);
                //if( ! this.getView().getModel("lineStatus").getProperty("/openDownTimeFlag"))  {

                var aSelectedRowPath = this.getView().byId("shiftNoteDetailsTableId").getSelectedContextPaths();
                var oLSReasonListModel = this.getView().getModel("oShiftNoteList");

                if (aSelectedRowPath.length > 0) {

                    let sPath = aSelectedRowPath[0];

                    var reason = oLSReasonListModel.getProperty(sPath + '/REASON');
                    var type = oLSReasonListModel.getProperty(sPath + '/TYPETEXT');
                    var DTSTART = oLSReasonListModel.getProperty(sPath + '/DTSTART');
                    var DTEND = oLSReasonListModel.getProperty(sPath + '/DTEND');
                    var SNTEXT = oLSReasonListModel.getProperty(sPath + '/SNTEXT');


                    var gri_cattext = oLSReasonListModel.getProperty(sPath+'/CATTEXT');
                    var splitCatText = gri_cattext.split(":");
                    var DTType = splitCatText[0];
                    var DTReason = splitCatText[2];
                             this.getView().byId("category").setValue(DTType);
                             this.getView().byId("reason").setValue(DTReason);
                             
                    this.getView().byId("startDateTime").setValue(DTSTART);
                    if (DTEND == 'TimeUnavai vailable')
                        this.getView().byId("endDateTime").setValue("");
                    else
                        this.getView().byId("endDateTime").setValue(DTEND);

                    this.getView().byId("notes").setValue(SNTEXT);
                    this.getView().byId("notes").setValue(SNTEXT);


                    var sReasonType = oLSReasonListModel.getProperty(sPath + '/TYPE');;
                    this.getView().byId("reason-" + sReasonType).setSelected(true);
                    this.filterReasonCodesForType(sReasonType);
                    var workorder =  oLSReasonListModel.getProperty(sPath+'/WORDER'); 
                    this.getView().byId("workorder").setValue(workorder);
                    
                    var notification =  oLSReasonListModel.getProperty(sPath+'/MNOTIF'); 
                    this.getView().byId("notification").setValue(notification);

                    //To do, select the reason code for the failure
                    var EQUITYPE = oLSReasonListModel.getProperty(sPath + '/EQUITYPE');
                    var CATCODE = oLSReasonListModel.getProperty(sPath + '/CATCODE');


                    this.setDTReasonRow(sReasonType, CATCODE, EQUITYPE);
                    
                   /* // if Auto Downtime,Supervisior only edit
                    var autoDWFlag = oLSReasonListModel.getProperty(sPath + '/AUTODTFLAG');
                    if (autoDWFlag == 1) {
                        if (!has_Access_Supervisor) {
                            this.getView().byId("startDateTime").setEnabled(false);
                            this.getView().byId("endDateTime").setEnabled(false);
                        } else {
                            this.getView().byId("startDateTime").setEnabled(true);
                            this.getView().byId("endDateTime").setEnabled(true);
                        }
                    } else {
                        this.getView().byId("startDateTime").setEnabled(true);
                        this.getView().byId("endDateTime").setEnabled(true);
                    }*/
                    
                    
                }

                //} 

            },

            // Filter reason codes
            /*****************************************************************************************************************************************************************************************/
            filterReasonCodes: function(oEvent) {



                var sID = oEvent.getSource().getId();
                var sType = sID.charAt(sID.length - 1)
                if (sType === "X") {
                    sType = "";
                }
                if (PopulateDTFlag != 1) {
                    this.filterReasonCodesForType(sType);
                }
                PopulateDTFlag = 0;
            },

            startMaintenance: function() {

                this.openDowntime(true);

            },

            startDowntime: function() {


                this.openDowntime(false);
            },


            /**************************************************************************************************************************************************************************************/
            //Start the downtime. if gotomn is 1 then redirect to MN screen after starting downtime in HNZ_DOWNTIME.
            // If gotomn is 0 the redirect to home page after starting downtime in HNZ_DOWNTIME.
            /*****************************************************************************************************************************************************************************************/
            openDowntime: function(bMaintenance) {

                var aSelectedRowPath = this.getView().byId("reasonListTableId").getSelectedContextPaths();



                var downtimeStart = this.getView().byId("startDateTime").getValue();

                if (aSelectedRowPath.length > 0) {
                    let sPath = aSelectedRowPath[0];
                    var oLSReasonListModel = this.getView().getModel("oLSReasonList");
                    var cattext = oLSReasonListModel.getProperty(sPath + '/CatDesc');
                    var catCode = oLSReasonListModel.getProperty(sPath + '/CatCode');

                    var sParams = this.populateParams("startdwntime", aSelectedRowPath, oLSReasonListModel);

                    var oModelInsertDownTime = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchLineStatus-->openDowntime-->XACQ_ManageDownTimeV2");

                    var that = this;
                    oModelInsertDownTime.attachRequestCompleted(
                        function() {


                            if (CommonUtility.getJsonModelRowCount(oModelInsertDownTime.getData()) > 0) {

                                var oInsertDowntimeResponse = oModelInsertDownTime.getData().Rowsets.Rowset[0].Row[0];
                                if (oInsertDowntimeResponse.Type == "SS") {



                                    var sStartDTSuccessMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0012");
                                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTSuccessMsg);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

                                    // Navigate to Request maintenance Page
                                    if (bMaintenance) {
                                        setTimeout(function() {
                                            that._oRouter.navTo("BatchMaintainNotif");
                                        }, 1000);

                                    } else {
                                        setTimeout(function() {
                                            that._oRouter.navTo("BatchStartCampaign");
                                        }, 1000);

                                    }

                                    that.getOpenDowntime();

                                    that.getView().getModel("lineStatus").setProperty("/openDownTimeFlag", true);

                                    
                                } else if (oInsertDowntimeResponse.Type == "ES") {
                                    var sStartDTErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0014");
                                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTErrorMsg);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                                } else if (oInsertDowntimeResponse.Type == "CS") {
                                    var sStartDTConflictMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0014") +
                                        oInsertDowntimeResponse.Message;
                                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTConflictMsg);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                                } else if (oInsertDowntimeResponse.Type == "CS2") {
                                    var sStartDTConflictMessage = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0102");
                                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTConflictMessage);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

                                }
                            } else {
                                var sStartDTErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0014");
                                sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTErrorMsg);
                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");

                            }


                        });

                    if (downtimeStart != "") {
                        if (downtimeStart >= shiftStartTime && downtimeStart <= shiftEndTime) {
                            if (cattext && catCode) {

                                oModelInsertDownTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                    "/QueryTemplate/XACQ_ManageDownTimeV2&" + sParams + "&Content-Type=text/json", "", false);
                            } else {
                                var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082");
                                MessageBox.alert(sAlertMsg, {
                                    title: "Alert",
                                });
                            }
                        } else {
                            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0036");
                            MessageBox.alert(sAlertMsg, {
                                title: "Alert",
                            });
                        }

                    } else {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0010");
                        MessageBox.alert(sAlertMsg, {
                            title: "Alert",
                        });
                    }
                } else {


                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082");
                    MessageBox.alert(sAlertMsg);

                }
                /**
                 * TO-DO
                 */



            },

            /**************************************************************************************************************************************************************************************/
            //Populate params for start and end downtime
            /*****************************************************************************************************************************************************************************************/
            populateParams: function(operation, aSelectedRowPath, oLSReasonListModel) {
                let sPath = aSelectedRowPath[0];
                var selectedTypeVal = oLSReasonListModel.getProperty(sPath + '/TCODE');
                var selectedAreaVal = oLSReasonListModel.getProperty(sPath + '/ACODE');
                var selectedSubAreaVal = oLSReasonListModel.getProperty(sPath + '/SACODE');
                var selectedTypeTxt = oLSReasonListModel.getProperty(sPath + '/TDESC');
                var selectedAreaTxt = oLSReasonListModel.getProperty(sPath + '/ADESC');
                var selectedSubAreaTxt = oLSReasonListModel.getProperty(sPath + '/SADESC');
                var dispDesc = oLSReasonListModel.getProperty(sPath + '/DispDesc');
                var cattext = oLSReasonListModel.getProperty(sPath + '/CatDesc');
                var catCode = oLSReasonListModel.getProperty(sPath + '/CatCode');
                var downtimeStart = this.getView().byId("startDateTime").getValue();
                var sntext = this.getView().byId("notes").getValue();
                var downtimeEnd = this.getView().byId("endDateTime").getValue();
                var currentDT = CommonUtility.getCurrentDateTime(new Date());

                var MNId;
                var equiCode;
                var operationValue;


                if (selectedTypeVal == "F") {
                    equiCode = oLSReasonListModel.getProperty(sPath + '/EquipmentCode');
                }

                var equiText = dispDesc;
                var sRoutingParams = {
                    EquiText: equiText,
                    EquiCode: equiCode,
                    MNID: MNId,
                    Notes: sntext,
                    DTStart: downtimeStart
                };

             //   sap.ui.getCore().setModel(sRoutingParams, "routingParams");
                if (operation == 'startdwntime') {
                    var eccdate = CommonUtility.formatDateToCallProcessMsg();
                    var ecctime = CommonUtility.formatTimeToCallProcessMsg();
                    MNId = plant + resource + eccdate + ecctime;
                    operationValue = 'S';
                } else if (operation == 'enddwntime') {
                    MNId = "";
                    operationValue = 'E';
                }
                var sParams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + downtimeStart + "&Param.4=" + downtimeEnd +
                    "&Param.5=" + catCode + "&Param.6=" + operationValue + "&Param.7=" + "" + "&Param.8=" + sntext + "&Param.9=" +
                    selectedTypeVal +
                    "&Param.10=" + cattext + "&Param.11=" + selectedAreaVal + "&Param.12=" + selectedSubAreaVal + "&Param.13=" + "BUS0010" +
                    "&Param.14=" + "" + "&Param.15=" + shiftname + "&Param.16=" + userName + "&Param.17=" + shiftId +
                    "&Param.18=" + selectedTypeTxt + "&Param.19=" + selectedAreaTxt + "&Param.20=" + selectedSubAreaTxt + "&Param.21=" + "" +
                    "&Param.22=" + teamId + "&Param.23=" + "" + "&Param.24=" + "" + "&Param.25=" + dispDesc +
                    "&Param.26=" + equiCode + "&Param.27=" + MNId+ "&Param.28=" + "0";
                sParams = CommonUtility.encodeParam(sParams);
                return sParams;
            },

            /**************************************************************************************************************************************************************************************/
            //End the downtime in HNZ_DOWNTIME table.
            /*****************************************************************************************************************************************************************************************/
            endDownTime: function() {
                var aSelectedRowPath = this.getView().byId("reasonListTableId").getSelectedContextPaths();
                var oLSReasonListModel = this.getView().getModel("oLSReasonList");
                var DTstart = this.getView().byId("startDateTime").getValue();
                var DTEnd = this.getView().byId("endDateTime").getValue();


                if (aSelectedRowPath.length > 0) {
                    var sParams = this.populateParams("enddwntime", aSelectedRowPath, oLSReasonListModel);
                    if (DTEnd != "") {
                        if (DTEnd >= shiftStartTime && DTEnd <= shiftEndTime) {
                            if (DTstart >= shiftStartTime && DTstart <= shiftEndTime) {

                                var oModelInsertDownTime = models.createNewJSONModel(
                                    "com.khc.batchhub.controller.BatchLineStatus-->endDownTime-->XACQ_ManageDownTimeV2");

                                var that = this;
                                oModelInsertDownTime.attachRequestCompleted(
                                    function() {
                                        if (CommonUtility.getJsonModelRowCount(oModelInsertDownTime.getData()) > 0) {

                                            var oInsertDowntimeResponse = oModelInsertDownTime.getData().Rowsets.Rowset[0].Row[0];
                                            if (oInsertDowntimeResponse.Type == "SE") {

                                                var sStartDTSuccessMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0015");
                                                sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTSuccessMsg);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

                                                that.getView().byId("endDateTime").setValue("");
                                                sap.ui.getCore().getModel("duration").setProperty("/duration", "");
                                                that.getOpenDowntime();
                                                //Remove selected reasonList table
                                                that.getView().byId("reasonListTableId").removeSelections()
                                               
                                            } else if (oInsertDowntimeResponse.Type == "EE") {
                                                var sStartDTErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0017");
                                                sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTErrorMsg);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                                            } else if (oInsertDowntimeResponse.Type == "BE") {
                                                var sStartDTConflictMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0018");
                                                sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTConflictMsg);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                                            } else if (oInsertDowntimeResponse.Type == "CE") {
                                                var sStartDTConflictMessage = sap.ui.getCore().getModel("i18n").getProperty(
                                                    "HUB_MSG_0016") + oInsertDowntimeResponse.Message;
                                                sap.ui.getCore().getModel("oMessage").setProperty("/message", sStartDTConflictMessage);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                                            }
                                        }
                                    });
                                oModelInsertDownTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                    "/QueryTemplate/XACQ_ManageDownTimeV2&" + sParams + "&Content-Type=text/json", "", false);


                            } else {
                                var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0038");
                                MessageBox.alert(sAlertMsg, {
                                    title: "Alert",
                                });
                            }

                        } else {
                            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0038");
                            MessageBox.alert(sAlertMsg, {
                                title: "Alert",
                            });
                        }
                    } else {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0080");
                        MessageBox.alert(sAlertMsg, {
                            title: "Alert",
                        });
                    }

                } else {
                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082");
                    MessageBox.alert(sAlertMsg, {
                        title: "Alert",
                    });
                }

                /**
                 * TO-DO
                 */


            },

            Ins_Downtime: function() {
                // alert("Inserted");
                var SelRow = this.getView().byId("reasonListTableId").getSelectedContextPaths()[0];

                if (SelRow) {

                    var currenttime = new Date();
                    var currentDT = CommonUtility.getCurrentDateTime(currenttime);
                    var oRow = this.getView().getModel("oLSReasonList").getProperty(SelRow);

                    var catcode = oRow.CatCode;
                    var cattext = oRow.CatDesc;
                    /** from UI**/
                    var DTstart = this.getView().byId("startDateTime").getValue();
                    var sntext = this.getView().byId("notes").getValue();
                    var DTEnd = this.getView().byId("endDateTime").getValue();

                    var selectedTypeVal = oRow.TCODE;
                    var selectedAreaVal = oRow.ACODE;
                    var selectedSubAreaVal = oRow.SACODE
                    var selectedTypeTxt = oRow.TDESC
                    var selectedAreaTxt = oRow.ADESC
                    var selectedSubAreaTxt = oRow.SADESC
                    var DispDesc = oRow.DispDesc
                    var EquiType = oRow.EquipmentCode
                    if (DTstart != "" && DTEnd != "") {
                        if (DTstart < DTEnd) {
                            if (cattext && catcode) {

                                if (DTstart >= shiftStartTime && DTstart <= shiftEndTime &&
                                    DTEnd >= shiftStartTime && DTEnd <= shiftEndTime) {

                                    var that = this;
                                    var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + DTstart + "&Param.4=" + DTEnd +
                                        "&Param.5=" + catcode + "&Param.6=" + cattext + "&Param.7=" + selectedTypeVal + "&Param.8=" +
                                        selectedAreaVal +
                                        "&Param.9=" + selectedSubAreaVal + "&Param.10=" + sntext + "&Param.11=" + "BUS0010" +
                                        "&Param.12=" + "" + "&Param.13=" + "" + "&Param.14=" + shiftname +
                                        "&Param.15=" + shiftId + "&Param.16=" + selectedTypeTxt +
                                        "&Param.17=" + selectedAreaTxt + "&Param.18=" + selectedSubAreaTxt + "&Param.19=" + "" + "&Param.20=" +
                                        teamId + "&Param.21=" + "" + "&Param.22=" + "" + "&Param.23=" + DispDesc +
                                        "&Param.24=" + "" + "&Param.25=" + EquiType;
                                    params = CommonUtility.encodeParam(params);
                                    var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_InsRetroDownTime&" +
                                        "Content-Type=text/json&" + params

                                    $.ajax({
                                        url: url,
                                        type: "POST",
                                        async: false,
                                        success: function(data, txt, jqXHR) {
                                            var getData = data.Rowsets.Rowset[0].Row[0];
                                            if (getData.Type == "S") {
                                                MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0077") +
                                                    getData.Message)
                                                that.getOpenDowntime();
                                                //document.APLT_GRI_Downtime.refresh();
                                            } else if (getData.Type == "E") {
                                                MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0078") +
                                                    getData.Message)
                                            } else if (getData.Type == "C") {
                                                MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0079"))
                                            }
                                        },
                                        error: function(jqXHR, textStatus, errorThrown) {
                                            MessageBox.error(jqXHR.responseText);
                                        }
                                    });
                                } else {
                                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0062"));
                                }
                            } else {
                                MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
                            }
                        } else {
                            MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0054"));
                        }
                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0060"));
                    }
                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
                }
            },
            Upd_Downtime: function() {
                //alert("Upd_Downtime");

                var currenttime = new Date();
                var currentDT = CommonUtility.getCurrentDateTime(currenttime);

                //Get from UI
                var DTstart = this.getView().byId("startDateTime").getValue();
                var sntext = this.getView().byId("notes").getValue();
                var DTEnd = this.getView().byId("endDateTime").getValue();

                var SelRow = this.getView().byId("reasonListTableId").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var SelRowReasonList = this.getView().byId("reasonListTableId").getSelectedContextPaths()[0];

                    //Get from shiftNote table
                    var ReasonListSltRow = this.getView().getModel("oLSReasonList").getProperty(SelRowReasonList)

                    var selectedTypeVal = ReasonListSltRow.TCODE;
                    var selectedAreaVal = ReasonListSltRow.ACODE;
                    var selectedSubAreaVal = ReasonListSltRow.SACODE;
                    var selectedTypeTxt = ReasonListSltRow.TDESC;
                    var selectedAreaTxt = ReasonListSltRow.ADESC;
                    var selectedSubAreaTxt = ReasonListSltRow.SADESC;
                    var DispDesc = ReasonListSltRow.DispDesc;
                    var EquiType = ReasonListSltRow.EquipmentCode;
                    var catcode = ReasonListSltRow.CatCode;
                    var cattext = ReasonListSltRow.CatDesc;

                    var DT_SelRow = this.getView().byId("shiftNoteDetailsTableId").getSelectedContextPaths().length;
                    if (DT_SelRow != 0) {
                        var ShiftNDSelRow = this.getView().byId("shiftNoteDetailsTableId").getSelectedContextPaths()[0];

                        //Get from Downtime Table
                        var DTSelectedRow = this.getView().getModel("oShiftNoteList").getProperty(ShiftNDSelRow);
                        var gri_cattext = DTSelectedRow.CATTEXT;
                        var gri_DTstart = DTSelectedRow.DTSTART;
                        var gri_DTStatus = DTSelectedRow.OPEN;
                        var gri_catcode = DTSelectedRow.CATCODE;

                        //** single quotes replacement **

                        //alert(sntext)
                        if (gri_DTStatus != 1) {

                            var uName = userName; //this.getView().getModel("session").getData().IllumLoginName;
                            var params = "Param.1=" + catcode + "&Param.2=" + cattext + "&Param.3=" + DTEnd + "&Param.4=" + DTstart +
                                "&Param.5=" + sntext + "&Param.6=" + selectedTypeVal + "&Param.7=" + selectedAreaVal + "&Param.8=" +
                                selectedSubAreaVal +
                                "&Param.9=" + "" + "&Param.10=" + plant + "&Param.11=" + resource +
                                "&Param.12=" + gri_DTstart + "&Param.13=" + gri_catcode + "&Param.14=" + uName +
                                "&Param.15=" + selectedTypeTxt + "&Param.16=" + selectedAreaTxt +
                                "&Param.17=" + selectedSubAreaTxt + "&Param.18=" + "" + "&Param.19=" + "" + "&Param.20=" +
                                "" + "&Param.21=" + DispDesc + "&Param.22=" + EquiType;

                            params = CommonUtility.encodeParam(params);
                            var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_UpdateDownTime&" +
                                "Content-Type=text/json&" + params

                            var that = this;
                            $.ajax({
                                url: url,
                                type: "POST",
                                async: false,
                                success: function(data, txt, jqXHR) {
                                    if (data.Rowsets.Rowset != null) {
                                        var getData = data.Rowsets.Rowset[0].Row[0];
                                        if (getData.Type == "S") {
                                            sap.m.MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0075") +
                                                getData.Message)

                                            that.getOpenDowntime();
                                            //document.APLT_GRI_Downtime.refresh();

                                        } else if (getData.Type == "E") {
                                            sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty(
                                                "HUB_MSG_0076")); // + getData.Message)
                                        } else if (getData.Type == "C") {
                                            sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0079") +
                                                getData.Message)
                                        }
                                    } else {
                                        if (data.Rowsets.Messages.length > 0) {
                                            var errorMessage = data.Rowsets.Messages[0].Message
                                            sap.m.MessageBox.warning(errorMessage)
                                        }
                                    }
                                },
                                error: function(jqXHR, textStatus, errorThrown) {
                                    alert(jqXHR.responseText);
                                }
                            });


                        } else {
                            sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0092"));
                        }
                    } else {
                        sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
                    }
                } else {
                    sap.m.MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0082"));
                }

            },

            Del_ShiftNoteDetails: function() {
                //alert("Del_ShiftNoteDetails");

                //Get Selected Value from table
                var DT_SelRow = this.getView().byId("shiftNoteDetailsTableId").getSelectedContextPaths().length;
                if (DT_SelRow != 0) {
                    var ShiftNDSelRow = this.getView().byId("shiftNoteDetailsTableId").getSelectedContextPaths()[0];
                    var DTSelectedRow = this.getView().getModel("oShiftNoteList").getProperty(ShiftNDSelRow);

                    var SelStart = DTSelectedRow.DTSTART;
                    var params = "Param.1=" + SelStart + "&Param.2=" + plant + "&Param.3=" + resource;
                    var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_DelShiftNoteDetails&" +
                        "Content-Type=text/json&" + params
                    //alert(url);

                    var that = this;
                    $.ajax({
                        url: url,
                        type: "POST",
                        async: false,
                        success: function(data, txt, jqXHR) {
                            that.getOpenDowntime();
                            //document.APLT_GRI_Downtime.refresh();                 
                            MessageBox.success(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0084"));

                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            MessageBox.error(jqXHR.responseText);
                        }
                    });

                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0096"));
                }
            },
            setDTReasonRow: function(type, catCode, equitype) {



                var oLSReasonListModel = this.getView().getModel("oLSReasonList");

                var oReasonTable = this.getView().byId("reasonListTableId");
                var oReasonData = oReasonTable.getItems();
                var that = this;

                oReasonData.forEach((item) => {

                    var sItemPath = item.getBindingContextPath();
                    var sCatCode = oLSReasonListModel.getProperty(sItemPath + "/CatCode");
                    var sEqType = oLSReasonListModel.getProperty(sItemPath + "/EquipmentCode");
                    var bSelected = false;

                    if (type === "F") {

                        if (sCatCode === catCode && sEqType === equitype) {
                            item.setSelected(true);
                            bSelected = true;
                        }
                    } else {

                        if (sCatCode === catCode) {
                            item.setSelected(true);
                            bSelected = true;
                        }
                    }

                    if (bSelected) {

                        var SADesc = oLSReasonListModel.getProperty(sItemPath + '/SADESC');
                        var TDesc = oLSReasonListModel.getProperty(sItemPath + '/TDESC');

                        that.getView().byId("category").setValue(TDesc);
                        that.getView().byId("reason").setValue(SADesc);


                    }

                });

            },


        });
    });