sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models",
        "com/khc/batchhub/model/formatter", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput", "sap/ui/core/Fragment"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter, Dialog, Button, DateTimeInput, Fragment) {
        var that;
        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var dt;
        return Controller.extend("com.khc.batchhub.controller.BatchProdDispatch", {
            formatter: formatter,
            onInit: function() {

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchProdDispatch").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },
            /*********************************************************************************************************************************************************************************/
            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },
            /*********************************************************************************************************************************************************************************/
            _oRoutePatternMatched: function(oEvent) {

                //Hide the messages and set busy to false

                UI_utilities.batchPageOpened(this, "common");
                //  UI_utilities.batchPageOpened(this,"BatchProdDispatch");
                this.oRoutePatternMatched();
            },
            /*********************************************************************************************************************************************************************************/
            oRoutePatternMatched: function() {
                //Set Model values
                this.getRouterDetails();
                //Load Tables
                this.getDispList();
                this.getCampList();
                dt = new Date();
                this.getView().byId("DispListscrollContainer").scrollTo(0, 0, 0);
                this.getView().byId("CampPoolscrollContainer").scrollTo(0, 0, 0)
            },
            /*********************************************************************************************************************************************************************************/
            getRouterDetails: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
            },
            /*********************************************************************************************************************************************************************************/
            getDispList: function() {
                var taskListQObj = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->getDispList-->XACQ_GetDispatchList");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + "0,1,2,4";
                var that = this;
                taskListQObj.attachRequestCompleted(
                    function() {
                        that.getView().setModel(taskListQObj, "DispList");
                    });

                taskListQObj.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetDispatchList&" + params +
                    "&Content-Type=text/json", "", false);

            },
            /*********************************************************************************************************************************************************************************/
            setDispCampStat: function() {
                var rowCount = this.getView().byId("id_DispList").getItems().length;
                var modelCount = CommonUtility.getJsonModelRowCount(this.getView().getModel("DispList").getData());
                if (rowCount > 0 && modelCount > 0) {
                    for (var j = 0; j < rowCount; j++) {
                        var dispList = this.getView().getModel("DispList").getData().Rowsets.Rowset[0].Row[j];
                        if (dispList.STATUS == "Running") {
                            var status = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0070");
                            this.getView().getModel("DispList").getData().Rowsets.Rowset[0].Row[j].STATUS = status;
                        } else if (dispList.STATUS == "Dispatched") {
                            var status = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0069");
                            this.getView().getModel("DispList").getData().Rowsets.Rowset[0].Row[j].STATUS = status;
                        } else if (dispList.STATUS == "Complete") {
                            var status = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0071");
                            this.getView().getModel("DispList").getData().Rowsets.Rowset[0].Row[j].STATUS = status;
                        }
                    }
                }
            },
            /*********************************************************************************************************************************************************************************/
            getCampList: function() {
                var CampPoolObj = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->getCampList-->XACQ_GetCampPoolList");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + "0";
                var that = this;
                CampPoolObj.attachRequestCompleted(
                    function() {
                        that.getView().setModel(CampPoolObj, "CampPool");
                    });

                CampPoolObj.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetCampPoolList&" + params +
                    "&Content-Type=text/json", "", false);
            },
            /*********************************************************************************************************************************************************************************/
            setCampPoolStat: function() {
                var rowCount = this.getView().byId("id_CampPool").getItems().length;
                var modelCount = CommonUtility.getJsonModelRowCount(this.getView().getModel("CampPool").getData());
                if (rowCount > 0 && modelCount > 0) {
                    for (var j = 0; j < rowCount; j++) {
                        var CampPoolList = this.getView().getModel("CampPool").getData().Rowsets.Rowset[0].Row[j];
                        if (CampPoolList.STATUS == "Scheduled") {
                            var status = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0069");
                            this.getView().getModel("CampPool").getData().Rowsets.Rowset[0].Row[j].STATUS = status;
                        }
                    }
                }
            },
            /*********************************************************************************************************************************************************************************/
            Runchart: function() {
                if (!this.oDispathRunChart) {
                    this.oDispathRunChart = sap.ui.xmlfragment("com.khc.batchhub.view.Fragments.DispatchRunChart", this);
                }
                this.oDispathRunChart.open();

                // window.open('../IRPT/DispatchRunChart.irpt?qs_resr='+resr+'&qs_plant='+plant+'&qs_crdest='+crdest , 'RunChart', 'width=730,height=500,scrollbars=yes,left=90,top=100,resizable=yes,status=yes,location=no,menubar=yes');
            },
            /*********************************************************************************************************************************************************************************/
            DispatchDetail: function() {
                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                    var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);

                    var orderid = DLSelectedRow.ORDERID;

                    if (orderid != "---") {
                        var msgid = DLSelectedRow.MSGID;
                        var plant = DLSelectedRow.PLANT;
                        var resr = DLSelectedRow.RESR;
                        var crdest = DLSelectedRow.CRDEST;
                        var orderid = DLSelectedRow.ORDERID;
                        var modorderid = DLSelectedRow.modORDERID;
                        var crid = DLSelectedRow.CRID;
                        var matnr = DLSelectedRow.modMATNR;
                        var mattext = DLSelectedRow.MATTEXT;
                        var status = DLSelectedRow.STATUSCLR;
                        var bcount = DLSelectedRow.BATCHCOUNT;
                        var bsize = DLSelectedRow.BATCHSIZE;

                        mattext = mattext.replace(/%/gi, "%25");

                        var RouterParamModel = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->DispatchDetail-->RouterParambatchDispDetails");
                        let sID = {
                            qs_msgid: msgid,
                            qs_plant: plant,
                            qs_resr: resr,
                            qs_crdest: crdest,
                            qs_orderid: orderid,
                            qs_modorderid: modorderid,
                            qs_crid: crid,
                            qs_matnr: matnr,
                            qs_bcount: bcount,
                            qs_bsize: bsize,
                            qs_mattext: mattext,
                            qs_status: status
                        }
                        RouterParamModel.setData(sID)
                        sap.ui.getCore().setModel(RouterParamModel, "BatchDispDetailParams")
                        this._oRouter.navTo("BatchDispDetail")
                        //window.location.href="BatchDispDetail.irpt?qs_msgid="+msgid+"&qs_plant="+plant+"&qs_resr="+resr+"&qs_crdest="+crdest+"&qs_orderid="+orderid+"&qs_modorderid="+modorderid+"&qs_crid="+crid+"&qs_matnr="+matnr+"&qs_bcount="+bcount+"&qs_bsize="+bsize+"&qs_mattext="+mattext+"&qs_status="+status;
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0043");
                        MessageBox.error(msg)
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0002");
                    MessageBox.error(msg)
                }
            },
            /*********************************************************************************************************************************************************************************/
            hold: function() {
                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                    var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);

                    var orderid = DLSelectedRow.ORDERID;
                    var status = DLSelectedRow.STATUSCLR;
                    var resr = DLSelectedRow.RESR;
                    if (status != 2) {
                        if (orderid != "---") {

                            var HoldCampaign = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchProdDispatch-->hold-->SQLQ_UpdHoldCampaign");
                            var params = "Param.1=" + resr + "&Param.2=" + orderid;
                            HoldCampaign.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/SQLQ_UpdHoldCampaign&" + params + "&Content-Type=text/json", "", false);

                            this.getDispList();
                            this.getCampList();
                        } else {
                            var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0041");
                            MessageBox.error(msg)
                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0042");
                        MessageBox.error(msg)
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0002");
                    MessageBox.error(msg)
                }

            },
            /*********************************************************************************************************************************************************************************/
            insert: function() {
                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;

                if (SelRow > 0) {
                    var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                    var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);
                    var plant = DLSelectedRow.PLANT;
                    var resr = DLSelectedRow.RESR;
                    var crdest = DLSelectedRow.CRDEST;
                    var orderid = DLSelectedRow.ORDERID;
                    var crid = DLSelectedRow.CRID;
                    var duration = DLSelectedRow.DURATION;
                    var schedate = DLSelectedRow.SCHEDATE;
                    var mattext = DLSelectedRow.MATTEXT;
                    var status = DLSelectedRow.STATUSCLR;
                    var enddate = DLSelectedRow.ENDDATE;

                    mattext = mattext.replace(/%/gi, "%25");
                    //var Url = "BatchInsertDispatch.irpt?qs_plant="+plant+"&qs_resr="+resr+"&qs_crdest="+crdest+"&qs_orderid="+orderid+"&qs_crid="+crid+"&qs_duration="+duration+"&qs_schedate="+schedate+"&qs_status="+status+"&qs_enddate="+enddate+"&qs_mattext="+mattext;
                    //window.open(Url, "InsertDispatch", 'width=450,height=350,scrollbars=no,left=200,top=220,resizable=no,status=yes,location=no');
                    //alert("BatchInsertDispatch.irpt")
                    this.openBatchInsertDispatch();
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0002");
                    MessageBox.error(msg)
                }
            },
            openBatchInsertDispatch: function() {
                if (!this.oBatchInsertDisp) {
                    this.oBatchInsertDisp = sap.ui.xmlfragment("com.khc.batchhub.view.Fragments.BatchInsertDispatch", this);
                }
                this.oBatchInsertDisp.open();
                this.BatchInsDispIniLoad()
            },
            /*********************************************************************************************************************************************************************************/
            movedown: function() {
                var TotalRows = CommonUtility.getJsonModelRowCount(this.getView().getModel("DispList").getData()) - 1;
                var oTable = this.getView().byId("id_DispList");

                var selectedindex = itemIndex = oTable.indexOfItem(oTable.getSelectedItem());

                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;
                if (SelRow > 0) {
                    var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                    var preDLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);

                    var preorderid = preDLSelectedRow.ORDERID;
                    var precrid = preDLSelectedRow.CRID;
                    var preduration = preDLSelectedRow.DURATION;
                    var preschedate = preDLSelectedRow.SCHEDATE;
                    var premattext = preDLSelectedRow.MATTEXT;
                    var prestatus = preDLSelectedRow.STATUSCLR;
                    var preenddate = preDLSelectedRow.ENDDATE;
                    var preplandate = preDLSelectedRow.STARTDATE;

                    if (TotalRows > selectedindex) {
                        if (mattext != "" || duration != "" || schedate != "" || enddate != "") {
                            var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                            var DLSelectedRow = this.getView().getModel("DispList").getProperty('/Rowsets/Rowset/0/Row/' + (selectedindex + 1));

                            var plant = DLSelectedRow.PLANT;
                            var resr = DLSelectedRow.RESR;
                            var crdest = DLSelectedRow.CRDEST;
                            var orderid = DLSelectedRow.ORDERID;
                            var crid = DLSelectedRow.CRID;
                            var duration = DLSelectedRow.DURATION;
                            var schedate = DLSelectedRow.SCHEDATE;
                            var mattext = DLSelectedRow.MATTEXT;
                            var status = DLSelectedRow.STATUSCLR;
                            var enddate = DLSelectedRow.ENDDATE;
                            var plandate = DLSelectedRow.STARTDATE;

                            if (orderid != preorderid || crid != precrid || mattext != premattext || duration != preduration) {
                                var APLT_CMD_MoveUp = models.createNewJSONModel(
                                    "com.khc.batchhub.controller.BatchProdDispatch-->movedown-->XACQ_MoveDispatchList");
                                var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + crdest + "&Param.4=" +
                                    orderid + "&Param.5=" + crid + "&Param.6=" + duration + "&Param.7=" + schedate + "&Param.8=" +
                                    mattext + "&Param.9=" + status + "&Param.10=" + enddate + "&Param.11=" + preorderid + "&Param.12=" +
                                    precrid + "&Param.13=" + preduration + "&Param.14=" + preschedate + "&Param.15=" + premattext +
                                    "&Param.16=" +
                                    prestatus + "&Param.17=" + preenddate + "&Param.18=" + plandate + "&Param.19=" + preplandate;
                                APLT_CMD_MoveUp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                    "/QueryTemplate/XACQ_MoveDispatchList&" + params + "&Content-Type=text/json", "", false);

                                //var message = document.APLT_CMD_MoveUp.getFirstValue('MESSAGE');
                                // Add error message

                                this.getDispList();
                            }
                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0004");
                        MessageBox.error(msg)
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0002");
                    MessageBox.error(msg)
                }
            },
            /*********************************************************************************************************************************************************************************/
            moveup: function() {
                var oTable = this.getView().byId("id_DispList");
                var selectedindex = itemIndex = oTable.indexOfItem(oTable.getSelectedItem());
                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;
                if (SelRow > 0) {

                    if (selectedindex > 0) {
                        var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                        var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);

                        var plant = DLSelectedRow.PLANT;
                        var resr = DLSelectedRow.RESR;
                        var crdest = DLSelectedRow.CRDEST;
                        var orderid = DLSelectedRow.ORDERID;
                        var crid = DLSelectedRow.CRID;
                        var duration = DLSelectedRow.DURATION;
                        var schedate = DLSelectedRow.SCHEDATE;
                        var mattext = DLSelectedRow.MATTEXT;
                        var status = DLSelectedRow.STATUSCLR;
                        var enddate = DLSelectedRow.ENDDATE;
                        var plandate = DLSelectedRow.STARTDATE;

                        var preDLSelectedRow = this.getView().getModel("DispList").getProperty('/Rowsets/Rowset/0/Row/' + (selectedindex - 1));

                        var preorderid = preDLSelectedRow.ORDERID;
                        var precrid = preDLSelectedRow.CRID;
                        var preduration = preDLSelectedRow.DURATION;
                        var preschedate = preDLSelectedRow.SCHEDATE;
                        var premattext = preDLSelectedRow.MATTEXT;
                        var prestatus = preDLSelectedRow.STATUSCLR;
                        var preenddate = preDLSelectedRow.ENDDATE;
                        var preplandate = preDLSelectedRow.STARTDATE;

                        if (orderid != preorderid || crid != precrid || mattext != premattext || duration != preduration) {
                            var APLT_CMD_MoveUp = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchProdDispatch-->MoveUp-->XACQ_MoveDispatchList");
                            var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + crdest + "&Param.4=" +
                                orderid + "&Param.5=" + crid + "&Param.6=" + duration + "&Param.7=" + schedate + "&Param.8=" +
                                mattext + "&Param.9=" + status + "&Param.10=" + enddate + "&Param.11=" + preorderid + "&Param.12=" +
                                precrid + "&Param.13=" + preduration + "&Param.14=" + preschedate + "&Param.15=" + premattext + "&Param.16=" +
                                prestatus + "&Param.17=" + preenddate + "&Param.18=" + plandate + "&Param.19=" + preplandate;
                            APLT_CMD_MoveUp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_MoveDispatchList&" + params + "&Content-Type=text/json", "", false);


                            // var message = document.APLT_CMD_MoveUp.getFirstValue('MESSAGE');
                            // Add error message
                            this.getDispList();
                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0003");
                        MessageBox.error(msg)
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0002");
                    MessageBox.error(msg)
                }
            },
            /*********************************************************************************************************************************************************************************/
            removefromlist: function() {
                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;

                if (SelRow > 0) {
                    var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                    var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);
                    var plant = DLSelectedRow.PLANT;
                    var resr = DLSelectedRow.RESR;
                    var crdest = DLSelectedRow.CRDEST;
                    var orderid = DLSelectedRow.ORDERID;
                    var crid = DLSelectedRow.CRID;
                    var duration = DLSelectedRow.DURATION;
                    var startdate = DLSelectedRow.STARTDATE;
                    var schedate = DLSelectedRow.SCHEDATE;
                    var mattext = DLSelectedRow.MATTEXT;
                    var status = DLSelectedRow.STATUSCLR;
                    var matnr = DLSelectedRow.MATNR;
                    var cstatus = 0;
                    if (status != 1 && status != 2 && status != 4) {
                        var APLT_CMD_RemoveDispatchList = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->removefromlist-->XACQ_RemoveDispatchList");
                        var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + crdest + "&Param.4=" +
                            orderid + "&Param.5=" + crid + "&Param.6=" + duration + "&Param.7=" + startdate + "&Param.8=" +
                            schedate + "&Param.9=" + mattext + "&Param.10=" + status + "&Param.11=" + cstatus + "&Param.12=" +
                            matnr + "&d=" + dt;

                        var that = this;
                        APLT_CMD_RemoveDispatchList.attachRequestCompleted(
                            function() {
                                that.getDispList();
                                that.getCampList();
                                if (CommonUtility.getJsonModelRowCount(APLT_CMD_RemoveDispatchList.getData()) > 0) {

                                    var message1 = APLT_CMD_RemoveDispatchList.getData().Rowsets.Rowset[0].Row[0].MESSAGE;

                                    if (message1 == "RUNNING") {
                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0071");
                                        MessageBox.success(msg)
                                    }
                                }

                            });
                        APLT_CMD_RemoveDispatchList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_RemoveDispatchList&" + params + "&Content-Type=text/json", "", false);

                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0040");
                        MessageBox.error(msg)
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0002");
                    MessageBox.error(msg)
                }
            },
            /*********************************************************************************************************************************************************************************/
            addtodispatch: function() {

                var CPSelRow = this.getView().byId("id_CampPool").getSelectedContextPaths().length;

                if (CPSelRow > 0) {
                    var CPSelRowPath = this.getView().byId("id_CampPool").getSelectedContextPaths()[0];
                    var CPSelectedRow = this.getView().getModel("CampPool").getProperty(CPSelRowPath);

                    var plant = CPSelectedRow.PLANT;
                    var resr = CPSelectedRow.RESR;
                    var crdest = CPSelectedRow.CRDEST;
                    var orderid = CPSelectedRow.ORDERID;
                    var crid = CPSelectedRow.CRID;
                    var duration = CPSelectedRow.DURATION;
                    var startdate = CPSelectedRow.STARTDATE;
                    var mattext = CPSelectedRow.MATTEXT;
                    var msgid = CPSelectedRow.MSGID;
                    var matnr = CPSelectedRow.MATNR;
                    var matqty = CPSelectedRow.MATQTY;
                    var targetspeed = CPSelectedRow.TARGETSPEED;
                    var uom = CPSelectedRow.UOM;
                    var prodspeed = CPSelectedRow.PRODSPEED;
                    var insplot = CPSelectedRow.INSPLOT;
                    var inspstatus = CPSelectedRow.INSPSTATUS;
                    var batchcount = CPSelectedRow.BATCHCOUNT;
                    var batchsize = CPSelectedRow.BATCHSIZE;
                    var prdunit = "";
                    var TotalRows = CommonUtility.getJsonModelRowCount(this.getView().getModel("DispList").getData())

                    if (TotalRows != 0) {
                        var APLT_CMD_AddtoDispatchList = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->addtodispatch-->XACQ_AddtoDispatchList");
                        var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + crdest + "&Param.4=" +
                            orderid + "&Param.5=" + crid + "&Param.6=" + duration + "&Param.7=" + startdate + "&Param.8=" +
                            mattext + "&Param.9=" + msgid + "&Param.10=" + matnr + "&Param.11=" + matqty + "&Param.12=" +
                            targetspeed + "&Param.13=" + uom + "&Param.14=" + prodspeed + "&Param.15=" + insplot + "&Param.16=" +
                            inspstatus + "&Param.17=" + batchcount + "&Param.18=" + batchsize;
                        APLT_CMD_AddtoDispatchList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_AddtoDispatchList&" + params + "&Content-Type=text/json", "", false);

                        // Refresh Grid
                        this.getDispList();
                        this.getCampList();

                        // Split Campaign
                        if (batchcount != "" && batchsize != "") {
                            var APLT_CMD_DisOrderBatch = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchProdDispatch-->addtodispatch-->XACQ_DispatchOrderBatch");
                            var params = "Param.1=" + msgid + "&Param.2=" + crid + "&Param.3=" + resr + "&Param.4=" +
                                crdest + "&Param.5=" + orderid + "&Param.6=" + plant + "&Param.7=" + prdunit + "&Param.8=" +
                                batchcount + "&Param.9=" + batchsize;
                            APLT_CMD_DisOrderBatch.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_DispatchOrderBatch&" + params + "&Content-Type=text/json", "", false);


                        } else {
                            var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0039");
                            MessageBox.error(msg)
                        }
                    } else {
                        mattext = mattext.replace(/%/gi, "%25");
                        // var Url = "BatchScheduleDateTime.irpt?qs_plant="+plant+"&qs_resr="+resr+"&qs_crdest="+crdest+"&qs_orderid="+orderid+"&qs_crid="+crid+"&qs_duration="+duration+"&qs_startdate="+startdate+"&qs_msgid="+msgid+"&qs_matnr="+matnr+"&qs_matqty="+matqty+"&qs_targetspeed="+targetspeed+"&qs_uom="+uom+"&qs_prodspeed="+prodspeed+"&qs_insplot="+insplot+"&qs_inspstatus="+inspstatus+"&qs_batchcount="+batchcount+"&qs_batchsize="+batchsize+"&qs_mattext="+mattext;
                        // window.open(Url, "ScheduledTime", 'width=400,height=220,scrollbars=no,left=300,top=250,resizable=no,status=yes,location=no');
                        // alert("BatchScheduleDateTime.irpt?")
                        this.openBatchScheduleDateTime();
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0001");
                    MessageBox.error(msg)
                }
            },
            /*********************************************************************************************************************************************************************************/
            /*BatchScheduledateTime.Fragment Functoins Start*/
            openBatchScheduleDateTime: function() {
                if (!this.oBatchScheduleDateTime) {
                    this.oBatchScheduleDateTime = sap.ui.xmlfragment("com.khc.batchhub.view.Fragments.BatchScheduleDateTime", this);
                }
                this.oBatchScheduleDateTime.open();
                //UI_utilities.DisableDatePickerInput(this.getView().byId("id_BatchSchDateTime"));
            },

            BatchSchDTAddtodispatch: function() {
                var CPSelRow = this.getView().byId("id_CampPool").getSelectedContextPaths().length;

                if (CPSelRow > 0) {
                    var CPSelRowPath = this.getView().byId("id_CampPool").getSelectedContextPaths()[0];
                    var CPSelectedRow = this.getView().getModel("CampPool").getProperty(CPSelRowPath);

                    var plant = CPSelectedRow.PLANT;
                    var resr = CPSelectedRow.RESR;
                    var crdest = CPSelectedRow.CRDEST;
                    var orderid = CPSelectedRow.ORDERID;
                    var crid = CPSelectedRow.CRID;
                    var duration = CPSelectedRow.DURATION;
                    var startdate = CPSelectedRow.STARTDATE;
                    var mattext = CPSelectedRow.MATTEXT;
                    var msgid = CPSelectedRow.MSGID;
                    var matnr = CPSelectedRow.MATNR;
                    var matqty = CPSelectedRow.MATQTY;
                    var targetspeed = CPSelectedRow.TARGETSPEED;
                    var uom = CPSelectedRow.UOM;
                    var prodspeed = CPSelectedRow.PRODSPEED;
                    var insplot = CPSelectedRow.INSPLOT;
                    var inspstatus = CPSelectedRow.INSPSTATUS;
                    var batchcount = CPSelectedRow.BATCHCOUNT;
                    var batchsize = CPSelectedRow.BATCHSIZE;
                    var plandate = sap.ui.getCore().byId("id_BatchSchDateTime").getValue();
                    var prdunit = "";
                    var APLT_CMD_AddtoDispatchList = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchProdDispatch-->BatchSchDTAddtodispatch-->XACQ_AddtoDispatchList");
                    var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + crdest + "&Param.4=" +
                        orderid + "&Param.5=" + crid + "&Param.6=" + duration + "&Param.7=" + startdate + "&Param.8=" +
                        mattext + "&Param.9=" + msgid + "&Param.10=" + matnr + "&Param.11=" + matqty + "&Param.12=" +
                        targetspeed + "&Param.13=" + uom + "&Param.14=" + prodspeed + "&Param.15=" + insplot + "&Param.16=" +
                        inspstatus + "&Param.17=" + batchcount + "&Param.18=" + batchsize + "&Param.19=" + plandate;
                    APLT_CMD_AddtoDispatchList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_AddtoDispatchList&" + params + "&Content-Type=text/json", "", false);

                    if (batchcount != "" && batchsize != "") {
                        var APLT_CMD_DisOrderBatch = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->BatchSchDTAddtodispatch-->XACQ_DispatchOrderBatch");
                        var params = "Param.1=" + msgid + "&Param.2=" + crid + "&Param.3=" + resr + "&Param.4=" +
                            crdest + "&Param.5=" + orderid + "&Param.6=" + plant + "&Param.7=" + prdunit + "&Param.8=" +
                            batchcount + "&Param.9=" + batchsize + "&Param.10=" + matnr + "&Param.11=" + matqty + "&Param.12=" +
                            targetspeed + "&Param.13=" + uom + "&Param.14=" + prodspeed + "&Param.15=" + insplot + "&Param.16=" +
                            inspstatus + "&Param.17=" + batchcount + "&Param.18=" + batchsize + "&Param.19=" + plandate;
                        APLT_CMD_DisOrderBatch.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_DispatchOrderBatch&" + params + "&Content-Type=text/json", "", false);
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0039");
                        MessageBox.error(msg)
                    }

                    this.oBatchScheduleDateTime.close();
                    this.oRoutePatternMatched();
                }

            },

            BatchSchDTBack: function() {
                this.oBatchScheduleDateTime.close();
            },
            /*********************************************************************************************************************************************************************************/
            /*BatchScheduledateTime.Fragment Functoins End*/

            /*BatchInsertDispatch.Fragment Functoins Start*/
            BatchInsDispIniLoad: function() {
                sap.ui.getCore().byId("id_txt_minute").setValue("00");
                var evecode = sap.ui.getCore().byId("EventId").setSelectedKey("");
                sap.ui.getCore().byId("id_RadioButtonA").setSelected(true)
                //this.GetDuration();         this is selection change event not onload event

                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;

                if (SelRow != 0) {
                    var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                    var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);

                    sap.ui.getCore().byId("BatchInsDisp_starttime").setValue(DLSelectedRow.SCHEDATE);
                }

                this.getDispatchEveCombo();
            },
            /*********************************************************************************************************************************************************************************/

            getDispatchEveCombo: function() {


                var APLT_BRO_DispatchEve = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchExecuteOrder-->getDispatchEveCombo-->SQLQ_GetDispatchEvent");
                var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + sLanguage.toUpperCase();

                APLT_BRO_DispatchEve.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetDispatchEvent&" +
                    params + "&Content-Type=text/json", "", false);

                sap.ui.getCore().setModel(APLT_BRO_DispatchEve, "oDispatchEvent");
            },
            /*********************************************************************************************************************************************************************************/
            GetDuration: function() {
                var lang = sap.ui.getCore().getModel("session").getData().Language.toUpperCase();
                var evecode = sap.ui.getCore().byId("EventId").getSelectedKey();
                if (evecode != "") {
                    var APLT_CMD_EventDur = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchProdDispatch-->GetDuration-->XACQ_GetDispatchEventDuration");
                    var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + lang + "&Param.4=" + evecode;
                    APLT_CMD_EventDur.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_GetDispatchEventDuration&" + params + "&Content-Type=text/json", "", false);

                    if (CommonUtility.getJsonModelRowCount(APLT_CMD_EventDur.getData()) > 0) {
                        var oDuration = APLT_CMD_EventDur.getData().Rowsets.Rowset[0].Row[0].O_DURATION;

                        sap.ui.getCore().byId("id_txt_minute").setValue(oDuration);
                    }
                } else {
                    sap.ui.getCore().byId("id_txt_minute").setValue("00");
                }
            },
            /*********************************************************************************************************************************************************************************/
            gettimeFragment: function(val) {
                var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
                    var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);

                    var adate = DLSelectedRow.SCHEDATE;
                    var bdate = DLSelectedRow.ENDDATE;

                    if (val.getSource().getId() == "id_RadioButtonB") {
                        sap.ui.getCore().byId("BatchInsDisp_starttime").setValue(bdate);
                    } else {
                        sap.ui.getCore().byId("BatchInsDisp_starttime").setValue(adate);
                    }
                }
            },
            /*********************************************************************************************************************************************************************************/
            batchInsDispInsert: function() {
                var mattext = sap.ui.getCore().byId("EventId")._getSelectedItemText()
                var flag = 0;
                var flag1 = 0;
                var schedate = sap.ui.getCore().byId("BatchInsDisp_starttime").getValue();
                /*var SelRow = this.getView().byId("id_DispList").getSelectedContextPaths().length;
       if (SelRow != 0) {
			var DLSelRow = this.getView().byId("id_DispList").getSelectedContextPaths()[0];
			var DLSelectedRow = this.getView().getModel("DispList").getProperty(DLSelRow);
  		
  		if (sap.ui.getCore().byId("id_RadioButtonA").getSelected()) {
  			 schedate = DLSelectedRow.SCHEDATE;
  		} else if (sap.ui.getCore().byId("id_RadioButtonB").getSelected()) {
  			 schedate = DLSelectedRow.ENDDATE;
  		}*/

                if (mattext == "" || mattext == null) {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0104");
                    MessageBox.error(msg)
                    flag = 1;
                }

                if (flag == 0) {
                    if (isNaN(sap.ui.getCore().byId("id_txt_minute").getValue())) {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0105");
                        MessageBox.error(msg)
                        flag1 = 1;
                    }

                    var minute = sap.ui.getCore().byId("id_txt_minute").getValue();
                    var interval = minute * 60;

                    if (flag1 == 0) {
                        if (interval == "" || interval == 0) {
                            var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0106");
                            MessageBox.error(msg)
                            flag1 = 1;
                        }
                    }

                    if (flag1 == 0) {

                        var APLT_CMD_InsDispatchList = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->batchInsDispInsert-->XACQ_InsDispatchList");
                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" +
                            " " + "&Param.5=" + " " + "&Param.6=" + interval + "&Param.7=" + schedate + "&Param.8=" +
                            schedate + "&Param.9=" + mattext + "&Param.10=" + '0';
                        APLT_CMD_InsDispatchList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_InsDispatchList&" + params + "&Content-Type=text/json", "", false);
                        this.getDispList();
                        this.batchInsDispCloseDialog()

                    }
                }
                //}
            },
            /*********************************************************************************************************************************************************************************/
            batchInsDispCloseDialog: function() {
                this.oBatchInsertDisp.close();
            },
            /*********************************************************************************************************************************************************************************/
            /*BatchInsertDispatch.Fragment Functoins End*/
            insertBackFragment: function() {
                //window.close();

            },
            /*********************************************************************************************************************************************************************************/
            DispRunChart: function() {
                var APLT_CHA_DispRun = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->DispRunChart-->XACQ_DispatchRunChart");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                APLT_CHA_DispRun.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_DispatchRunChart&" + params + "&Content-Type=text/json", "", false);

                sap.ui.getCore().setModel(APLT_CHA_DispRun, "DispatchRunChart")
                this.getView().setModel(APLT_CHA_DispRun, "DispatchRunChart");
            },
            /*********************************************************************************************************************************************************************************/
            DispRunChartCloseDialog: function() {
                this.oDispathRunChart.close();
            },
        });
    });