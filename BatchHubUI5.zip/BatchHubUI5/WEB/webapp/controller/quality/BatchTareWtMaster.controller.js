sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "sap/m/Dialog", 
      "sap/m/Button", "sap/m/DateTimeInput","com/khc/batchhub/model/formatter",  "com/khc/batchhub/model/models"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, Dialog, Button, DateTimeInput,formatter, models) {
        "use strict";
   var plant;
   var resource;
   var resourceText;
   var projectName;
   var dt;
   
   var selectedRes;
   var TareWTID;
     return Controller.extend("com.khc.batchhub.controller.quality.BatchTareWtMaster", {
      formatter:formatter,
            onInit: function() {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchTareWtMaster").attachPatternMatched(this._oRoutePatternMatched, this);

            },
/**************************************************************************************************************************************************************************************/
            _oRoutePatternMatched: function(oEvent) {
            
                UI_utilities.batchPageOpened(this, "BatchTareWtMaster");
       UI_utilities.qualityMenuBar();
      plant=sap.ui.getCore().getModel("session").oData.CA_Plant
      resource=sap.ui.getCore().getModel("session").oData.CA_Resource
      resourceText=sap.ui.getCore().getModel("session").oData.CA_ResrText
      projectName=sap.ui.getCore().getModel("session").oData.CA_ProjectName
   
         var oDisplayData = {
               selectedOption : "TareWtData"
            };
            var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
            this.getView().setModel(oDisplayOptionModel,"displayOption");
   
      dt=new Date();
   
      this.getResource();
      this.loadResrFromSession();
      this.getTareWtList();
      
      this.getMaterialListForResource();
      //this.setVisibility();
                },

/**************************************************************************************************************************************************************************************/
   menuSelected : function (oEvent) {
         
         // Navigate the the selected menu page
         
         var sKey = oEvent.getParameters().key;
         UI_utilities.openMenu(this._oRouter,this,sKey);
         
            },
/**************************************************************************************************************************************************************************************/
setVisibility:function(){
   let selectedTareWT=this.getView().byId("txt_TWIDList").getSelectedKey();
   if(selectedTareWT==""){
      this.getView().getModel("displayOption").setProperty("/selectedOption","NoTareWtData");
   }
   else{
      this.getView().getModel("displayOption").setProperty("/selectedOption","TareWtData");
   }
},
/*************************************************************************************************************************************************************************************/
//On page load,load the Resource combobox
/**************************************************************************************************************************************************************************************/
getResource:function(){
   //this.getView().byId("txt_TWID").setVisible(false);
   var resourceDD = this.getView().byId("resource");
    var resourceModel = models.createNewXMLModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->getResource-->XACQ_GetResrByPlant");
         resourceModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetResrByPlant&Param.1="+plant+"&d="+new Date()+"&Content-Type=text/xml", "", false);
         resourceDD.setModel(resourceModel, "oresource");
   this.getMaterialListForResource();
},
/*************************************************************************************************************************************************************************************/
//On page load, Set the resource
/**************************************************************************************************************************************************************************************/
loadResrFromSession:function(){
    this.getView().byId("resource").setSelectedKey(resource);
   selectedRes=this.getView().byId("resource").getSelectedKey();
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
getTareWtList:function(){
   this.getView().byId("txt_TWID").setVisible(false);
   this.getView().byId("txt_TWIDList").setVisible(true);
   selectedRes=this.getView().byId("resource").getSelectedKey();
    var tareWtListModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->getTareWtList-->SQLQ_GetTareWtIDList");
   var tareWtDD = this.getView().byId("txt_TWIDList");
   var that=this;
   tareWtListModel.attachRequestCompleted(
          function(){ 
            tareWtDD.setModel(tareWtListModel, "oTareWt");
            if(CommonUtility.getJsonModelRowCount(tareWtListModel.getData())){
            
            that.getView().byId("txt_TWIDList").setSelectedKey(tareWtListModel.getData().Rowsets.Rowset[0].Row[0].TAREWEIGHTID);
         }
            else{
                sap.ui.getCore().setModel( new sap.ui.model.json.JSONModel(),"oTareWt");
            }    
          });
  
         tareWtListModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetTareWtIDList&Param.1="+plant+"&Param.2="+selectedRes+"&d="+new Date()+"&Content-Type=text/json", "", false);
   
   this.getMICList();
   this.getTareWtMaster();
   this.getMaterialListForResource();
      this.setVisibility();
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
getMICList:function(){
   
    var MICListModel = models.createNewXMLModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->getMICList-->SQLQ_GetInspCharList");
      var charListDD = this.getView().byId("charList");
         MICListModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetInspCharList&Param.1="+plant+"&Param.2="+selectedRes+"&d="+new Date()+"&Content-Type=text/xml", "", false); 
         charListDD.setModel(MICListModel, "oCharList");
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
getTareWtMaster:function(){
   
   let selectedTareWT=this.getView().byId("txt_TWIDList").getSelectedKey();
    var tareWtMasterModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->getTareWtMaster-->XACQ_GetTareWeightMaster");
   var that=this;
   tareWtMasterModel.attachRequestCompleted(
          function(){ 
         if(CommonUtility.getJsonModelRowCount(tareWtMasterModel.getData())){
         let spath=tareWtMasterModel.getData().Rowsets.Rowset[0].Row[0];   
         
   that.getView().byId("txt_TWdesc").setValue(spath.TareWtDesc);
   that.getView().byId("txt_TWlife").setValue(spath.Life);
   that.getView().byId("unitdropdownid").setSelectedKey(spath.LifeUnit);
   that.getView().byId("txt_method").setValue(spath.Method);
   that.getView().byId("txt_sample").setValue(spath.Sample);
   that.getView().byId("txt_lowPlauseLmt").setValue(spath.LowerPlausiblelimit);
   that.getView().byId("txt_uppPlauseLmt").setValue(spath.UpperPlausibleLimit);
   that.getView().byId("plauseunitdropdownid").setSelectedKey(spath.PlausibleUnit);
   that.getView().byId("charList").setSelectedKey(spath.MIC);  
   }
   });
   
         tareWtMasterModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetTareWeightMaster&Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+selectedTareWT+"&d="+new Date()+"&Content-Type=text/json", "", false);
      
   this.getTableInfo(selectedRes,selectedTareWT);
   
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
getTableInfo:function(selectedRes,selectedTareWT){

    var linkedMatChartModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->getTableInfo-->SQLQ_GetLinkedMaterial");
         linkedMatChartModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_GetLinkedMaterial&Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+selectedTareWT+"&d="+new Date()+"&Content-Type=text/json", "", false);
   this.getView().setModel(linkedMatChartModel,"oLinkedMat")   

},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
getMaterialListForResource:function(){
   var that=this;
   let matListDD=this.getView().byId("materials");
   
    var matListModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->getMaterialListForResource-->XACQ_GetMaterialforResource");
   matListModel.attachRequestCompleted(
          function(){  
            matListDD.setModel(matListModel, "oMatList");
      if(CommonUtility.getJsonModelRowCount(matListModel.getData())){
          
      that.getView().byId("materials").setSelectedKey(matListModel.getData().Rowsets.Rowset[0].Row[0].MATERIAL);
      }
      else{
        sap.ui.getCore().setModel( new sap.ui.model.json.JSONModel(),"oMatList");
      }
   });
   
         matListModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetMaterialforResource&Param.1="+plant+"&Param.2="+selectedRes+"&d="+new Date()+"&Content-Type=text/json", "", false);
   
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
addTareWtMast:function(){
   let MIC=this.getView().byId("charList").getSelectedKey();
   let lifeunit=this.getView().byId("unitdropdownid").getSelectedKey();
   let plauseUnit=this.getView().byId("plauseunitdropdownid").getSelectedKey();
   let twID=this.getView().byId("txt_TWID").getValue();
   let twDesc=this.getView().byId("txt_TWdesc").getValue();
   let twLife=this.getView().byId("txt_TWlife").getValue()
   let method=this.getView().byId("txt_method").getValue();
   let sample=this.getView().byId("txt_sample").getValue();
   let lowPlauseLmt=this.getView().byId("txt_lowPlauseLmt").getValue();
   let uppPlauseLmt=this.getView().byId("txt_uppPlauseLmt").getValue();
   

   this.getView().byId("txt_TWID").setVisible(true);
   if(this.getView().byId("txt_TWIDList").getVisible()){
      this.getView().byId("txt_TWIDList").setVisible(false);
      this.getView().byId("txt_TWdesc").setValue("");
      this.getView().byId("txt_TWID").setValue("");
      this.getView().byId("txt_TWlife").setValue("");
      this.getView().byId("txt_method").setValue("");
      this.getView().byId("txt_sample").setValue("");
      this.getView().byId("txt_lowPlauseLmt").setValue("");
      this.getView().byId("txt_uppPlauseLmt").setValue("");
      this.getView().byId("charList").setSelectedKey("");
      this.getView().getModel("displayOption").setProperty("/selectedOption","Yes");
   }
   else if(MIC==""){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0186");
      MessageBox.alert(msg, {title: "Alert", });
   }
   else if(this.getView().byId("txt_TWID").getValue()==""){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0152");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(isNaN(twLife) || twLife=="" || twLife=="0"){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0148");
      MessageBox.error(msg, {title: "Error", });
      
   }
   else if(isNaN(sample) || sample=="" || sample=="0"){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0149");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(isNaN(lowPlauseLmt) || lowPlauseLmt==""){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0150");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(isNaN(uppPlauseLmt) || uppPlauseLmt==""){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0151");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(uppPlauseLmt<lowPlauseLmt){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0177");
      MessageBox.error(msg, {title: "Error", });
   }
   else{
    var checkTareWtIDModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->addTareWtMast-->SQLQ_CheckTareWtID");
   let checkTareWtIDParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+twID+"&d="+dt;
          checkTareWtIDModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_CheckTareWtID&"+checkTareWtIDParam+"&Content-Type=text/json", "", false);
         
   if(CommonUtility.getJsonModelRowCount(checkTareWtIDModel.getData())==1){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0174")+": "+checkTareWtIDModel.getData().Rowsets.Rowset[0].Row[0].MIC;
      MessageBox.error(msg, {title: "Error", });
      return;
   }
   
   let rowCountMIC=this.CheckTareWtMasterMIC(selectedRes,MIC);
   if(rowCountMIC==1){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0175")+": "+TareWTID;
      MessageBox.error(msg, {title: "Error", });
      return;
   }
    var createTareWTMasterModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->addTareWtMast-->XACQ_InsTareWeightMaster");
   let createTareWTParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+twID+"&Param.4="+twDesc+"&Param.5="+twLife+"&Param.6="+lifeunit+"&Param.7="+method+"&Param.8="+sample+"&Param.9="+lowPlauseLmt+"&Param.10="+uppPlauseLmt+"&Param.11="+plauseUnit+"&Param.12="+MIC+"&d="+dt;
    createTareWTMasterModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_InsTareWeightMaster&"+createTareWTParam+"&d="+new Date()+"&Content-Type=text/json", "", false);
      
   if(CommonUtility.getJsonModelRowCount(createTareWTMasterModel.getData())){
      let status=createTareWTMasterModel.getData().Rowsets.Rowset[0].Row[0].InsertSuccessStatus
      if(status=="1"){
      
      let msg=sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0153");
          MessageBox.success(msg, {title: "Success", });
            this.getTareWtList();
      }
   }
   
   }
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
updateTareWtMaster:function(){
   let MIC=this.getView().byId("charList").getSelectedKey();
   let lifeunit=this.getView().byId("unitdropdownid").getSelectedKey();
   let plauseUnit=this.getView().byId("plauseunitdropdownid").getSelectedKey();
   let twIDList=this.getView().byId("txt_TWIDList").getSelectedKey();
   let twDesc=this.getView().byId("txt_TWdesc").getValue();
   let twLife=this.getView().byId("txt_TWlife").getValue()
   let method=this.getView().byId("txt_method").getValue();
   let sample=this.getView().byId("txt_sample").getValue();
   let lowPlauseLmt=this.getView().byId("txt_lowPlauseLmt").getValue();
   let uppPlauseLmt=this.getView().byId("txt_uppPlauseLmt").getValue();
   
   this.getView().byId("txt_TWID").setVisible(false);
   
   if(MIC==""){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0186");
      MessageBox.alert(msg, {title: "Alert", });
   }
   else if(isNaN(twLife) || twLife=="" || twLife=="0"){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0148");
      MessageBox.error(msg, {title: "Error", });
      
   }
   else if(isNaN(sample) || sample=="" || sample=="0") {
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0149");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(isNaN(lowPlauseLmt || lowPlauseLmt=="")){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0150");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(isNaN(uppPlauseLmt) || uppPlauseLmt==""){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0151");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(uppPlauseLmt<lowPlauseLmt){
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0177");
      MessageBox.error(msg, {title: "Error", });
   }
   else if(!this.getView().byId("txt_TWIDList").getVisible()){
      this.getView().byId("txt_TWIDList").setVisible()
   }
   else{
   let rowCountMIC=this.CheckTareWtMasterMIC(selectedRes,MIC);
   if(rowCountMIC==1){
         if(twIDList != TareWTID){
         let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0176")+": "+TareWTID;
         MessageBox.error(msg, {title: "Error", });
         return;
         }
      }
   
    var updateTareWTMasterModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->updateTareWtMaster-->XACQ_UpdateTareWeightMaster");
   let updateTareWTParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+twIDList+"&Param.4="+twDesc+"&Param.5="+twLife+"&Param.6="+lifeunit+"&Param.7="+method+"&Param.8="+sample+"&Param.9="+lowPlauseLmt+"&Param.10="+uppPlauseLmt+"&Param.11="+plauseUnit+"&Param.12="+MIC+"&d="+dt;
   updateTareWTMasterModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_UpdateTareWeightMaster&"+updateTareWTParam+"&d="+new Date()+"&Content-Type=text/json", "", false);
   
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0154")+": "+TareWTID;
   MessageBox.success(msg, {title: "Success", });
   }
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
deleteTareWtMaster:function(){
      this.getView().byId("txt_TWID").setVisible(false);
      
      if(this.getView().byId("txt_TWIDList").getVisible()){
         let SelTareWTID=this.getView().byId("txt_TWIDList").getSelectedKey();
         
      var checkTareWtUsageModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->deleteTareWtMaster-->XACQ_GetTareWtUsage");
      let checkTareWtUsageParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+SelTareWTID+"&d="+dt;
      checkTareWtUsageModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_GetTareWtUsage&"+checkTareWtUsageParam+"&Content-Type=text/json", "", false);
      let linkedmaterial=checkTareWtUsageModel.getData().Rowsets.Rowset[0].Row[0].LinkedMaterial
      
       if(linkedmaterial.length != 0) {
                           if(linkedmaterial == "TareWeightChecked")  {
            let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0159");
            MessageBox.error(msg, {title: "Error", });
         }
         else{
            let that=this;
            let msg= sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0158")+" "+SelTareWTID+" "+ sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0160")
          MessageBox.warning(
                          msg, {
                              icon: MessageBox.Icon.WARNING,
                              title: "Message from webpage",
                              actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                              onClose: function(oAction) {
                                  if (oAction === "OK") {
                                    that.deleteTareWt(SelTareWTID,linkedmaterial);
                                  }
                              }
                          });
         }
      }
      else{
           this.deleteTareWt(SelTareWTID,linkedmaterial);
      }
      }  
      else{
       this.getView().byId("txt_TWIDList").setVisible()
      }
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
deleteTareWt:function(SelTareWTID,linkedmaterial){
   var deleteTareWtmatLinkModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->deleteTareWt-->XACQ_DelTareWeightMaterialLink");
   let deleteTareWtmatLinkParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+SelTareWTID+"&Param.4="+linkedmaterial+"&d="+dt;
   deleteTareWtmatLinkModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_DelTareWeightMaterialLink&"+deleteTareWtmatLinkParam+"&Content-Type=text/json", "", false);
   

   var deleteTareWtModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->deleteTareWt-->XACQ_DelTareWeightMaster");
   let deleteTareWtParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+SelTareWTID+"&d="+dt;
   deleteTareWtModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_DelTareWeightMaster&"+deleteTareWtParam+"&Content-Type=text/json", "", false);
   
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0155");
   MessageBox.success(msg, {title: "Success", });
   this.getTareWtList();
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
CheckTareWtMasterMIC:function(selectedRes,MIC){
   
   var checkTareWtMasterMICModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->CheckTareWtMasterMIC-->SQLQ_CheckTareWtMIC");
   let checkTareWtMasterMICParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+MIC+"&d="+dt;
   checkTareWtMasterMICModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/SQLQ_CheckTareWtMIC&"+checkTareWtMasterMICParam+"&Content-Type=text/json", "", false);
   let count=CommonUtility.getJsonModelRowCount(checkTareWtMasterMICModel.getData());
   if(count>0){
   TareWTID=checkTareWtMasterMICModel.getData().Rowsets.Rowset[0].Row[0].TAREWEIGHTID
   }
   return count;
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
updateTWExpiry:function(){
   let chardesc=this.getView().byId("charList").getSelectedKey();
   
   var TareWeightCheckModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.BatchTareWtMaster-->updateTWExpiry-->XACQ_TWCheck");
   let TareWeightCheckParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.4="+chardesc+"&d="+dt;
   TareWeightCheckModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_TWCheck&"+TareWeightCheckParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(TareWeightCheckModel.getData())){

   let spath=TareWeightCheckModel.getData().Rowsets.Rowset[0].Row[0];

   if(spath.TareWeightID!=""){
   var oTareWtModel = new sap.ui.model.json.JSONModel();
   let sID={
         qs_TareWeightID:spath.TareWeightID,
         qs_TareWeightDesc:spath.TareWeightDesc,
         qs_Life:spath.Life,
         qs_Unit:spath.Unit,
         qs_Method:spath.Method,
         qs_SampleSize:spath.SampleSize,
         qs_UpperPausibleLimit:spath.UpperPausibleLimit,
         qs_LowerPausibleLimit:spath.LowerPausibleLimit,
         qs_PausibleUnitLife:spath.PausibleUnit,
         qs_LastRecordedDate:spath.LastRecordedDate,
         qs_TW_LastRecdValue:spath.TW_LastRecdValue,
         qs_ExpiryDate:spath.ExpiryDate,
         qs_ExpiryStatus:spath.ExpiryStatus
   }
   oTareWtModel.setData(sID)
   sap.ui.getCore().setModel(oTareWtModel,"oTareWtParam")   

   this._oRouter.navTo("BatchTareWtcheck_1");   
   }
   
   else{
   let msg = "Please create Tare Weight before checking it";
   MessageBox.success(msg, {title: "Success", });
   }
   }
},
/*************************************************************************************************************************************************************************************/

/**************************************************************************************************************************************************************************************/
linkMaterial:function(){
   let SelTareWTID=this.getView().byId("txt_TWIDList").getSelectedKey();
      
   if(SelTareWTID == ""){
    let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0178");
    MessageBox.error(msg, {title: "Error", });
   }
   else{
      let matnr=this.getView().byId("materials").getSelectedKey();
      let matwithdesc=this.getView().byId("materials").getProperty("value");
       let matlength = matnr.length;
       let matwithdeslength = matwithdesc.length ;
      //let descleng = matwithdeslength - (matlength + 3);
        let matdescr = matwithdesc.slice(matlength+2,matwithdeslength -1);

   var TareWtMatLinkModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->linkMaterial-->XACQ_InsTareWtMaterialLink");
   let TareWtMatLinkParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+SelTareWTID+"&Param.4="+matnr+"&Param.5="+matdescr+"&d="+dt;
   TareWtMatLinkModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_InsTareWtMaterialLink&"+TareWtMatLinkParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(TareWtMatLinkModel.getData())){
      let selectedTareWT=this.getView().byId("txt_TWIDList").getSelectedKey();
      this.getTableInfo(selectedRes,selectedTareWT);
      let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0157");
      MessageBox.success(msg, {title: "Success", });
      
   }
   else{
      var ExistMatModel = models.createNewJSONModel("com.khc.batchhub.controller.quality.batchTareWtMaster-->linkMaterial-->XACQ_ExistMaterialTWLink");
   let ExistMatParam= "Param.1="+plant+"&Param.2="+selectedRes+"&Param.3="+matnr+"&d="+dt;
   ExistMatModel.loadData("/XMII/Illuminator?QueryTemplate="+projectName+"/QueryTemplate/XACQ_ExistMaterialTWLink&"+ExistMatParam+"&Content-Type=text/json", "", false);
   if(CommonUtility.getJsonModelRowCount(ExistMatModel.getData())){
   let tareWt=ExistMatModel.getData().Rowsets.Rowset[0].Row[0].TareWeightAlreadyLinked
   let msg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0161")+" "+matnr+" "+sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0162")+tareWt+" "+sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0163");
      MessageBox.success(msg, {title: "Success", });
   }
      
   }
   }
   
}

    });
});