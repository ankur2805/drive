 sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models",
        "com/khc/batchhub/model/formatter", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput", "sap/ui/core/Fragment"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter, Dialog, Button, DateTimeInput, Fragment) {
     
        "use strict";
        var plant;
        var resource;
        var projectName;
        var shiftname = '';
        var shiftId = '';
        var teamId = '';
        var shiftStartTime = '';
        var shiftEndTime = '';
        var oDownTimeData;
        var sDTStartDateFormatted;
        var userName;
        var crdest;

 var autoRefresh;
      // from session
      var count = 0;
      var colorDark = "";
      var colorLight = "";
      var warning = ""; 
	 var inSplot1;
	var insporder;
      var js_LoopCount = 0;

        var InspectPoint;
        var txt_Mat;
        var crid;
        var txt_Ord;

        return Controller.extend("com.khc.batchhub.controller.quality.InspectionPoint", {
            formatter: formatter,
            onInit: function() {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("InspectionPoint").attachPatternMatched(this._oRoutePatternMatched, this); 

                var oInscPointRoute = {
                    qs_phs: '',
                    qs_currenttime: ""
                };
                var oInscPointRouteModel = new sap.ui.model.json.JSONModel(oInscPointRoute);
                sap.ui.getCore().setModel(oInscPointRouteModel, "InspPointRoute")
            }, 
            _oRoutePatternMatched: function(oEvent) {

                UI_utilities.batchPageOpened(this, "InspectionPoint");

                this.routerPatternMatched();

            },

            routerPatternMatched: function() {
 this.getView().byId("id_txt_ordstrip").setValue("");
                  txt_Ord = "";
                  crid = "";
                  txt_Mat = "";
                  this.getView().byId("id_txt_matstrip").setValue("");
                  this.getView().byId("id_txt_mattext").setValue("");
                  inSplot1 = "";
                  this.getView().byId("id_txt_insplot").setValue("");

autoRefresh=true;

                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", false);
                var oInsPointData = {
                    orderId: '',
                    crid: '',
                    newInspButton: true,
                    updateButton: true, 
                };
                var oInsPointModel = new sap.ui.model.json.JSONModel(oInsPointData);
                sap.ui.getCore().setModel(oInsPointModel, "InsPointDetails")
                
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;

                var oEmptyModel = new sap.ui.model.json.JSONModel();
                sap.ui.getCore().setModel(oEmptyModel, "PhasesNextTime");
                sap.ui.getCore().setModel(oEmptyModel, "InspectPointList");

                this.getRunningShift();
                this.getRunningOrder();
                /*if (sap.ui.getCore().getModel("oRedirectFromChildPage").getProperty("/Parent_Page") == true) {
                    // sap.ui.getCore().getModel("oRedirectFromChildPage").setProperty("/Parent_Page",false)
                } else {
                    sap.ui.getCore().setModel(oEmptyModel, "InspectPointList");
                    sap.ui.getCore().getModel("InspectionPointRoute").setProperty("/qs_phs", "")
                }*/ 
                // Set session row from route
                this.selectSessionPhase();
            },

            // on Load get the running shift details
            getRunningShift: function() {

                var oModelRunningShiftDetails = models
                    .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningShift-->XACQ_GetRunningShift");
                var that = this;
                oModelRunningShiftDetails.attachRequestCompleted(function() {

                    that.getView().setModel(oModelRunningShiftDetails, "oRunningShiftList");
                    if (CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData()) > 0) {
                        var oRunningShiftData = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
                        shiftname = oRunningShiftData.SHIFTNAME;
                        shiftStartTime = oRunningShiftData.STARTTIME;
                        shiftEndTime = oRunningShiftData.ENDTIME;
                        shiftId = oRunningShiftData.SHIFTID;
                        teamId = oRunningShiftData.TEAMID;
                    } else {
                        var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                    }
                });

                oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetRunningShift&Param.1=" + plant + "&Param.2=" + resource + "&d="+new Date()+"&Content-Type=text/json",
                    "", false);

            },
 
 
            getRunningOrder: function() {

                var that = this;
                // getOrder Details count

                var oModelRuningOrder = models
                    .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningOrder-->XACQ_GetRunningOrderOpenInsp");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest +"&d="+new Date();
                oModelRuningOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetRunningOrderOpenInsp&" + params + "&Content-Type=text/json", "", false);
                var orderCount;
                if (CommonUtility.getJsonModelRowCount(oModelRuningOrder.getData()) > 0 ) {
                    var OrerForInsp = oModelRuningOrder.getData().Rowsets.Rowset[0].Row[0];
                    var orderCount = oModelRuningOrder.getData().Rowsets.Rowset[0].Row.length;

                    if (orderCount != 0) {
                        insporder = OrerForInsp.ORDERID;
                        that.getView().byId("id_txt_ordstrip").setValue(OrerForInsp.MODORDERID);
                        // that.getView().byId("id_txt_ord").setValue(insporder);
                        txt_Ord = OrerForInsp.ORDERID;
                        crid = OrerForInsp.CRID
                        // that.getView().byId("id_hid_crid").setValue(crid);
                        // that.getView().byId("id_txt_mat").setValue(OrerForInsp.MATNR);
                        txt_Mat = OrerForInsp.MATNR
                        that.getView().byId("id_txt_matstrip").setValue(OrerForInsp.MODMATNR);
                        that.getView().byId("id_txt_mattext").setValue(OrerForInsp.MATTEXT);
                        var inSplot = OrerForInsp.INSPLOT;
		inSplot1 = OrerForInsp.INSPLOT;
                        that.getView().byId("id_txt_insplot").setValue(inSplot);

                        // getOrder Details count

                        var oOrderListModel = models
                            .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningOrder-->XACQ_GetRunningOrder");

                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest +"&d="+new Date();
                        oOrderListModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetRunningOrder&" + params + "&Content-Type=text/json", "", false);

                        if (CommonUtility.getJsonModelRowCount(oOrderListModel.getData()) > 0 ) {
 
                            var OrerForInsp = oOrderListModel.getData().Rowsets.Rowset[0].Row;

                            var runningorder = OrerForInsp[0].ORDERID;
                            if (runningorder != "" && runningorder != "---") {
                                if (runningorder != insporder) {
                                   /* var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0122");
                                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Warning");
                                */}
                            }

                        }
this.getPhaseDetails();
               

                    } else {
                        var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0013");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                        that.getView().getModel("InsPointDetails").setProperty("/newInspButton", true)
                        that.getView().getModel("InsPointDetails").setProperty("/updateButton", true) 

                    }

                } else {
                    var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0013");
                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sNoShiftMsg);
                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                    that.getView().getModel("InsPointDetails").setProperty("/newInspButton", false)
                    that.getView().getModel("InsPointDetails").setProperty("/updateButton", false) 

                }

            },

             getPhaseDetails:function(){
			
		    var date = CommonUtility.getCurrentDateTime(new Date());

   var date = CommonUtility.getCurrentDateTime(new Date());

                        // getOrder Details count

                        var oPhasesNextTime = models
                            .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningOrder-->XACQ_GetPhaseNextTime");

                        var params = "Param.1=" + inSplot1 + "&Param.2=" + insporder + "&Param.3=" + plant + "&Param.4=" + resource +
                            "&Param.5=" + date + "&Param.6=" + crid +"&d="+date;
                        oPhasesNextTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetPhaseNextTime_ALL&" + params + "&Content-Type=text/json", "", false);
 
                            sap.ui.getCore().setModel(null, "PhasesNextTime");
                            sap.ui.getCore().setModel(oPhasesNextTime, "PhasesNextTime");

                 
		this.autoRefreshTable();
		
	},

	autoRefreshTable:function(){
		if(autoRefresh==true){
			var that = this;
				let dur= sap.ui.getCore().getModel("session").oData.CA_AutoRefreshQualityPhase;
				if(isNaN(dur)){dur=3;}
				dur=dur*60000;
				setTimeout(function(){that.getPhaseDetails(); }, dur);
				this.getView().byId("APLT_CMD_GetPhasesNextTime").removeSelections(true);
				let oEmptyModel = new sap.ui.model.json.JSONModel();
             			 sap.ui.getCore().setModel(oEmptyModel, "InspectPointList");
				   
		}

	},

            // **** Populates the inspection points in
            // APLT_GRI_InspectPoint taken from HNZ_INSPPOINT table
            // based on phase selected in APLT_CMD_GetPhasesNextTime
            // Grid

            GetInspectPoints: function() {

                var that = this;
                var SelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                    var phase = NtSelectedRow.Phase;

                    // getOrder Details count

                    var InspectPointList = models
                        .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->GetInspectPoints-->XACQ_GetInspectionPoints");

                    var insplot = that.getView().byId("id_txt_insplot").getValue();
                    var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource+"&d="+new Date();
                    InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
sap.ui.getCore().setModel(null, "InspectPointList"); 
                        sap.ui.getCore().setModel(InspectPointList, "InspectPointList");
               /*     if (CommonUtility.getJsonModelRowCount(InspectPointList.getData()) > 0 ) {

                        InspectPoint = InspectPointList.getData().Rowsets.Rowset[0].Row;
                         
                        // var runningorder = InspectPoint.ORDERID;
                        var rowcount = InspectPointList.getData().Rowsets.Rowset[0].Row.length
                        var complete = 0;

                        // this.getView().byId("APLT_GRI_InspectPoint").setSelectedItem(this.getView().byId("APLT_GRI_InspectPoint").getItems()[rowcount
                        // - 1])
                    }*/
                }

            }, 
            getTodayDate: function() {
	autoRefresh=false;
                var that = this;
                var SelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;

                if (SelRow != 0) {
                    var QnSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NtSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(QnSelRow);

                    var phase = NtSelectedRow.Phase;
                    if (phase != "") {
                        var currentDT = CommonUtility.getCurrentDateTime(new Date());

                        var js_insplot = that.getView().byId("id_txt_insplot").getValue();

                        var AddInspPoint = models
                            .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getTodayDate-->SQLQ_InsInspectPoint");

                        var params = "Param.2=" + "NA" + "&Param.3=" + js_insplot + "&Param.4=" + phase + "&Param.6=" + currentDT +
                            "&Param.10=0&Param.11=" + plant + "&Param.12=" + resource + "&Param.13=" + "0"+"&d="+new Date();

                        AddInspPoint.attcheReques
                        AddInspPoint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsInspectPoint&" +
                            params + "&Content-Type=text/json", "", false);

                        // getOrder Details count

                        var InspectPointList = models.createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getTodayDate-->XACQ_GetInspectionPoints");

                        var insplot = that.getView().byId("id_txt_insplot").getValue();
                        var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource+"&d="+new Date();
                        InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
		sap.ui.getCore().setModel(null, "InspectPointList");
  
                        sap.ui.getCore().setModel(InspectPointList, "InspectPointList");

                        // document.APLT_GRI_InspectPoint.getGridObject().setSelectedRow(1);
                        this.getView().byId("APLT_GRI_InspectPoint").setSelectedItem(
                            this.getView().byId("APLT_GRI_InspectPoint").getItems()[0])

                        this.openSPCCharts();

                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0014"));

                    }

                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0014"));

                }

            },

            // **** Redirect to InspectResultSubmitNewV2 page for
            // selected inspection point and pass required value via
            // query string

            openSPCCharts: function() {
autoRefresh=false;
                var that = this;
                        

                var PhasesNTSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;
                var InspectPointSelRow = this.getView().byId("APLT_GRI_InspectPoint").getSelectedContextPaths().length;

                if (InspectPointSelRow != 0) {

                    var IpSelRow = this.getView().byId("APLT_GRI_InspectPoint").getSelectedContextPaths()[0];
                    var IpSelectedRow = this.getView().getModel("InspectPointList").getProperty(IpSelRow);

                    var NTSelRow = this.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NTSelectedRow = this.getView().getModel("PhasesNextTime").getProperty(NTSelRow);

                    var InsDateTime = IpSelectedRow.InsDateTime;

                    if (InsDateTime != "" && InsDateTime != null) {
                        var currentDT = CommonUtility.getCurrentDateTime(new Date());
		let   resourceTxt=  sap.ui.getCore().getModel("session").oData.CA_ResrText;
                        var js_date = IpSelectedRow.InsDate;
                        var js_time = IpSelectedRow.InsTime;
                        var js_currenttime = IpSelectedRow.InsDateTime;

                        var js_phs = NTSelectedRow.Phase;
                        var js_phstxt = NTSelectedRow.PhaseText;
                        // var js_currenttime = NTSelectedRow.Time;

                        // Default CCP Change by Praveen 16.02.2022
                        var js_stdkey = NTSelectedRow.StdKey;

                        var js_mat = txt_Mat;
                        var js_ord = txt_Ord;

                        var js_matdesc = that.getView().byId("id_txt_mattext").getValue();
                        var js_insplot = that.getView().byId("id_txt_insplot").getValue();
                        var js_matstrip = that.getView().byId("id_txt_matstrip").getValue();
                        var js_ordstrip = that.getView().byId("id_txt_ordstrip").getValue(); 
      
                        var incResSubmitModel = new sap.ui.model.json.JSONModel();
                        let sID = {
                          plant: plant,
                          resource: resource,
                          qs_insplot: js_insplot,
                            qs_mat: js_mat,
                            qs_matdesc: js_matdesc,
                            qs_ord: js_ord,
                            qs_phs: js_phs,
                            qs_date: js_date,

                            qs_time: js_time,
                            qs_currenttime: js_currenttime,
                            qs_matstrip: js_matstrip,
                            qs_ordstrip: js_ordstrip,
                            qs_phstxt: js_phstxt,
                            qs_ccpsign: js_stdkey,
                            isQualityInspectionView: false,
			js_resr:resource,
			js_resrtxt:resourceTxt
                        }
                        incResSubmitModel.setData(sID)
                        sap.ui.getCore().setModel(incResSubmitModel, "IncResSubmitModel")

                        UI_utilities.setContainerBusyState(this, true);
                        // ID is Mandatory parameter in the routing, to find
                        // the model path in start phase screen 
                          this._oRouter.navTo("BatchInspectResultSubmit", {
                            ID: incResSubmitModel
                        }); 

                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0015"));
                    }

                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0016"));

                }

            },


            selectSessionPhase: function() {
                var qs_phs = sap.ui.getCore().getModel("InspPointRoute").getProperty("/qs_phs");
                if (qs_phs != "") {

                    if (sap.ui.getCore().getModel("PhasesNextTime").getData() != null) {
                        this.GetInspectPoints();
                        var ChkCount = sap.ui.getCore().getModel("PhasesNextTime").getData().Rowsets.Rowset[0].Row.length;

                        for (var i = 0; i < ChkCount; i++) {
                            var oPhaseNetTime = sap.ui.getCore().getModel("PhasesNextTime").getData().Rowsets.Rowset[0].Row;

                            if (oPhaseNetTime[i].Phase == qs_phs) {
                                this.getView().byId("APLT_CMD_GetPhasesNextTime").setSelectedItem(
                                this.getView().byId("APLT_CMD_GetPhasesNextTime").getItems()[i]);
                                this.GetInspectPoints();
                                break;
                            }
                            else{
                              this.getView().byId("APLT_CMD_GetPhasesNextTime").setSelectedItem(
                              this.getView().byId("APLT_CMD_GetPhasesNextTime").getItems()[0]);
                              this.GetInspectPoints();
                              break;
                            }
                        }

                        if (sap.ui.getCore().getModel("InspectPointList").getData() != null) {

                            var currenttime = sap.ui.getCore().getModel("InspPointRoute").getProperty("/qs_currenttime");
                            var insCount = sap.ui.getCore().getModel("InspectPointList").getData().Rowsets.Rowset[0].Row.length;
                            for (var i = 0; i < insCount; i++) {
                                var insList = sap.ui.getCore().getModel("InspectPointList").getData().Rowsets.Rowset[0].Row;

                                if (insList[i].InsDateTime == currenttime) {
                                    var OInsTable = this.getView().byId("APLT_GRI_InspectPoint");
                                    OInsTable.setSelectedItem(OInsTable.getItems()[i]);
                                    break;
                                }
                            }
                        }

                    }
                }

            },
            menuSelected: function(oEvent) {

                // Navigate the the selected menu page
autoRefresh=false;
                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },
            onHelp: function() {

                UI_utilities.OpenHelpFileSingle("Resultentry");
            }

        });
    });