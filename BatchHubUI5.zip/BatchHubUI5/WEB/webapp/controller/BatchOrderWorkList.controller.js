sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility",
        "com/khc/batchhub/model/models"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models) {
        var that;
        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var txt_shift;
        var id_hid_shiftstart;
        var id_hid_shiftend;
        var oModelCampaigns;
        var id_hid_selorder;
        var oModelOrderWorkList;


        return Controller.extend("com.khc.batchhub.controller.BatchOrderWorkList", {
            onInit: function() {


                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchOrderWorkList").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },

            _oRoutePatternMatched: function(oEvent) {

                //Hide the messages and set busy to false  
                UI_utilities.batchPageOpened(this, "BatchOrderWorkList");

                this.getView().byId("buttonList").setVisible(false)
                this.getRouterDetails();
                this.checkShift();


                this.getView().byId("campaign_Id").insertItem(new sap.ui.core.Item({
                    key: "All",
                    text: "All"
                }), 0);
                this.getView().byId("campaign_Id").setSelectedKey("All");

                this.getcampaigns();
                this.Setorder();
                this.getOrderList();
                // Need to check from where it needs to be called
                this.GenerateButton();

                this.getSCADAButtonVisibility();
                this.getView().byId("orderWorkListScrollBar").scrollTo(0, 0, 0)
            },

            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },

            getRouterDetails: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                txt_shift = sap.ui.getCore().getModel("session").oData.txt_shift;
            },

            //Creation Event-1 for Error Message

            checkShift: function() {
                var dt = new Date();
                var TodayDate = getCurrentDateTime(dt);

                var oModelShift = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchOrderWorkList-->checkShift-->XACQ_GetRunningShift");
                var tparams = "Param.1=" + plant + "&Param.2=" + resource;
                oModelShift.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningShift&" + tparams +
                    "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelShift, "oShift");

                if (CommonUtility.getJsonModelRowCount(oModelShift.getData()) != 0) {
                    txt_shift = oModelShift.getData().Rowsets.Rowset[0].Row[0].SHIFTNAME
                    id_hid_shiftstart = oModelShift.getData().Rowsets.Rowset[0].Row[0].STARTTIME
                    id_hid_shiftend = oModelShift.getData().Rowsets.Rowset[0].Row[0].ENDTIME

                    this.getView().byId("buttonList").setVisible(true);
                    if (TodayDate >= id_hid_shiftend) {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0073");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                  	this.getView().byId("buttonList").setVisible(false); 
                    }

                } else {
                    this.getView().byId("buttonList").setVisible(false);
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0026");
                    sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                }
            },

            //////////////// //Drop Down Loading/////////////////////////


            //creation event//
            getcampaigns: function() {
                var oModelPlant = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchOrderWorkList-->getcampaigns-->XACQ_GetRunningOrder_ALL");
                var oparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                oModelPlant.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningOrder_ALL&" + oparams +
                    "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelPlant, "oPlant");
                this.getView().byId("campaign_Id").insertItem(new sap.ui.core.Item({
                    key: "All",
                    text: "All"
                }), 0);
            },

            Setorder: function() {


                order = this.getView().byId("campaign_Id").getSelectedKey();
                id_hid_selorder = order;
                //this.getView().byId("campaign_Id").setSelectedKey(order)
                //document.APLT_BRO_Order.setPropertyValue("selorder", order);  
                this.getOrderList();
            },

            ////////////////////////// /////table binding //////////////////////////
            getOrderList: function() {

                //var selorderid = document.APLT_BRO_Order.getPropertyValue("selorder");
                var selorderid = this.getView().byId("campaign_Id").getSelectedKey()
                if (selorderid != "All" && selorderid != "*" && selorderid != "") {

                    frombatch = this.getView().byId("txt_frombatch").getValue()
                    if (!isNaN(frombatch)) {
                        if (frombatch == "") {
                            frombatch = 0;
                        }

                    } else {
                        MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0112"));
                    }
                    oModelOrderWorkList = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchOrderWorkList-->getOrderList-->XACQ_GetOrderWorkList");
                    var sparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + "0,1" + "&Param.4=" + selorderid + "&Param.5=" +
                        frombatch + "&Param.6=" + "1";
                    oModelOrderWorkList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOrderWorkList&" +
                        sparams + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oModelOrderWorkList, "oOrderWorkList");

                } else {

                    oModelOrderWorkList = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchOrderWorkList-->getOrderList-->XACQ_GetOrderWorkList");
                    var gparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + "0,1" + "&Param.4=" + "&Param.5=" + "0" +
                        "&Param.6=" + "1";

                    oModelOrderWorkList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOrderWorkList&" +
                        gparams + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oModelOrderWorkList, "oOrderWorkList");
                }
            },

            ////////creation event//////////////

            GenerateButton: function() {

                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;

                var oModelButton = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchOrderWorkList-->GenerateButton-->SQLQ_GetPrdunitByResr");
                var bparams = "Param.1=" + plant + "&Param.2=" + resource;
                oModelButton.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetPrdunitByResr&" + bparams +
                    "&Content-Type=text/json", "", false);
                // this.getView().setModel(oModelButton, "oButton");
                sap.ui.getCore().setModel(oModelButton, "oButton");
                //  document.getElementById("buttonList").innerHTML =document.APLT_CMD_GenerateKettleButton.getFirstValue('O_Return');


            },


            assignunit: function(buttonid) {

                var dt = new Date();
                var currentDT = getCurrentDateTime(dt);

                var aSelectedRowPath = this.getView().byId("orderWorkList_ID").getSelectedContextPaths();
                var oOrderWorkListModel = this.getView().getModel("oOrderWorkList");

                if (aSelectedRowPath.length > 0) {

                    var resr = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/RESR");
                    var plant1 = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/PLANT");
                    var orderid = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/ORDERID");
                    var batch = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/BATCH");
                    var crdest = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/CRDEST");
                    var crid = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/CRID");
                    var selprdunit = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/PRDUNIT");
                    var batchsize = oOrderWorkListModel.getObject(aSelectedRowPath[0] + "/ACTBATCHSIZE");
                    var status = "1";

                    var oModelCheckBatchPhaseStatus = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchOrderWorkList-->assignunit-->XACQ_CheckBatchPhaseStatus");
                    var sparams = "Param.1=" + orderid + "&Param.2=" + plant1 + "&Param.3=" + resr + "&Param.4=" + batch + "&Param.5=" + crdest;
                    oModelCheckBatchPhaseStatus.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_CheckBatchPhaseStatus&" + sparams + "&Content-Type=text/json", "", false);
                    // this.getView().setModel(oModelCheckBatchPhaseStatus, "oOrderCheckBatchPhaseStatus");

                    if (CommonUtility.getJsonModelRowCount(oModelCheckBatchPhaseStatus.getData()) != 0) {

                        var aprdunit = oModelCheckBatchPhaseStatus.getData().Rowsets.Rowset[0].Row[0].PRDUNIT;
                        var astatus = oModelCheckBatchPhaseStatus.getData().Rowsets.Rowset[0].Row[0].STATUS;

                        if (aprdunit) {

                            if (astatus == 0) {
                                if (buttonid != selprdunit) {
                                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0083") + " " + aprdunit + "," + " " + sap
                                        .ui
                                        .getCore().getModel("i18n").getProperty("BATCH_MSG_0084");
                                    var that = this;
                                    MessageBox.confirm(
                                        msg, {
                                            icon: MessageBox.Icon.INFORMATION,
                                            title: "Message from webpage",
                                            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                            onClose: function(oAction) {
                                                if (oAction === "OK") {
                                                    var oModelUpdOrdPrdUnit = models.createNewJSONModel(
                                                        "com.khc.batchhub.controller.BatchOrderWorkList-->assignunit-->XACQ_UpdOrdPrdUnit"
                                                    );
                                                    var sparams = "Param.1=" + buttonid + "&Param.2=" + status + "&Param.3=" + plant1 +
                                                        "&Param.4=" + resr + "&Param.5=" + orderid + "&Param.6=" + batch + "&Param.7=" +
                                                        crdest + "&Param.8=" + crid + "&Param.9=" + batchsize + "&Param.10=" +
                                                        currentDT;
                                                    oModelUpdOrdPrdUnit.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                                        "/QueryTemplate/XACQ_UpdOrdPrdUnit&" + sparams + "&Content-Type=text/json",
                                                        "",
                                                        false);
                                                    that.getView().setModel(oModelUpdOrdPrdUnit, "oOrderUpdOrdPrdUnit");

                                                    var sparams2 = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + "0,1" +
                                                        "&Param.6=" + "1";
                                                    oModelOrderWorkList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                                        "/QueryTemplate/XACQ_GetOrderWorkList&" + sparams +
                                                        "&Content-Type=text/json",
                                                        "", false);
                                                    that.getView().setModel(oModelOrderWorkList, "oOrderWorkList");

                                                    var oData = {
                                                        qs_selprdunit: buttonid,
                                                        qs_batch: batch,
                                                        qs_orderid: orderid
                                                    };
                                                    var oDestModel = new sap.ui.model.json.JSONModel(oData);
                                                    sap.ui.getCore().setModel(oDestModel, "BatchExecuteOrderParams");
                                                    //this._oRouter.navTo("BatchExecuteOrder")
                                                    var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
                                                    // set Busy Icon
                                                    UI_utilities.setContainerBusyState(that, true);
                                                    setTimeout(function() {
                                                        oRouter.navTo("BatchExecuteOrder");
                                                    }, 500);


                                                    //window.open('/XMII/CM/GBL_BatchHub/IRPT/BatchExecuteOrder.irpt?qs_selprdunit="+ buttonid +"&qs_batch="+ batch +"&qs_orderid="+ orderid, 'BatchExecuteOrder', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');

                                                } else {

                                                }
                                            }
                                        });
                                } else {
                                    var oData = {
                                        qs_selprdunit: selprdunit,
                                        qs_batch: batch,
                                        qs_orderid: orderid
                                    };
                                    var oDestModel = new sap.ui.model.json.JSONModel(oData);
                                    sap.ui.getCore().setModel(oDestModel, "BatchExecuteOrderParams");
                                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                                    UI_utilities.setContainerBusyState(this, true);
                                    setTimeout(function() {
                                        oRouter.navTo("BatchExecuteOrder");
                                    }, 500);
                                    // this._oRouter.navTo("BatchExecuteOrder")
                                    //window.open('/XMII/CM/GBL_BatchHub/IRPT/BatchExecuteOrder.irpt?qs_selprdunit="+ selprdunit +"&qs_batch="+ batch +"&qs_orderid="+ orderid, 'BatchExecuteOrder', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');

                                }

                            } else {

                                if (buttonid == selprdunit) {
                                    var oData = {
                                        qs_selprdunit: selprdunit,
                                        qs_batch: batch,
                                        qs_orderid: orderid
                                    };
                                    var oDestModel = new sap.ui.model.json.JSONModel(oData);
                                    sap.ui.getCore().setModel(oDestModel, "BatchExecuteOrderParams");
                                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                                    UI_utilities.setContainerBusyState(this, true);
                                    setTimeout(function() {
                                        oRouter.navTo("BatchExecuteOrder");
                                    }, 500);
                                    //this._oRouter.navTo("BatchExecuteOrder")
                                    //window.open('/XMII/CM/GBL_BatchHub/IRPT/BatchExecuteOrder.irpt?qs_selprdunit="+ selprdunit +"&qs_batch="+ batch +"&qs_orderid="+ orderid, 'BatchExecuteOrder', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');

                                } else {

                                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0044"));

                                }

                            }

                        } else {
                            var oModelUpdOrdPrdUnit = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchOrderWorkList-->assignunit-->XACQ_UpdOrdPrdUnit");
                            var sparams = "Param.1=" + buttonid + "&Param.2=" + status + "&Param.3=" + plant1 + "&Param.4=" + resr +
                                "&Param.5=" +
                                orderid + "&Param.6=" + batch + "&Param.7=" + crdest + "&Param.8=" + crid + "&Param.9=" + batchsize +
                                "&Param.10=" +
                                currentDT;
                            oModelUpdOrdPrdUnit.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_UpdOrdPrdUnit&" +
                                sparams + "&Content-Type=text/json", "", false);
                            this.getView().setModel(oModelUpdOrdPrdUnit, "oOrderUpdOrdPrdUnit");

                            var sparams2 = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + "0,1" + "&Param.6=" + "1";
                            oModelOrderWorkList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_GetOrderWorkList&" + sparams2 + "&Content-Type=text/json", "", false);
                            this.getView().setModel(oModelOrderWorkList, "oOrderWorkList");

                            var oData = {
                                qs_selprdunit: buttonid,
                                qs_batch: batch,
                                qs_orderid: orderid
                            };
                            var oDestModel = new sap.ui.model.json.JSONModel(oData);
                            sap.ui.getCore().setModel(oDestModel, "BatchExecuteOrderParams");
                            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                            UI_utilities.setContainerBusyState(this, true);
                            setTimeout(function() {
                                oRouter.navTo("BatchExecuteOrder");
                            }, 500);
                            // this._oRouter.navTo("BatchExecuteOrder")
                            //window.open('/XMII/CM/GBL_BatchHub/IRPT/BatchExecuteOrder.irpt?qs_selprdunit="+ buttonid +"&qs_batch="+ batch +"&qs_orderid="+ orderid, 'BatchExecuteOrder', 'width=1050,height=780,scrollbars=yes,left=0,top=0,resizable=yes,status=yes,location=no,menubar=yes');
                        }

                    }

                } else {
                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0045"));
                }

                //alert("clicked "+buttonid)

            },


            CampaignView: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;

                var resrtxt = this.getView().byId("txt_ResourceText").getValue();

                //if(document.APLT_GRI_OrderWorkList.getGridObject().getSelectedRow() != "")
                var aSelectedRowPath = this.getView().byId("orderWorkList_ID").getSelectedContextPaths();
                var oOrderWorkListModel = this.getView().getModel("oOrderWorkList");
                if (aSelectedRowPath.length > 0) {
                    let sPath = aSelectedRowPath[0];

                    var orderid = oOrderWorkListModel.getProperty(sPath + '/ORDERID');
                    var crid = oOrderWorkListModel.getProperty(sPath + '/CRID');
                    var modorderid = oOrderWorkListModel.getProperty(sPath + '/ModOrderId');
                    var msgid = oOrderWorkListModel.getProperty(sPath + '/MSGID');
                    var matnum = oOrderWorkListModel.getProperty(sPath + '/MATNUM');
                    var modmatnum = oOrderWorkListModel.getProperty(sPath + '/ModMatNum');
                    var mattext = oOrderWorkListModel.getProperty(sPath + '/MATTEXT');

                    var oData = {
                        qs_plant: plant,
                        qs_resr: resource,
                        qs_resrtxt: resrtxt,
                        qs_orderid: orderid,
                        qs_crid: crid,
                        qs_modorderid: modorderid,
                        qs_msgid: msgid,
                        qs_matnum: matnum,
                        qs_modmatnum: modmatnum,
                        qs_mattext: mattext,

                    };
                    var oDestModel = new sap.ui.model.json.JSONModel(oData);
                    sap.ui.getCore().setModel(oDestModel, "BatchIdentParams");
                    this._oRouter.navTo("BatchCampaign");
                } else {
                    // alert(document.getElementById("id_msg_alert3").innerHTML);
                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0024"));
                }
            },

            FilterOrderList: function(status, orderstatus) {

                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;

                var oModelWorkList = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchOrderWorkList-->FilterOrderList-->XACQ_GetOrderWorkList");
                var kparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + status + "&Param.6=" + orderstatus;
                oModelWorkList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOrderWorkList&" + kparams +
                    "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelWorkList, "oOrderWorkList");
                //this.getOrderList();
            },
            selectfirstrow: function() {
                var OOrderWL = this.getView().getModel("oOrderWorkList");;
                if (CommonUtility.getJsonModelRowCount(OOrderWL.getData()) != 0) {

                    var OInsTable = this.getView().byId("orderWorkList_ID");
                    OInsTable.setSelectedItem(OInsTable.getItems()[0]);
                }

            },
            getSCADAButtonVisibility: function() {

                var currentDT = getCurrentDateTime(new Date());
                var oSCADAModel = new sap.ui.model.xml.XMLModel();
                oSCADAModel.loadData("/XMII/Illuminator?QueryTemplate=GBL_BatchHub/QueryTemplate/SQLQ_SCADADisplayStatus&Param.1=" + plant +
                    "&Param.2=" + resource + "&Content-Type=text/xml&d=" + currentDT, "", false);

                var flagSCADA = oSCADAModel.getProperty("/Rowset/Row/CONNECTSCADA");


                if (flagSCADA != "Y") {
                    this.getView().byId("id_btn_SCADA").setVisible(false);
                }

            },
            openSCADA: function() {
                window.open("/XMII/CM/GBL_BatchHub/WebContent/SCADA_Visualization.html?qs_plant=" + plant + "&qs_resr=" + resource,
                    "SCADA Visualization", "height=700,width=1000, resizable=yes, scrollbars=yes,menubar=yes, toolbar=yes,titlebar=yes");
            }
        });
    });