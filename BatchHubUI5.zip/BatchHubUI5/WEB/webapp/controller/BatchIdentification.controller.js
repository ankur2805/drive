sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models",
        "com/khc/batchhub/model/formatter", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput", "sap/ui/core/Fragment"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter, Dialog, Button, DateTimeInput, Fragment) {

        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var crid;
        var orderID = "";
        var matnum = "";
        var BatchIdentParams;
        var FromCampaignList;
        var hasPrevPageData = false;


        var hid_txt_camp = "";
        var hid_txt_matnum = "";

        return Controller.extend("com.khc.batchhub.controller.BatchIdentification", {
            formatter: formatter,
            onInit: function() {

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchIdentification").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },

            _oRoutePatternMatched: function(oEvent) {

                //Hide the messages and set busy to false
                //   UI_utilities.batchPageOpened(this, "home");
                UI_utilities.batchPageOpened(this, "BatchIdentification");
                this.oRoutePatternMatched();
            },
            oRoutePatternMatched: function() {

                var oData = {
                    qs_campaign: "",
                    qs_campaignstrip: "",
                    qs_material: "",
                    qs_materialstrip: "",
                    qs_mattext: "",
                    qs_reqbatch: "",
                };
                var oDestModel = new sap.ui.model.json.JSONModel(oData);
                //sap.ui.getCore().setModel(oDestModel, "BatchIdentParams");
                //  this.getView().byId("hid_txt_camp").setValue("");
                // this.getView().byId("hid_txt_matnum").setValue("")

                this.ClearAllValues();
                this.loadData();
                this.GetMatBatchList();
                this.GetActBatch();
                this.GetStock();
            },
            /****************************************************************************************************************************************************************************************/
            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

                //  var oEmptyModel = new sap.ui.model.json.JSONModel();
                //sap.ui.getCore().setModel(null, "BatchIdentParams");  //set getData() {}
                sap.ui.getCore().getModel("BatchIdentParams").setData(""); //set getData() ''

                hid_txt_camp = "";
                hid_txt_matnum = "";
                BatchIdentParams = "";

  		hasPrevPageData=false;	
            },
            /****************************************************************************************************************************************************************************************/
            loadData: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;

                BatchIdentParams = sap.ui.getCore().getModel("BatchIdentParams");
                if (JSON.stringify(BatchIdentParams.getData()) !== "{}") {
                    //    if (JSON.stringify(BatchIdentParams.getData())!=="{}") {               
                    hid_txt_camp = BatchIdentParams.oData.qs_campaign
                    hid_txt_matnum = BatchIdentParams.oData.qs_material
                    hasPrevPageData = true;
                }
            },
            /****************************************************************************************************************************************************************************************/
            GetMatBatchList: function() {
                /*  var txt_camp = "";
                var txt_matnum = "";
	 
                if (BatchIdentParams) {
                	//if (CommonUtility.getJsonModelRowCount(BatchIdentParams.getData())>0) {
                 	   txt_camp = BatchIdentParams.oData.qs_campaign
                 	   txt_matnum = BatchIdentParams.oData.qs_material
		//}
                }*/
                let id_txt_camp = "";
                let id_matnum = "";
                id_txt_camp = hid_txt_camp;
                id_matnum = hid_txt_matnum;
                if (hid_txt_camp != "") {

                    var oMatBatchListModel = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchDispDetail-->GetMatBatchList-->XACQ_GetOrdBOMList");
                    var params = "Param.1=" + resource + "&Param.2=" + id_txt_camp + "&Param.3=" + id_matnum + "&Param.4=" + plant;

                    oMatBatchListModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOrdBOMList&" +
                        params + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oMatBatchListModel, "MatBatchList");

                    /*   if (CommonUtility.getJsonModelRowCount(oMatBatchListModel.getData()) > 0) {
                    let getItemss=this.getView().byId("MatBatchList").getItems()
                    		getItemss[0].setSelected(true);
                    	this.SelBatchforMat();
                    	}
                    */
                } else {
                    this.GetRunCamp();
                }
            },
            /****************************************************************************************************************************************************************************************/
            GetRunCamp: function() {
                oGetLatestRunCampDetails = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->GetRunCamp-->XACQ_GetLatestRunCampDetails");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                oGetLatestRunCampDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetLatestRunCampDetails&" + params + "&Content-Type=text/json", "", false);

                this.getView().setModel(oGetLatestRunCampDetails, "runningOrderDetails");

                if (CommonUtility.getJsonModelRowCount(oGetLatestRunCampDetails.getData()) > 0) {
                    var oData = oGetLatestRunCampDetails.getData().Rowsets.Rowset[0].Row[0];
                    orderID = oData.ORDERID;
                    matnum = oData.MATNR;
                    hid_txt_camp = orderID;
                    hid_txt_matnum = matnum;
                    this.getView().byId("txt_matnumstrip").setValue(oData.MATNRSTRIP);
                    this.getView().byId("txt_desc").setValue(oData.MATTEXT);
                    this.getView().byId("id_txt_campstrip").setValue(oData.ORDERSTRIP);

                    this.GetActBatch();
                    this.GetMatBatchList();
                }

            },
            /****************************************************************************************************************************************************************************************/
            GetActBatch: function() {
                var id_txt_camp = hid_txt_camp;
                var oGetBatchCount = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->GetActBatch-->SQLQ_GetTotalBatchCount");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + id_txt_camp;
                oGetBatchCount.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/SQLQ_GetTotalBatchCount&" + params + "&Content-Type=text/json", "", false);


                if (CommonUtility.getJsonModelRowCount(oGetBatchCount.getData()) > 0) {
                    var oData = oGetBatchCount.getData().Rowsets.Rowset[0].Row[0];

                    this.getView().byId("txt_reqbatch").setValue(oData.MAX_BATCH);
                }

            },
            /****************************************************************************************************************************************************************************************/
            GetStock: function() {
                var id_txt_camp = hid_txt_camp;
                var oPopulateStockData = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->GetStock-->XACQ_PopulateStockData");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + id_txt_camp;
                oPopulateStockData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_PopulateStockData&" + params + "&Content-Type=text/json", "", false);


            },
            /****************************************************************************************************************************************************************************************/
            SelBatchforMat: function() {
                var SelRow = this.getView().byId("MatBatchList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var BLSelRow = this.getView().byId("MatBatchList").getSelectedContextPaths()[0];
                    var BSSelectedRow = this.getView().getModel("MatBatchList").getProperty(BLSelRow);

                    var selMat = BSSelectedRow.BOM;
                    var selMatStrip = BSSelectedRow.ModBOM;
                    var selMatText = BSSelectedRow.BOMTEXT;
                    crid = BSSelectedRow.CRID;
                    var selBatch = BSSelectedRow.BATCHID;
                    var selPSA = BSSelectedRow.PSA;

                    this.getView().byId("id_txt_MaterialStrip").setValue(selMatStrip);
                    this.getView().byId("id_txt_matdesc").setValue(selMatText);

                    var oBRO_BatchData = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchProdDispatch-->SelBatchforMat-->SQLQ_GetBatchByMaterial");
                    var params = "Param.1=" + plant + "&Param.2=" + selMat;
                    oBRO_BatchData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/SQLQ_GetBatchByMaterial&" + params + "&Content-Type=text/json", "", false);

                    this.getView().setModel(oBRO_BatchData, "BroBatchData");

                    if (CommonUtility.getJsonModelRowCount(oBRO_BatchData.getData()) > 0) {
                        this.getView().byId("id_batch").setSelectedKey(oBRO_BatchData.getData().Rowsets.Rowset[0].Row[0].BATCH);
                    }


                    var RowCount = CommonUtility.getJsonModelRowCount(oBRO_BatchData.getData())
                    if (RowCount > 0) {
                        //document.APLT_BRO_Batch.getBrowserObject().setSelectedItemByIndex(2);
                        //console.log("APLT_BRO_Batch-.setSelectedItemByIndex(2)")
                        var oBRO_PSAData = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->SelBatchforMat-->SQLQ_GetPSA");
                        var params = "Param.1=" + oBRO_BatchData.getData().Rowsets.Rowset[0].Row[0].BATCH + "&Param.2=" + selMat + "&Param.3=" +
                            plant;
                        oBRO_PSAData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/SQLQ_GetPSA&" + params + "&Content-Type=text/json", "", false);

                        this.getView().setModel(oBRO_PSAData, "psaComboList");


                        var RowCountPSA = CommonUtility.getJsonModelRowCount(oBRO_PSAData.getData())

                        if (RowCountPSA == 1) {
                            //document.APLT_BRO_PSA.getBrowserObject().setSelectedItemByIndex(2);
                            // console.log("APLT_BRO_PSA-.setSelectedItemByIndex(2)")
                            this.getView().byId("id_psa").setSelectedKey(oBRO_PSAData.getData().Rowsets.Rowset[0].Row[0].PSA);

                        }
                    } else {
                        var oBRO_PSAData = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->SelBatchforMat-->SQLQ_GetPSA");
                        var params = "Param.1=" + selBatch + "&Param.2=" + selMat + "&Param.3=" + plant;
                        oBRO_PSAData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/SQLQ_GetPSA&" + params + "&Content-Type=text/json", "", false);

                        this.getView().setModel(oBRO_PSAData, "psaComboList");


                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0099");
                    MessageBox.error(msg)
                }
            },
            /****************************************************************************************************************************************************************************************/
            setpendinRow: function() {
                var MatBLtable = this.getView().byId("MatBatchList");
                var oMatBatchModel = this.getView().getModel("MatBatchList");
                for (i = 0; i < MatBLtable.getItems().length; i++) {
                    var batchID = oMatBatchModel.getProperty("/Rowsets/Rowset/0/Row/" + i).MSGID
                    if (batchID == "---") {
                        oMatBatchModel.setSelectedItem(oMatBatchModel.getItems()[i]);
                        break;
                    }
                }

            },
            /****************************************************************************************************************************************************************************************/
            GetBatchWisePSA: function() {
                var SelRow = this.getView().byId("MatBatchList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var BLSelRow = this.getView().byId("MatBatchList").getSelectedContextPaths()[0];
                    var BSSelectedRow = this.getView().getModel("MatBatchList").getProperty(BLSelRow);

                    var selMat = BSSelectedRow.BOM;
                    var selBatch = this.getView().byId("id_batch").getSelectedKey()
                    var oBRO_PSAData = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchProdDispatch-->GetBatchWisePSA-->SQLQ_GetPSA");
                    var params = "Param.1=" + selBatch + "&Param.2=" + selMat + "&Param.3=" + plant;
                    oBRO_PSAData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/SQLQ_GetPSA&" + params + "&Content-Type=text/json", "", false);

                    this.getView().setModel(oBRO_PSAData, "psaComboList");


                    if (CommonUtility.getJsonModelRowCount(oBRO_PSAData.getData()) > 0) {

                        //document.APLT_BRO_PSA.getBrowserObject.setSelectedItemByIndex(2);
                        console.log("APLT_BRO_PSA-.setSelectedItemByIndex(2)")
                    }

                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0099");
                    MessageBox.error(msg)
                }


            },
            /****************************************************************************************************************************************************************************************/
            GetBatchCancel: function() {
                var that = this;
                var msg = "Are you sure to cancel? The changes will be lost.";
                MessageBox.confirm(
                    msg, {
                        icon: MessageBox.Icon.WARNING,
                        title: "Confirmation",
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        onClose: function(oAction) {
                            if (oAction === "OK") {
                                var id_txt_camp = hid_txt_camp;
                                var id_matnum = hid_txt_matnum;
                                var oUpdBatchCancel = models.createNewJSONModel(
                                    "com.khc.batchhub.controller.BatchProdDispatch-->GetBatchCancel-->XACQ_UpdBatchCancel");
                                var params = "Param.1=" + crid + "&Param.2=" + resource + "&Param.3=" + id_txt_camp + "&Param.4=" +
                                    id_matnum;
                                oUpdBatchCancel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                    "/QueryTemplate/XACQ_UpdBatchCancel&" + params + "&Content-Type=text/json", "", false);

                                that.GetMatBatchList();

                                //window.location.href="BatchStartCampaign.irpt"; 
                                that._oRouter.navTo("BatchStartCampaign");

                            }
                        }
                    });


            },
            /****************************************************************************************************************************************************************************************/
            PrintPickList: function() {
                var OrdId;
                var MatNo;
                var mattxt;
                var rsrtxt = sap.ui.getCore().getModel("session").oData.CA_ResrText;
                var ords;
                //BatchIdentParams = sap.ui.getCore().getModel("BatchIdentParams");

                if (hasPrevPageData == true) {
                    OrdId = BatchIdentParams.getData().qs_campaign;
                    MatNo = BatchIdentParams.getData().qs_material;
                    mattxt = BatchIdentParams.getData().qs_mattext;
                    ords = this.getView().byId("txt_reqbatch").getValue();
                } else {
                    let orderData = this.getView().getModel("runningOrderDetails").getData().Rowsets.Rowset[0].Row[0];
                    OrdId = orderData.ORDERID;
                    MatNo = orderData.MATNR;
                    mattxt = orderData.MATTEXT;
                    // rsrtxt=sap.ui.getCore().getModel("session").oData.CA_ResrText;
                    ords = this.getView().byId("txt_reqbatch").getValue();
                }
                var Url = '/XMII/CM/GBL_BatchHub/IRPT/BatchPickLIst.irpt?qs_ordid=' + OrdId + '&qs_matno=' + MatNo + '&qs_rsrtxt=' + rsrtxt +
                    '&qs_mattxt=' + mattxt + '&qs_ords=' + ords + '&CA_Plant=' + plant + '&CA_Resource=' + resource;
                // var Url = '/XMII/CM/GBL_BatchHub/IRPT/BatchPickLIst.irpt?qs_ordid=' + OrdId + '&qs_matno=' + MatNo + '&qs_rsrtxt=' + rsrtxt + '&qs_mattxt=' + mattxt + '&qs_ords=' + ords+'&CA_Plant='+plant+'&CA_Resource='+resource; 
                window.open(Url, 'PickList', 'width=1150,height=856,scrollbars=no,resizable=no,status=yes,location=yes,left=0,top=0');
            },

            /*************************************************************************************************************************************************/
            GetBatchComplete: function() {
                var that = this;
                var msg = "Are you sure to save the changes?";
                MessageBox.confirm(
                    msg, {
                        icon: MessageBox.Icon.WARNING,
                        title: "Confirmation",
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        onClose: function(oAction) {
                            if (oAction === "OK") {

                                var id_txt_camp = hid_txt_camp;
                                var id_matnum = hid_txt_matnum;

                                var oUpdBatchComplete = models.createNewJSONModel(
                                    "com.khc.batchhub.controller.BatchProdDispatch-->GetBatchComplete-->XACQ_UpdBatchComplete");
                                var params = "Param.1=" + crid + "&Param.2=" + resource + "&Param.3=" + id_txt_camp + "&Param.4=" +
                                    id_matnum;
                                oUpdBatchComplete.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                    "/QueryTemplate/XACQ_UpdBatchComplete&" + params + "&Content-Type=text/json", "", false);

                                that.GetMatBatchList();

                                //window.location.href="BatchStartCampaign.irpt"; 
                                that._oRouter.navTo("BatchStartCampaign");

                            }
                        }
                    });

            },
            /****************************************************************************************************************************************************************************************/
            UpdStock: function() {
                this.GetStock();
                var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0103");
                MessageBox.success(msg)
                //this.oRoutePatternMatched();
                //window.location.reload();
            },
            /****************************************************************************************************************************************************************************************/
            changeMatBatch: function() {

                var SelRow = this.getView().byId("MatBatchList").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var BLSelRow = this.getView().byId("MatBatchList").getSelectedContextPaths()[0];
                    var BSSelectedRow = this.getView().getModel("MatBatchList").getProperty(BLSelRow);

                    var selMat = BSSelectedRow.BOM;

                    var selBatch = this.getView().byId("id_batch").getSelectedKey();
                    var selPSA = this.getView().byId("id_psa").getSelectedKey();

                    if (selBatch != "" && selPSA != "") {
                        var oBatchitem = this.getView().byId("id_batch").getSelectedItem().oBindingContexts
                        var selBatchQty = oBatchitem.BroBatchData.getProperty('STOCK')

                        var oUpdOrdBOM = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchProdDispatch-->changeMatBatch-->SQLQ_UpdOrdBOMPSA");
                        var params = "Param.1=" + selBatch + "&Param.2=" + selMat + "&Param.3=" + crid +
                            "&Param.4=" + resource + "&Param.5=" + selBatchQty + "&Param.6=" + selPSA;
                        oUpdOrdBOM.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/SQLQ_UpdOrdBOMPSA&" + params + "&Content-Type=text/json", "", false);

                        this.GetMatBatchList();
                        this.getView().byId("id_btn_cancel").setEnabled(true);
                        this.getView().byId("id_btn_complete").setEnabled(true);
                    } else {
                        // If batch is not selected check with HU number
                        var labelid = this.getView().byId("txt_labelid").getValue();
                        var qty = BSSelectedRow.BOMQTY;
                        if (labelid != "") {
                            var oCheckMatHUUpdOrdBOM = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchProdDispatch-->changeMatBatch-->XACQ_CheckMAterialAvailByHU");
                            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + labelid +
                                "&Param.4=" + selMat + "&Param.5=" + qty;
                            oCheckMatHUUpdOrdBOM.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_CheckMAterialAvailByHU&" + params + "&Content-Type=text/json", "", false);
                            if (CommonUtility.getJsonModelRowCount(oCheckMatHUUpdOrdBOM.getData()) > 0) {

                                var oData = oCheckMatHUUpdOrdBOM.getData().Rowsets.Rowset[0].Row[0];

                                var Batch = oData.Batch;
                                if (Batch != "") {
                                    var BatchQty = oData.Qty;


                                    var oCheckMatHUUpdOrdBOM = models.createNewJSONModel(
                                        "com.khc.batchhub.controller.BatchProdDispatch-->changeMatBatch-->SQLQ_UpdOrdBOMPSA");
                                    var params = "Param.1=" + Batch + "&Param.2=" + selMat + "&Param.3=" + crid +
                                        "&Param.4=" + resource + "&Param.5=" + BatchQty + "&Param.6=" + selPSA;
                                    oCheckMatHUUpdOrdBOM.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                        "/QueryTemplate/SQLQ_UpdOrdBOMPSA&" + params + "&Content-Type=text/json", "", false);


                                    this.GetMatBatchList();
                                    this.getView().byId("id_btn_cancel").setEnabled(true);
                                    this.getView().byId("id_btn_complete").setEnabled(true);
                                    this.getView().byId("txt_labelid").setValue("")
                                } else {
                                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0100");
                                    MessageBox.error(msg)
                                }
                            }
                        } else {
                            var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0101");
                            MessageBox.error(msg)
                        }
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0102");
                    MessageBox.error(msg)
                }
            },

            ClearAllValues: function() {

                //this.getView().byId("id_txt_Resr").setValue("");  
                //this.getView().byId("id_txt_campstrip").setValue("");
                //this.getView().byId("txt_matnumstrip").setValue("");
                //this.getView().byId("txt_desc").setValue("");
                this.getView().byId("txt_reqbatch").setValue("");
                // var oEmptyModel = new sap.ui.model.json.JSONModel();
                // sap.ui.getCore().setModel(oEmptyModel, "MatBatchList");
                this.getView().setModel(null, "MatBatchList");
                this.getView().byId("id_txt_MaterialStrip").setValue("");
                this.getView().byId("id_txt_matdesc").setValue("");
                this.getView().byId("id_batch").setSelectedKey("");
                //this.getView().setModel(null, "psaComboList");
                var oEmptyModel = new sap.ui.model.json.JSONModel();
                sap.ui.getCore().setModel(oEmptyModel, "BroBatchData");
                sap.ui.getCore().setModel(oEmptyModel, "psaComboList");
                this.getView().setModel(null, "BroBatchData");
                this.getView().setModel(null, "psaComboList");
                this.getView().byId("id_batch").setSelectedKey("");
                this.getView().byId("id_psa").setSelectedKey("");
                //this.getView().setModel(null, "BroBatchData");
                this.getView().byId("txt_labelid").setValue("");
                this.getView().byId("MatBatchList").removeSelections(true);
            }


            /****************************************************************************************************************************************************************************************/
        });
    });