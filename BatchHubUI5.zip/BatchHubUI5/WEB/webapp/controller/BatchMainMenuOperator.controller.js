sap.ui.define(["sap/ui/core/mvc/Controller", "com/khc/batchhub/utils/UI_utilities", "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models",
        "sap/m/MessageBox"
    ],
    function(Controller, UI_utilities, CommonUtility, models, MessageBox) {
        "use strict";
        var that;
        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;

        return Controller.extend("com.khc.batchhub.controller.BatchMainMenuOperator", {
            onInit: function() {
                that = this;
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

                this._oRouter.getRoute("home").attachPatternMatched(this._oRoutePatternMatched, this);
                this._oRouter.getRoute("default").attachPatternMatched(this._oRoutePatternMatched, this);

            },

            /**
             * Called when the Routing is matched, 'RepHome'
             * 
             */

            _oRoutePatternMatched: function(oEvent) {
                UI_utilities.batchPageOpened(this, "home");
                this.setCustomHeaderText();

                var oData = {
                    validDestination: "false"
                };
                var oDestModel = new sap.ui.model.json.JSONModel(oData);
                this.getView().setModel(oDestModel, "destModel");


                // temp mode
                var oData = {
                    orderid: '',
                    orderidstrip: '',
                    mattext: '',
                    matno: '',
                    matnostrip: '',
                    batch: '',
                };

                var oModel = new sap.ui.model.json.JSONModel(oData);
                this.getView().setModel(oModel, "OrderDetailsParam");

                this.clearDetails();
                this.getRouterDetails();
                //On view query /Display Template null
                this.manualmaster();
                this.getRunningCamp()
                this.GetShiftDetails()
                this.VerifyDest()
            },

            clearDetails: function() {
                this.getView().byId("campnum").setText("")
                that.byId("id_btn_OrderWorklist").removeStyleClass("btn_greenColor");
                that.byId("id_btn_StartCampaign").removeStyleClass("btn_greenColor");
                that.byId("id_btn_BatchIdent").removeStyleClass("btn_greenColor");
                that.byId("id_btn_StartShift").removeStyleClass("btn_greenColor");

            },
            getRouterDetails: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
            },
            manualmaster: function() {
                var CA_manualMasterFlag = sap.ui.getCore().getModel("session").getData().CA_manualMasterFlag;
                if (CA_manualMasterFlag == "1") {
                    this.getView().byId("hid_manualmaster").setVisible(true);
                }
            },
            getRunningCamp: function() {
                var unit = sap.ui.getCore().getModel("session").getData().CA_Unit; // Missing


                var APLT_CMD_GetLatestRunCampDetails = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchMainMenuOperator-->getRunningCamp-->XACQ_GetLatestRunCampDetails"
                ); //new sap.ui.model.json.JSONModel();
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                APLT_CMD_GetLatestRunCampDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetLatestRunCampDetails&" + params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetLatestRunCampDetails.getData()) > 0) {
                    var oModel = APLT_CMD_GetLatestRunCampDetails.getData().Rowsets.Rowset[0].Row[0];
                    var runningord = oModel.ORDERID;
                    this.getView().getModel("OrderDetailsParam").setProperty("/orderid", runningord);
                    var orderidstrip = oModel.ORDERSTRIP;
                    this.getView().getModel("OrderDetailsParam").setProperty("/orderidstrip", orderidstrip);
                    var mattext = oModel.MATTEXT;
                    this.getView().getModel("OrderDetailsParam").setProperty("/mattext", mattext);
                    var matno = oModel.MATNR;
                    this.getView().getModel("OrderDetailsParam").setProperty("/matno", matno);
                    var matnostrip = oModel.MATNRSTRIP;
                    this.getView().getModel("OrderDetailsParam").setProperty("/matnostrip", matnostrip);
                    var batch = oModel.BATCHCOUNT;
                    this.getView().getModel("OrderDetailsParam").setProperty("/batch", batch);

                    if (runningord != "") {

                        this.getView().byId("campnum").setText(orderidstrip)
                        that.byId("id_btn_StartCampaign").addStyleClass("btn_greenColor");
                        var APLT_CMD_getBatchIdentByOrder = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchMainMenuOperator-->getRunningCamp-->SQLQ_GetBatchIdentifiedByCamp"
                        ); //new sap.ui.model.json.JSONModel();
                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + runningord;
                        APLT_CMD_getBatchIdentByOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/SQLQ_GetBatchIdentifiedByCamp&" + params + "&Content-Type=text/json", "", false);

                        if (CommonUtility.getJsonModelRowCount(APLT_CMD_getBatchIdentByOrder.getData()) > 0) {
                            var oModel = APLT_CMD_getBatchIdentByOrder.getData().Rowsets.Rowset[0].Row[0];
                            var rowcount = oModel.COUNT;
                            if (rowcount != 0) {
                                that.byId("id_btn_BatchIdent").addStyleClass("btn_greenColor");

                                var APLT_CMD_getRunningBatchOrder = models.createNewJSONModel(
                                    "com.khc.batchhub.controller.BatchMainMenuOperator-->getRunningCamp-->SQLQ_GetRunningBatchOrderByUnit"
                                ); // new sap.ui.model.json.JSONModel();
                                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + unit +
                                    "&Param.5=" +
                                    runningord;
                                APLT_CMD_getRunningBatchOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                    "/QueryTemplate/SQLQ_GetRunningBatchOrderByUnit&" + params + "&Content-Type=text/json", "", false);

                                if (CommonUtility.getJsonModelRowCount(APLT_CMD_getRunningBatchOrder.getData()) > 0) {
                                    var oModel = APLT_CMD_getRunningBatchOrder.getData().Rowsets.Rowset[0].Row[0];

                                    var batchcount = oModel.ACTBATCHCOUNT;
                                    var batch = oModel.BATCH;

                                    if (batch <= batchcount && batch != "" && batchcount != "" && batch != "---" && batchcount != "---") {

                                        this.getView().byId("campnum").setText(batch + "/" + batchcount)
                                        that.byId("id_btn_OrderWorklist").addStyleClass("btn_greenColor");
                                    }
                                }
                            }
                        }
                    }
                }

            },
            GetShiftDetails: function() {
                var currenttime = new Date();
                var currentDT = CommonUtility.getCurrentDateTime(new Date());

                var APLT_CMD_GetShiftDetails = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchMainMenuOperator-->GetShiftDetails-->XACQ_GetShiftDetails"
                ); // new sap.ui.model.json.JSONModel();
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + currentDT;
                APLT_CMD_GetShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetShiftDetails&" +
                    params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetShiftDetails.getData()) != 0) {

                    that.byId("id_btn_StartShift").addStyleClass("btn_greenColor");

                }

            },
            VerifyDest: function() {

                var APLT_CMD_GetCRDest = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchMainMenuOperator-->VerifyDest-->XACQ_GetCRDestByApp"
                ); // new sap.ui.model.json.JSONModel();

                var params = "Param.1=" + "BATCHHUB";
                APLT_CMD_GetCRDest.loadData("/XMII/Illuminator?QueryTemplate=ReuseLibrary/Common/Query Template/XACQ_GetCRDestByApp&" +
                    params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetCRDest.getData()) > 0) {
                    var oModel = APLT_CMD_GetCRDest.getData().Rowsets.Rowset[0].Row[0];

                    var batchhubCRDest = oModel.O_Destination;
                    var sessionCRDest = crdest;

                    if (sessionCRDest != "*") {
                        if (sessionCRDest != batchhubCRDest) {


                            this.getView().getModel("destModel").setProperty("/validDestination", "false")
                        } else {
                            this.getView().getModel("destModel").setProperty("/validDestination", "true")

                        }
                    } else {
                        this.getView().getModel("destModel").setProperty("/validDestination", "true")

                    }
                }
            },

            setCustomHeaderText: function() {
                this.getView().byId("customHeader").setText("MII Batch Hub Main Menu");

            },
            // Button onClick function start
            OpenSettngs: function() {
                // Set the busy indicator until the page  load
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("sessionSetting");
            },
            // Button onClick function start
            OpenManualMaster: function() {

                var manualURL = sap.ui.getCore().getModel("session").oData.CA_ManualMasterURL;
                window.open(manualURL, 'ManualMaster',
                    'width=1050,height=800,scrollbars=yes,left=10,top=10,resizable=yes,status=yes,location=no');
            },

            //Navigating to BatchProdDispatch
            BatchprodDispatch: function() {

                var illumuserrole = sap.ui.getCore().getModel("session").getData().IllumLoginRoles;
                var userRoles = new Array();
                userRoles = illumuserrole.split(',');
                var has_Access_Supervisor = false;
                for (var i = 0; i <= userRoles.length - 1; i++) {

                    if (userRoles[i].toString().toUpperCase() == "'ZMIP_PRD_BATCH_SUPERVISOR'") {
                        has_Access_Supervisor = true;
                        break;
                    }

                }

                if (has_Access_Supervisor) {
                    UI_utilities.setContainerBusyState(this, true);
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("BatchProdDispatch");
                } else {
                    MessageBox.error("Supervisor Role is needed to access Campaign Management");
                }



            },

            StartCampaign: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchStartCampaign");
            },

            StartShift: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("startShift");
            },

            redirectBatchList: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchOrderWorkList");
            },

            redirectPlantView: function() {

                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchPlantView");
            },


            redirectBatchIdent: function() {
                var js_campaign = this.getView().getModel("OrderDetailsParam").getProperty("/orderid");
                var js_campaignstrip = this.getView().getModel("OrderDetailsParam").getProperty("/orderidstrip");
                var js_mattext = this.getView().getModel("OrderDetailsParam").getProperty("/mattext");
                var js_material = this.getView().getModel("OrderDetailsParam").getProperty("/matno");
                var js_materialstrip = this.getView().getModel("OrderDetailsParam").getProperty("/matnostrip");

                js_mattext = js_mattext.replace(/%/gi, "%25");
                var js_reqbatch = this.getView().getModel("OrderDetailsParam").getProperty("/batch");


                var oData = {
                    qs_campaign: js_campaign,
                    qs_campaignstrip: js_campaignstrip,
                    qs_material: js_material,
                    qs_materialstrip: js_materialstrip,
                    qs_mattext: js_mattext,
                    qs_reqbatch: js_reqbatch,
                };
                var oDestModel = new sap.ui.model.json.JSONModel(oData);
                sap.ui.getCore().setModel(oDestModel, "BatchIdentParams");
                this._oRouter.navTo("BatchIdentification");
            },

            redirectQualityNotif: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchQualityNotif");
            },

            redirectMaintainNotif: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchMaintainNotif");
            },
            redirectLineStatus: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchLineStatus");
            },
            redirectLogReport: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("LogRep");
            },

            redirectBatchAnalysis: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("BatchAnalysis");
            },
            redirectInspectionPage: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("InspectionPoint");
            },

            redirectReprintLabel: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("ReprintLabel");
            },
            redirectInspResults: function() {
                UI_utilities.setContainerBusyState(this, true);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("InspMICViewResults");
            },

            LogOff: function() {
                top.location.href = '/XMII/Illuminator?service=logout';
            }
        });

    });