var global = "";
var username = "";
var plantid = "";
var plantresr = "";
var bScaleIntegration = false;
sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility",
        "com/khc/batchhub/model/formatter",
        "com/khc/batchhub/model/models"
    ],
    function(Controller, MessageBox, UI_utilities, CommonUtility, formatter, models) {
        "use strict";
        var plant;
        var resource;
        var crdest;
        var projectName;
        var userName;
        var InsShiftMsg;
        return Controller.extend("com.khc.batchhub.controller.BatchStartShift", {
            formatter: formatter,

            onInit: function() {

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("startShift").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },

            _oRoutePatternMatched: function(oEvent) {

                //Hide the messages and set busy to false
                UI_utilities.batchPageOpened(this, "common");

                this.getView().byId("add").setVisible(false);
                this.getView().byId("reduce").setVisible(false);
                this.getView().byId("updshift").setEnabled(false);
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName

                this.getShifts();
                this.getTeamList();
                this.getShiftDetails();
                this.getOrderData();
                this.getMaintenanceNotif();
                this.getPrevNotes();

            },

            /**********************************************************************************************************/
            //on load of page insert the shift details to dropdown
            /*************************************************************************************************************/
            getShifts: function() {

                var oModelShiftName = models.createNewXMLModel(
                "com.khc.batchhub.controller.BatchStartShift-->getShifts-->XACQ_GetShiftsByResr");
                oModelShiftName.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetShiftsByResr&Param.1=" +
                    plant + "&Param.2=" + resource + "&d=" + new Date() + "&Content-Type=text/xml", "", false);
                var shiftDataDD = this.getView().byId("shifts");
                let rowCount = $(oModelShiftName.getData()).find("Row").length
                if (rowCount > 0) {
                    shiftDataDD.setModel(oModelShiftName, "oshiftName");
                }
            },


            /**********************************************************************************************************/
            //on load of page insert the Team details to dropdown
            /*************************************************************************************************************/

            getTeamList: function() {

                var oModelTeamList = models.createNewXMLModel("com.khc.batchhub.controller.BatchStartShift-->getTeamList-->SQLQ_GetTeamList");
                oModelTeamList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetTeamList&d=" + new Date() +
                    "&Content-Type=text/xml", "", false);
                let rowCount = $(oModelTeamList.getData()).find("Row").length
                if (rowCount > 0) {
                    sap.ui.getCore().setModel(oModelTeamList, "oteamList")
                }
            },

            /*****************************************************************************************************************************************************************************************/
            //**** Called from creation event of APLT_CMD_GetShiftDetails applet. Get the details of a running shift and populate required fields.
            /*****************************************************************************************************************************************************************************************/

            getShiftDetails: function() {

                var currenttime = new Date();
                var currentDT = CommonUtility.getCurrentDateTime(currenttime);


                var oModelCurrentShiftData = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->getShiftDetails-->XACQ_GetShiftDetails");
                oModelCurrentShiftData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetShiftDetails&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + currentDT + "&d=" +
                    new Date() + "&Content-Type=text/json", "", false);
                sap.ui.getCore().setModel(oModelCurrentShiftData, "oCurrentShiftData")

                let rowCount = CommonUtility.getJsonModelRowCount(oModelCurrentShiftData.getData())
                if (rowCount > 0) {
                    var startTime = oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].StartTime

                    this.getView().byId('start_date').setValue(startTime.split("T")[0] + " " + startTime.split("T")[1]);
                    this.getView().byId('duration').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].Duration)
                    this.getView().byId('shifts').setSelectedKey(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].ShiftName)
                    this.getView().byId("teamList").setSelectedKey(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].TeamId);
                    //this.getView().byId('teamId').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].TeamId);
                    this.getView().byId('Lead').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].Lead)
                    this.getView().byId('crewList').setValue(oModelCurrentShiftData.getData().Rowsets.Rowset[0].Row[0].TeamSize)

                    this.getView().byId("setshift").setEnabled(false);
                    this.getView().byId("updshift").setEnabled(true);
                    this.getView().byId("endshift").setEnabled(true);

                } else {
                    this.getView().byId("start_date").setValue("");
                    this.getView().byId('duration').setValue("");
                    this.getView().byId('Lead').setValue(userName);
                    this.getView().byId("teamList").setSelectedKey("");
                    this.getView().byId('crewList').setValue("");
                    this.getView().byId("shifts").setSelectedKey("");

                    this.getView().byId("setshift").setEnabled(false);
                    this.getView().byId("updshift").setEnabled(false);
                    this.getView().byId("endshift").setEnabled(false);

                }

                if (this.getView().getModel("oCurrentShiftData").getData().Rowsets.Rowset[0].Row == null) {
                    this.getView().byId("createSNBtn").setEnabled(false);
                } else {
                    this.getView().byId("createSNBtn").setEnabled(true);
                }

            },

            /**************************************************************************************************************************************************************************************/
            //on Load get the list of running order
            /*****************************************************************************************************************************************************************************************/
            getOrderData: function() {

                var crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest
                var oModelOrderDetails = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->getOrderData-->SQLQ_GetRunningOrder");
                var that = this;
                oModelOrderDetails.attachRequestCompleted(
                    function() {
                        //if(CommonUtility.getJsonModelRowCount(oModelOrderDetails.getData())) { 
                        sap.ui.getCore().setModel(oModelOrderDetails, "oOrderdetails");
                        that.getQualityNotif();
                        //}
                    });

                oModelOrderDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetRunningOrder&Param.1=" +
                    plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&d=" + new Date() + "&Content-Type=text/json", "", false);
            },

            /**************************************************************************************************************************************************************************************/
            //on load get the Quality notification
            /*****************************************************************************************************************************************************************************************/
            getQualityNotif: function() {

                var matNum = "";
                var orderId = "";
                let ODRowCount = CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("oOrderdetails").getData())

                if (ODRowCount > 0) {
                    matNum = sap.ui.getCore().getModel("oOrderdetails").getData().Rowsets.Rowset[0].Row[0].MATNR
                    orderId = sap.ui.getCore().getModel("oOrderdetails").getData().Rowsets.Rowset[0].Row[0].ORDERID
                }
                var oModelQualityNotif = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->getQualityNotif-->XACQ_GetQualNotList");

                oModelQualityNotif.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetQualNotList&Param.1=" +
                    plant + "&Param.2=" + resource + "&Param.3=" + orderId + "&Param.4=" + matNum + "&d=" + new Date() +
                    "&Content-Type=text/json", "", false);
                let rowCount = CommonUtility.getJsonModelRowCount(oModelQualityNotif.getData())
                if (rowCount > 0) {
                    sap.ui.getCore().setModel(oModelQualityNotif, "oQualityNotif");
                }
            },

            /**************************************************************************************************************************************************************************************/
            //on load get the Maintenance notification
            /*****************************************************************************************************************************************************************************************/
            getMaintenanceNotif: function() {


                var oModelMaintenanceNotif = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->getMaintenanceNotif-->XACQ_GetMaintNotV1");

                oModelMaintenanceNotif.loadData("/XMII/Illuminator?QueryTemplate=NL_ELS_HUB/QueryTemplate/XACQ_GetMaintNotV1&Param.1=" +
                    resource + "&Param.2=" + plant + "&d=" + new Date() + "&Content-Type=text/json", "", false);
                let rowCount = CommonUtility.getJsonModelRowCount(oModelMaintenanceNotif.getData())
                if (rowCount > 0) {
                    sap.ui.getCore().setModel(oModelMaintenanceNotif, "oMaintNotif");
                }
            },

            /*****************************************************************************************************************************************************************************************/
            //on load of page insert the Shift Notes for Previous Shift dropdown. Get the list of order with status =0 from HNZ_TASKLIST table.
            /****************************************************************************************************************************************************************************************/

            getPrevNotes: function() {
                var oModelPrevNotes = models.createNewXMLModel(
                    "com.khc.batchhub.controller.BatchStartShift-->getPrevNotes-->XACQ_GetShiftNotes_PrevShift");
                oModelPrevNotes.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetShiftNotes_PrevShift&Param.1=" + plant + "&Param.2=" + resource + "&d=" + new Date() +
                    "&Content-Type=text/xml", "", false);
                var oPrevNotesTable = this.getView().byId("prevNotes")
                let rowCount = $(oModelPrevNotes.getData()).find("Row").length
                if (rowCount > 0) {
                    oPrevNotesTable.setModel(oModelPrevNotes, "oPrevNotes")
                }
            },

            /******************************************************************************************************************************************************************************************/
            // on click of create shift notes
            /******************************************************************************************************************************************************************************************/

            createShiftNotes: function() {
                var dt = new Date();
                var date = formatDate(dt);
                var currentDT = getCurrentDateTime(dt);
                var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
                var shiftName = this.getView().byId("shifts").getSelectedKey();
                var Dur = this.getView().byId("duration").getValue();
                var shiftStime = this.getView().getModel("oCurrentShiftData").getData().Rowsets.Rowset[0].Row[0].StartTime;

                var hour = Dur / 60;
                hour = Math.floor(hour);
                var minute = Dur - (hour * 60);
                minute = minute - 1;

                var endtime = new Date(shiftStime.substring(0, 4), shiftStime.substring(5, 7) - 1, shiftStime.substring(8, 10), shiftStime
                    .substring(11, 13), shiftStime.substring(14, 16), shiftStime.substring(17, 19), 0);
                //	alert(shiftStime.substring(0,4)+shiftStime.substring(5,7)+shiftStime.substring(8,10)+shiftStime.substring(11,13)+shiftStime.substring(14,16)+shiftStime.substring(17,19));	

                endtime.setHours(endtime.getHours() + hour);
                endtime.setMinutes(endtime.getMinutes() + minute);


                if (dt > endtime) {
                    date = formatDate(endtime);
                    currentDT = getCurrentDateTime(endtime);
                    time = endtime.getHours() + ":" + endtime.getMinutes() + ":" + endtime.getSeconds();
                }
                var ShiftNoteValue = this.getView().byId("CreateShiftNoteTA").getValue();

                if (this.getView().byId("CreateShiftNoteTA").getValue() != "") {
                    var oModelCrtShiftNotes = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchStartShift-->createShiftNotes-->XACQ_CreateShiftNotes");
                    oModelCrtShiftNotes.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_CreateShiftNotes&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + "ZG99" +
                        "&Param.4=" + date + "&Param.5=" + time + "&Param.6=" + "" + "&Param.7=" + "" + "&Param.8=" + "" + "&Param.9=" +
                        ShiftNoteValue + "&Param.10=" + "" + "&Param.11=" + "" + "&Param.12=" + "HomePageShiftNote" + "&Param.13=" +
                        userName + "&d=" + new Date() + "&Content-Type=text/json", "", false);
                    sap.ui.getCore().setModel(oModelCrtShiftNotes, "oCrtShiftNotes");

                    var ShiftNoteNum = sap.ui.getCore().getModel("oCrtShiftNotes").getData().Rowsets.Rowset[0].Row[0].O_ShiftNote;
                    if (ShiftNoteNum == "E") {
                        //MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0086"));
                        var sCrtSNErrorMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0086");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message", sCrtSNErrorMsg);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                    } else {
                        //MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0085")+ShiftNoteNum);
                        var sCrtSNSuccessMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0085");
                        sap.ui.getCore().getModel("oMessage").setProperty("/message", sCrtSNSuccessMsg + ShiftNoteNum);
                        sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

                        var oModelShiftNote = models.createNewXMLModel(
                            "com.khc.batchhub.controller.BatchStartShift-->createShiftNotes-->SQLQ_InsShiftNote");
                        oModelShiftNote.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/SQLQ_InsShiftNote&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + shiftName +
                            "&Param.4=" + currentDT + "&Param.5=" + "" + "&Param.6=" + ShiftNoteValue + "&Param.7=" + ShiftNoteNum + "&d=" +
                            new Date() + "&Content-Type=text/xml", "", false);
                    }

                } else {
                    //MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0128"));
                    MessageBox.alert("Shift note cannot be blank");
                }
                this.getView().byId("CreateShiftNoteTA").setValue("");
            },


            /******************************************************************************************************************************************************************************************/
            // on click of create shift notes
            /******************************************************************************************************************************************************************************************/
            Check_EndShift: function() {

                var starttime = this.getView().byId("start_date").getValue();

                var oModelDoubleCheckShift = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->Check_EndShift-->XACQ_DoubleCheckShift");
                oModelDoubleCheckShift.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_DoubleCheckShift&Param.1=" + plant + "&Param.2=" + resource + "&d=" + new Date() +
                    "&Content-Type=text/json", "", false);
                sap.ui.getCore().setModel(oModelDoubleCheckShift, "oDoubleCheckShift");

                var ShiftType = oModelDoubleCheckShift.oData.Rowsets.Rowset[0].Row[0].TYPE;



                if (ShiftType == "E") {
                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0076");
                    var that = this;
                    MessageBox.confirm(
                        sAlertMsg, {
                            onClose: function(oAction) {
                                if (oAction === "OK") {
                                    that.GetConfirmAction_EndShift();
                                } else {
                                    //window.location.reload();
                                    that._oRoutePatternMatched();
                                }

                            }
                        });

                } else if (ShiftType == "B") {
                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0082"));
                } else {
                    this.GetConfirmAction_EndShift();

                }

            },


            GetConfirmAction_EndShift: function() {
                var oModelEndShift = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->GetConfirmAction_EndShift-->XACQ_EndShift");
                oModelEndShift.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_EndShift&Param.1=" + plant +
                    "&Param.2=" + resource + "&d=" + new Date() + "&Content-Type=text/json", "", false);
                sap.ui.getCore().setModel(oModelEndShift, "oEndShift");

                var EndType = oModelEndShift.oData.Rowsets.Rowset[0].Row[0].Type;
                if (EndType == "S") {
                    //MessageBox.alert("Shift ended successfully");
                    // Show Success Message in the screen
                    sap.ui.getCore().getModel("oMessage").setProperty("/message", "Shift ended successfully");
                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");
                    this.getView().byId("endshift").setEnabled(false);
                    this.getView().byId("setshift").setEnabled(true);
                    this.getView().byId("updshift").setEnabled(false);
                    this.getView().byId("createSNBtn").setEnabled(false);

                    var oModelArchiveCamp = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchStartShift-->GetConfirmAction_EndShift-->XACQ_UpdCampArchiving");
                    oModelArchiveCamp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_UpdCampArchiving&Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&d=" +
                        new Date() + "&Content-Type=text/json", "", false);
                    sap.ui.getCore().setModel(oModelArchiveCamp, "oArchiveCamp");

                    this._oRoutePatternMatched();
                    //window.location.reload();
                } else if (EndType == "C") {
                    //MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0002")+" "+InsShiftMsg);
                    var sConflictMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0002") + " " + InsShiftMsg;
                    sap.ui.getCore().getModel("oMessage").setProperty("/message", sConflictMsg);
                    sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                }

            },


            /**********************************************************************************************************/
            //on click of set shift button 
            /*************************************************************************************************************/

            Ins_ShiftData: function() {

                var startTime = this.getView().byId("start_date").getValue();
                var duration = this.getView().byId("duration").getValue();
                var shiftName = this.getView().byId("shifts").getSelectedKey();
                var lead = this.getView().byId("Lead").getValue();
                var teamSize = this.getView().byId("crewList").getValue();
                var teamId = this.getView().byId("teamList").getSelectedKey();
                var teamName = this.getView().byId("teamList").getProperty("value");


                var dt = new Date();
                var currentTime = CommonUtility.getCurrentDateTime(dt);

                if (startTime <= currentTime) {
                    if (startTime == "" || duration == "" || shiftName == "" || lead == "" || teamSize == "") {
                        var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0003")
                        MessageBox.warning(
                            msg, {
                                icon: MessageBox.Icon.WARNING,
                                title: "Message from webpage",
                                actions: [MessageBox.Action.OK]
                            });

                    } else if (teamName == "") {
                        var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0128")
                        MessageBox.warning(
                            msg, {
                                icon: MessageBox.Icon.WARNING,
                                title: "Message from webpage",
                                actions: [MessageBox.Action.OK]
                            });

                    } else if (isNaN(this.getView().byId("duration").getValue()) || isNaN(this.getView().byId("crewList").getValue())) {
                        let msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0004")

                        MessageBox.warning(
                            msg, {
                                icon: MessageBox.Icon.WARNING,
                                title: "Message from webpage",
                            });

                    } else if (this.getView().byId("crewList").getValue() < 0) {
                        let msg = "Crew cannot be negative";

                        MessageBox.warning(
                            msg, {
                                icon: MessageBox.Icon.WARNING,
                                title: "Message from webpage",
                            });

                    } else {



                        var oModelSetShift = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchStartShift-->Ins_ShiftData-->XACQ_InsShift");
                        oModelSetShift.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_InsShift&Param.1=" +
                            plant + "&Param.2=" + resource + "&Param.3=" + startTime + "&Param.4=" + duration + "&Param.5=" + shiftName +
                            "&Param.6=" + lead + "&Param.7=" + teamSize + "&Param.8=" + "0" + "&Param.9=" + "0" + "&Param.10=" + teamName +
                            "&Param.11=" + teamId + "&Param.12=" + "0" + "&d=" + new Date() + "&Content-Type=text/json", "", false);

                        let rowCount = CommonUtility.getJsonModelRowCount(oModelSetShift.getData())
                        if (rowCount > 0) {
                            if (oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type == "S") {
                                var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0001")
                                sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");
                                UI_utilities.showAlert();

                                this.getView().byId("endshift").setEnabled(true);
                                this.getView().byId("setshift").setEnabled(false);
                                this.getView().byId("updshift").setEnabled(true);
                                this.getView().byId("createSNBtn").setEnabled(true);

                                InsShiftMsg = oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Message;

                            } else if (oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type == "C") {
                                var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0002") + "." + oModelSetShift.getData().Rowsets
                                    .Rowset[0].Row[0].Message
                                sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                            } else if (oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type == "E") {
                                var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0005")
                                sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                            } else if (oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Type == "CO") {
                                var msg = oModelSetShift.getData().Rowsets.Rowset[0].Row[0].Message
                                sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                                sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                                sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                            }
                        }

                    }
                } else {
                    var msg = this.getView().getModel("i18n").getProperty("BATCH_MSG_0115")
                    MessageBox.warning(
                        msg, {
                            icon: MessageBox.Icon.WARNING,
                            title: "Message from webpage",
                            actions: [MessageBox.Action.OK]
                        });
                }



            },

            /**************************************************************************************************************************************************************************************/
            //on select of item from dropdown load other input boxes
            /*****************************************************************************************************************************************************************************************/
            GetOldShiftDetails: function(oEvent) {
                var selectedShift = this.getView().byId("shifts").getValue()
                //this.getShiftNames(selectedShift);

                if (selectedShift == "Night" || selectedShift == "Nacht" || selectedShift == "Nights" || selectedShift ==
                    "Sunday Night 10 hr" || selectedShift == "Start-Up - Sunday" || selectedShift == "Trzecia zmiana" || selectedShift ==
                    "Nuit" || selectedShift == "Red Shift" || selectedShift == "Blue Shift") {
                    this.getView().byId("add").setVisible(false);
                    this.getView().byId("reduce").setVisible(true);
                } else {
                    this.getView().byId("add").setVisible(false);
                    this.getView().byId("reduce").setVisible(false);
                }


                var oModelShiftData = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->GetOldShiftDetails-->XACQ_GetOldShiftDetails");

                oModelShiftData.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOldShiftDetails&Param.1=" +
                    plant + "&Param.2=" + resource + "&Param.3=" + selectedShift + "&d=" + new Date() + "&Content-Type=text/json", "", false
                    );

                let rowCount = CommonUtility.getJsonModelRowCount(oModelShiftData.getData())

                if (rowCount > 0) {
                    sap.ui.getCore().setModel(oModelShiftData, "shiftData")

                    var currentDate = CommonUtility.getCurrentDate()
                    this.getView().byId("start_date").setValue(currentDate + " " + oModelShiftData.getData().Rowsets.Rowset[0].Row[0].StartTime)
                    this.getView().byId("duration").setValue(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].Duration);
                    this.getView().byId("Lead").setValue(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].Lead);

                    this.getView().byId("crewList").setValue(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].TeamSize);
                    let rowCount = CommonUtility.getJsonModelRowCount(oModelShiftData.getData())
                    if (rowCount > 0) {
                        this.getView().byId("teamList").setSelectedKey(oModelShiftData.getData().Rowsets.Rowset[0].Row[0].TeamId);
                    }

                    /*
                    this.GetTagConfigforResrByTime(this.getView().byId('start_date').getValue())
                    
                    if (plant=="3278"|| plant=="3005" || plant=="3017")
                    {
                    	if((oModelShiftData.getData().Rowsets.Rowset[0].Row[0].Running) != "1")
                    	{
                    		this.getView().byId('shift_counter').setValue("0")
                    	}
                    			
                    }
                    */
                    this.getView().byId("setshift").setEnabled(true);
                } else {
                    this.getView().byId("duration").setValue("480");
                    this.getView().byId("Lead").setValue(userName)
                    /*
                    if (plant=="3278"|| plant=="3005")
                    {
                    	this.getView().byId("shift_counter").setValue("0")
                    	
                    }
                    this.GetTagConfigforResrByTime(this.getView().byId("start_date").getValue());
                    */
                    this.getView().byId("setshift").setEnabled(true);

                }

            },


            /**********************************************************************************************************/
            //on click of update shift button call-Check_UpdShift and Check_UpdShift calls-below function 
            /*************************************************************************************************************/
            Upd_Shift: function() {

                var duration = this.getView().byId("duration").getValue();
                var lead = this.getView().byId("Lead").getValue();
                var teamSize = this.getView().byId("crewList").getValue();
                var teamId = this.getView().byId("teamList").getSelectedKey()
                var teamName = this.getView().byId("teamList").getProperty("value")
                var startTime = this.getView().byId("start_date").getValue();
                var shiftName = this.getView().byId("shifts").getSelectedKey();

                //var trgtspeed = document.getElementById("TrgtSpd").value;	

                if (startTime == "" || duration == "" || shiftName == "" || lead == "" || teamSize == "") {
                    var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0003")
                    MessageBox.warning(
                        msg, {
                            icon: MessageBox.Icon.WARNING,
                            title: "Message from webpage",
                            actions: [MessageBox.Action.OK]
                        });

                } else if (teamName == "") {
                    var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0128")
                    MessageBox.warning(
                        msg, {
                            icon: MessageBox.Icon.WARNING,
                            title: "Message from webpage",
                            actions: [MessageBox.Action.OK]
                        });

                } else if (isNaN(this.getView().byId("duration").getValue()) || isNaN(this.getView().byId("crewList").getValue())) {
                    let msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0004")

                    MessageBox.warning(
                        msg, {
                            icon: MessageBox.Icon.WARNING,
                            title: "Message from webpage",
                        });

                } else if (this.getView().byId("crewList").getValue() < 0) {
                    let msg = "Crew cannot be negative";

                    MessageBox.warning(
                        msg, {
                            icon: MessageBox.Icon.WARNING,
                            title: "Message from webpage",
                        });

                } else {

                    var oModelUpdateShift = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchStartShift-->Upd_Shift-->XACQ_UpdShift");

                    oModelUpdateShift.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_UpdShift&Param.1=" +
                        duration + "&Param.2=" + lead + "&Param.3=" + plant + "&Param.4=" + resource + "&Param.5=" + teamId + "&Param.6=" +
                        teamName + "&Param.7=" + teamSize + "&d=" + new Date() + "&Content-Type=text/json", "", false);
                    let rowCount = CommonUtility.getJsonModelRowCount(oModelUpdateShift.getData())
                    if (rowCount > 0) {

                        if (oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Type == "S") {
                            var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0133")
                            sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type", "Success");

                        } else if (oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Type == "E") {
                            var msg = this.getView().getModel("i18n").getProperty("HUB_MSG_0005")
                            sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                        } else if (oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Type == "CO") {
                            var msg = oModelUpdateShift.getData().Rowsets.Rowset[0].Row[0].Message
                            sap.ui.getCore().getModel("oMessage").setProperty("/message", msg);
                            sap.ui.getCore().getModel("oMessage").setProperty("/showMessage", true);
                            sap.ui.getCore().getModel("oMessage").setProperty("/type", "Error");
                        }
                    }
                }
            },

            /**********************************************************************************************************/

            /*************************************************************************************************************/
            addDate: function() {
                let dateTime = this.getView().byId("start_date").getValue();
                this.getView().byId("add").setVisible(false);
                this.getView().byId("reduce").setVisible(true);
                let date = new Date(dateTime);
                date.setDate(date.getDate() + 1);
                let formatedDate = CommonUtility.getCurrentDateTime(date);
                this.getView().byId("start_date").setValue(formatedDate);
                //this.GetTagConfigforResrByTime(this.getView().byId("start_date").getValue());
            },
            /**********************************************************************************************************/

            /*************************************************************************************************************/
            reduceDate: function() {
                let dateTime = this.getView().byId("start_date").getValue();
                this.getView().byId("add").setVisible(true);
                this.getView().byId("reduce").setVisible(false);
                let date = new Date(dateTime);
                date.setDate(date.getDate() - 1);
                let formatedDate = CommonUtility.getCurrentDateTime(date);
                this.getView().byId("start_date").setValue(formatedDate);
                //this.GetTagConfigforResrByTime(this.getView().byId("start_date").getValue());
            },
            /*************************************************************************************************************/
            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },

            onHelp: function() {

                UI_utilities.OpenHelpFileSingle("StartShift");
            },


        });

    });