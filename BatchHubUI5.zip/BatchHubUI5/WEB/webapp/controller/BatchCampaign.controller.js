sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models",   "com/khc/batchhub/model/formatter"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter) {


        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var crid;
        var resrtxt;

        return Controller.extend("com.khc.batchhub.controller.BatchCampaign", {
            formatter: formatter,
            onInit: function() {

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchCampaign").attachPatternMatched(
                    this._oRoutePatternMatched, this);
                // Model for ViewInstruction Fragment
                var oContent = {
                  isPhaseLong: false,
                  content: "",
              };
              var oContModel = new sap.ui.model.json.JSONModel(oContent);
              sap.ui.getCore().setModel(oContModel, "oPhaseLongText");
            },

            _oRoutePatternMatched: function(oEvent) {

                //Hide the messages and set busy to false 
                UI_utilities.batchPageOpened(this, "home");
                UI_utilities.batchPageOpened(this, "BatchCampaign");
                var oData = {
                    qs_crid: "",
                    qs_orderid: "",
                    qs_msgid: "",
                    qs_matnum: "",
                    qs_mattext: "",
                    qs_modorderid: "",
                    qs_modmatnum: ""

                };
                var oDestModel = new sap.ui.model.json.JSONModel(oData);
                sap.ui.getCore().setModel(oDestModel, "BatchCampaignParams");

                var oEmptyModel = new sap.ui.model.json.JSONModel();
                this.getView().setModel(oEmptyModel, "campaignViewModel");

                this.loadData();
                this.Campview();
                this.GetActBatch();
            },

            loadData: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;

                resrtxt = sap.ui.getCore().getModel("session").oData.CA_ResrText;
                if (sap.ui.getCore().getModel("BatchCampaignParams")) {
                    var camp = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_modorderid
                    this.getView().byId("id_txt_camp").setValue(camp);
                    var txt_matnum = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_modmatnum
                    this.getView().byId("txt_matnum").setValue(txt_matnum);
                    var txt_desc = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_mattext
                    this.getView().byId("txt_desc").setValue(txt_desc);

                    var orderID = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_orderid
                    this.getView().byId("id_hid_orderid").setValue(orderID);
                    var matNum = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_matnum
                    this.getView().byId("id_hid_matnum").setValue(matNum);
                    var crid = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_crid;
                    this.getView().byId("id_hid_crid").setValue(crid);
                    var msgid = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_msgid
                    this.getView().byId("id_hid_msgid").setValue(msgid);
                }
            },

            Campview: function() {
                var orderID = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_orderid;
                var matNum = sap.ui.getCore().getModel("BatchCampaignParams").oData.qs_matnum;

                var hid_OrderId = this.getView().byId("id_hid_orderid").getValue();
                var hid_matNum = this.getView().byId("id_hid_matnum").getValue();
                var hid_crId = this.getView().byId("id_hid_crid").getValue();

                if (hid_OrderId != orderID || hid_matNum != matNum) {



                    var oCampviewModel = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchDispDetail-->Campview-->XACQ_CampaignView");
                    var params = "Param.1=" + hid_OrderId + "&Param.2=" + hid_crId + "&Param.3=" + plant + "&Param.4=" +
                        resource + "&Param.5=" + crdest + "&Param.6=" + resrtxt;

                    oCampviewModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CampaignView&" +
                        params + "&Content-Type=text/json", "", false);
                    this.getView().setModel(oCampviewModel, "campaignViewModel");



                } else {
                    this.GetRunCamp();
                }
            },
            GetRunCamp: function() {
                var oGetLatestRunCampDetails = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->GetRunCamp-->XACQ_GetLatestRunCampDetails");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest;
                oGetLatestRunCampDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetLatestRunCampDetails&" + params + "&Content-Type=text/json", "", false);


                if (CommonUtility.getJsonModelRowCount(oGetLatestRunCampDetails.getData()) > 0) {
                    var oData = oGetLatestRunCampDetails.getData().Rowsets.Rowset[0].Row[0];

		if(oData.ORDERSTRIP!="" && oData.ORDERSTRIP!="NA") {
                    this.getView().byId("id_txt_camp").setValue(oData.ORDERSTRIP);
                    this.getView().byId("txt_matnum").setValue(oData.MATNRSTRIP);
                    this.getView().byId("txt_desc").setValue(oData.MATTEXT);

                    this.getView().byId("id_hid_orderid").setValue(oData.ORDERID);
                    this.getView().byId("id_hid_crid").setValue(oData.CRID);
                    this.getView().byId("id_hid_msgid").setValue(oData.MSGID);

                    this.GetActBatch();
                    this.Campview();
                	}
	}

            },
            GetActBatch: function() {

                var hid_orderid = this.getView().byId("id_hid_orderid").getValue();
                var crid = this.getView().byId("id_hid_crid").getValue();
                var oGetBatchCount = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->GetActBatch-->SQLQ_GetTotalBatchCount");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + hid_orderid;
                oGetBatchCount.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/SQLQ_GetTotalBatchCount&" + params + "&Content-Type=text/json", "", false);


                if (CommonUtility.getJsonModelRowCount(oGetBatchCount.getData()) > 0) {
                    var oData = oGetBatchCount.getData().Rowsets.Rowset[0].Row[0];

                    this.getView().byId("txt_reqbatch").setValue(oData.MAX_BATCH);
                }

                var oGetBatchSize = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchProdDispatch-->GetActBatch-->SQLQ_GetOrderBatchSize");
                var params = "Param.1=" + crid + "&Param.2=" + hid_orderid + "&Param.3=" + plant;
                oGetBatchSize.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/SQLQ_GetOrderBatchSize&" + params + "&Content-Type=text/json", "", false);


                if (CommonUtility.getJsonModelRowCount(oGetBatchSize.getData()) > 0) {
                    var oData = oGetBatchSize.getData().Rowsets.Rowset[0].Row[0];

                    this.getView().byId("id_hid_batchsize").setValue(oData.ACTBATCHSIZE);
                }


            },
            SetInstruction: function() {

                var SelRow = this.getView().byId("campaignTable").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var cSelRow = this.getView().byId("campaignTable").getSelectedContextPaths()[0];
                    var cSelectedRow = this.getView().getModel("campaignViewModel").getProperty(cSelRow);

                    var selPhase = cSelectedRow.PHASE;
                   
                    var orderid = this.getView().byId("id_hid_orderid").getValue();
                    var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
                    //this.openBatchOrdInstPopUp(orderid, selPhase);
                    
                    if (!this.oBatchPhaseInsPopUp) {
                      this.oBatchPhaseInsPopUp = sap.ui.xmlfragment("com.khc.batchhub.view.BatchExecuteOrder.PhaseLongTextPopUp", this);
                   }
                   this.oBatchPhaseInsPopUp.open();
                   
                   
                   this.setPhaseLongText(sLanguage, orderid, plant, selPhase,projectName);
                   
                } else {
                    MessageBox.error("Please select a row to view phase instruction");
                }

            }, 

            SetOrderInstruction: function() {

              var sLanguage =  sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
                var phase = "%20"; // "\xa0";
                var orderid = this.getView().byId("id_hid_orderid").getValue();
                //this.openBatchOrdInstPopUp(orderid, phase);
                
                if (!this.oBatchPhaseInsPopUp) {
                  this.oBatchPhaseInsPopUp = sap.ui.xmlfragment("com.khc.batchhub.view.BatchExecuteOrder.PhaseLongTextPopUp", this);
               }
               this.oBatchPhaseInsPopUp.open();
               
               
               this.setPhaseLongText(sLanguage, orderid, plant, phase,projectName);
               
            },

             
            /*Instruction long Text Bind to Model*/
 
       closeLongTextPopUp: function() {
          this.oBatchPhaseInsPopUp.close();
       },
            setPhaseLongText: function(sLanguage, sOrderID, sPlant, sPhase, sProjectName) {
              
                var sParams = "Param.1=" + sLanguage + "&Param.2=" + sOrderID + "&Param.3=" + sPhase + "&Param.4=" + sPlant;
                jQuery.ajax({
                    url: "/XMII/Illuminator?QueryTemplate=" + sProjectName + "/QueryTemplate/XACQ_GetLongText&" + sParams +
                        "&content-type=text/xml",
                    type: 'GET',
                    async: false,
                    success: function(xmlData) {

                        var longtext = $(xmlData).find("Row").text(); 
                        longtext = longtext.replace(/&lt;/gi, "<");
                        longtext = longtext.replace(/&gt;/gi, ">");

                        var result = longtext.match(/(!@)/g);
                        var splt = longtext.split("!@");

                        var k = 0;
                        if (result != null) {
                            for (var i = 0; i < result.length; i++) {
                                k = longtext.indexOf(result[i], k);
                                k += result[i].length;

                                if (i % 2 != 0) {
                                    splt[i] = '<A HREF="' + splt[i] + '" target="_blank"' + '>' + splt[i] + '</A>';
                                }

                                if (i == result.length - 1) {
                                    longtext = "<b>" + splt.join(" ") + "</b>"; 
                                    sap.ui.getCore().getModel("oPhaseLongText").setProperty("/content", longtext);
                                }
                            }
                        } else {
                            sap.ui.getCore().getModel("oPhaseLongText").setProperty("/content", longtext);
                        }
                    },
                    error: function(errorData2) {
                        console.log(errorData2);
                    }
                });

            },
            
            /*Instruction long Text Bind to Model End*/

            ShowMatList: function() {
                 
                this.openBatchMatListPopUp();
            },
            /*BatchMaterialListPopUp.Fragment Functoins Start*/
            openBatchMatListPopUp: function() {
                if (!this.oBatchMatListPopUp) {
                    this.oBatchMatListPopUp = sap.ui.xmlfragment("com.khc.batchhub.view.Fragments.BatchMaterialListPopUp", this);
                }
                this.oBatchMatListPopUp.open();
                this.getMaterialList();
            },
            closeBatchMatListPopUp: function() {
                this.oBatchMatListPopUp.close();
            },

            getMaterialList: function() {
                var orderId = this.getView().byId("id_hid_orderid").getValue();
                var batchSize = this.getView().byId("id_hid_batchsize").getValue();
                var hid_crId = this.getView().byId("id_hid_crid").getValue();
                var APLT_GRI_MaterialList = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchCampaign-->getMaterialList-->XACQ_GetMaterialList");
                var params = "Param.1=" + plant + "&Param.2=" + orderId + "&Param.3=" + batchSize + "&Param.4=" + hid_crId + "&Param.5=" +
                    resource;
                APLT_GRI_MaterialList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetMaterialList&" + params + "&Content-Type=text/json", "", false);
                // this.getView().setModel(APLT_GRI_MaterialList, "materialListModel");
                sap.ui.getCore().setModel(APLT_GRI_MaterialList, "materialListModel");
            },
            /*BatchMaterialListPopUp.Fragment Functoins End*/



            menuSelected: function(oEvent) {

                // Navigate the the selected menu page

                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            }

        });
    });