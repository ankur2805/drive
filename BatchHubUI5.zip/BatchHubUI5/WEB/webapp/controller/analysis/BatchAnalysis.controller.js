sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
   "sap/m/MessageBox",
   "com/khc/batchhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility", "sap/m/DateTimeInput", "com/khc/batchhub/model/models"
],
function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, DateTimeInput, models) {
   var plant;
   var projectName;
   var selected = 0;
   var js_CampaingFlag = 0;
   var js_InputMatFlag = 0;
   var js_InputBatchFlag = 0;
   var js_OutputMatFlag = 0;
   var js_OutputBatchFlag = 0;
   var js_ChkAptLoopCount = 0;
   var js_ChkPageLoadFlag = 0;
   
   return Controller.extend("com.khc.batchhub.controller.analysis.BatchAnalysis", {
      onInit: function() {
         
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         this._oRouter.getRoute("BatchAnalysis").attachPatternMatched(
         this._oRoutePatternMatched, this);
      },
      
      _oRoutePatternMatched: function(oEvent) {
         
         //Hide the messages and set busy to false
         UI_utilities.batchPageOpened(this, "BatchAnalysis");
         plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
         projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
         
         this.LoadCampain();
         this.LoadInputMat();
         this.LoadInputBatch();
         this.LoadOutputMat();
         this.LoadOutputBatch();
         this.checkApplet();
         this.clearValues();
      },
      
      menuSelected: function(oEvent) {
         
         // Navigate the the selected menu page
         
         var sKey = oEvent.getParameters().key;
         UI_utilities.openMenu(this._oRouter, this, sKey);
         
      },
      LoadCampain: function() {
         js_CampaingFlag = 1;
      },
      
      LoadInputMat: function() {
         js_InputMatFlag = 1;
      },
      
      LoadInputBatch: function() {
         js_InputBatchFlag = 1;
      },
      
      LoadOutputMat: function() {
         js_OutputMatFlag = 1;
      },
      
      LoadOutputBatch: function() {
         js_OutputBatchFlag = 1;
      },
      
      checkApplet: function() {
         if (js_InputMatFlag == 1 && js_InputBatchFlag == 1 && js_OutputMatFlag == 1 && js_OutputBatchFlag == 1 && js_CampaingFlag == 1) {
            this.GetCampaign();
            this.PopulateMatBatch();
            js_ChkPageLoadFlag = 1;
            } else {
            if (js_ChkAptLoopCount > 6) {
               return;
               } else {
               js_ChkAptLoopCount = js_ChkAptLoopCount + 1;
               setTimeout(function() {
                  this.checkApplet();
               }, 1000);
            }
         }
      },
      
      /* ***********************Populate the date fields through this function *************************************************/
      
      SetToFromDateTIme: function() {
         
         var date = new Date();
         var changedDate = date.setDate(date.getDate() - 7);
         var fromDate = CommonUtility.getCurrentDateTime (new Date(changedDate));
         var toDate = CommonUtility.getCurrentDateTime(new Date());
         
         //var EndDate = CommonUtility.getCurrentDateTime(new Date());
         //var TheDate = CommonUtility.getCurrentDateTime(new Date());
         //var EndDate =(new Date());
         //var TheDate = (new Date());
         //TheDate = TheDate.setDate(TheDate.getCurrentDateTime() - 7);
         //TheDate = TheDate.setDate(TheDate.getDate() - 7);
         //var StartDate = new Date(TheDate);
         
         this.getView().byId("timeFrom").setValue(fromDate);
         this.getView().byId("timeTo").setValue(toDate);
         
         this.SetDefaults();
         this.checkApplet();
      },
      
      SetDefaults: function() {
         
         var Campaign = '%';
         var InputMaterial = '%';
         var InputBatch = '%';
         var OutputMaterial = '%';
         var OutputBatch = '%';
         timeFrom = new Date(this.getView().byId("timeFrom").getValue());
         timeTo = new Date(this.getView().byId("timeTo").getValue());
         
         var BatchAnalysisTopDown = models.createNewXMLModel(
         "com.khc.batchhub.controller.analysis.BatchAnalysis-->SetDefaults-->SQLQ_BatchAnalysisTopDown");
         var params = "Param.1=" + InputMaterial + "&Param.2=" + InputBatch + "&Param.3=" + OutputMaterial + "&Param.4=" + OutputBatch +
         "&Param.5=" + Campaign + "&Param.6=" + plant + "&Param.7=" + timeFrom + "&Param.8=" + timeTo +"&d="+new Date();
         var url = "/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_BatchAnalysisTopDown&" + params + "&content-type=text/xml";
         
         BatchAnalysisTopDown.loadData(encodeURI(url), "", false);
         this.getView().setModel(BatchAnalysisTopDown, "oBatchAnalysis");
         
      },
      
      GetCampaign: function() {
         if (this.getView().byId("timeFrom").getValue() == "" || this.getView().byId("timeTo").getValue() == "") {
            this.SetToFromDateTIme();
            } else {
            var tipTimeFrom = this.getView().byId("timeFrom").getValue();
            var tipTimeTo = this.getView().byId("timeTo").getValue();
            var CampaignList = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.BatchAnalysis-->GetCampaign-->SQLQ_GetCampaignList");
            var params = "Param.1=" + plant + "&Param.2=" + tipTimeFrom + "&Param.3=" + tipTimeTo +"&d="+new Date();
            CampaignList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/SQLQ_GetCampaignList&" + params + "&Content-Type=text/json", "", false);
            this.getView().setModel(CampaignList, "oCampignlist");
         }
         
      },
      
      PopulateMatBatch: function() {
         
         //var CampaignNumber = document.APLT_BRO_Campaign.getBrowserObject().getSelectedDatalinkValue();
         var CampaignNumber = this.getView().byId("campignId").getSelectedKey();
         
         this.getView().byId("InputMaterialId").setSelectedKey("");
         var inputMaterial = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.BatchAnalysis-->PopulateMatBatch-->SQLQ_InputMaterial");
         var params = "Param.1=" + CampaignNumber + "&Param.2=" + plant +"&d="+new Date();
         inputMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_InputMaterial&" + params + "&Content-Type=text/json", "", false);
         this.getView().setModel(inputMaterial, "oInputMateriallist");
         
         this.getView().byId("InputBatchId").setSelectedKey("");
         var inputBatch = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.BatchAnalysis-->PopulateMatBatch-->SQLQ_InputBatch");
         var params = "Param.1=" + CampaignNumber + "&Param.2=" + plant +"&d="+new Date();
         inputBatch.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_InputBatch&" + params + "&Content-Type=text/json", "", false);
         this.getView().setModel(inputBatch, "oInputBatchlist");
         
         this.getView().byId("OutputMaterialId").setSelectedKey("");
         var outputMaterial = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.BatchAnalysis-->PopulateMatBatch-->SQLQ_OutputMaterial");
         var params = "Param.1=" + CampaignNumber + "&Param.2=" + plant +"&d="+new Date();
         outputMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_OutputMaterial&" + params + "&Content-Type=text/json", "", false);
         this.getView().setModel(outputMaterial, "oOutputMateriallist");
         
         this.getView().byId("OutputBatchId").setSelectedKey("");
         var outputBatch = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.BatchAnalysis-->PopulateMatBatch-->SQLQ_OutputBatch");
         var params = "Param.1=" + CampaignNumber + "&Param.2=" + plant +"&d="+new Date();
         outputBatch.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_OutputBatch&" + params + "&Content-Type=text/json", "", false);
         this.getView().setModel(outputBatch, "oOutputBatchlist");
         
      },
      
      /******************* Function to be triggered when a Campaign has been selected *****************************/
      
      ChangeOption: function() {
         if (selected == 0)
         selected = 1;
         else
         selected = 0;
      },
      
      displayTable: function() {
         var InputMaterial = this.getView().byId("InputMaterialId").getSelectedKey();
         var InputBatch = this.getView().byId("InputBatchId").getSelectedKey();
         var OutputMaterial = this.getView().byId("OutputMaterialId").getSelectedKey();
         var OutputBatch = this.getView().byId("OutputBatchId").getSelectedKey();
         var Campaign = this.getView().byId("campignId").getSelectedKey();
         var tipTimeFrom = this.getView().byId("timeFrom").getValue();
         var tipTimeTo = this.getView().byId("timeTo").getValue();
         
         if (InputMaterial == "") {
            InputMaterial = "%";
         }
         if (InputBatch == "") {
            InputBatch = "%";
         }
         if (OutputMaterial == "") {
            OutputMaterial = "%";
         }
         if (OutputBatch == ""){
            OutputBatch = "%";
         }
         if (selected == 0) {
            this.getView().byId("DivBottom").setVisible(false);
            var BatchAnalysisTopDown = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.BatchAnalysis-->displayTable-->SQLQ_BatchAnalysisTopDown");
            var params = "Param.1=" + InputMaterial + "&Param.2=" + InputBatch + "&Param.3=" + OutputMaterial + "&Param.4=" + OutputBatch +
            "&Param.5=" + Campaign + "&Param.6=" + plant + "&Param.7=" + tipTimeFrom + "&Param.8=" + tipTimeTo +"&d="+new Date();
            var url = "/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/SQLQ_BatchAnalysisTopDown&" + params + "&Content-Type=text/json";
            BatchAnalysisTopDown.loadData(encodeURI(url), "", false);
            this.getView().setModel(BatchAnalysisTopDown, "oTopDownTable");
            
            if (CommonUtility.getJsonModelRowCount(BatchAnalysisTopDown.getData()) != 0) {
               var RowCount = BatchAnalysisTopDown.getData().Rowsets.Rowset[0].Row.length;
               if (RowCount != 0){
                  this.getView().byId("DivTop").setVisible(true);
               }
            
               else {
               var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
               MessageBox.alert(msg);
               }
                 }
         } else {
            
            this.getView().byId("DivTop").setVisible(false);
            
            var BatchAnalysisBottomUp = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.BatchAnalysis-->displayTable-->SQLQ_BatchAnalysisBottomUp");
            var params = "Param.1=" + InputMaterial + "&Param.2=" + InputBatch + "&Param.3=" + OutputMaterial + "&Param.4=" + OutputBatch +
            "&Param.5=" + Campaign + "&Param.6=" + plant + "&Param.7=" + tipTimeFrom + "&Param.8=" + tipTimeTo +"&d="+new Date();
            BatchAnalysisBottomUp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/SQLQ_BatchAnalysisBottomUp&" + params + "&Content-Type=text/json", "", false);
            this.getView().setModel(BatchAnalysisBottomUp, "oBottomUpTable");
            
            if (CommonUtility.getJsonModelRowCount(BatchAnalysisBottomUp.getData()) != 0) {
               var RowCount = BatchAnalysisBottomUp.getData().Rowsets.Rowset[0].Row.length;
               if (RowCount != 0){
                  
                  this.getView().byId("DivBottom").setVisible(true);
               }
            
               else {
               var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
               MessageBox.alert(msg);
               }
                  }
         }
         
      },
      
      RefreshCampaign: function() {
         if (js_ChkPageLoadFlag == 1) {
            this.GetCampaign();
         } else {}
      },
      
      clearValues: function()
      {
         var oBatchAnalysisModel = new sap.ui.model.json.JSONModel();
         this.getView().setModel(oBatchAnalysisModel, "oTopDownTable");
         this.getView().setModel(oBatchAnalysisModel, "oBottomUpTable");
         this.getView().byId("campignId").setSelectedKey("");
         this.getView().byId("InputMaterialId").setSelectedKey("");
         this.getView().byId("InputBatchId").setSelectedKey("");
         this.getView().byId("OutputMaterialId").setSelectedKey("");
         this.getView().byId("OutputBatchId").setSelectedKey("");
         
      } ,
      onHelp: function() {
         
         UI_utilities.OpenHelpFileSingle("Plantview");
      }
      
      });
   });   