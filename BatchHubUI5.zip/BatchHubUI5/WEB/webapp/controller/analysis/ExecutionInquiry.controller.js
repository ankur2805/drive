sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
   "sap/m/MessageBox",
   "com/khc/batchhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models","com/khc/batchhub/model/formatter"
],
function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models,formatter) {
   
   var plant;
   var projectName;
   var Campaign;
   var tipTimeFrom;
   var tipTimeTo;
   var resource;
   var oBatchExectionInqry;
   
   
   
   return Controller.extend("com.khc.batchhub.controller.analysis.ExecutionInquiry", {
	   formatter: formatter,
      onInit: function() {
         oBatchExectionInqry=this;
         
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         this._oRouter.getRoute("ExecutionInquiry").attachPatternMatched(
         this._oRoutePatternMatched, this);
      },
      
      _oRoutePatternMatched: function(oEvent) {
         
         //Hide the messages and set busy to false
         UI_utilities.batchPageOpened(this, "ExecutionInquiry");
         plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
         projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
         var oDisplayData = {
            selectedOption: "show"
         };
         var oDisplayOptionModel = new sap.ui.model.json.JSONModel(oDisplayData);
         sap.ui.getCore().setModel(oDisplayOptionModel, "displayOption");
         this.SetDefaults();
         this.clearValues();
      },
      
      menuSelected: function(oEvent) {
         
         // Navigate the the selected menu page
         
         var sKey = oEvent.getParameters().key;
         UI_utilities.openMenu(this._oRouter, this, sKey);
         
      },
      
      SetDefaults: function() {
         //var fromDate = CommonUtility.getCurrentDateTime(new Date());
         var date = new Date();
         var changedDate = date.setDate(date.getDate() - 30);
         var fromDate = CommonUtility.getCurrentDateTime(new Date(changedDate));
         var toDate = CommonUtility.getCurrentDateTime(new Date());
         
         oBatchExectionInqry.getView().byId("timeFrom").setValue(fromDate);
         oBatchExectionInqry.getView().byId("timeTo").setValue(toDate);
         
         this.GetCampaign();
         
      },
      
      GetCampaign: function() {
         tipTimeFrom = oBatchExectionInqry.getView().byId("timeFrom").getValue();
         tipTimeTo = oBatchExectionInqry.getView().byId("timeTo").getValue();
         var CampaignList = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.ExecutionInquiry-->GetCampaign-->SQLQ_GetCampaignList");
         var params = "Param.1=" + plant + "&Param.2=" + tipTimeFrom + "&Param.3=" + tipTimeTo +"&d="+new Date();
         CampaignList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_GetCampaignList&" + params + "&Content-Type=text/json", "", false);
         oBatchExectionInqry.getView().setModel(CampaignList, "oCampignlist");
         //this.getView().byId("campignId").insertItem(new  sap.ui.core.Item({key:"Select",text:"Select"}),0);          
         
      },
      
      /**********Function to be triggered when a Campaign has been selected ************/
      PopulateResource: function() {
         oBatchExectionInqry.getView().byId("resourceId").setSelectedKey("");
         oBatchExectionInqry.getView().byId("productionUnitId").setSelectedKey("")
         var resourceList = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.ExecutionInquiry-->PopulateResource-->SQLQ_ResourceExeInq");
         var params = "Param.1=" + plant +"&d="+new Date();
         resourceList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_ResourceExeInq&" + params + "&Content-Type=text/json", "", false);
         oBatchExectionInqry.getView().setModel(resourceList, "oResourcelist");
         
         oBatchExectionInqry.getView().byId("phaseId").setSelectedKey("")
         Campaign = oBatchExectionInqry.getView().byId("campignId").getSelectedKey();
         var distPhase = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.ExecutionInquiry-->PopulateResource-->SQLQ_GetTextKeyByOrder");
         var params = "Param.1=" + Campaign +"&d="+new Date();
         distPhase.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_GetTextKeyByOrder&" + params + "&Content-Type=text/json", "", false);
         oBatchExectionInqry.getView().setModel(distPhase, "oDistPhaselist");
      },
      
      PopulateProduction: function() {
         oBatchExectionInqry.getView().byId("productionUnitId").setSelectedKey("");
         resource = oBatchExectionInqry.getView().byId("resourceId").getSelectedKey();
         var prodUnitList = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.ExecutionInquiry-->PopulateProduction-->SQLQ_ProductionUnit");
         var params = "Param.1=" + plant + "&Param.2=" + resource +"&d="+new Date();
         prodUnitList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_ProductionUnit&" + params + "&Content-Type=text/json", "", false);
         oBatchExectionInqry.getView().setModel(prodUnitList, "oProdUnitlist");
      },
      
      displayTable: function() {
         
         var ProdUni = oBatchExectionInqry.getView().byId("productionUnitId").getSelectedKey();
         resource = oBatchExectionInqry.getView().byId("resourceId").getSelectedKey();
         Campaign = oBatchExectionInqry.getView().byId("campignId").getSelectedKey();
         tipTimeFrom = oBatchExectionInqry.getView().byId("timeFrom").getValue();
         tipTimeTo = oBatchExectionInqry.getView().byId("timeTo").getValue();
         var OrderPhase = oBatchExectionInqry.getView().byId("phaseId").getSelectedKey();
         
         if (resource == "") {
            resource = "%";
         }
         if (ProdUni == "") {
            ProdUni = "%";
         }
         if (OrderPhase == "") {
            OrderPhase = "%";
         }
         //var oExecutionTable = new sap.ui.model.json.JSONModel();
         var oExecutionTable = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.ExecutionInquiry-->displayTable-->SQLQ_Execution");
         var params = "Param.1=" + ProdUni + "&Param.2=" + resource + "&Param.3=" + Campaign + "&Param.4=" + tipTimeFrom + "&Param.5=" +
         tipTimeTo + "&Param.6=" + OrderPhase +"&d="+new Date();
         var url = "/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_Execution&" + params + "&Content-Type=text/json";
         oExecutionTable.loadData(encodeURI(url), "", false);
         oBatchExectionInqry.getView().setModel(oExecutionTable, "oExecutionTable");
         
         //var RowCount = document.APLT_GRI_Execution.getGridObject().getRowcount();
         if (CommonUtility.getJsonModelRowCount(oExecutionTable.getData()) != 0) {
            var RowCount = oExecutionTable.getData().Rowsets.Rowset[0].Row.length;
            if (RowCount != 0) {
               
               oBatchExectionInqry.getView().byId("ExecutionId").setVisible(true);
               oBatchExectionInqry.getView().byId("Execution").setVisible(true);
               oBatchExectionInqry.getView().byId("id_btn_details").setVisible(true);
               } else {
               var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
               MessageBox.alert(msg);
            }
            } else {
            var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_GRI_0054");
            MessageBox.alert(msg);
         }
         
      },
      
      PadZeroes: function(OriginalText, ZeroPadding) {
         var Padding = 0;
         var ZeroPad = 0;
         
         for (Padding = 1; Padding < ZeroPadding; Padding++)
         ZeroPad = ZeroPad + '0';
         
         OriginalText = ZeroPad + OriginalText;
         return OriginalText;
      },
      
      openDialogBox: function() {
         
         //var phase = document.APLT_GRI_Execution.getGridObject().getSelectedCellValueByName('TEXTKEY');
         var phase = "";
         var phasetext = "";
         var batch = "";
         var insplot = "";
         
         var aSelectedRowPath = oBatchExectionInqry.getView().byId("Execution").getSelectedContextPaths();
         var oExecutionTable = oBatchExectionInqry.getView().getModel("oExecutionTable");
         if (aSelectedRowPath.length > 0) {
            let sPath = aSelectedRowPath[0];
            phase = oExecutionTable.getProperty(sPath + '/TEXTKEY');
            phasetext = oExecutionTable.getProperty(sPath + '/PHASE');
            resource = oExecutionTable.getProperty(sPath + '/RESR');
            batch = oExecutionTable.getProperty(sPath + '/BATCH');
         }
         else {
            //sap.ui.getCore().byId("GROutput").setVisible(false);
            sap.ui.getCore().getModel("displayOption").setProperty("/selectedOption", "showNoData");
            
         }
         Campaign = oBatchExectionInqry.getView().byId("campignId").getSelectedKey();
         var StrLength = Campaign.length;
         StrLength = 12 - StrLength;
         if (StrLength > 0)
         Campaign = this.PadZeroes(Campaign, StrLength);
         
         /******************** We have the following cases BatchOEMatPreparaion.irpt for the WEIGH (0210) *****************************************/
         
         if (phase == "WEIGH" || phase == "CWEIGH") {
            var matPrepLisTable = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.ExecutionInquiry-->openDialogBox-->XACQ_GetMatPrepListByPhase");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phasetext + "&Param.4=" + Campaign + "&Param.5=" + batch +"&d="+new Date();
            matPrepLisTable.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/XACQ_GetMatPrepListByPhase&" + params + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(matPrepLisTable, "MatPrepListModel");
            sap.ui.getCore().getModel("displayOption").setProperty("/selectedOption", "showMatPrepList");
            sap.ui.getCore().byId("GROutput").setVisible(false);
         }
         
         /******************** We have the following cases BatchOEMatTipping.irpt for the DOSING (0211) **********************************/
         else if (phase == "ADDMAN" || phase == "ADDMANV") {
		     sap.ui.getCore().getModel("displayOption").setProperty("/selectedOption", "showMatIdenList");
            var matIdenListTable = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.ExecutionInquiry-->openDialogBox-->XACQ_GetMatTipListByPhase");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phasetext + "&Param.4=" + Campaign + "&Param.5=" + batch +"&d="+new Date();
            matIdenListTable.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/XACQ_GetMatTipListByPhase&" + params + "&Content-Type=text/json", "", false);
	  sap.ui.getCore().setModel(matIdenListTable, "matIdenListModel");
       
	
            sap.ui.getCore().byId("GROutput").setVisible(false);
            
         }
         
         /************************ We have the following cases BatchOEDischarge.irpt for the phase (0410) **************************************/
         else if (phase == "GRIM") {
            var dischargeMatListTable = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.ExecutionInquiry-->openDialogBox-->XACQ_DischargeMatList");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + Campaign + "&Param.4=" + batch +"&d="+new Date();
            dischargeMatListTable.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/XACQ_DischargeMatList&" + params + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(dischargeMatListTable, "dischargeMatModel");
            
            var GROutput = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.ExecutionInquiry-->openDialogBox-->SQLQ_GROutput");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + Campaign + "&Param.4=" + batch +"&d="+new Date();
            GROutput.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/SQLQ_GROutput&" + params + "&Content-Type=text/json", "", false);
            
            //document.APLT_GRI_GROutput.executeCommand();
            //var GROutput = document.APLT_GRI_GROutput.getFirstValue("OUTPUT");
            if (CommonUtility.getJsonModelRowCount(GROutput.getData()) != 0) {
               var oBatchGROutput = GROutput.getData().Rowsets.Rowset[0].Row[0];
               var GROutput = oBatchGROutput.OUTPUT;
               sap.ui.getCore().byId("GROutputInput").setValue(GROutput);
            }
            //document.APLT_GRI_DischargeMatList.updateGrid(true);
            sap.ui.getCore().getModel("displayOption").setProperty("/selectedOption", "showDischargeMat");
            sap.ui.getCore().byId("GROutput").setVisible(true);
         }
         
         /********************* We have the following cases BatchInspectionPointV2.irpt for the phase (0405) *******************************/
         else if (phase == "QACHK" || phase == "QACHKL" || phase == "QACHKF" || phase == "CCP1" || phase == "CCP2") {
            var aSelectedRowPath = oBatchExectionInqry.getView().byId("Execution").getSelectedContextPaths();
            var oExecutionTable = oBatchExectionInqry.getView().getModel("oExecutionTable");
            if (aSelectedRowPath.length > 0) {
               let sPath = aSelectedRowPath[0];
               insplot = oExecutionTable.getProperty(sPath + '/INSPLOT');
            }
            
            var PhaseInpectionsTable = models.createNewJSONModel(
            "com.khc.batchhub.controller.analysis.ExecutionInquiry-->openDialogBox-->XACQ_PhaseInspectionChecks");
            var params = "Param.1=" + insplot + "&Param.2=" + "%" +"&d="+new Date();
            var url = "/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/XACQ_PhaseInspectionChecks&" + params + "&Content-Type=text/json";
            PhaseInpectionsTable.loadData(encodeURI(url), "", false);
            sap.ui.getCore().setModel(PhaseInpectionsTable, "phaseInsChecksModel");
            //document.APLT_GRI_GetPhaseInpections.refresh();
            this.getInspectPoints();
            sap.ui.getCore().getModel("displayOption").setProperty("/selectedOption", "showPhaseInsChecks");
            sap.ui.getCore().byId("GROutput").setVisible(false);
            } else {
            sap.ui.getCore().byId("GROutput").setVisible(false);
            sap.ui.getCore().getModel("displayOption").setProperty("/selectedOption", "showNoData");
            
         }
         
      },
      getInspectPoints: function() {
         var dataPointsInspReq="";
         var insplot="";
         var OutputMaterial ="";
         var ResultType="";
         var InspReq="";
         var MasterChar="";
         var InspMethod="";
         var DataPoints="";
         
         var SelRow = sap.ui.getCore().byId("phase_0405").getSelectedContextPaths().length;
         if(SelRow == 0){
            SelRow = 1;
            //var BLSelRow =sap.ui.getCore().byId("phase_0405").getSelectedContextPaths()[0];
            //var BSSelectedRow = sap.ui.getCore().getModel("phaseInsChecksModel").getProperty(BLSelRow);

          if (CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("phaseInsChecksModel").getData()) > 0) {
            var objgridObj = sap.ui.getCore().getModel("phaseInsChecksModel").getData().Rowsets.Rowset[0].Row[0];
            ResultType= objgridObj.Phase;
            InspReq = objgridObj.InspectionCharacteristic;
            MasterChar = objgridObj.MasterChar;
            InspMethod = objgridObj.Lights;
            DataPoints = objgridObj.ResultType;
         } 
         var aSelectedRowPath = this.getView().byId("Execution").getSelectedContextPaths();
         var oExecutionTable = this.getView().getModel("oExecutionTable");
         if (aSelectedRowPath.length > 0) {
            let sPath = aSelectedRowPath[0];
            insplot = oExecutionTable.getProperty(sPath + '/INSPLOT');
            resource = oExecutionTable.getProperty(sPath + '/RESR');
            OutputMaterial = oExecutionTable.getProperty(sPath + '/HDRMAT');
            var StrLength = OutputMaterial.length;
            StrLength = 18 - StrLength;
            if (StrLength > 0)
            OutputMaterial = this.PadZeroes(OutputMaterial, StrLength);
         }
         if (ResultType == "SINGLE" && InspReq > 0) {
            dataPointsInspReq =DataPoints * InspReq;
            } else {
            dataPointsInspReq = DataPoints;
         }
         
         var InspectPointTable = models.createNewJSONModel(
         "com.khc.batchhub.controller.analysis.ExecutionInquiry-->getInspectPoints-->XACQ_ViewResult");
         var params = "Param.1=" + insplot + "&Param.2=" + MasterChar + "&Param.3=" + resource + "&Param.4=" + dataPointsInspReq +
         "&Param.5=" +
         OutputMaterial + "&Param.6=" + plant +"&d="+new Date();
         InspectPointTable.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/XACQ_ViewResult&" + params + "&Content-Type=text/json", "", false);
         sap.ui.getCore().setModel(InspectPointTable, "viewResultsModel");
         }
      },
      
      onDetails: function(oEvent) {
         if (!this.oBatchExecutionInquiry) {
            this.oBatchExecutionInquiry = sap.ui.xmlfragment("com.khc.batchhub.view.Fragments.ExecutionInquiry", this);
         }
         this.oBatchExecutionInquiry.open();
         this.openDialogBox(); 
      }, 
      
      closeExecutionInquiryPopUp: function() {
         this.oBatchExecutionInquiry.close();
      },
      
      clearValues: function() {
         var oExecutionInquiryModel = new sap.ui.model.json.JSONModel();
         oBatchExectionInqry.getView().setModel(oExecutionInquiryModel, "oExecutionTable");
         oBatchExectionInqry.getView().byId("campignId").setSelectedKey("");
         oBatchExectionInqry.getView().byId("resourceId").setSelectedKey("");
         oBatchExectionInqry.getView().byId("productionUnitId").setSelectedKey("");
         oBatchExectionInqry.getView().byId("phaseId").setSelectedKey("")
         oBatchExectionInqry.getView().byId("id_btn_details").setVisible(false);
         
      },
      
      
      onHelp: function() {
         
         UI_utilities.OpenHelpFileSingle("Plantview");
      }
      
   });
});   