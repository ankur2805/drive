sap.ui.define(["sap/ui/core/mvc/Controller",
      "sap/ui/model/Filter",
      "sap/m/MessageBox",
      "com/khc/batchhub/utils/UI_utilities",
      "com/khc/common/Script/CommonUtility", "sap/m/DateTimeInput", "com/khc/batchhub/model/models"
   ],
   function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, DateTimeInput, models) {
  var that;
  var plant;
 var resource;
  var projectName;
  var userName;
  var crdest;

      return Controller.extend("com.khc.batchhub.controller.ReprintLabel", {
         onInit: function() {

            this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            this._oRouter.getRoute("ReprintLabel").attachPatternMatched(
               this._oRoutePatternMatched, this);
         },

         _oRoutePatternMatched: function(oEvent) {
            //Hide the messages and set busy to false
            UI_utilities.batchPageOpened(this, "ReprintLabel");
            this.getRouterDetails();
            this.GetResourcelist();
               this.Listprinter(); 
           //  this.getView().byId("batchlist_id").insertItem(new  sap.ui.core.Item({key:"All",text:"All"}),0); 
            this.initialize();
         //   this.clearValues();
            //this.getOrderList();
         },

         menuSelected: function(oEvent) {
            // Navigate the the selected menu page
            var sKey = oEvent.getParameters().key;
            UI_utilities.openMenu(this._oRouter, this, sKey);
         },
         
         getRouterDetails: function() {
           plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
          resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
           projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
           userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
           crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
           txt_shift=sap.ui.getCore().getModel("session").oData.txt_shift;
         },
         
         //////////////// //Drop Down Loading/////////////////////////        
         // Resource creation event//
         getOrderList:function(){
           var oModelOrder= models.createNewJSONModel(
           "com.khc.batchhub.controller.ReprintLabel-->getOrderList-->SQLQ_GetOrderListByResr");
           resource= this.getView().byId("resource_id").getSelectedKey();
           var oparams = "Param.1=" + plant + "&Param.2=" + resource+"&d="+new Date();
           oModelOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName+ "/QueryTemplate/SQLQ_GetOrderListByResr&" + oparams+ "&Content-Type=text/json", "", false);
               this.getView().setModel(oModelOrder, "oOrder"); 
           // this.getView().byId("campaign_Id").insertItem(new  sap.ui.core.Item({key:"All",text:"All"}),0);          
         },
         
         GetResourcelist:function(){
           var oModelRes= models.createNewJSONModel(
           "com.khc.batchhub.controller.ReprintLabel-->GetResourcelist-->XACQ_GetResrByPlant");
           oModelRes.loadData("/XMII/Illuminator?QueryTemplate=" + projectName+ "/QueryTemplate/XACQ_GetResrByPlant&Param.1="+plant+"&d="+new Date()+"&Content-Type=text/json", "", false);
               this.getView().setModel(oModelRes, "oRes"); 

                        var firstrow = oModelRes.getData().Rowsets.Rowset[0].Row[0]
                        this.getView().byId("resource_id").setSelectedKey(firstrow.RESR);
                    
         },
         initialize:function()
         {
           var d = new Date();
            var d_day = d.toDateString(); 
            var d_date = d_day.split(" ");
            if((d.getDate()) < 10)
               var day = "0" + (d.getDate());
            else
               var day = d.getDate();
            if((d.getMonth()+1) < 10)
               var currentMonth = "0" + (d.getMonth()+1);
            else
               var currentMonth = d.getMonth()+1;          
            var currentD = day + "." + currentMonth + "." + d.getFullYear();
            this.getView().byId("StartDate").setValue(currentD);
            this.getView().byId("EndDate").setValue(currentD);
         },
         
    getBatchList:function(){
           var list= this.getView().byId("order_id").getSelectedKey();
           var oModelGetBatch= models.createNewJSONModel(
           "com.khc.batchhub.controller.ReprintLabel-->getBatchList-->SQLQ_GetBatchListByOrder");
           // resource= this.getView().byId("resource_id").getSelectedKey();         
      var bparams = "Param.1=" + list +"&d="+new Date();
           oModelGetBatch.loadData("/XMII/Illuminator?QueryTemplate=" + projectName+ "/QueryTemplate/SQLQ_GetBatchListByOrder&"+bparams+"&Content-Type=text/json", "", false);
               this.getView().setModel(oModelGetBatch, "oGetBatch"); 
               this.getView().byId("batchlist_id").insertItem(new  sap.ui.core.Item({key:"All",text:"All"}),0);          

         },

     ////printer table Binding////
         
         Listprinter:function(){
           var oModelList = models.createNewJSONModel(
           "com.khc.batchhub.controller.ReprintLabel-->Listprinter-->XACQ_GetPrinterListByPlant");
            var gparams = "Param.1=" + plant +"&d="+new Date();
           oModelList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName+ "/QueryTemplate/XACQ_GetPrinterListByPlant&" + gparams+ "&Content-Type=text/json", "", false);
           this.getView().setModel(oModelList, "oList");
         },
         
         DeleteLabel:function()
         {
         var that = this;
   var del_flag=" ";
         var msg = this.getView().getModel("i18n").getProperty("BATCH_MSG_0081")
         MessageBox.confirm(
             msg, {
                 icon: MessageBox.Icon.WARNING,
                 title: "Message from webpage",
                 actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                 onClose: function(oAction) {
                     if (oAction === "OK") {
                       if(del_flag)
                     var StartDate= that.getView().byId("StartDate").getValue();
                      var EndDate=that.getView().byId("EndDate").getValue();
                                        
                      var oModelDeleteLabel = models.createNewJSONModel(
                      "com.khc.batchhub.controller.ReprintLabel-->DeleteLabel-->XACQ_DeleteLabel");
                      var eparams = "Param.1=" + StartDate + "&Param.2=" + EndDate+"&d="+new Date();
                      oModelDeleteLabel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName+ "/QueryTemplate/XACQ_DeleteLabel&" + eparams+ "&Content-Type=text/json", "", false);
                      that.getView().setModel(oModelDeleteLabel, "oDeleteLabel");
                     
                     } //end of if condition endofShift
                 }
             });
         },
                    
           SearchLabel:function(){
             
             var batch = this.getView().byId("batchlist_id").getSelectedKey(); 
             
             var Resource=this.getView().byId("resource_id").getSelectedKey(); 
             
             var Order= this.getView().byId("order_id").getSelectedKey(); 
             
             var StartDate= this.getView().byId("StartDate").getValue();
             
             var EndDate= this.getView().byId("EndDate").getValue();
             
             if (batch == "All") {
              batch = "%";
            } 
             var oModelPrintLabel = models.createNewJSONModel(
             "com.khc.batchhub.controller.ReprintLabel-->SearchLabel-->SQLQ_GetPrintLabel");
             var lparams = "Param.1=" + plant + "&Param.2=" + Resource +"&Param.3=" + Order + "&Param.4=" + batch+"&Param.5=" + StartDate + "&Param.6=" + EndDate+"&d="+new Date();
             var url="/XMII/Illuminator?QueryTemplate=" + projectName+ "/QueryTemplate/SQLQ_GetPrintLabel&" + lparams+ "&Content-Type=text/json";
             oModelPrintLabel.loadData(encodeURI(url), "", false);
             this.getView().setModel(oModelPrintLabel, "oPrintLabel");
             },
             
             
              PrintLabel:function()
   {
   var aSelectedRowPath = this.getView().byId("orderWorkList_ID").getSelectedContextPaths();
   var oOrderPrintLabelModel = this.getView().getModel("oPrintLabel");

   var aSelectedRowPath1 = this.getView().byId("PrinterList_tbl").getSelectedContextPaths();
   var oOrderWorkListModel = this.getView().getModel("oList");
      
   if(aSelectedRowPath.length == 0) {
      let sPath = aSelectedRowPath[0];
      MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0079"));
   }
   
   else if(aSelectedRowPath1.length == 0) {
      let sPath = aSelectedRowPath1[0];
      MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0080"));
   }
   else{
      var file= oModelPrintLabel.getData().Rowsets.Rowset[0].Row[0].FILENAME;                
      var filename = file.split("/"); 
      var oModelReprint = models.createNewJSONModel(
      "com.khc.batchhub.controller.ReprintLabel-->PrintLabel-->XACQ_DeleteLabel");
      var rparams = "Param.1=" + filename[5] + "&Param.2=" +oModelList.getData().Rowsets.Rowset[0].Row[0].PrinterName+"&Param.3=" + oModelList.getData().Rowsets.Rowset[0].Row[0].PrinterIP +"&d="+new Date();
      oModelReprint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName+ "/QueryTemplate/XACQ_ReprintLabel&" + rparams+ "&Content-Type=text/json", "", false);
      that.getView().setModel(oModelReprint, "oReprint");
      
   }           
},
             clearValues: function() {
               this.getView().byId("resource_id").setSelectedKey("");
               this.getView().byId("order_id").setSelectedKey("");
               this.getView().byId("batchlist_id").setSelectedKey("");
               //this.getView().byId("phaseId").setSelectedKey("")

            },

   onHelp: function() {
      UI_utilities.OpenHelpFileSingle("Checklog");
   }
      
      });
   });