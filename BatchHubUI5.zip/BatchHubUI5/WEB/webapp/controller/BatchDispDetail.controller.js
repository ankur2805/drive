sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models", "com/khc/batchhub/model/formatter"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter) {
        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var crid;
        var orderID;


        return Controller.extend("com.khc.batchhub.controller.BatchDispDetail", {
            formatter: formatter,
            onInit: function() {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("BatchDispDetail").attachPatternMatched(
                    this._oRoutePatternMatched, this);
            },

            _oRoutePatternMatched: function(oEvent) {
                //Hide the messages and set busy to false
                UI_utilities.batchPageOpened(this, "common");
                // UI_utilities.batchPageOpened(this,"BatchDispDetail");
                var oData = {
                    buttonStaus: "true"
                };
                var oDestModel = new sap.ui.model.json.JSONModel(oData);
                this.getView().setModel(oDestModel, "BatchDispButtonModel");

                if (sap.ui.getCore().getModel("BatchDispDetailParams") == null) {
                    this._oRouter.navTo("BatchProdDispatch");
                    return;
                }

                this.getView().byId("id_txt_override").setValue("");
                this.loadData();
                this.getOrderList();
                this.getTotalBatch();
            },

            menuSelected: function(oEvent) {
                // Navigate the the selected menu page
                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);
            },
            back: function() {
                this._oRouter.navTo("BatchProdDispatch");
            },
            loadData: function() {
                plant = sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_plant;
                resource = sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_resr;
                crdest = sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_crdest;
                orderID = sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_orderid;
                crid = sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_crid;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;

            },

            getOrderList: function() {
                var oModelBatchSplit = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchDispDetail-->getOrderList-->XACQ_GetOrderBatchList");
                var params = "Param.1=" + crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + crdest + "&Param.5=" + orderID;

                oModelBatchSplit.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetOrderBatchList&" +
                    params + "&Content-Type=text/json", "", false);
                this.getView().setModel(oModelBatchSplit, "BatchSplit");

                if (sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_status == "2") {
                    this.getView().getModel("BatchDispButtonModel").setProperty("/buttonStaus", false)
                }
            },
            getTotalBatch: function() {
                var oTotalBatchCountModel = models.createNewJSONModel(
                    "com.khc.batchhub.controller.BatchDispDetail-->getTotalBatch-->SQLQ_GetTotalBatchCount");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + orderID;

                oTotalBatchCountModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetTotalBatchCount&" +
                    params + "&Content-Type=text/json", "", false);

                if (CommonUtility.getJsonModelRowCount(oTotalBatchCountModel.getData()) > 0) {
                    var oData = oTotalBatchCountModel.getData().Rowsets.Rowset[0].Row[0];

                    var maxBatch = oData.MAX_BATCH;
                    this.getView().byId("txt_reqbatch").setValue(maxBatch);
                }


            },
            dispatch: function() {
                var oTableModel = this.getView().getModel("BatchSplit").getData();
                var lastrow = CommonUtility.getJsonModelRowCount(oTableModel)
                if (lastrow > 0) {

                    var batch = oTableModel.Rowsets.Rowset[0].Row[0].BATCH;
                    var flag = 0;
                    if (batch == "") {
                        this.rundispatch();
                        this.getOrderList();
                    } else {
                        var that = this;
                        var answerfco = MessageBox.warning(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0117"), {
                            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                            emphasizedAction: MessageBox.Action.OK,
                            onClose: function(sAction) {
                                if (sAction == "OK") {
                                    for (var j = 0; j < lastrow; j++) {
                                        if (oTableModel.Rowsets.Rowset[0].Row[j].STATUS != "0") {
                                            flag = 1;
                                            break;
                                        }
                                    }
                                    if (flag == 0) {
                                        that.rundispatch();
                                        that.getOrderList();
                                    } else {
                                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0089");
                                        MessageBox.error(msg)
                                    }
                                }
                            }
                        });

                    }
                }
            },
            rundispatch: function() {
                
                var msgid = sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_msgid;

                var orderid = orderID;
                var bcount = this.getView().byId("txt_reqbatch").getValue();
                var bsize;
                var prdunit = "";
                var txt_override = this.getView().byId("id_txt_override").getValue();
                if (txt_override != "" && !isNaN(txt_override)) {
                    bsize = txt_override;
                } else {
                    bsize = this.getView().byId("txt_batchsize").getValue();
                }
                bsize = bsize.split(" ").join("");
                bcount = bcount.split(" ").join("");
                if (bsize != "" && bcount != "") {
                    if (!isNaN(bsize) && !isNaN(bcount)) {
                        var oDispatchOrderModel = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchDispDetail-->rundispatch-->XACQ_DispatchOrderBatch");
                        var params = "Param.1=" + msgid + "&Param.2=" + crid + "&Param.3=" + resource + "&Param.4=" +
                            crdest + "&Param.5=" + orderID + "&Param.6=" + plant + "&Param.7=" + prdunit + "&Param.8=" + bcount + "&Param.9=" +
                            bsize;

                        oDispatchOrderModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_DispatchOrderBatch&" +
                            params + "&Content-Type=text/json", "", false);

                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0090");
                        MessageBox.error(msg)
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0091");
                    MessageBox.error(msg)
                }

            },
            update: function() {
                var SelRow = this.getView().byId("APLT_GRI_BatchSplit").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var BSSelRow = this.getView().byId("APLT_GRI_BatchSplit").getSelectedContextPaths()[0];
                    var BSSelectedRow = this.getView().getModel("BatchSplit").getProperty(BSSelRow);

                    var crid = BSSelectedRow.CRID;
                    var resr = BSSelectedRow.RESR;
                    var crdest = BSSelectedRow.CRDEST;
                    var orderid = BSSelectedRow.ORDERID;
                    var plant = BSSelectedRow.PLANT;
                    var batch = BSSelectedRow.BATCH;
                    var status = BSSelectedRow.STATUS;
                    var bsize = this.getView().byId("id_txt_override").getValue();
                    if (status == "0" || status == "4") {
                        bsize = bsize.split(" ").join("");
                        if (bsize != "") {
                            if (!isNaN(bsize)) {
                                var oDispatchOrderModel = models.createNewJSONModel(
                                    "com.khc.batchhub.controller.BatchDispDetail-->update-->XACQ_UpdOrderBatch");
                                var params = "Param.1=" + crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" +
                                    crdest + "&Param.5=" + orderID + "&Param.6=" + batch + "&Param.7=" + bsize;

                                oDispatchOrderModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                    "/QueryTemplate/XACQ_UpdOrderBatch&" +
                                    params + "&Content-Type=text/json", "", false);


                                this.getOrderList();
                                this.getView().byId("id_txt_override").setValue("")
                            } else {
                                var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0092");
                                MessageBox.error(msg)
                            }
                        } else {
                            var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0093");
                            MessageBox.error(msg)
                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0094");
                        MessageBox.error(msg)
                    }

                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0085");
                    MessageBox.error(msg)
                }
            },
            add: function() {
                var oTableModel = this.getView().getModel("BatchSplit").getData();
                var lastrow = CommonUtility.getJsonModelRowCount(oTableModel)
                if (lastrow > 0) {

                    var batch = oTableModel.Rowsets.Rowset[0].Row[0].BATCH;
                    if (batch != "") {
                        var lastrow = lastrow - 1;
                        batch = oTableModel.Rowsets.Rowset[0].Row[lastrow].BATCH;

                        var msgid = sap.ui.getCore().getModel("BatchDispDetailParams").oData.qs_msgid;
                        var prdunit = "";
                        var bcount = oTableModel.Rowsets.Rowset[0].Row[lastrow].ACTBATCHCOUNT;

                        var bsize = this.getView().byId("txt_batchsize").getValue();
                        var status = 0;

                        var oAddDisOrderBatchModel = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchDispDetail-->add-->XACQ_AdditionalDispatchOrderBatch");
                        var params = "Param.1=" + msgid + "&Param.2=" + crid + "&Param.3=" + resource + "&Param.4=" +
                            crdest + "&Param.5=" + orderID + "&Param.6=" + plant + "&Param.7=" + prdunit + "&Param.8=" +
                            bcount + "&Param.9=" + bsize + "&Param.10=" + batch + "&Param.11=" + status;

                        oAddDisOrderBatchModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_AdditionalDispatchOrderBatch&" +
                            params + "&Content-Type=text/json", "", false);


                        this.getOrderList();
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0086");
                        MessageBox.success(msg)

                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0095");
                        MessageBox.error(msg)
                    }
                }
            },
            complete: function() {
                this.updstatus("6");
            },
            hold: function() {
                this.updstatus("4");
            },
            release: function() {
                this.updstatus("0");
            },
            updstatus: function(val) {
                var SelRow = this.getView().byId("APLT_GRI_BatchSplit").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var BSSelRow = this.getView().byId("APLT_GRI_BatchSplit").getSelectedContextPaths()[0];
                    var BSSelectedRow = this.getView().getModel("BatchSplit").getProperty(BSSelRow);

                    var crid = BSSelectedRow.CRID;
                    var resr = BSSelectedRow.RESR;
                    var crdest = BSSelectedRow.CRDEST;
                    var orderid = BSSelectedRow.ORDERID;
                    var plant = BSSelectedRow.PLANT;
                    var batch = BSSelectedRow.BATCH;
                    var status = BSSelectedRow.STATUS;
                    if (status != "2") {
                        if (status != "1") {
                            var oUpdOrderBatchStatusModel = models.createNewJSONModel(
                                "com.khc.batchhub.controller.BatchDispDetail-->updstatus-->XACQ_UpdOrderBatchStatus");
                            var params = "Param.1=" + crid + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" +
                                crdest + "&Param.5=" + orderID + "&Param.6=" + batch + "&Param.7=" + val + "&Param.8=" +
                                status;

                            oUpdOrderBatchStatusModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_UpdOrderBatchStatus&" +
                                params + "&Content-Type=text/json", "", false);

                            this.getOrderList();
                        } else {
                            var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0096");
                            MessageBox.error(msg)
                        }
                    } else {
                        var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0097");
                        MessageBox.error(msg)
                    }
                } else {
                    var msg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0085");
                    MessageBox.error(msg)
                }

            },
        });
    });