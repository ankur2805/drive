sap.ui.define(
    ["sap/ui/core/mvc/Controller",
        "com/khc/batchhub/utils/UI_utilities", "sap/m/MessageBox",
        "com/khc/batchhub/model/formatter", "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models"
    ],
    function(Controller, UI_utilities, MessageBox, formatter, CommonUtility, models) {
        "use strict";
        var plant;
        var resource;
        var projectName;
        var command;
        return Controller.extend("com.khc.batchhub.controller.LogRep", {
            formatter: formatter,
            onInit: function() {
                //this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.getRoute("LogRep").attachPatternMatched(this._oRoutePatternMatched, this);

            },

            _oRoutePatternMatched: function(oEvent) {

                UI_utilities.batchPageOpened(this, "LogRep");

                plant = sap.ui.getCore().getModel("session").oData.CA_Plant
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                UI_utilities.DisableDatePickerInput(this.getView().byId("fromDateTime"));
                UI_utilities.DisableDatePickerInput(this.getView().byId("toDateTime"));

                this.SetShiftDate();
                this.getComponent();
                this.getLogType();
                this.getResource();
                this.clear();

            },
            // Navigate the the selected menu page
            menuSelected: function(oEvent) {
                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);

            },
            SetShiftDate: function() {

                var that = this;
                var oRunningShiftModel = models.createNewJSONModel(
                    "com.khc.batchhub.controller.LogRep-->SetShiftDate-->XACQ_GetRunningShift");
                oRunningShiftModel.attachRequestCompleted(
                    function() {
                        if (CommonUtility.getJsonModelRowCount(oRunningShiftModel.getData()) > 0) {

                            var ShiftStart = oRunningShiftModel.getData().Rowsets.Rowset[0].Row[0].STARTTIME;
                            that.getView().byId("fromDateTime").setValue(ShiftStart);
                            //that.GetLog();
                        }

                    });

                oRunningShiftModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetRunningShift&Param.1=" +
                    plant + "&Param.2=" + resource + "&Content-Type=text/json", "", false);
                this.getView().setModel(oRunningShiftModel, "oRunningShift");
                // Call query by passing plant and resource

            },

            getComponent: function() {

                var that = this;
                var oModelComponentlist = models.createNewJSONModel(
                    "com.khc.batchhub.controller.LogRep-->getComponent-->SQLQ_GetLogComponent");
                oModelComponentlist.attachRequestCompleted(
                    function() {

                        var oItem = {
                            COMPONENT: "All"
                        };
                        if (CommonUtility.getJsonModelRowCount(oModelComponentlist.getData()) > 0) {

                            //var oData  = oModelComponentlist.getData().Rowsets.Rowset[0].Row;
                            oModelComponentlist.getData().Rowsets.Rowset[0].Row.splice(0, 0, oItem);

                        } else {

                            var oData = {
                                "Rowsets": {

                                    "Rowset": [{
                                        "Row": [{
                                            "COMPONENT": "All"
                                        }]
                                    }]
                                }
                            };
                            oModelComponentlist.setData(oData);
                        }

                        that.getView().setModel(oModelComponentlist, "oComponentlist");
                        that.getView().byId("compnent").setSelectedKey("All");

                    });
                oModelComponentlist.loadData(
                    "/XMII/Illuminator?QueryTemplate=ReuseLibrary/LogManagement/QueryTemplate/SQLQ_GetLogComponent&Content-Type=text/json",
                    "", false
                );

            },

            getLogType: function() {
                var oModelLoglist = models.createNewJSONModel(
                    "com.khc.batchhub.controller.LogRep-->getLogType-->XACQ_GetLogStatusList");

                var that = this;
                oModelLoglist.attachRequestCompleted(
                    function() {

                        var oItem = {
                            StatusType: "All",
                            StatusText: "All"
                        };
                        if (CommonUtility.getJsonModelRowCount(oModelLoglist.getData()) > 0) {

                            //var oData  = oModelLoglist.getData().Rowsets.Rowset[0].Row;
                            oModelLoglist.getData().Rowsets.Rowset[0].Row.splice(0, 0, oItem);

                        } else {

                            var oData = {
                                "Rowsets": {

                                    "Rowset": [{
                                        "Row": [{
                                            "StatusType": "All",
                                            "StatusText": "All"
                                        }]
                                    }]
                                }
                            };
                            oModelLoglist.setData(oData);

                        }
                        that.getView().setModel(oModelLoglist, "oLoglist");
                        that.getView().byId("log").setSelectedKey("All");

                    });

                oModelLoglist.loadData(
                    "/XMII/Illuminator?QueryTemplate=ReuseLibrary/LogManagement/QueryTemplate/XACQ_GetLogStatusList&Content-Type=text/json",
                    "",
                    false);
            },

            getResource: function() {
                var oModelResrList = models.createNewJSONModel(
                    "com.khc.batchhub.controller.LogRep-->getResource-->XACQ_GetResrByPlant");

                var that = this;
                oModelResrList.attachRequestCompleted(
                    function() {

                        var oItem = {
                            RESR: "All",
                            RESRTEXT: "All"
                        };
                        if (CommonUtility.getJsonModelRowCount(oModelResrList.getData()) > 0) {

                            //var oData  = oModelLoglist.getData().Rowsets.Rowset[0].Row;
                            oModelResrList.getData().Rowsets.Rowset[0].Row.splice(0, 0, oItem);

                        } else {

                            var oData = {
                                "Rowsets": {

                                    "Rowset": [{
                                        "Row": [{
                                            "RESR": "All",
                                            "RESRTEXT": "All"
                                        }]
                                    }]
                                }
                            };
                            oModelResrList.setData(oData);

                        }
                        that.getView().setModel(oModelResrList, "oResrList");
                        that.getView().byId("resource").setSelectedKey("All");
                        //that.getView().byId("resource").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Resource)

                    });

                oModelResrList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetResrByPlant&Param.1=" +
                    plant +
                    "&Content-Type=text/json", "", false);

            },



            GetLog: function() {

                //var i5Command = new com.sap.xmii.chart.hchart.i5Command("Default/Muthu/SQLQ_SelLog","Default/Muthu/CMD_VerifyDigitalSignature",creation);
                //i5Command.executeCommand();	

                var FromDate = this.getView().byId("fromDateTime").getValue();
                var ToDate = this.getView().byId("toDateTime").getValue();
                var Username = this.getView().byId("Name").getValue();
                var CompType = this.getView().byId("compnent").getSelectedKey();
                var LogType = this.getView().byId("log").getSelectedKey();
                var SelResr = this.getView().byId("resource").getSelectedKey();

                if (FromDate != "" && ToDate != "") {
                    if (LogType == "All") {
                        LogType = "";
                    }

                    if (SelResr == "All") {
                        SelResr = "";
                    }

                    if (CompType == "All") {
                        CompType = "";
                    }

                    var oLogListModel = models.createNewJSONModel("com.khc.batchhub.controller.LogRep-->GetLog-->SQLQ_SelLog");
                    let getLogListParam = "Param.1=" + LogType + "&Param.2=" + CompType + "&Param.3=" + Username + "&Param.4=" + FromDate +
                        "&Param.5=" + ToDate + "&Param.6=" + SelResr + "&d=" + new Date();
                    oLogListModel.loadData("/XMII/Illuminator?QueryTemplate=ReuseLibrary/LogManagement/QueryTemplate/SQLQ_SelLog&" +
                        getLogListParam +
                        "&Content-Type=text/json", "", false);
                    this.getView().setModel(oLogListModel, "log");
                } else {

                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0113");
                    MessageBox.alert(sAlertMsg);

                }
            },

            /**
             * to open the help document
             */

            onHelp: function() {

                UI_utilities.OpenHelpFileSingle("Checklog");
            },

            checkAudit: function() {

            },
            onBack: function() {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RepHome");
                //window.location.replace("/XMII/CM/NL_ELS_HUB_SAPUi5/webapp/index.irpt#/RepHome");
                //location.reload();
            },

            fnValidateDate: function(oEvent) {

                var toSelectedDate = this.getView().byId("toDateTime").getValue();
                var fromSelectedDate = this.getView().byId("fromDateTime").getValue();

                if (fromSelectedDate && toSelectedDate && fromSelectedDate > toSelectedDate) {

                    MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0081"));
                    oEvent.getSource().setValue("")
                }
            },

            clear: function() {

                this.getView().byId("fromDateTime").setValue("");
                this.getView().byId("toDateTime").setValue("");
                this.getView().byId("Name").setValue("");
                var oEmptyModel = new sap.ui.model.json.JSONModel();
                sap.ui.getCore().setModel(oEmptyModel, "log");
                //let todayDateTime = CommonUtility.getCurrentDateTime(new Date());
                //this.getView().byId("toDateTime").setValue(todayDateTime);
                //this.getView().byId("resource").setSelectedKey(sap.ui.getCore().getModel("session").getData().CA_Resource)
                this.getView().setModel(null, "log");
            }



        });
    });