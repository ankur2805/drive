sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
   "sap/m/MessageBox",
   "com/khc/batchhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models","com/khc/batchhub/model/formatter"
],
function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models,formatter) {
   var plant;
   var resource;
   var projectName;
   var userName;
   var crdest;
   var crid;
   var orderID;
   var oBatchOEMatIdentification;
   
   
   
   return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatIdentification", {
      formatter: formatter,
      onInit: function() {
         oBatchOEMatIdentification = this;
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         
      },
      
      /*  _oRoutePatternMatched: function(oEvent) {
            //Hide the messages and set busy to false
            UI_utilities.batchPageOpened(this, "ReprintLabel");
         this.getRouterDetails();
         this.GetMatIdenList(); 
         //this.clearValues();
            //this.getOrderList();
         this.buttonDisable();
         }, 
         
         onLoadBatchInspectionPoint: function() {
            this.getRouterDetails();
         this.GetMatIdenList(); 
         //this.clearValues();
            //this.getOrderList();
         this.buttonDisable();
      }, */
        
      /*Fragment - BatchOEMatIdentification Start*/
            onLoadBatchOEMatIdentification: function() {
         this.clearValues();
         this.getRouterDetails();
                   this.GetMatIdenList();
         this.BatchOEMatButtonDisable();
         
      },
      getRouterDetails: function() {
         plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
         resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
         projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
         userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
         crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
         txt_shift=sap.ui.getCore().getModel("session").oData.txt_shift;
      },
      clearValues:function(){
         oBatchOEMatIdentification.getView().byId("txt_id_Component").setValue("");
                oBatchOEMatIdentification.getView().byId("txt_id_Description").setValue("");
                oBatchOEMatIdentification.getView().byId("txt_id_Quantity").setValue("");
                oBatchOEMatIdentification.getView().byId("txt_id_UOM").setValue("");
                oBatchOEMatIdentification.getView().byId("txt_id_Batch").setValue("");

      },
      
        GetMatIdenList: function() {
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
            var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");
         
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
         
            var oModelPhase = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatIdentification-->GetMatIdenList-->XACQ_GetMatIdenListByPhase");
            var sparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid + "&Param.5=" + Batch +"&d="+new Date();
            oModelPhase.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMatIdenListByPhase&" + sparams +
         "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(oModelPhase, "oModelPhase");
      },
      
        //*************************** Selection event for table**************************//
        getContDetails: function() {
         
            var aSelectedRowPath = oBatchOEMatIdentification.getView().byId("MatIdenList_tbl_id").getSelectedContextPaths();
            var oExecutionTable = sap.ui.getCore().getModel("oModelPhase");
            if (aSelectedRowPath.length > 0) {
                let sPath = aSelectedRowPath[0];
            oBatchOEMatIdentification.getView().byId("txt_id_Component").setValue(oExecutionTable.getProperty(sPath + '/BOMMOD'));
                oBatchOEMatIdentification.getView().byId("txt_id_Description").setValue(oExecutionTable.getProperty(sPath + '/BOMTEXT'));
                oBatchOEMatIdentification.getView().byId("txt_id_Quantity").setValue(oExecutionTable.getProperty(sPath + '/BOMQTY'));
                oBatchOEMatIdentification.getView().byId("txt_id_UOM").setValue(oExecutionTable.getProperty(sPath + '/BOMUOM'));
                oBatchOEMatIdentification.getView().byId("txt_id_Batch").setValue(oExecutionTable.getProperty(sPath + '/BATCHID'));
            
         }
      },
      
        //*********** On Click event of Verify Button - Check the container entered for the material and verifiesit with the actual coantiner for the material *******// 
      
        identifyMaterial: function() {
         
            var RowNo = oBatchOEMatIdentification.getView().byId("MatIdenList_tbl_id").getSelectedContextPaths().length;
         
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
            var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");
         
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
            var connum = oBatchOEMatIdentification.getView().byId("txt_id_Container").getValue();
            var directFlag = "";
            let sPath = oBatchOEMatIdentification.getView().byId("MatIdenList_tbl_id").getSelectedContextPaths()[0]; 

            if (RowNo != 0) {
                var oExecutionTable = sap.ui.getCore().getModel("oModelPhase");
                directFlag = oExecutionTable.getProperty(sPath + '/DIRECTISSUE');
            
         }
         if (connum == "") {
            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0064"));
         } 
         else {
            var oModelCheckContainer = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatIdentification-->identifyMaterial-->SQLQ_CheckContainerByBatch");
            var cparams = "Param.1=" + plant + "&Param.2=" + orderid + "&Param.3=" + Batch + "&Param.4=" + connum +"&d="+new Date();
            oModelCheckContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
            "/QueryTemplate/SQLQ_CheckContainerByBatch&" + cparams + "&Content-Type=text/json", "", false);
            
            if (CommonUtility.getJsonModelRowCount(oModelCheckContainer.getData()) == 0) {
               if (directFlag == "Y") {
                  
                  var bom = oExecutionTable.getProperty(sPath + '/BOM');
                  var bomqty = oExecutionTable.getProperty(sPath + '/BOMQTY');
                  var uom = oExecutionTable.getProperty(sPath + '/UOM');
                  
                  
                  var oModelDirectMaterial = models.createNewJSONModel(
                  "com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatIdentification-->identifyMaterial-->XACQ_VerifyDirectMaterial");
                  var Mparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + Batch +
                  "&Param.5=" + connum + "&Param.6=" + bom + "&Param.7=" + bomqty + "&Param.8=" + uom + "&Param.9=" + connum +"&d="+new Date();
                  oModelDirectMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                  "/QueryTemplate/XACQ_VerifyDirectMaterial&" + Mparams + "&Content-Type=text/json", "", false);
                  
                  //alert(document.APLT_CMD_VerifyDirectMaterial.getFirstValue('O_Return'));
                  if (CommonUtility.getJsonModelRowCount(oModelDirectMaterial.getData()) != 0) {
                     MessageBox.alert(oModelDirectMaterial.getData().Rowsets.Rowset[0].Row[0].O_Return)
                  }
                  
                  oBatchOEMatIdentification.getView().byId("txt_id_Container").setValue("");
                        } else {
                  MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0065"));
                  }
                    } 
               else {
               
               var oModelVerifyMaterial = models.createNewJSONModel(
               "com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatIdentification-->identifyMaterial-->XACQ_VerifyMaterial");
               var Vparams = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + Batch +
               "&Param.5=" + connum +"&d="+new Date();
               oModelVerifyMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
               "/QueryTemplate/XACQ_VerifyMaterial&" + Vparams + "&Content-Type=text/json", "", false);
               oBatchOEMatIdentification.getView().setModel(oModelVerifyMaterial, "oVerifyMaterial");
               
               oBatchOEMatIdentification.getView().byId("txt_id_Container").setValue("");
            }
         }
            
            this.GetMatIdenList();
      },
        BatchOEMatButtonDisable: function() {
   var hid_phasestatus= sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
            if (hid_phasestatus == "1") {
                oBatchOEMatIdentification.getView().byId("id_btn_viewinstruct").setEnabled(true)
                oBatchOEMatIdentification.getView().byId("id_btn_verify").setEnabled(true)
   } else {
                oBatchOEMatIdentification.getView().byId("id_btn_viewinstruct").setEnabled(false)
                oBatchOEMatIdentification.getView().byId("id_btn_verify").setEnabled(false)
        oBatchOEMatIdentification.getView().byId("id_btn_test_tip").setEnabled(false)
    }
         
      },
      
      onNavigateTipping: function() {
         sap.ui.getCore().getModel("oMessage").setProperty("/oPageMessage", false);
            sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/oFragMentPath", "BatchOEMatTipping")
             sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatTipping").onLoadBatchOEMatTipping();
      },
      
        CheckGoToTip: function() {
            var oTable = sap.ui.getCore().getModel("oModelPhase").getData()
            var tablerowcount = CommonUtility.getJsonModelRowCount(oTable)
            var hid_phasestatus= sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
            if (tablerowcount != 0) {
                if (hid_phasestatus == "1") {
                    for (var i = 0; i < tablerowcount; i++) {
                        var valflag = oTable.Rowsets.Rowset[0].Row[i].VALFLAG
                        if (valflag != 1) {
                            oBatchOEMatIdentification.getView().byId("id_btn_verify").setEnabled(true)
                            oBatchOEMatIdentification.getView().byId("id_btn_test_tip").setEnabled(false)
                            break;
      } else {
                            oBatchOEMatIdentification.getView().byId("id_btn_verify").setEnabled(false)
                            oBatchOEMatIdentification.getView().byId("id_btn_test_tip").setEnabled(true)
                  }
               }
            }
         }
      },
      
        release: function() { 
         this._oRouter.navTo("BatchProdDispatch");
      },
        /*Fragment - BatchOEMatIdentification  End*/
      
   });
});