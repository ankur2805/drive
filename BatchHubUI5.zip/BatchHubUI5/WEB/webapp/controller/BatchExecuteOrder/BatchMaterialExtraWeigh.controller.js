var plant;
var resr;
var OrdBatch;
var orderid;
var phase;
var projectName;
var weightype;
var oModelGetMatPrepList;
var oModelGetOrderBatchList;
var SelRow;
var batchListSelRow
var Itemno;
var itemnoFinal;
var oBatchMaterialExtraWeigh;
var ScaleDecimal;
var crdest ;
var dp;
var setBatchRow;
var setMatRow;
var SelMatRow;
var SelBatchRow;	
var continueFlag;
var punit;

//hidden variables
var hid_PartialFlag;
var hid_PartialDisplayFlag;
var hid_lastcontainer;
var txt_crdest;
var hid_curMatRow;
var hid_firstMatLoad;
var hid_WeighedMat=0;
var hid_curMatRow;
var hid_phase;
var hid_textkey;
var txt_Component;
var hid_bom; //qs_bom
var hid_opr; //qs_opr
var hid_sloc; //qs_strgloc
var hid_itemno; //qs_itemno

sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/Button",
	"com/khc/batchhub/utils/UI_utilities",
	"com/khc/common/Script/CommonUtility",
	"com/khc/batchhub/model/formatter",
	"sap/m/MessageBox",
	"com/khc/batchhub/model/models"
	],
	function(Controller,Button,UI_utilities,CommonUtility,formatter,MessageBox,models) {

	"use strict";

	return Controller.extend("com.khc.batchhub.BatchExecuteOrder.BatchMaterialExtraWeigh", {
		formatter:formatter,
		onInit: function() {
			oBatchMaterialExtraWeigh =this;
	},

		_oRoutePatternMatched: function(oEvent) {
			console.log("pattern match funtion");

		},

		onLoadBatchMaterialExtraWeigh: function() {

			//UI_utilities.setContainerBusyState(oBatchMaterialExtraWeigh, false);

			oBatchMaterialExtraWeigh.clearValues();
			plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
			resr = sap.ui.getCore().getModel("session").oData.CA_Resource;
			orderid =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");
			phase = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.hid_phase;			
			OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_Order;			
			projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
			hid_PartialDisplayFlag = sap.ui.getCore().getModel("session").oData.CA_BHPartialWeigh;
			ScaleDecimal = sap.ui.getCore().getModel("session").oData.CA_ScaleDecimal;
			txt_crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
			punit = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_punit");
			hid_bom = sap.ui.getCore().getModel("BatchMaterialExtraWeighDataModel").oData.qs_bom;
			hid_opr = sap.ui.getCore().getModel("BatchMaterialExtraWeighDataModel").oData.qs_opr;
			hid_sloc = sap.ui.getCore().getModel("BatchMaterialExtraWeighDataModel").oData.qs_strgloc;
			hid_itemno = sap.ui.getCore().getModel("BatchMaterialExtraWeighDataModel").oData.qs_itemno;
			crdest = txt_crdest;	
			dp = parseInt(ScaleDecimal);
			SelRow = 0;
			hid_firstMatLoad =0;
			oBatchMaterialExtraWeigh.initiate();
			oBatchMaterialExtraWeigh.ScaleNameList();

		},

		//************** get the List of Material to be Wieghed for the Order ********//


		GetMatPrepList: function() {

			OrdBatch= OrdBatch.toString();
			var splitOrdBatch = OrdBatch.split("/");			
			var Batch = splitOrdBatch[0];

			oModelGetMatPrepList = models.createNewXMLModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->GetMatPrepList-->XACQ_GetMatPrepListByPhase");
			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + phase + "&Param.4=" + orderid + "&Param.5=" + Batch+"&d=" +new Date();
			oModelGetMatPrepList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetMatPrepListByPhase&" + params + "&Content-Type=text/xml", "", false);
			sap.ui.getCore().setModel(oModelGetMatPrepList, "GetMatPrepListData");

			oBatchMaterialExtraWeigh.setFirstRow(); // Update event called
			oBatchMaterialExtraWeigh.generatescalebutton();

		},

		generatescalebutton: function() {

			var produnit;
			var oModelGenerateScaleButton = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->generatescalebutton-->XACQ_GenerateScaleButton");
			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + produnit+"&d=" +new Date();
			oModelGenerateScaleButton.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GenerateScaleButton&" + params + "&Content-Type=text/json", "", false);

			//Assign button result to a div
		},

		//********** Get the List of Material by Batch for the Order **************//
/****
		GetMatPrepListByBatch: function(batch) {

			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + phase + "&Param.4=" + orderid + "&Param.5=" + batch+"&d=" +new Date();
			oModelGetMatPrepList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetMatPrepListByPhase&" + params + "&Content-Type=text/xml", "", false);
			sap.ui.getCore().setModel(oModelGetMatPrepList, "GetMatPrepListData");

			//oBatchMaterialExtraWeigh.setFirstRow(); // Update event called
		},
****/
		//************** Get the Conatiner Details for the Materials ******************//
/*** not used
		getContDetails: function() {

			//SelRow = 0;

			if (CommonUtility.getXmlModelRowCount(oModelGetMatPrepList.getData()) > 0) {
				var oData = oModelGetMatPrepList.getObject("/Rowset/Row/"+SelRow);

				oBatchMaterialExtraWeigh.getView().byId("txt_Container").setValue($(oData).find("CONTAINER").text() );

					oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").setValue(parseFloat($(oData).find("ActQty").text()).toFixed(dp));

				oBatchMaterialExtraWeigh.getView().byId("txt_Seq").setValue(SelRow+1);
				txt_Component= $(oData).find("BOM").text();
				oBatchMaterialExtraWeigh.getView().byId("txt_CompDesc").setValue($(oData).find("BOMTEXT").text());
				oBatchMaterialExtraWeigh.getView().byId("txt_TargetWeight").setValue(parseFloat($(oData).find("BOMQTY").text()).toFixed(dp));
				oBatchMaterialExtraWeigh.getView().byId("txt_GridUOM").setValue($(oData).find("BOMUOM").text());
				oBatchMaterialExtraWeigh.getView().byId("txt_Batch").setValue($(oData).find("BATCHID").text());
				oBatchMaterialExtraWeigh.getView().byId("txt_Componentstrip").setValue($(oData).find("ModBOM").text());
				hid_WeighedMat= $(oData).find("STATUS").text();

			}

		},
***/
		/********************************** Set Upper and Lower limit Code Added by Vaibhav for Seclin Plant***************/

		setUpperandLowerLimit: function() {

			var TrgtWeight = oBatchMaterialExtraWeigh.getView().byId("txt_TargetWeight").getValue();
			var TarWeight = TrgtWeight.replace("," , ".");
			var FormatTrgrtWgt = parseFloat(TarWeight);

			var LowTolerance = parseFloat("0");
			var UpTolerance = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.5;

			oBatchMaterialExtraWeigh.getView().byId("id_display_UpTrgtWgt").setValue(UpTolerance.toFixed(dp));
			oBatchMaterialExtraWeigh.getView().byId("id_display_LowTrgtWgt").setValue(LowTolerance.toFixed(dp));

		},

		//****************** Insert the Qty of the Material Weighed alongiwht the conatiner entered ****************//

		CheckandInsCont: function(){

				var containNum = oBatchMaterialExtraWeigh.getView().byId("txt_Container").getValue();
				var Batch = oBatchMaterialExtraWeigh.getView().byId("txt_Order").getValue();
				var BOM = hid_bom;

				var QtyIssued = Number(oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getValue());
				var TargetWeigh = Number(oBatchMaterialExtraWeigh.getView().byId("txt_TargetWeight").getValue());

					var QtyIssuedUL =Number(oBatchMaterialExtraWeigh.getView().byId("id_display_UpTrgtWgt").getValue());
					var QtyIssuedLL = Number(oBatchMaterialExtraWeigh.getView().byId("id_display_LowTrgtWgt").getValue());

					var BatchIDFlag=0;
					var BOMBatch = oBatchMaterialExtraWeigh.getView().byId("txt_Batch").getValue();
					if(BOMBatch==""){
						BatchIDFlag=0;
					}
					else if(BOMBatch=="---"){
						BatchIDFlag=0;
					}
					else{
						BatchIDFlag=1;
					}

					if(BatchIDFlag==1)
					{
						if(QtyIssued > QtyIssuedLL && QtyIssued <= QtyIssuedUL)
						{
							if(containNum != "" && QtyIssued !="" && containNum != "---")
							{
								var oModelCheckContainer = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->CheckandInsCont-->XACQ_CheckContainer");
								var params = "Param.1=" + plant + "&Param.2=" + containNum + "&Param.3=" + orderid + "&Param.4=" + Batch + "&Param.5=" + BOM+"&d=" +new Date();
								oModelCheckContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_CheckContainer&" + params + "&Content-Type=text/json", "", false);

								if (CommonUtility.getJsonModelRowCount(oModelCheckContainer.getData()) > 0) {

									var contFlag = oModelCheckContainer.getData().Rowsets.Rowset[0].Row[0].O_ContainerData;

									if(contFlag == 1)
									{

										var msg = "Container not empty. You want to Clear the Container and Confirm?";
										var that = oBatchMaterialExtraWeigh;
										MessageBox.confirm(
												msg, {
													icon: MessageBox.Icon.INFORMATION,
													title: "Message from webpage",
													actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
													onClose: function(oAction) { 
														if(oAction==="OK"){
															that.ConfirmMatPrep('1');
															that.PrintLabel();
															that.GetBack();
														}
														else {
															
														}
													}
												});	

									}
									else {

										oBatchMaterialExtraWeigh.ConfirmMatPrep('0');
															oBatchMaterialExtraWeigh.PrintLabel();
															oBatchMaterialExtraWeigh.GetBack();

									}
								}
							}
							else
							{
								MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0062"));							
							}
						}
						else
						{
							MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0074"));	

						}
					}
					else
					{
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0108"));	

					} 

		},

		ConfirmMatPrep: function(ContFlag) {

			var hdrmat = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_MatNo;

				var Opr = hid_opr;
				var BOM = hid_bom;
				var BOMBatch = oBatchMaterialExtraWeigh.getView().byId("txt_Batch").getValue();
				var BOMQty = oBatchMaterialExtraWeigh.getView().byId("txt_TargetWeight").getValue();
				var sloc = hid_sloc;
				var UOM = oBatchMaterialExtraWeigh.getView().byId("txt_GridUOM").getValue();


			var Batch = oBatchMaterialExtraWeigh.getView().byId("txt_Order").getValue();
			var QtyIssued = oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getValue();
			var containNum = oBatchMaterialExtraWeigh.getView().byId("txt_Container").getValue();
			hid_lastcontainer = containNum;
			var Flag = ContFlag;
			var ContText = "";	
			var itemno= hid_itemno;

			var oModelConfirmMaterialPreparation = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->ConfirmMatPrep-->XACQ_ConfirmMaterialPrepExtra");
			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + orderid + "&Param.4=" + hdrmat + "&Param.5=" + phase
			+ "&Param.6=" + Opr+ "&Param.7=" + BOM+ "&Param.8=" + BOMBatch+ "&Param.9=" + BOMQty+ "&Param.10=" + Batch+ "&Param.11=" + QtyIssued
			+ "&Param.12=" + containNum+ "&Param.13=" + Flag+ "&Param.14=" + ContText+ "&Param.15=" + crdest+ "&Param.16=" + UOM
			+ "&Param.17=" + sloc + "&Param.18=" + itemno+"&d=" +new Date();
			oModelConfirmMaterialPreparation.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_ConfirmMaterialPrepExtra&" + params + "&Content-Type=text/json", "", false);

			var nextItem = oModelConfirmMaterialPreparation.getData().Rowsets.Rowset[0].Row[0].O_NextExtraItem;
			
		},

		//****************** Redirects to the Material Preparation Page ****************//

		GetBack: function()
		{
			//window.history.back(-1);
			sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchMaterialExtraWeigh", false);
			sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatPreparation").GetMatPrepList();
			sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchOEMatPreparation", true);

		},

		initiate: function()
		{
			oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").focus();
			if(oBatchMaterialExtraWeigh.getView().byId("txt_Container").getValue() == ""){
				var prdunit = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_punit;	

				var oModelGetConfigContainer = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->getContDetails-->XACQ_GetConfigContainer");
				var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + prdunit+"&d=" +new Date();
				oModelGetConfigContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetConfigContainer&" + params + "&Content-Type=text/json", "", false);

				oBatchMaterialExtraWeigh.getView().byId("txt_Container").setValue(oModelGetConfigContainer.getData().Rowsets.Rowset[0].Row[0].CONNUM);	
			}

			oBatchMaterialExtraWeigh.generatescalebutton();
			oBatchMaterialExtraWeigh.setUpperandLowerLimit();
		},

		searchKeyPress: function() {

			if(oBatchMaterialExtraWeigh.getVieW().byId("id_btn_NextIngr").getEnabled()) {

				oBatchMaterialExtraWeigh.NextComponent();
			}

		},

		ReadWeight: function() {

			var Scale = oBatchMaterialExtraWeigh.getView().byId("id_ScaleList").getSelectedKey();
			var O_Weight;

			var UpperTrgtWeight= oBatchMaterialExtraWeigh.getView().byId("id_display_UpTrgtWgt").getValue();
			var LowerTrgtWeight= oBatchMaterialExtraWeigh.getView().byId("id_display_LowTrgtWgt").getValue();

			/***** 			---NOT BEING USED---
			var DestID = "";

			if (plant == "3278")
			{
				DestID = "MT_SCALES_ELST";
			}
			else if (plant == "3005")
			{
				DestID = "SCALES_KG";
			}
			else if (plant == "3414")
			{
				DestID = "SCALES_LL";
			}
			else if (plant == "3309")
			{
				DestID = "SCALES_PU";
			}
			 *****/
			if(oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getValue() == ""){

				var oModelCheckWeighingWebSocket = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->ReadWeight-->XACQ_CheckWeighingWebSocketConnectin");
				//var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + orderid + "&Param.4=" + batch+"&d=" +new Date();
				oModelCheckWeighingWebSocket.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_CheckWeighingWebSocketConnectin&Content-Type=text/json", "", false);

				var PCoConnectionFlag = parseInt(oModelCheckWeighingWebSocket.getData().Rowsets.Rowset[0].Row[0].WebSocketFlag);
				if(PCoConnectionFlag == 1)
				{
					var oModelGetWeighScaleReadingFromPCo = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->ReadWeight-->XACQ_GetWeighScaleReadingFromPCo");
					var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + Scale+"&d=" +new Date();
					oModelGetWeighScaleReadingFromPCo.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetWeighScaleReadingFromPCo&"+ params +"&Content-Type=text/json", "", false);

					O_Weight = oModelGetWeighScaleReadingFromPCo.getData().Rowsets.Rowset[0].Row[0].Value;

					oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").setValue(parseFloat(O_Weight).toFixed(dp));

				}
				else {

					var oModelReadWeight = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->ReadWeight-->XACQ_ReadWeight");
					var params = "Param.1=" + plant + "&Param.2=" + Scale+"&d=" +new Date();
					oModelReadWeight.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_ReadWeight&"+ params +"&Content-Type=text/json", "", false);

					O_Weight = oModelReadWeight.getData().Rowsets.Rowset[0].Row[0].O_Weight;
					oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").setValue(parseFloat(O_Weight).toFixed(dp));

				}
			}

			var TrgtWeight = oBatchMaterialExtraWeigh.getView().byId("txt_TargetWeight").getValue();
			var FormatTrgrtWgt = parseFloat(TrgtWeight);
			var SclWeight = oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getValue();

			if (Number(SclWeight )>=Number( LowerTrgtWeight )&&Number(SclWeight) <= Number(UpperTrgtWeight))
			{
				oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
				oBatchMaterialExtraWeigh.getView().byId("id_btn_NextIngr").setType("Emphasized");	
				oBatchMaterialExtraWeigh.getView().byId("id_btn_ReadScale").setType("Default");
				oBatchMaterialExtraWeigh.getView().byId("id_btn_NextIngr").setEnabled(true);

			}
			else{

				oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
				oBatchMaterialExtraWeigh.getView().byId("id_btn_NextIngr").setType("Default");	
				oBatchMaterialExtraWeigh.getView().byId("id_btn_ReadScale").setType("Emphasized");
				oBatchMaterialExtraWeigh.getView().byId("id_btn_NextIngr").setEnabled(false);

			}

		},

		PrintLabel: function() {

			var splitOrdBatch = OrdBatch.split("/");			
			var Batch = splitOrdBatch[0];

			var oModelGetBatchByOrderMaterial = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->PrintLabel-->SQLQ_GetBatchByOrderMaterial");
			var params = "Param.1=" + oBatchMaterialExtraWeigh.getView().byId("txt_Batch").getValue() + "&Param.2=" + txt_Component + "&Param.3=" + orderid+"&d=" +new Date();
			oModelGetBatchByOrderMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/SQLQ_GetBatchByOrderMaterial&"+ params +"&Content-Type=text/json", "", false);

			if (CommonUtility.getJsonModelRowCount(oModelGetBatchByOrderMaterial.getData()) != 0) {
				var expiry = oModelGetBatchByOrderMaterial.getData().Rowsets.Rowset[0].Row[0].EXPIRYDATE;
				var expiry = expiry.split(" ");
				var expiry_final = expiry[0].split("/");

				var dt =  new Date();
				//var d_day = d.toDateString(); 
				//var d_date = d_day.split(" ");

				if(dt.getDate() < 10) {
					var day = "0"+dt.getDate();
				}
				else{
					var day=dt.getDate();
				}

				if(dt.getMonth()+1 < 10) {
					var month = "0"+eval(dt.getMonth()+1);
				}
				else{
					var month=eval(dt.getMonth()+1);
				}	

				var currentD = day + "." + month + "." + dt.getFullYear();	
				var currentT = dt.toTimeString();
				var currentTime_Final = currentT.split(" ");
				var cont = oBatchMaterialExtraWeigh.getView().byId("txt_Container").getValue();
				var oModelPrintLabel = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->PrintLabel-->XACQ_CreateLabelPrint");

				var params = "Param.1=" + oBatchMaterialExtraWeigh.getView().byId("txt_Batch").getValue() + "&Param.2=" + cont + "&Param.3=" 
				+ expiry_final[1] + "." + expiry_final[0] + "." + expiry_final[2] + "&Param.4=" + cont + "&Param.5=" + currentD
				+ "&Param.6=" + currentTime_Final[0] + "&Param.7=" + txt_Component+ "&Param.8=" + oBatchMaterialExtraWeigh.getView().byId("txt_CompDesc").getValue()
				+ "&Param.9=" + orderid+ "&Param.10=" + plant+ "&Param.11=" + oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getValue()
				+ "&Param.12=" + resr+ "&Param.13=MATID&Param.14=" + splitOrdBatch[0]+ "&Param.15=" + splitOrdBatch[1]+ "&Param.17=" 
				+ oBatchMaterialExtraWeigh.getView().byId("txt_GridUOM").getValue() +"&d=" +new Date();

				oModelPrintLabel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_CreateLabelPrint&" + params + "&Content-Type=text/json", "", false);
			}

		},

		ScaleNameList: function() {

			var oModelGetBatchByOrderMaterial = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialExtraWeigh-->ScaleNameList-->XACQ_GetWeighScaleList");
			oModelGetBatchByOrderMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetWeighScaleList&Content-Type=text/json", "", false);
			sap.ui.getCore().setModel(oModelGetBatchByOrderMaterial, "GetWeighScaleListData");
			oBatchMaterialExtraWeigh.getView().byId("id_ScaleList").setSelectedKey(oModelGetBatchByOrderMaterial.getData().Rowsets.Rowset[0].Row[0].ScaleName)

		},

		clearValues : function() {

			oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
			oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").setEnabled(true);
			oBatchMaterialExtraWeigh.getView().byId("txt_Container").setValue("");
			oBatchMaterialExtraWeigh.getView().byId("txt_ScaleWgt").setValue("");
			oBatchMaterialExtraWeigh.getView().byId("id_btn_ReadScale").setEnabled(true);
			oBatchMaterialExtraWeigh.getView().byId("id_btn_ReadScale").setType("Emphasized");
			oBatchMaterialExtraWeigh.getView().byId("id_btn_NextIngr").setEnabled(false);
			oBatchMaterialExtraWeigh.getView().byId("id_btn_NextIngr").setType("Default");
			
		},

	
	});
});
 //# sourceURL=https://sapmiigih.mykft.net/XMII/CM/BatchHubUI5/webapp/controller/BatchExecuteOrder/BatchMaterialExtraWeigh.controller.js?eval