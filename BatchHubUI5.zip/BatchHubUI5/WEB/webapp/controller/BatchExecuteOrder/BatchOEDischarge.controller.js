sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
   "sap/m/MessageBox",
  
   "com/khc/batchhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models","com/khc/batchhub/model/formatter"
],
function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models,formatter) {
   var plant;
   var resource;
   var projectName;
   var userName;
   var crdest;
   var crid;
   var orderID;
   
   var shiftname;
   var shiftStartTime;
   var shiftEndTime;
   var shiftId;
   var teamId;
   var crew;
   
   var oBatchOEDischarge;
   var id_hid_shiftnotenum;
   return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEDischarge", {
      formatter: formatter,
      onInit: function() { 
         oBatchOEDischarge=this;
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         this._oRouter.getRoute("BatchDispDetail").attachPatternMatched(
         this._oRoutePatternMatched, this);
      },
      
      _oRoutePatternMatched: function(oEvent) {
         
         //Hide the messages and set busy to false
         UI_utilities.batchPageOpened(this, "common");
      },
      
        onLoadBatchOEDischarge: function() {
            plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
            resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
            crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
            projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName; 
         userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
         
         
         this.ClearAllValues();
            this.BatchOEDischargeloadPlannedTime();
            this.BatchOEDischargebuttonDisable();
            this.BatchOEDischargeGetMatPrepList(); 
            this.getReasonCodeList(); 
            this.getRunningShift();
      },
        
      
        
      // on Load get the running shift details
      getRunningShift : function() {
         
         var oModelRunningShiftDetails = models
         .createNewJSONModel("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEDischarge-->getRunningShift-->XACQ_GetRunningShift");
         var that = oBatchOEDischarge;
         oModelRunningShiftDetails.attachRequestCompleted(function() {
            
                that.getView().setModel(oModelRunningShiftDetails, "oRunningShiftList");
                if (CommonUtility.getJsonModelRowCount(oModelRunningShiftDetails.getData()) > 0) {
               var oRunningShiftData = oModelRunningShiftDetails.getData().Rowsets.Rowset[0].Row[0];
               shiftname = oRunningShiftData.SHIFTNAME;
               shiftStartTime = oRunningShiftData.STARTTIME;
               shiftEndTime = oRunningShiftData.ENDTIME;
               shiftId = oRunningShiftData.SHIFTID;
               teamId = oRunningShiftData.TEAMID;
               crew= oRunningShiftData.TEAMSIZE;
               } else {
               var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0019");
               sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sNoShiftMsg);
               sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
               sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Error");
            }
         });
         
         oModelRunningShiftDetails.loadData("/XMII/Illuminator?QueryTemplate=" + projectName
                + "/QueryTemplate/XACQ_GetRunningShift&Param.1=" + plant + "&Param.2=" + resource + "&d="+new Date() + "&Content-Type=text/json",
         "", false);
         
      },
      
      getReasonCodeList : function() {
         var oReasonCodeList  = models
         .createNewJSONModel("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEDischarge-->getReasonCodeList-->SQLQ_GetScrapCode");
         
         oReasonCodeList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
         "/QueryTemplate/SQLQ_GetScrapCode&Content-Type=text/json", "", false);
         
         oBatchOEDischarge.getView().setModel(oReasonCodeList, "oReasonCode");
         
      },
      BatchOEDischargeloadPlannedTime: function() {
         var hid_PlannedTime=sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_PlannedTime");
         oBatchOEDischarge.getView().byId("txt_PlannedTime").setValue( hid_PlannedTime );
         oBatchOEDischarge.getView().byId("txt_BatchSize").setValue(  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ActBatchSize") );
         
         var hid_UOM=sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_UOM");
         oBatchOEDischarge.getView().byId("txt_UOM").setValue( hid_UOM );
         
         var batch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch");//txt_RunBatch; 
         var currentDT = CommonUtility.getCurrentDateTime(new Date());
         var startdate =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_StartTime");
         
         var APLT_CMD_TotalTime = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->loadPlannedTime-->XACQ_CalculateOrderTotalTime");
         var params = "Param.1=" + startdate + "&Param.2=" + currentDT;
         APLT_CMD_TotalTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CalculateOrderTotalTime&" +
         params + "&Content-Type=text/json", "", false);
         
         //document.getElementById("txt_BatchNbr").value = parent.document.getElementById("txt_OrdNoStrip").value+padno(batch);
         var txt_OrdNoStrip = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_OrdNoStrip");
         
         oBatchOEDischarge.getView().byId("txt_BatchNbr").setValue(txt_OrdNoStrip + this.padno(batch));
         
         if (CommonUtility.getJsonModelRowCount(APLT_CMD_TotalTime.getData()) > 0) {
            var oData = APLT_CMD_TotalTime.getData().Rowsets.Rowset[0].Row[0];
            var oDuration = oData.O_Duration;
            oBatchOEDischarge.getView().byId("txt_TotalTime").setValue(oDuration);
         }
      },
      
      padno: function(str) {
         if (str.length == 1) {
            str = "00" + str;
            } else if (str.length == 2) {
            str = "0" + str;
            } else if (str.length == 3) {
            str = str;
         }
         return str;
      },
      
      BatchOEDischargebuttonDisable: function() {
           var hid_phasestatus= sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
         //var hid_phasestatus == "1";
         if (hid_phasestatus == "1") {
            oBatchOEDischarge.getView().byId("BatchOEDischarge_btn_viewinstruct").setEnabled(true)
            oBatchOEDischarge.getView().byId("id_btn_variance").setEnabled(true)
            oBatchOEDischarge.getView().byId("id_btn_createHU").setEnabled(true)
            this.CheckDischargeStatus();
            } else {
            oBatchOEDischarge.getView().byId("BatchOEDischarge_btn_viewinstruct").setEnabled(false)
            oBatchOEDischarge.getView().byId("id_btn_variance").setEnabled(false)
            oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(false)
            oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(false)
            oBatchOEDischarge.getView().byId("id_btn_createHU").setEnabled(false)
            
         }
      },
      BatchOEDischargeGetMatPrepList: function() {
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var batch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch");//txt_RunBatch;
         
         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");
         var splitOrdBatch = OrdBatch.split("/");
         var Batch1 = splitOrdBatch[0];
         
         var APLT_GRI_DischargeMatList = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->GetMatIdenList-->XACQ_DischargeMatList");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + batch +"&d="+new Date();
         APLT_GRI_DischargeMatList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_DischargeMatList&" +
         params + "&Content-Type=text/json", "", false);
         sap.ui.getCore().setModel(APLT_GRI_DischargeMatList, "dischargeMatListModel");
         
         var APLT_CMD_GetLastReceiptOutput = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->GetMatIdenList-->SQLQ_GetLastReceiptOutput");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid +"&d="+new Date();
         APLT_CMD_GetLastReceiptOutput.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetLastReceiptOutput&" +
         params + "&Content-Type=text/json", "", false);
         
         
         if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetLastReceiptOutput.getData()) > 0) {
            var oData = APLT_CMD_GetLastReceiptOutput.getData().Rowsets.Rowset[0].Row[0];
            var output = oData.OUTPUT;
            oBatchOEDischarge.getView().byId("txt_Output").setValue(output);
         }
         
         this.checkFlag();
         
      },
      
      checkFlag: function() {
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         
         var hid_phasestatus= sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");
         var splitOrdBatch = OrdBatch.split("/");
         var Batch = splitOrdBatch[0];
         
         var APLT_CMD_GetActionFlag = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->checkFlag-->SQLQ_GetBatchPhaseActionFlag");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + orderid + "&Param.5=" + phase +
         "&Param.6=" + Batch +"&d="+new Date();
         APLT_CMD_GetActionFlag.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetBatchPhaseActionFlag&" +
         params + "&Content-Type=text/json", "", false);
         
         if (hid_phasestatus == "1") {
            
            if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetActionFlag.getData()) > 0) {
               var oData = APLT_CMD_GetActionFlag.getData().Rowsets.Rowset[0].Row[0];
               
               var actionFlag = oData.ACTIONFLAG;
               if (actionFlag == "1") {
                  oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(false)
                  oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(false)
               }
               } else {
               oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(true)
               oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(true)
            }
            
         }
      },
      
      
      
      openVarianceReason : function() {
         var RowNo = oBatchOEDischarge.getView().byId(
         "BatchOEDischargeMatIdenListTable").getSelectedContextPaths().length;
         
         var sPath = oBatchOEDischarge.getView().byId(
         "BatchOEDischargeMatIdenListTable").getSelectedContextPaths()[0];
         
         var oDischargeMatListTable = oBatchOEDischarge.getView().getModel(
         "dischargeMatListModel");
         
         if (RowNo != 0) {
            var js_shiftname = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/qs_shiftname");
            var js_matno = oDischargeMatListTable.getProperty(sPath + '/BOMMOD');
            var js_batchnr = oBatchOEDischarge.getView().byId("txt_BatchNbr").getValue();
            var js_bomqty = oDischargeMatListTable.getProperty(sPath + '/BOMQTY');
            var js_variance = oDischargeMatListTable.getProperty(sPath + '/VARFLAG');
            
            // var Url =
            // "BatchVarianceExplPopUp.irpt?qs_shiftname="+js_shiftname+"&qs_matno="+js_matno+"&qs_batchnr="+js_batchnr+"&qs_bomqty="+js_bomqty+"&qs_variance="+js_variance;
            // window.open(Url, "ExplainVariance",
            // 'width=400,height=200,scrollbars=no,left=400,top=350,resizable=no,status=yes,location=no');
            
            if (!this.oBatchVarianceExplPopUp) {
               this.oBatchVarianceExplPopUp = sap.ui.xmlfragment(
               "com.khc.batchhub.view.BatchExecuteOrder.BatchVarianceExplPopUp",this);                          
            }
            this.oBatchVarianceExplPopUp.open();
            
            
            } else {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty(
            "BATCH_MSG_0061");
            MessageBox.error(sAlertMsg);
         }
      },
      
      
      closeBatchOrdInstPopUp: function() {
         this.oBatchVarianceExplPopUp.close();
      },
      
      
      createShiftNotes:function(){
         
        //
         var dt = new Date();
         var date = formatDate(dt);
         var currentDT = CommonUtility.getCurrentDateTime(new Date());
         var time = dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
         
         var RowNo = oBatchOEDischarge.getView().byId(
         "BatchOEDischargeMatIdenListTable").getSelectedContextPaths().length;
         
         var sPath = oBatchOEDischarge.getView().byId(
         "BatchOEDischargeMatIdenListTable").getSelectedContextPaths()[0];
         
         var oDischargeMatListTable = oBatchOEDischarge.getView().getModel(
         "dischargeMatListModel");
         
         ShiftName=sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_shift");
         
         var MatNo=oDischargeMatListTable.getProperty(sPath + '/BOMMOD');
         
         var BatchNr=oBatchOEDischarge.getView().byId("txt_BatchNbr").getValue();
         
         var BomQty=oDischargeMatListTable.getProperty(sPath + '/BOMQTY');
         var Variance=oDischargeMatListTable.getProperty(sPath + '/VARFLAG');
         
         var explain=sap.ui.getCore().byId("notes").getValue();
         
         var NoteText = "Campaign:"+BatchNr+", Variance on Material:"+MatNo+", Reqd:"+BomQty+", Variance:"+Variance+", Explanation : "+explain;
         
         var oshiftNoteQObjModel = models
         .createNewJSONModel("com.khc.batchhub.controller.BatchExecuteOrder-->createShiftNotes-->XACQ_CreateShiftNotes");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3="
         + "ZG99" + "&Param.4=" + date + "&Param.5=" + time
         + "&Param.6=" + "" + "&Param.7=" + "" + "&Param.8="
         + "" + "&Param.9=" + NoteText + "&Param.10=" + ""
         + "&Param.11=" + "" + "&Param.12=" + "Confirmation"
         + "&Param.13=" +userName +"&d="+new Date();
         
         oshiftNoteQObjModel.loadData("/XMII/Illuminator?QueryTemplate="
            + projectName + "/QueryTemplate/XACQ_CreateShiftNotes&" + params
         + "&Content-Type=text/json", "", false);
         // this.getView().setModel(oshiftNoteQObjModel, "shiftNoteQObjModel");
         
         
         if (CommonUtility.getJsonModelRowCount(oshiftNoteQObjModel.getData()) > 0) {
            var ShiftNoteNum=oshiftNoteQObjModel.getData().Rowsets.Rowset[0].Row[0];
            var ShiftNote = ShiftNoteNum.O_ShiftNote;
            
            if(oshiftNoteQObjModel.getData().Rowsets.Rowset[0].Row[0].O_ShiftNote=="E"){
               id_hid_shiftnotenum="";
               var sMatTippMsg ="Shift NoteNot Created please check the log";
                 sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                 sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                 sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Error");
        sap.ui.getCore().byId("notes").setValue("");
                 this.oBatchVarianceExplPopUp.close(); 
          }
            else{
               id_hid_shiftnotenum=ShiftNote;
               
               var APLT_CMD_ShiftNote = models
               .createNewJSONModel("com.khc.batchhub.controller.BatchExecuteOrder-->createShiftNotes-->SQLQ_InsShiftNote");
               var paramShfit= "Param.1=" + plant + "&Param.2=" + resource + "&Param.3="
               + ShiftName + "&Param.4=" + currentDT + "&Param.5=" + ""
               + "&Param.6=" + NoteText + "&Param.7=" + ShiftNote +"&d="+new Date();
               APLT_CMD_ShiftNote.loadData("/XMII/Illuminator?QueryTemplate="
                  + projectName + "/QueryTemplate/SQLQ_InsShiftNote&" + paramShfit
               + "&Content-Type=text/json", "", false);
               
           
               var sMatTippMsg ="Shift Note "+ShiftNote+"  created successfully";
           sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
           sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
           sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
           sap.ui.getCore().byId("notes").setValue("");
           this.oBatchVarianceExplPopUp.close();
            }  
         
            }
          
         
         
      },
      
      ConfirmScrap: function() {    
         var currentDT = CommonUtility.getCurrentDateTime(new Date());
         var evtdate1 = this.formatDateToCallProcessMsg();
         var evttime = this.formatTimeToCallProcessMsg1(currentDT);
         var evtdate = this.formatDateToCallProcessMsg1(currentDT);
         var id_txt_scode = oBatchOEDischarge.getView().byId("reasonCodeId").getSelectedKey();
         var id_txt_sreason = "";
         var id_txt_crdest = "";
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var uom = oBatchOEDischarge.getView().byId("txt_UOM").getValue();
         var totalTime = oBatchOEDischarge.getView().byId("txt_TotalTime").getValue();
         var shift = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_shift");
         var shiftName = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/shiftname");
         var teamid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/teamID");
         var selprdunit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;
         var oper = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_opr");//hid_opr;
         var txt_RunBatch =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch");
         var txt_MatNo =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");//
         var hid_phasetext = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasetext");//
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var crid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_crid"); //hid_crid;
         var txtOutput = oBatchOEDischarge.getView().byId("txt_Output").getValue();
         var test = "test";
         //if(document.getElementById("txt_Output").value != "" && !isNaN(document.getElementById("txt_Output").value))
         if (oBatchOEDischarge.getView().byId("txt_Output").getValue() != "" && !isNaN(oBatchOEDischarge.getView().byId("txt_Output").getValue())) {
       
         //   if (id_txt_scode != "") {
	if(oBatchOEDischarge.getView().byId("reasonCodeId").getSelectedItem()){
   	  id_txt_sreason= oBatchOEDischarge.getView().byId("reasonCodeId").getSelectedItem().getText()
               var APLT_CMD_ScrapConfirm = models.createNewJSONModel(
               "com.khc.batchhub.controller.BatchExecuteOrder-->ConfirmScrap-->XACQ_RecordScrapConfirm");
               var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + evtdate1 + "&Param.4=" + evtdate + "&Param.5=" + evttime +
               "&Param.6=" + "00004" +
               "&Param.7=" + orderid + "&Param.8=" + userName + "&Param.9=" + oper + "&Param.10=" + phase + "&Param.11=" + id_txt_scode +
               "&Param.12=" + txtOutput + "&Param.13=" + uom + "&Param.14=" + txt_RunBatch + "&Param.15=" + id_txt_crdest + "&Param.16=" + crid +
               "&Param.17=" + totalTime + "&Param.18=" + txt_MatNo + "&Param.19=" + test +
               "&Param.20=" + hid_phasetext + "&Param.21=" + shift + "&Param.22=" + shiftName + "&Param.23=" + id_txt_sreason + "&Param.24=" +
               teamid +
               "&Param.25=" + selprdunit + "&Param.26=" + currentDT +"&d="+new Date();
               APLT_CMD_ScrapConfirm.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_RecordScrapConfirm&" +
               params + "&Content-Type=text/json", "", false);
               
               if (CommonUtility.getJsonModelRowCount(APLT_CMD_ScrapConfirm.getData()) > 0) {
                  var oData = APLT_CMD_ScrapConfirm.getData().Rowsets.Rowset[0].Row[0];
                  var type = oData.Type;
                  if (type == "S") { 
                     //document.getElementById("id_msg_scrap_success").style.display='block';   
                     var sMatTippMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0012");
                     sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                     sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                     sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
                     this.CheckScrapStatus();
                     this.checkFlag();
                     } else if (type == "E") {
                     //document.getElementById("id_msg_scrap_error").style.display='block';  
                     var sMatTippMsg = oData.Message;
                     sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                     sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                     sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Error");
                     oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(true)
                     oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(true)
                     
                  }
               }
               } else {
               var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0059");
               MessageBox.alert(sAlertMsg);
            }
            } else {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0060");
            MessageBox.alert(sAlertMsg);
         }
      },
      ConfirmGoodsReceipt: function() {
         //oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(false)
         //oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(false)
         
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var oper = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_opr");//hid_opr;
         var hdrmat = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");//txt_MatNo;
         var batchid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch");//txt_RunBatch;
         var msgId = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_msgid");//hid_ordid;
         
         var prodoutput = oBatchOEDischarge.getView().byId("txt_Output").getValue();
         var uom = oBatchOEDischarge.getView().byId("txt_UOM").getValue();
         var shiftId = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_shift");//txt_shift;
         var prdunit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;
         var interval = oBatchOEDischarge.getView().byId("txt_TotalTime").getValue(); 
         var batchNum = oBatchOEDischarge.getView().byId("txt_BatchNbr").getValue();
         var batchsize = oBatchOEDischarge.getView().byId("txt_BatchSize").getValue();
         var crid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_crid"); //hid_crid;
         var batchsizeUL = parseFloat(batchsize) + 0.02 * parseFloat(batchsize)
         var shiftName = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/shiftname");
         
         var currentDT = CommonUtility.getCurrentDateTime(new Date());
         
         if (oBatchOEDischarge.getView().byId("txt_Output").getValue() == "" || isNaN(oBatchOEDischarge.getView().byId("txt_Output").getValue())) {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0058");
            MessageBox.error(sAlertMsg);
            } else if (prodoutput > batchsizeUL) {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0075");
            MessageBox.error(sAlertMsg);
            } else {
            var APLT_CMD_CofirmGoodsReceipt = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->ConfirmGoodsReceipt-->XACQ_GoodsReceipt_Discharge");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + phase + "&Param.5=" + oper +
            "&Param.6=" + hdrmat +
            "&Param.7=" + batchid + "&Param.8=" + prodoutput + "&Param.9=" + uom + "&Param.10=" + shiftId + "&Param.11=" + prdunit +
            "&Param.12=" + crdest + "&Param.13=" + currentDT + "&Param.14=" + interval + "&Param.15=" + crew + "&Param.16=" + batchNum +
            "&Param.17=" + msgId + "&Param.18=" + crid +"&d="+new Date();
            APLT_CMD_CofirmGoodsReceipt.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GoodsReceipt_Discharge&" +
            params + "&Content-Type=text/json", "", false);
            
            if (CommonUtility.getJsonModelRowCount(APLT_CMD_CofirmGoodsReceipt.getData()) > 0) {
               var oData = APLT_CMD_CofirmGoodsReceipt.getData().Rowsets.Rowset[0].Row[0];
               var type = oData.Type;
               if (type == "S") {
                  //document.getElementById("id_msg_discharge_success").style.display='block';
                  var sMatTippMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0011");
                  sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                  sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                  sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
                  this.CheckDischargeStatus();
                  this.checkFlag();
                  } else if (type == "E") {
                  //document.getElementById("id_msg_discharge_error").style.display='block';
                  var sMatTippMsg =  oData.Message;
                  sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                  sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                  sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Error");
                  oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(true)
                  oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(true)
                  
               }
            }
         }
         
      },
      
      /*BatchPhaseInstructionPopUp.Fragment Functoins Start*/
      
      GetPhaseLongText: function() { 
         sap.ui.getCore().getModel("BatchExecOrderFragment").setProperty("/hid_msgid", ""); 
            var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
            var selPhase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         
         
         if (!this.oBatchPhaseInsPopUp) {
            this.oBatchPhaseInsPopUp = sap.ui.xmlfragment("com.khc.batchhub.view.BatchExecuteOrder.PhaseLongTextPopUp", this);
         }
         this.oBatchPhaseInsPopUp.open();
         /*  var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
            var oView = sap.ui.getCore();
            var sID = "instruction";
         UI_utilities.setOrderPahseLongText(oView, sID, sLanguage, orderid, plant, phase, projectName);*/
         sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder").setPhaseLongText( sLanguage, orderid, plant, selPhase, projectName);
         
         
      },
      
      closeBatchPhaseInsPopUp: function() {
         this.oBatchPhaseInsPopUp.close();
      },
      closeLongTextPopUp: function() {
         this.oBatchPhaseInsPopUp.close();
      },
      /*BatchPhaseInstructionPopUp.Fragment Functoins End*/
      
      //********* Check for the Status of the Discharge action for the Batch. Enables & Diables button accordingly *****************//
      
      CheckDischargeStatus: function() {
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var batch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch");//txt_RunBatch; 
         var punit = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_punit");//txt_punit; 
         
         var APLT_CMD_CheckDischargeStatus = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->CheckDischargeStatus-->XACQ_CheckDischargeStatus");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + batch + "&Param.5=" + punit +"&d="+new Date();
         APLT_CMD_CheckDischargeStatus.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CheckDischargeStatus&" +
         params + "&Content-Type=text/json", "", false);
         
         if (CommonUtility.getJsonModelRowCount(APLT_CMD_CheckDischargeStatus.getData()) > 0) {
            var oData = APLT_CMD_CheckDischargeStatus.getData().Rowsets.Rowset[0].Row[0];
            var ReturnStatus = oData.O_Count;
            if(ReturnStatus=="0"){
               //oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(true)
               //oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(true)
               this.CheckScrapStatus();
            }
            else{
               oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(false);
               oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(false);
            }
         }
         else{
            
            //oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(true);
            //oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(true);
            this.CheckScrapStatus();
            
         }
         
      },
      //********* Check for the Status of the Scrap action for the Batch. Enables & Diables button accordingly *****************//
      
      CheckScrapStatus: function() {
         
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var batch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_RunBatch");//txt_RunBatch; 
         var punit = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_punit");//txt_punit; 
         
         var APLT_CMD_CheckScrapStatus = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->CheckScrapStatus-->XACQ_CheckScrapStatus");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + batch + "&Param.5=" + punit +"&d="+new Date();
         APLT_CMD_CheckScrapStatus.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CheckScrapStatus&" +
         params + "&Content-Type=text/json", "", false);
         
         if (CommonUtility.getJsonModelRowCount(APLT_CMD_CheckScrapStatus.getData()) > 0) {
            var oData = APLT_CMD_CheckScrapStatus.getData().Rowsets.Rowset[0].Row[0];
            var ReturnStatus = oData.O_Count;
            if(ReturnStatus=="0"){
               oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(true)
               oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(true)
            }
            else{
               
               oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(false);
               oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(false)   ;
            }
         }
         else{
            
            oBatchOEDischarge.getView().byId("id_btn_complete").setEnabled(true);
            oBatchOEDischarge.getView().byId("id_btn_scrap").setEnabled(true) ;
         }
      },
      
      formatDateToCallProcessMsg: function(date) {
         var dt = new Date();
         if(dt.getDate() < 10) {
            var day = "0"+dt.getDate();
         }
         else{
            var day=dt.getDate();
         }
         
         if(dt.getMonth()+1 < 10) {
            var month = "0"+eval(dt.getMonth()+1);
         }
         else{
            var month=eval(dt.getMonth()+1);
         }     
         return dt.getFullYear()+""+month+""+day;
      },
      formatTimeToCallProcessMsg1: function(date) {
         var rectime = date.substring(11,13)+""+date.substring(14,16)+""+date.substring(17,19);
         return rectime;
      },
      formatDateToCallProcessMsg1: function(date) {
         
         var recdate = date.substring(0,4)+""+date.substring(5,7)+""+date.substring(8,10);
         return recdate;
      },
      
      
      ClearAllValues: function() {
         
         
         oBatchOEDischarge.getView().byId("reasonCodeId").setSelectedKey("");
         oBatchOEDischarge.getView().byId("txt_Output").setValue("");
         sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", false);
      }
      
      
   });
});