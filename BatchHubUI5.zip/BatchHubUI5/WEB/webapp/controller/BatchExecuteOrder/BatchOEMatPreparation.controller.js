sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
   "sap/m/MessageBox",
   "com/khc/batchhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models","com/khc/batchhub/model/formatter"
   ],
   function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models,formatter) {
   var plant;
   var resource;
   var projectName;
   var userName;
   var crdest;
   var crid;
   var orderID;
   var oBatchOEMatPreparation;
   var APLT_GRI_MatPrepList;

   return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatPreparation", {
      formatter: formatter,
      onInit: function() { 
         oBatchOEMatPreparation=this;
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         this._oRouter.getRoute("BatchDispDetail").attachPatternMatched(
               this._oRoutePatternMatched, this);
      },

      _oRoutePatternMatched: function(oEvent) {

         //Hide the messages and set busy to false
         UI_utilities.batchPageOpened(this, "common");

      },

      menuSelected: function(oEvent) {
         // Navigate the the selected menu page
         var sKey = oEvent.getParameters().key;
         UI_utilities.openMenu(this._oRouter, this, sKey);
      },

      onLoadBatchOEMatPreparation: function() {

         plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
         resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
         crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
         projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName; 
         userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;

         this.ClearValues();
         this.buttonDisable();
         this.GetMatPrepList();
         this.SetInstruction();
      },
      buttonDisable: function() {
         var hid_phasestatus= sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
         if (hid_phasestatus == "1") {
            oBatchOEMatPreparation.getView().byId("id_btn_weighing").setEnabled(true)
            oBatchOEMatPreparation.getView().byId("id_btn_pickmat").setEnabled(true)
            oBatchOEMatPreparation.getView().byId("id_btn_extraweigh").setEnabled(true)
            oBatchOEMatPreparation.getView().byId("id_btn_chgbatch").setEnabled(true)
            oBatchOEMatPreparation.getView().byId("id_btn_confirm").setEnabled(true)
         } else {
            oBatchOEMatPreparation.getView().byId("id_btn_weighing").setEnabled(false)
            oBatchOEMatPreparation.getView().byId("id_btn_pickmat").setEnabled(false)
            oBatchOEMatPreparation.getView().byId("id_btn_extraweigh").setEnabled(false)
            oBatchOEMatPreparation.getView().byId("id_btn_chgbatch").setEnabled(false)
            oBatchOEMatPreparation.getView().byId("id_btn_clearcont").setEnabled(false)
            oBatchOEMatPreparation.getView().byId("id_btn_cancel").setEnabled(false)
            oBatchOEMatPreparation.getView().byId("id_btn_confirm").setEnabled(false)
         }
      },
      GetMatPrepList: function() {
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");

         var splitOrdBatch = OrdBatch.split("/");
         var Batch = splitOrdBatch[0];

         APLT_GRI_MatPrepList = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->GetMatPrepList-->XACQ_GetMatPrepListByPhase");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid +
         "&Param.5=" + Batch +"&d="+new Date();

         APLT_GRI_MatPrepList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMatPrepListByPhase&" +
               params + "&Content-Type=text/json", "", false);
         oBatchOEMatPreparation.getView().setModel(APLT_GRI_MatPrepList, "materialListModel")

         var APLT_CMD_GetActionFlag = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->GetMatPrepList-->SQLQ_GetBatchPhaseActionFlag");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest + "&Param.4=" + orderid + "&Param.5=" + phase +
         "&Param.6=" + Batch +"&d="+new Date();

         APLT_CMD_GetActionFlag.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
               "/QueryTemplate/SQLQ_GetBatchPhaseActionFlag&" +
               params + "&Content-Type=text/json", "", false);

         if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetActionFlag.getData()) > 0) {
            var oData = APLT_CMD_GetActionFlag.getData().Rowsets.Rowset[0].Row[0];

            if (oData.ACTIONFLAG == "1") {
               checkActionFlag = "1";
               oBatchOEMatPreparation.getView().byId("id_btn_confirm").setEnabled(false)
            }
         }

      },
      SetInstruction: function() { 
         var selPhase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         //document.getElementById("textframe").src ="BatchPhaseInstructionPopUp.irpt?qs_plant="+plant + '&qs_ordid=' + orderid + '&qs_phase=' + selPhase;

         var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
         /* var oView = oBatchOEMatPreparation.getView();
            var sID = "textframe";
         UI_utilities.setOrderPahseLongText(oView, sID, sLanguage, orderid, plant, selPhase, projectName);*/
         sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder").setPhaseLongText( sLanguage, orderid, plant, selPhase, projectName);


      },
      getContDetails: function() {
         var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
         var oMatPrepListTable = oBatchOEMatPreparation.getView().getModel("materialListModel");
         if (aSelectedRowPath.length > 0) {
            let sPath = aSelectedRowPath[0];
            var container = oMatPrepListTable.getProperty(sPath + '/CONTAINER');
            oBatchOEMatPreparation.getView().byId("txt_containerID").setValue(container);
            oBatchOEMatPreparation.getView().byId("txt_qtyissue").setValue(oMatPrepListTable.getProperty(sPath + '/ActQty'));
         }
      },
      OpenBatchIdent: function() {

         //var js_campaign = parent.document.getElementById("id_hid_ordid").value;
         //var js_campstrip = parent.document.getElementById("txt_OrdNoStrip").value;
         //var js_material = parent.document.getElementById("txt_MatNo").value;
         //var js_matnostrip = parent.document.getElementById("txt_MatNostrip").value;
         //var js_mattext = parent.document.getElementById("txt_GoodDesc").value;

         var js_campaign = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var js_campstrip = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_OrdNoStrip"); //this.getView().byId("").getValue();
         var js_material = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");//txt_MatNo;
         var js_matnostrip =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNostrip");  
         var js_mattext = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_GoodDesc");   
         js_mattext = js_mattext.replace(/%/gi, "%25");

         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");    
         var splitOrdBatch = OrdBatch.split("/");
         var Batch = splitOrdBatch[0];

         var js_reqbatch = ReqBatch;
         var oData = {
               qs_campaign: js_campaign,
               qs_campaignstrip: js_campstrip,
               qs_material: js_material,
               qs_materialstrip:js_matnostrip,
               qs_mattext:js_mattext,
               qs_reqbatch:js_reqbatch,
         };
         var oDestModel = new sap.ui.model.json.JSONModel(oData);
         sap.ui.getCore().setModel(oDestModel, "BatchIdentParams");
         oRouter.navTo("BatchIdentification");

         //parent.window.location.href="BatchIdentification.irpt?qs_campaign="+js_campaign+"&qs_material="+js_material+"&qs_mattext="+js_mattext+"&qs_reqbatch="+js_reqbatch+"&qs_campaignstrip="+js_campstrip+"&qs_materialstrip="+js_matnostrip; 
      },

      //*************** OnClick event of Start Weighing Button - Redirects to BatchMaterialWeighing.irpt page where the Materials can be weighed *******//

      OpenMatWeigh: function() {
         //var js_OrdBatch = parent.document.getElementById("txt_Order").value;
         var js_OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");   


         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var splitOrdBatch = js_OrdBatch.split("/");
         var batch = splitOrdBatch[0];
         var totalrow = CommonUtility.getJsonModelRowCount(oBatchOEMatPreparation.getView().getModel("materialListModel").getData());
         if (totalrow > 0) {
            var flag = 0;
            for (var i = 0; i < totalrow; i++) {
               var objgridObj =oBatchOEMatPreparation.getView().getModel("materialListModel").getData().Rowsets.Rowset[0].Row[i];

               if (objgridObj.STATUS == 1 || objgridObj.STATUS == 0) {
                  flag = 1;
                  break;
               }
            }
         }
         var APLT_CMD_CheckAlternateCount = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->OpenMatWeigh-->SQLQ_CheckAlternateCount");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + batch + "&Param.4=" + orderid +"&d="+new Date();
         APLT_CMD_CheckAlternateCount.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
               "/QueryTemplate/SQLQ_CheckAlternateCount&" +
               params + "&Content-Type=text/json", "", false);

         if (CommonUtility.getJsonModelRowCount(APLT_CMD_CheckAlternateCount.getData()) > 0) {

            var oData = APLT_CMD_CheckAlternateCount.getData().Rowsets.Rowset[0].Row[0];

            var AlternateFlag = oData.COUNT;
            var AltGrp = oData.ALTITEMGRP;
         }     
         if (AlternateFlag == "1" || AlternateFlag == "" || AlternateFlag == null) {
            if (flag == "1") {

               var js_campaign = orderid;
               var js_material = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");//txt_MatNo;
               var js_mattext =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_GoodDesc");    
               //  if (selBatchPhaseList != null) {


               var js_TextKey =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/currentTextKey");
               js_mattext = js_mattext.replace(/%/gi, "%25");
               var js_Phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;

               var currentDT = CommonUtility.getCurrentDateTime(new Date());
               var selprdunit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;;
               var batchsize =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ActBatchSize");//hid_ActBatchSize;
               var status = "1";

               if (js_TextKey == "CWEIGH") {

                  var APLT_CMD_UpdOrdPrdUnitCamp = models.createNewJSONModel(
                  "com.khc.batchhub.controller.BatchExecuteOrder-->OpenMatWeigh-->XACQ_UpdOrdPrdUnitCamp");
                  var params = "Param.1=" + selprdunit + "&Param.2=" + status + "&Param.3=" + plant + "&Param.4=" + resource +
                  "&Param.5=" + orderid +
                  "&Param.6=" + batch + "&Param.7=" + crdest + "&Param.8=" + crid + "&Param.9=" + batchsize +
                  "&Param.10=" + currentDT + "&Param.11=" +
                  js_Phase +"&d="+new Date();
                  APLT_CMD_UpdOrdPrdUnitCamp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_UpdOrdPrdUnitCamp&" +
                        params + "&Content-Type=text/json", "", false);

               }
               //window.location.href = "BatchMaterialWeighing.irpt?qs_campaign=" + js_campaign + "&qs_material=" + js_material + "&qs_mattext=" + js_mattext + "&qs_OrdBatch=" + js_OrdBatch + "&qs_Phase=" + js_Phase + "&qs_TextKey=" + js_TextKey;

               var oData = {
                     qs_campaign:js_campaign,
                     qs_material:js_material,
                     qs_mattext:js_mattext,
                     qs_OrdBatch:js_OrdBatch,
                     qs_Phase:js_Phase,
                     qs_TextKey:js_TextKey,
               };
               var oDestModel = new sap.ui.model.json.JSONModel(oData);
               sap.ui.getCore().setModel(oDestModel, "BatchMaterialWeighingDataModel");
               sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchMaterialWeighing").onLoadBatchMaterialWeighing();
               sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchMaterialWeighing", true);
               sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchOEMatPreparation", false)
            }
            else {
               var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0072");
               MessageBox.error(sAlertMsg);
            }
         } else {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0078");
            MessageBox.error(sAlertMsg);
         }

      },
      PickAltMat: function() {
         var js_OrdBatch =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order"); 
         var splitOrdBatch = js_OrdBatch.split("/");
         var batch = splitOrdBatch[0];

         var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
         var SelRow = aSelectedRowPath.length
         var oMatPrepListTable = APLT_GRI_MatPrepList.getData().Rowsets.Rowset[0].Row[SelRow];
         if (SelRow > 0) {
            let sPath = aSelectedRowPath[0];
            var js_plant = oMatPrepListTable.PLANT;
            var js_resr = oMatPrepListTable.RESR;
            var js_order = oMatPrepListTable.ORDERID;
            var js_opr = oMatPrepListTable.OPR;
            var js_phase = oMatPrepListTable.PHASE;
            var js_bom = oMatPrepListTable.BOM;
            var js_altgrp = oMatPrepListTable.ALTGROUP;

            if (SelRow != "" || js_altgrp != "") {
               var APLT_CMD_UpdOrdPrdUnitCamp = models.createNewJSONModel(
               "com.khc.batchhub.controller.BatchExecuteOrder-->PickAltMat-->SQLQ_DelAltMatFromBOMISSUE");
               var params = "Param.1=" + js_plant + "&Param.2=" + js_resr + "&Param.3=" + js_order + "&Param.4=" + js_opr +
               "&Param.5=" + js_phase +
               "&Param.6=" + batch + "&Param.7=" + js_bom + "&Param.8=" + js_altgrp +"&d="+new Date();
               APLT_CMD_UpdOrdPrdUnitCamp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                     "/QueryTemplate/SQLQ_DelAltMatFromBOMISSUE&" +
                     params + "&Content-Type=text/json", "", false);

               this.GetMatPrepList();
            } else {
               var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0063");
               MessageBox.error(sAlertMsg);
            }
         } else {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0063");
            MessageBox.error(sAlertMsg);
         }




      },
      OpenMatExtraWeigh: function() {
         var js_campaign = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var js_material =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");// txt_MatNo;
         var js_mattext = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_GoodDesc");
         var js_TextKey = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/currentTextKey");
         js_mattext = js_mattext.replace(/%/gi, "%25");
         var js_Phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;

         var js_OrdBatch =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");

         var splitOrdBatch = js_OrdBatch.split("/");
         var batch = splitOrdBatch[0];

         var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
         var SelRow = aSelectedRowPath.length
         var oMatPrepListTable = oBatchOEMatPreparation.getView().getModel("materialListModel");
         if (SelRow > 0) {
            let sPath = aSelectedRowPath[0];

            var js_plant = oMatPrepListTable.getProperty(sPath + '/PLANT');
            var js_bom = oMatPrepListTable.getProperty(sPath + '/BOM');
            var js_bomMod = oMatPrepListTable.getProperty(sPath + '/ModBOM');
            var js_bomText = oMatPrepListTable.getProperty(sPath + '/BOMTEXT');
            var js_bomQty = oMatPrepListTable.getProperty(sPath + '/BOMQTY');
            var js_bomUOM = oMatPrepListTable.getProperty(sPath + '/BOMUOM');
            var js_batchid = oMatPrepListTable.getProperty(sPath + '/BATCHID');
            var js_strgloc = oMatPrepListTable.getProperty(sPath + '/STGELOC');
            var js_opr = oMatPrepListTable.getProperty(sPath + '/OPR');
            var js_itemno = oMatPrepListTable.getProperty(sPath + '/ITEMNO');

            var itemno = "";
            var indexofP = js_itemno.indexOf("P");
            var indexofE = js_itemno.indexOf("E");
            var itemnolength = js_itemno.length;

            if (indexofP != "-1") {
               itemno = js_itemno.substr(0, parseInt(itemnolength) - 2);
            } else if (indexofE != "-1") {
               itemno = js_itemno.substr(0, parseInt(itemnolength) - 2);
            } else {
               itemno = js_itemno;
            }

            var currentDT = CommonUtility.getCurrentDateTime(new Date());
            var selprdunit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;;

            var batchsize =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ActBatchSize");//hid_ActBatchSize;
            var status = "1";

            //window.location.href="BatchMaterialExtraWeigh.irpt?qs_campaign="+js_campaign+"&qs_material="+js_material+"&qs_mattext="+js_mattext+"&qs_OrdBatch="+batch+"&qs_Phase="+js_Phase+"&qs_TextKey="+js_TextKey+"&qs_bom="+js_bom+"&qs_bomMod="+js_bomMod+"&qs_bomText="+js_bomText+"&qs_bomQty="+js_bomQty+"&qs_bomUOM="+js_bomUOM+"&qs_batchid="+js_batchid+"&qs_strgloc="+js_strgloc+"&qs_opr="+js_opr+"&qs_itemno="+itemno;

            var oData = {
                  qs_campaign:js_campaign,
                  qs_material:js_material,
                  qs_mattext:js_mattext,
                  qs_OrdBatch:batch,
                  qs_Phase:js_Phase,
                  qs_TextKey:js_TextKey,
                  qs_bom:js_bom,
                  qs_bomMod:js_bomMod,
                  qs_bomText:js_bomText,
                  qs_bomQty:js_bomQty,
                  qs_bomUOM:js_bomUOM,
                  qs_batchid:js_batchid,
                  qs_strgloc:js_strgloc,
                  qs_opr:js_opr,
                  qs_itemno:itemno,
            };
            var oDestModel = new sap.ui.model.json.JSONModel(oData);
            sap.ui.getCore().setModel(oDestModel, "BatchMaterialExtraWeighDataModel");
            sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchMaterialExtraWeigh").onLoadBatchMaterialExtraWeigh();
            sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchMaterialExtraWeigh", true);
            sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchOEMatPreparation", false);
         } else {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0063");
            MessageBox.error(sAlertMsg);
         }




      },
      OpenBatchIdent: function() {

         var js_campaign = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var js_campstrip =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_OrdNoStrip"); 
         var js_material =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");// txt_MatNo;
         var js_matnostrip =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNostrip");  
         var js_mattext =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_GoodDesc");  
         js_mattext = js_mattext.replace(/%/gi, "%25");

         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");  
         var splitOrdBatch = OrdBatch.split("/");
         var Batch = splitOrdBatch[0];
         var ReqBatch = splitOrdBatch[1];
         var js_reqbatch = ReqBatch;

         var oData = {
               qs_campaign: js_campaign,
               qs_campaignstrip: js_campstrip,
               qs_material: js_material,
               qs_materialstrip: js_matnostrip,
               qs_mattext: js_mattext,
               qs_reqbatch: js_reqbatch, 
         };
         var oDestModel = new sap.ui.model.json.JSONModel(oData);
         sap.ui.getCore().setModel(oDestModel, "BatchIdentParams"); 
         this._oRouter.navTo("BatchIdentification");
         //parent.window.location.href="BatchIdentification.irpt?qs_campaign="+js_campaign+"&qs_material="+js_material+"&qs_mattext="+js_mattext+"&qs_reqbatch="+js_reqbatch+"&qs_campaignstrip="+js_campstrip+"&qs_materialstrip="+js_matnostrip; 
      },

      CheckandInsCont: function() {
         var containNum = oBatchOEMatPreparation.getView().byId("txt_containerID").getValue();
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var OrdBatch =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");  
         var splitOrdBatch = OrdBatch.split("/");
         var Batch = splitOrdBatch[0];
         //var QtyIssued = document.getElementById("txt_qtyissue").value;
         var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
         var oMatPrepListTable = oBatchOEMatPreparation.getView().getModel("materialListModel");
         if (aSelectedRowPath.length > 0) {
            let sPath = aSelectedRowPath[0];
            var QtyIssued = oMatPrepListTable.getProperty(sPath + '/ActQty');
         }
         var SelRow = this.getView().byId("matPrepListTable").getSelectedContextPaths().length;
         if (SelRow != 0) {
            var cSelRow = this.getView().byId("matPrepListTable").getSelectedContextPaths()[0];
            var cSelectedRow = this.getView().getModel("materialListModel").getProperty(cSelRow);
            var BOM = cSelectedRow.BOM;
            if(SelRow != "")
            {
               if(containNum != "" && QtyIssued !="")
               {
                  var APLT_CMD_CheckContainer = models.createNewJSONModel(
                  "com.khc.batchhub.controller.BatchExecuteOrder-->CheckandInsCont-->XACQ_CheckContainer");
                  var params = "Param.1=" + plant + "&Param.2=" + containNum + "&Param.3=" + orderid + "&Param.4=" + Batch +
                  "&Param.5=" + BOM +"&d="+new Date();
                  APLT_CMD_CheckContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CheckContainer&" +
                        params + "&Content-Type=text/json", "", false);

                  if (CommonUtility.getJsonModelRowCount(APLT_CMD_CheckContainer.getData()) > 0) {
                     var oData = APLT_CMD_CheckContainer.getData().Rowsets.Rowset[0].Row[0];
                     var contFlag = oData.O_ContainerData;

                     if(contFlag == 1)
                     {
                        var that = this;
                        var msg = "Container not empty. You want to Clear the Container and Confirm?";
                        MessageBox.confirm(
                              msg, {
                                 icon: MessageBox.Icon.CONFIRM,
                                 title: "Message from webpage",
                                 actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                 onClose: function(oAction) {
                                    if (oAction === "OK") {
                                       this.ConfirmMatPrep('1');
                                    }
                                 }
                              });
                     }           
                     else
                     {
                        this.ConfirmMatPrep('0');
                     }  
                  }
               }
               else
               {
                  var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0110");
                  MessageBox.alert(sAlertMsg);
               }
            }
         }
         else
         {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0102");
            MessageBox.alert(sAlertMsg);
         }

      },

      ConfirmMatPrep: function(ContFlag) {
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var hdrmat = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");//txt_MatNo;
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
         var SelRow = aSelectedRowPath.length
         var oMatPrepListTable = oBatchOEMatPreparation.getView().getModel("materialListModel");
         if (SelRow > 0) {
            let sPath = aSelectedRowPath[0];
            var Opr = oMatPrepListTable.getProperty(sPath + '/OPR');
            var BOM = oMatPrepListTable.getProperty(sPath + '/BOM');
            var BOMBatch = oMatPrepListTable.getProperty(sPath + '/BATCHID');
            var BOMQty = oMatPrepListTable.getProperty(sPath + '/BOMQTY');

            var OrdBatch =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");  
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
            //var QtyIssued = document.getElementById("txt_qtyissue").value;
            var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
            var oMatPrepListTable = oBatchOEMatPreparation.getView().getModel("materialListModel");
            if (aSelectedRowPath.length > 0) {
               let sPath = aSelectedRowPath[0];
               var QtyIssued = oMatPrepListTable.getProperty(sPath + '/ActQty');
            }
            var containNum = oBatchOEMatPreparation.getView().byId("txt_containerID").getValue();
            var Flag = ContFlag;
            var ContText = "";   
            var UOM = oMatPrepListTable.getProperty(sPath + '/BOMUOM');
            var itemNum = oMatPrepListTable.getProperty(sPath + '/ITEMNO');

            var APLT_CMD_ConfirmMatPrep = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->ConfirmMatPrep-->XACQ_ConfirmMaterialPreparation");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + hdrmat +
            "&Param.5=" + phase + "&Param.6=" + Opr + "&Param.7=" + BOM + "&Param.8=" + BOMBatch + "&Param.9=" + BOMQty +
            "&Param.10=" + Batch + "&Param.11=" + QtyIssued + "&Param.12=" + containNum + "&Param.13=" + Flag +
             "&Param.14=" + ContText + "&Param.15=" + crdest + "&Param.16=" + UOM+ "&Param.17=" + itemNum +"&d="+new Date();
               APLT_CMD_ConfirmMatPrep.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                     "/QueryTemplate/XACQ_ConfirmMaterialPreparation&" +
                     params + "&Content-Type=text/json", "", false);

            if (CommonUtility.getJsonModelRowCount(APLT_CMD_ConfirmMatPrep.getData()) > 0) {
               var oData = APLT_CMD_ConfirmMatPrep.getData().Rowsets.Rowset[0].Row[0];
               var oOutput = oData.O_Output;

               if(oOutput == 1)
               {
                  var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0053");
                  MessageBox.alert(sAlertMsg);
                  //APLT_GRI_MatPrepList.refresh();
                  var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
                  var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
                  var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");

                  var splitOrdBatch = OrdBatch.split("/");
                  var Batch = splitOrdBatch[0];

                  var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid +
                  "&Param.5=" + Batch +"&d="+new Date();

                  APLT_GRI_MatPrepList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMatPrepListByPhase&" +
                        params + "&Content-Type=text/json", "", false);
                  oBatchOEMatPreparation.getView().setModel(APLT_GRI_MatPrepList, "materialListModel")

               }

            }
         }
      },

      ClearCont: function() {

         var containNum = oBatchOEMatPreparation.getView().byId("txt_containerID").getValue();
         if (containNum != "") {
            var APLT_CMD_ClearContainer = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->ClearCont-->SQLQ_ClearContainer");
            var params = "Param.1=" + plant + "&Param.2=" + containNum +"&d="+new Date();
            APLT_CMD_ClearContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_ClearContainer&" +
                  params + "&Content-Type=text/json", "", false);

            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0054");
            MessageBox.success(sAlertMsg);
         } else {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0055");
            MessageBox.error(sAlertMsg);
         }
      },
      CancelConfirm: function() {
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
         var SelRow = aSelectedRowPath.length
         var oMatPrepListTable = oBatchOEMatPreparation.getView().getModel("APLT_GRI_MatPrepList");
         if (SelRow > 0) {
            let sPath = aSelectedRowPath[0];
            var bom = oMatPrepListTable.getProperty(sPath + '/BOM');

            //var js_plant = oMatPrepListTable.getProperty(sPath + '/PLANT'); 
            var hdrmat = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_MatNo");//txt_MatNo;
            var OrdBatch =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");  

            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];


            var APLT_CMD_CancelBOMIssue = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->CancelConfirm-->SQLQ_UpdBOMIssueCancel");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + hdrmat +
            "&Param.5=" + phase + "&Param.6=" + Batch + "&Param.6=" + bom +"&d="+new Date();
            APLT_CMD_CancelBOMIssue.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                  "/QueryTemplate/SQLQ_UpdBOMIssueCancel&" +
                  params + "&Content-Type=text/json", "", false);

            var APLT_CMD_CancelContainer = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->CancelConfirm-->SQLQ_UpdContainerCancel");
            var params = "Param.1=" + plant + "&Param.2=" + orderid + "&Param.3=" + Batch + "&Param.4=" + bom +"&d="+new Date();
            APLT_CMD_CancelContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                  "/QueryTemplate/SQLQ_UpdContainerCancel&" +
                  params + "&Content-Type=text/json", "", false);

            this.GetMatPrepList();
         } else {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0004");
            MessageBox.error(sAlertMsg, {
               title: "Error",
            });
         }

      },
      SendConfirm: function() {
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");   
         var splitOrdBatch = OrdBatch.split("/");
         var batch = splitOrdBatch[0];
         var component = "Preparation";
         var aSelectedRowPath = oBatchOEMatPreparation.getView().byId("matPrepListTable").getSelectedContextPaths();
         //var SelRow = aSelectedRowPath.length
         var oMatPrepListTable = oBatchOEMatPreparation.getView().getModel("materialListModel");
         //if (SelRow > 0) {
         let sPath = aSelectedRowPath[0];
         var js_TextKey = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/currentTextKey");


         if (js_TextKey == "WEIGH") {
            var APLT_CMD_CheckMatPrepWeigh = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->SendConfirm-->SQLQ_CheckMatPrepWeigh");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + phase + "&Param.5=" +
            batch +"&d="+new Date();
            APLT_CMD_CheckMatPrepWeigh.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                  "/QueryTemplate/SQLQ_CheckMatPrepWeigh&" +
                  params + "&Content-Type=text/json", "", false);

            if (CommonUtility.getJsonModelRowCount(APLT_CMD_CheckMatPrepWeigh.getData()) > 0) {
               var oData = APLT_CMD_CheckMatPrepWeigh.getData().Rowsets.Rowset[0].Row[0];

               if (oData.COUNT == 0) {
                  var APLT_CMD_ConfirmPrep = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchExecuteOrder-->SendConfirm-->XACQ_ConfirmMatPrep");
                  var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid +
                  "&Param.5=" + component +
                  "&Param.6=" + batch + "&Param.7=" + userName +"&d="+new Date();
                  APLT_CMD_ConfirmPrep.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_ConfirmMatPrep&" +
                        params + "&Content-Type=text/json", "", false);

                  if (CommonUtility.getJsonModelRowCount(APLT_CMD_ConfirmPrep.getData()) > 0) {
                     var oData = APLT_CMD_ConfirmPrep.getData().Rowsets.Rowset[0].Row[0];

                     var type = oData.Type;
                     if (type == "S") {
                        this.PrintLabel();
                        oBatchOEMatPreparation.getView().byId("id_btn_confirm").setEnabled(false)
                        var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0052");
                        this.getView().getModel("oPageMessage").setProperty("/message", sNoShiftMsg);
                        this.getView().getModel("oPageMessage").setProperty("/showMessage", true);
                        this.getView().getModel("oPageMessage").setProperty("/type", "Success");
                        //parent.NextPhaseW();
                        isNextPhaseW=true;
                        //this.NextPhase();
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder").NextPhaseW();
                     }
                  }
               }
            } else {
               var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0056");
               MessageBox.error(sAlertMsg);
            }
         } else if (js_TextKey == "CWEIGH") {
            var APLT_CMD_CheckMatPrepCWeigh = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->SendConfirm-->SQLQ_CheckMatPrepCWeigh");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + phase +"&d="+new Date();
            APLT_CMD_CheckMatPrepCWeigh.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                  "/QueryTemplate/SQLQ_CheckMatPrepCWeigh&" +
                  params + "&Content-Type=text/json", "", false);

            if (CommonUtility.getJsonModelRowCount(APLT_CMD_CheckMatPrepCWeigh.getData()) > 0) {
               var oData = APLT_CMD_CheckMatPrepCWeigh.getData().Rowsets.Rowset[0].Row[0];
               var count = oData.COUNT;

               if (count == 0) {
                  var APLT_CMD_ConfirmPrepCamp = models.createNewJSONModel(
                        "com.khc.batchhub.controller.BatchExecuteOrder-->SendConfirm-->XACQ_ConfirmMatPrepCamp");
                  var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid +
                  "&Param.5=" + component +
                  "&Param.6=" + batch + "&Param.7=" + userName +"&d="+new Date();
                  APLT_CMD_ConfirmPrepCamp.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_ConfirmMatPrepCamp&" +
                        params + "&Content-Type=text/json", "", false);

                  if (CommonUtility.getJsonModelRowCount(APLT_CMD_ConfirmPrepCamp.getData()) > 0) {
                     var oData = APLT_CMD_ConfirmPrepCamp.getData().Rowsets.Rowset[0].Row[0];

                     var type = oData.Type;
                     if (type == "S") {
                        this.PrintLabel();
                        oBatchOEMatPreparation.getView().byId("id_btn_confirm").setEnabled(false)
                        var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0052");
                        this.getView().getModel("oPageMessage").setProperty("/message", sNoShiftMsg);
                        this.getView().getModel("oPageMessage").setProperty("/showMessage", true);
                        this.getView().getModel("oPageMessage").setProperty("/type", "Success");

                        //parent.NextPhaseW();
                        isNextPhaseW=true;
                        sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder").NextPhaseW();
                     }
                  }
               }else {
                  var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0057");
                  MessageBox.error(sAlertMsg);
               } 
            }
         }
         //}
      },

      PrintLabel: function() {
         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_Order; 
         var splitOrdBatch = OrdBatch.split("/");
         var Batch = splitOrdBatch[0];

         var d = new Date(); //       CommonUtility.getCurrentDateTime(new Date());

         var d_day = d.toDateString();
         var d_date = d_day.split(" ");

         if ((d.getDate()) < 10) {
            var day = "0" + (d.getDate());
         } else {
            var day = d.getDate();
         }

         if ((d.getMonth() + 1) < 10) {
            var currentMonth = "0" + (d.getMonth() + 1);
         } else {
            var currentMonth = d.getMonth() + 1;
         }
         if ((d.getHours()) < 10) {
            var currentHours = "0" + (d.getHours());
         } else {
            var currentHours = d.getHours();
         }
         if ((d.getMinutes()) < 10) {
            var currentMinutes = "0" + (d.getMinutes());
         } else {
            var currentMinutes = d.getMinutes();
         }
         if ((d.getSeconds()) < 10) {
            var currentSeconds = "0" + (d.getSeconds());
         } else {
            var currentSeconds = d.getSeconds();
         }
         var currentD = day + "." + currentMonth + "." + d.getFullYear();

         var currentT = d.toTimeString();
         var currentTime_Final = currentT.split(" ");

         var APLT_CMD_LabelPrint = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->PrintLabel-->XACQ_CreateLabelPrint");
         var params = "Param.1=" + "" + "&Param.2=" + "" + "&Param.3=" + "" + "&Param.4=" + "" + "&Param.5=" + currentD +
         "&Param.6=" + currentTime_Final[0] + "&Param.7=" + "" + "&Param.8=" + "" + "&Param.9=" + orderid + "&Param.10=" + plant +
         "&Param.11=" +
         "" +
         "&Param.12=" + resource + "&Param.13=" + "IBC" + "&Param.14=" + splitOrdBatch[0] + "&Param.15=" + splitOrdBatch[1] +
         "&Param.16=" + phase +"&d="+new Date();
         APLT_CMD_LabelPrint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_CreateLabelPrint&" +
               params + "&Content-Type=text/json", "", false);
      },

      ClearValues: function() {

         oBatchOEMatPreparation.getView().byId("txt_containerID").setValue("");
         sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", false);

      }


   });
});
//# sourceURL=https://sapmiigih.mykft.net/XMII/CM/BatchHubUI5/webapp/controller/BatchExecuteOrder/BatchOEMatPreparation.controller.js?eval