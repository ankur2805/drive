sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
   "sap/m/MessageBox",
   "com/khc/batchhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models","com/khc/batchhub/model/formatter"
],
function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models,formatter) {
   var plant;
   var resource;
   var projectName;
   var userName;
   var crdest;
   var crid;
   var orderID;
   var id_hid_verifyflag;
   var oBatckOEMatTipping;
   
   return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatTipping", {
      formatter: formatter,
      onInit: function() {   
         oBatckOEMatTipping=this;
         
         this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
         
      },
      onLoadBatchOEMatTipping: function() {
         plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
            resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
            crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
            projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName; 
         userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
         id_hid_verifyflag = sap.ui.getCore().getModel("session").oData.CA_BatchVerifyFlag;
         this.ClearAllValues();
            this.BatchOEEbuttonDisable();
            this.BatchOEEGetMatIdenList();
            this.BatchOEESetInstruction();
      },
      BatchOEEbuttonDisable: function() {
         if(id_hid_verifyflag =="0")
         {
            var hid_phasestatus= sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
                if (hid_phasestatus == "1") {
                    oBatckOEMatTipping.getView().byId("BatchOEEMatTip_btn_viewinstruct").setEnabled(true)
                    oBatckOEMatTipping.getView().byId("id_btn_tip").setEnabled(true)
               } else {
                    oBatckOEMatTipping.getView().byId("BatchOEEMatTip_btn_viewinstruct").setEnabled(false)
                    oBatckOEMatTipping.getView().byId("id_btn_tip").setEnabled(false)
            }
         }
      },
        BatchOEESetInstruction: function() {
            var selPhase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
            
            var sLanguage = sap.ui.getCore().getModel("session").oData.CA_language;
            //document.getElementById("textframe").src ="BatchPhaseInstructionPopUp.irpt?qs_plant="+plant + '&qs_ordid=' + orderid + '&qs_phase=' + selPhase;
         
            var sLanguage = sap.ui.getCore().getModel("i18n").getProperty("USER_LANGUAGE");
         //   var oView =  oBatckOEMatTipping.getView();
         //  var sID = "BatchOEMatTiptextframe";
         //     UI_utilities.setOrderPahseLongText(oView, sID, sLanguage, orderid, plant, selPhase, projectName);
         sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder").setPhaseLongText( sLanguage, orderid, plant, selPhase, projectName);
         
            
      },
        EnableQty: function() {
            var RowNo = oBatckOEMatTipping.getView().byId("matIdenListTable").getSelectedContextPaths().length;
            if (RowNo != 0) {
                var cRowNo = oBatckOEMatTipping.getView().byId("matIdenListTable").getSelectedContextPaths()[0];
                var cSelectedRowNo = oBatckOEMatTipping.getView().getModel("matTipListModel").getProperty(cRowNo);
                var bomQty = cSelectedRowNo.BOMQTY;
            
                this.getView().byId("txt_DM_Qty").setValue("");
            
                var directIssue = cSelectedRowNo.DIRECTISSUE;
            
                if (directIssue == "Y") {
               
                    oBatckOEMatTipping.getView().byId("txt_DM_Qty").setEnabled(true);
                    //document.getElementById("txt_DM_Qty").setAttribute("className", "pageTextBox") ;
                    oBatckOEMatTipping.getView().byId("txt_DM_Qty").setValue(bomQty);
               } else {
                    //document.getElementById("txt_DM_Qty").setAttribute("className", "pageTextBoxRO") ;
                    oBatckOEMatTipping.getView().byId("txt_DM_Qty").setEnabled(false);
               
            }
            
         }
      },
      
        BatchOEEGetMatIdenList: function() {
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
         
            var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");//this.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
         
            var APLT_GRI_MatIdenList = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->GetMatIdenList-->XACQ_GetMatTipListByPhase");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + orderid + "&Param.5=" + Batch;
            APLT_GRI_MatIdenList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_GetMatTipListByPhase&" +
         params + "&Content-Type=text/json", "", false);
            sap.ui.getCore().setModel(APLT_GRI_MatIdenList, "matTipListModel");
         
         
            if (oBatckOEMatTipping.getView().byId("txt_ContainerInput").getValue() == "") {
                var prdunit = sap.ui.getCore().getModel("BatchExecuteOrderParams").oData.qs_selprdunit;
            
                var APLT_CMD_GetContainer = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->GetMatIdenList-->XACQ_GetConfigContainer");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + prdunit;
                APLT_CMD_GetContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetConfigContainer&" +
            params + "&Content-Type=text/json", "", false);
            
                if (CommonUtility.getJsonModelRowCount(APLT_CMD_GetContainer.getData()) > 0) {
                    var oData = APLT_CMD_GetContainer.getData().Rowsets.Rowset[0].Row[0];
                    var connum = oData.CONNUM;
               
                    if (connum == "---") {
                        oBatckOEMatTipping.getView().byId("txt_ContainerInput").setValue("");
                  } else {
                        oBatckOEMatTipping.getView().byId("txt_ContainerInput").setValue(connum);
               }
            }
         }
           //var gridObj =  document.APLT_GRI_MatIdenList.getGridObject();
         var compflag = 0;
         var count =CommonUtility.getJsonModelRowCount(APLT_GRI_MatIdenList.getData())
         for (var i = 0; i < count; i++) {
            var rowPath ="/Rowsets/Rowset/0/Row/"+i;
            var oMatTipList = APLT_GRI_MatIdenList.getProperty(rowPath);
            if (oMatTipList.TIPFLAG != 1) {
               compflag = 0;
               break;
               } else {
               compflag = 1;
            }
         }
         if (compflag == 1) {
            var APLT_CMD_UpdBatchPhaseActionFLag = models.createNewJSONModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->TipContMat-->SQLQ_UpdBatchPhaseActionFlag");
            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + phase + "&Param.5=" + Batch;
            APLT_CMD_UpdBatchPhaseActionFLag.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
               "/QueryTemplate/SQLQ_UpdBatchPhaseActionFlag&" +
            params + "&Content-Type=text/json", "", false);
         }
      },
        TipContMat: function() {
         
            var operation = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_opr");//hid_opr;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase");//hid_phase;
            var connum = oBatckOEMatTipping.getView().byId("txt_ContainerInput").getValue();
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");//hid_ordid;
         
            var OrdBatch =sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order");
         
            var splitOrdBatch = OrdBatch.split("/");
            var Batch = splitOrdBatch[0];
            var RowNo = oBatckOEMatTipping.getView().byId("matIdenListTable").getSelectedContextPaths().length;
            if (connum == "") {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0047");
            MessageBox.error(sAlertMsg);
            
            } else {
            
                if (RowNo != "0") {
               var cRowNo = oBatckOEMatTipping.getView().byId("matIdenListTable").getSelectedContextPaths()[0];
               var cSelectedRowNo = oBatckOEMatTipping.getView().getModel("matTipListModel").getProperty(cRowNo);
               
               
               var bom = cSelectedRowNo.BOM;
               var bomQty = cSelectedRowNo.BOMQTY;
               var bomUom = cSelectedRowNo.BOMUOM;
               var StorageLoc = cSelectedRowNo.STORAGELOC;
               var itemno = cSelectedRowNo.ITEMNO;
               var component = "Tipping";
               
                    var directIssue = cSelectedRowNo.DIRECTISSUE;
               
                    if (directIssue == "Y") {
                        oBatckOEMatTipping.getView().byId("txt_DM_Qty").setEnabled(false);
                        var dm_qty = oBatckOEMatTipping.getView().byId("txt_DM_Qty").getValue();
                        dm_qty = dm_qty.split(" ").join("");
                  
                        if (dm_qty == "") {
                            var that = this;
                            var msg = "Do you want to use quantity" + " " + bomQty + " " + bomUom;
                            MessageBox.confirm(
                                msg, {
                                    icon: MessageBox.Icon.CONFIRM,
                                    title: "Message from webpage",
                                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                    onClose: function(oAction) {
                                        if (oAction === "OK") {
                                            var APLT_CMD_TipDirectMat = models.createNewJSONModel(
                                                "com.khc.batchhub.controller.BatchExecuteOrder-->TipContMat-->XACQ_TipDirectMaterial"
                                 );
                                            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid +
                                 "&Param.4=" + bom + "&Param.5=" + bomQty +
                                 "&Param.6=" + bomUom +
                                 "&Param.7=" + StorageLoc + "&Param.8=" + operation + "&Param.9=" + phase +
                                 "&Param.10=" + Batch + "&Param.11=" + component +
                                 "&Param.12=" + userName + "&Param.13=" + connum + "&Param.14=" + itemno;
                                            APLT_CMD_TipDirectMat.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                                "/QueryTemplate/XACQ_TipDirectMaterial&" +
                                 params + "&Content-Type=text/json", "", false);
                                            if (CommonUtility.getJsonModelRowCount(APLT_CMD_TipDirectMat.getData()) > 0) {
                                                var oData = APLT_CMD_TipDirectMat.getData().Rowsets.Rowset[0].Row[0];
                                                var type = oData.Type;
                                                if (type == "S") {
                                                    //document.getElementById("id_msg_issue_success").style.display='block';
                                                    var sMatTippMsg = sap.ui.getCore().getModel("i18n").getProperty(
                                       "BATCH_MSG_0046");
                                                    sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                                                    sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                                                    sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
                                       
                                                    that.BatchOEEGetMatIdenList();
                                    }
                                    else if (type == "ES") {
                                       var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0048");
                                       MessageBox.error(sAlertMsg);
                                    }
                                    else {
                                       var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0049");
                                       MessageBox.error(sAlertMsg);
                                    }
                                 }
                              }
                           }
                        });
                        
                        
                        
                        
                        } else {
                        if (isNaN(dm_qty)) {
                           var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0111");
                           MessageBox.error(sAlertMsg);
                           oBatckOEMatTipping.getView().byId("txt_DM_Qty").setEnabled(true);
                           //document.getElementById("txt_DM_Qty").setAttribute("className", "pageTextBox") ;
                           } else if (dm_qty < 0) {
                           var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0118");
                           MessageBox.error(sAlertMsg);
                           oBatckOEMatTipping.getView().byId("txt_DM_Qty").setEnabled(true);
                           //document.getElementById("txt_DM_Qty").setAttribute("className", "pageTextBox") ;
                           } else {
                           //var confirmnewWeight;
                           if(bomQty!=dm_qty){
			var that=this;
                              let msg="Do you want Continue with Changed Quantity"+" "+dm_qty+" "+bomUom;
                              MessageBox.confirm(
                                                                msg, {
                                                                   icon: MessageBox.Icon.CONFIRM,
                                                                 title: "Message from webpage",
                                                               actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                                                           onClose: function(oAction) {
                                                               if (oAction === "OK") {
                                                     // confirmnewWeight=true;
                                                      var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + bom +
                                                      "&Param.5=" + dm_qty +
                                                      "&Param.6=" + bomUom +
                                                      "&Param.7=" + StorageLoc + "&Param.8=" + operation + "&Param.9=" + phase + "&Param.10=" + Batch +
                                                      "&Param.11=" + component +
                                                      "&Param.12=" + userName + "&Param.13=" + connum + "&Param.14=" + itemno;
                                                         that.tipping(params);
                                                     
                                    }
                                    
                                    }
                              });
                           }
                           else if(bomQty==dm_qty)
                           {
                              
                            
                                 var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + bom +
                              "&Param.5=" + bomQty +
                              "&Param.6=" + bomUom +
                              "&Param.7=" + StorageLoc + "&Param.8=" + operation + "&Param.9=" + phase + "&Param.10=" + Batch +
                              "&Param.11=" + component +
                              "&Param.12=" + userName + "&Param.13=" + connum + "&Param.14=" + itemno;
                                 this.tipping(params);
                      
                           }
                        }
                  }
                        oBatckOEMatTipping.getView().byId("txt_DM_Qty").setEnabled(true);
                        //document.getElementById("txt_DM_Qty").setAttribute("className", "pageTextBox") ;
                  
                  } else {
                        var APLT_CMD_ChkContainerByBatch = models.createNewJSONModel(
                  "com.khc.batchhub.controller.BatchExecuteOrder-->TipContMat-->SQLQ_CheckContainerByBatch");
                        var params = "Param.1=" + plant + "&Param.2=" + orderid + "&Param.3=" + Batch + "&Param.4=" + connum;
                        APLT_CMD_ChkContainerByBatch.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/SQLQ_CheckContainerByBatch&" +
                  params + "&Content-Type=text/json", "", false);
                  
                        if (CommonUtility.getJsonModelRowCount(APLT_CMD_ChkContainerByBatch.getData()) != 0) {
                     
                     
                            var APLT_CMD_TipContainerMat = models.createNewJSONModel(
                     "com.khc.batchhub.controller.BatchExecuteOrder-->TipContMat-->XACQ_TipContainerMat");
                            var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + operation +
                     "&Param.5=" + connum +
                     "&Param.6=" + component + "&Param.7=" + userName;
                            APLT_CMD_TipContainerMat.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                                "/QueryTemplate/XACQ_TipContainerMat&" +
                     params + "&Content-Type=text/json", "", false);
                     
                            if (CommonUtility.getJsonModelRowCount(APLT_CMD_TipContainerMat.getData()) > 0) {
                                var oData = APLT_CMD_TipContainerMat.getData().Rowsets.Rowset[0].Row[0];
                                var type = oData.Type;
                                if (type == "S") {
                                    //document.getElementById("id_msg_issue_success").style.display='block';
                                    var sMatTippMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0046");
                                    sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                                    sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                                    sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
                                    this.BatchOEEGetMatIdenList();
                           
                           } else if (type == "ENM") {
                                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0048");
                                    MessageBox.error(sAlertMsg);
                           } else {
                                    var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0049");
                                    MessageBox.error(sAlertMsg);
                        }
                     }
                  }
                  
                  else {
                     var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0050");
                     MessageBox.alert(sAlertMsg);
                  }
               }
               
            }
                
            else {
               var APLT_CMD_ChkContainerByBatch = models.createNewJSONModel(
               "com.khc.batchhub.controller.BatchExecuteOrder-->TipContMat-->SQLQ_CheckContainerByBatch");
               var params = "Param.1=" + plant + "&Param.2=" + orderid + "&Param.3=" + Batch + "&Param.4=" + connum;
               APLT_CMD_ChkContainerByBatch.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                  "/QueryTemplate/SQLQ_CheckContainerByBatch&" +
               params + "&Content-Type=text/json", "", false);
               
               if (CommonUtility.getJsonModelRowCount(APLT_CMD_ChkContainerByBatch.getData()) != 0) {
                  
                  var APLT_CMD_TipContainerMat = models.createNewJSONModel(
                  "com.khc.batchhub.controller.BatchExecuteOrder-->TipContMat-->XACQ_TipContainerMat");
                  var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + phase + "&Param.4=" + operation +
                  "&Param.5=" + connum +
                  "&Param.6=" + component + "&Param.7=" + userName;
                  APLT_CMD_TipContainerMat.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                     "/QueryTemplate/XACQ_TipContainerMat&" +
                  params + "&Content-Type=text/json", "", false);
                  
                  if (CommonUtility.getJsonModelRowCount(APLT_CMD_TipContainerMat.getData()) > 0) {
                     var oData = APLT_CMD_TipContainerMat.getData().Rowsets.Rowset[0].Row[0];
                     var type = oData.Type;
                     if (type == "S") {
                        //document.getElementById("id_msg_issue_success").style.display='block';
                        var sMatTippMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0046");
                        sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
                        sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
                        this.BatchOEEGetMatIdenList();
                        
                        } else if (type == "ENM") {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0051");
                        MessageBox.alert(sAlertMsg);
                        } else {
                        var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0049");
                        MessageBox.error(sAlertMsg);
                     }
                  } 
               }
               else {
                  var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0050");
                  MessageBox.alert(sAlertMsg);
               }
               
            }
         }
         
         
     
         oBatckOEMatTipping.getView().byId("txt_ContainerInput").setValue("");
         oBatckOEMatTipping.getView().byId("txt_DM_Qty").setValue("");
         
      },
/********************************************************************************************************************************************************************************/
tipping:function(params){
   var APLT_CMD_TipDirectMat = models.createNewJSONModel("com.khc.batchhub.controller.BatchExecuteOrder-->TipContMat-->XACQ_TipDirectMaterial");
      APLT_CMD_TipDirectMat.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +"/QueryTemplate/XACQ_TipDirectMaterial&" +params + "&Content-Type=text/json", "", false);
      if (CommonUtility.getJsonModelRowCount(APLT_CMD_TipDirectMat.getData()) > 0) {
         var oData = APLT_CMD_TipDirectMat.getData().Rowsets.Rowset[0].Row[0];
         var type = oData.Type;
          if (type == "S") {
         //document.getElementById("id_msg_issue_success").style.display='block';
             var sMatTippMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0046");
            sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sMatTippMsg);
            sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
            sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
            this.BatchOEEGetMatIdenList();
            } else if (type == "ES") {
            var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0048");
               MessageBox.error(sAlertMsg);
                } else {
                     var sAlertMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0049");
               MessageBox.error(sAlertMsg);
               }
      }

},

/********************************************************************************************************************************************************************************/
      
      ClearAllValues: function() {
         
         sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage",false);
         sap.ui.getCore().getModel("oPhaseLongText").setProperty("/isPhaseLong", false);
         oBatckOEMatTipping.getView().byId("txt_ContainerInput").setValue("");
         oBatckOEMatTipping.getView().byId("txt_DM_Qty").setValue("");
         oBatckOEMatTipping.getView().setModel(null, "matTipListModel");
      }
      
      
      
   });
});
