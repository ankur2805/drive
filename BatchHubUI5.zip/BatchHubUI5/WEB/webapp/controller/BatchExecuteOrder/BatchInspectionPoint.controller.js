sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models", "com/khc/batchhub/model/formatter"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter) {
        var plant;
        var resource;
        var projectName;
        var userName;
        var crdest;
        var crid;
        var orderID;
        var oBatchInspectionPoint;

        var txt_ordstrip;
        var txt_insplot;
        var txt_mattext;


        return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectionPoint", {
            formatter: formatter,
            onInit: function() {
                oBatchInspectionPoint = this;
	 var oInscPointRoute = {
                    qs_phs: '',
                    qs_currenttime: ""
                };
                var oInscPointRouteModel = new sap.ui.model.json.JSONModel(oInscPointRoute);
                sap.ui.getCore().setModel(oInscPointRouteModel, "InspPointRoute")

                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            },

            menuSelected: function(oEvent) {
                // Navigate the the selected menu page
                var sKey = oEvent.getParameters().key;
                UI_utilities.openMenu(this._oRouter, this, sKey);
            },

            onLoadBatchInspectionPoint: function() {

            sap.ui.getCore().getModel("oPageMessage").setProperty("/oPageMessage", false);

                var oEmptyModel = new sap.ui.model.json.JSONModel();
                sap.ui.getCore().setModel(oEmptyModel, "PhasesNextTime");
                sap.ui.getCore().setModel(oEmptyModel, "InspectPointList");

                sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectionPage", true)
                this.getRouterDetails();
                this.getRunningOrder();
                //this.clearValues();
                //this.getOrderList();
                this.buttonDisable();
            },

            getRouterDetails: function() {
                plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
                resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
                projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
                userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
                crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
                txt_shift = sap.ui.getCore().getModel("session").oData.txt_shift;
            },


            getRunningOrder: function() {

                var that = oBatchInspectionPoint;
                // getOrder Details count

                var oModelRuningOrder = models
                    .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningOrder-->XACQ_GetRunningOrderOpenInsp");
                var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest+"&d=" +new Date();
                oModelRuningOrder.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                    "/QueryTemplate/XACQ_GetRunningOrderOpenInsp&" + params + "&Content-Type=text/json", "", false);
                var orderCount;
                var batchOrderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid")

                if (CommonUtility.getJsonModelRowCount(oModelRuningOrder.getData()) > 0) {
                    
                  var oRunningOrderData = oModelRuningOrder.getData().Rowsets.Rowset[0].Row;
                  var RunningOrderRow=0;
                  for(var i=0;i<oRunningOrderData.length;i++){ 
                     if(oRunningOrderData[i].ORDERID==batchOrderid){
                        RunningOrderRow=i;
                     }
                  }
                  
                  
                  
                  
                    var OrerForInsp = oModelRuningOrder.getData().Rowsets.Rowset[0].Row[RunningOrderRow];
                   /* var orderCount = oModelRuningOrder.getData().Rowsets.Rowset[0].Row.length;

                    if (orderCount != 0) {*/
                        var insporder = OrerForInsp.ORDERID;
                        txt_ordstrip = OrerForInsp.MODORDERID;
                        txt_Ord = OrerForInsp.ORDERID;
                        crid = OrerForInsp.CRID
                        txt_Mat = OrerForInsp.MATNR
                        txt_matstrip = OrerForInsp.MODMATNR;
                        txt_mattext = OrerForInsp.MATTEXT;
                        txt_insplot = OrerForInsp.INSPLOT

                        // getOrder Details count

                        var oOrderListModel = models
                            .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningOrder-->XACQ_GetRunningOrder");

                        var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + crdest+"&d=" +new Date();
                        oOrderListModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetRunningOrder&" + params + "&Content-Type=text/json", "", false);


                        var date = CommonUtility.getCurrentDateTime(new Date());

                        // getOrder Details count

                        var oPhasesNextTime = models
                            .createNewJSONModel("com.khc.rephub.controller.quality.InspectionPoint-->getRunningOrder-->XACQ_GetPhaseNextTime");

                        var hid_phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase")

                        var params = "Param.1=" + txt_insplot + "&Param.2=" + insporder + "&Param.3=" + plant + "&Param.4=" + resource +
                            "&Param.5=" + date + "&Param.6=" + crid + "&Param.7=" + hid_phase+"&d=" +new Date();
                        oPhasesNextTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetPhaseNextTime&" + params + "&Content-Type=text/json", "", false);


                        /*  var params = "Param.1=" + txt_insplot + "&Param.2=" + insporder + "&Param.3=" + plant + "&Param.4=" + resource +
                            "&Param.5=" + date + "&Param.6=" + crid;
                        oPhasesNextTime.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetPhaseNextTime_ALL&" + params + "&Content-Type=text/json", "", false);
      */
                        sap.ui.getCore().setModel(oPhasesNextTime, "PhasesNextTime");

                   /* } else {
                        var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0013");
                        sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sNoShiftMsg);
                        sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                        sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Error");
                        that.getView().getModel("InsPointDetails").setProperty("/newInspButton", true)
                        that.getView().getModel("InsPointDetails").setProperty("/updateButton", true)

                    }*/

                } else {
                    var sNoShiftMsg = sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0013");
                    sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sNoShiftMsg);
                    sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                    sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Error");
                    that.getView().getModel("InsPointDetails").setProperty("/newInspButton", false)
                    that.getView().getModel("InsPointDetails").setProperty("/updateButton", false)

                }

            },


            ///********Creation Event-1*************///
            SetFlagForPhasesNextTimep: function() {
                js_FlagPhasesNextTime = 1;
            },
            //**********Creation Event-2*****//////////

            SetFlagForInspectPoint: function() {
                js_FlagInspectPoint = 1;
            },

            ///*****Creation Event-3******//////////

            checkApplet: function() {
                if (js_FlagInspectPoint == 1 && js_FlagPhasesNextTime == 1 && js_FlagOrderList == 1) {
                    this.getRunningOrder();
                } else {
                    setTimeout("this.checkApplet()", 500);
                }
            },

            /////*****Creation Event-4*****/////////

            SetFlagOrderList: function() {
                js_FlagOrderList = 1;
            },
            ///onpage Load Button Disable///////////////
            buttonDisable: function() {
                var hid_phasestatus = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus")
                if (hid_phasestatus == "1") {
                    oBatchInspectionPoint.byId("id_btn_newInspect").setEnabled(true);
                    oBatchInspectionPoint.byId("id_btn_result").setEnabled(true);
                } else if (hid_phasestatus == "2") {
                    oBatchInspectionPoint.byId("id_btn_newInspect").setEnabled(false);
                    oBatchInspectionPoint.byId("id_btn_result").setEnabled(false);
                    oBatchInspectionPoint.byId("id_btn_skipphase").setEnabled(false);
                } else {
                    oBatchInspectionPoint.byId("id_btn_newInspect").setEnabled(false);
                    oBatchInspectionPoint.byId("id_btn_result").setEnabled(false);
                }
            },

            GetInspectPoints: function() {
                var that = oBatchInspectionPoint;
                var SelRow = that.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var QnSelRow = that.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NtSelectedRow = that.getView().getModel("PhasesNextTime").getProperty(QnSelRow);
                    var phase = NtSelectedRow.Phase;
                    // getOrder Details count
                    var InspectPointList = models
                        .createNewJSONModel(
                            "com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectionPoint-->GetInspectPoints-->XACQ_GetInspectionPoints");
                    var insplot = txt_insplot;
                    var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource+"&d=" +new Date();
                    InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                        "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
                        sap.ui.getCore().setModel(InspectPointList, "InspectPointList");
                    if (CommonUtility.getJsonModelRowCount(InspectPointList.getData()) > 0) {
                        InspectPoint = InspectPointList.getData().Rowsets.Rowset[0].Row;


                        // var runningorder = InspectPoint.ORDERID;
                        var rowcount = InspectPointList.getData().Rowsets.Rowset[0].Row.length
                        var complete = 0;
                        // that.getView().byId("APLT_GRI_InspectPoint").setSelectedItem(that.getView().byId("APLT_GRI_InspectPoint").getItems()[rowcount
                        // - 1])
                    }
                }
            },


            // **** Redirect to InspectResultSubmitNewV2 page for
            // selected inspection point and pass required value via
            // query string
            openSPCCharts: function() {
             


                var that = oBatchInspectionPoint;

                var PhasesNTSelRow = oBatchInspectionPoint.byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;
                var InspectPointSelRow = oBatchInspectionPoint.byId("APLT_GRI_InspectPoint").getSelectedContextPaths().length;
                if (InspectPointSelRow != 0) {
                    var IpSelRow = oBatchInspectionPoint.byId("APLT_GRI_InspectPoint").getSelectedContextPaths()[0];
                    var IpSelectedRow = oBatchInspectionPoint.getView().getModel("InspectPointList").getProperty(IpSelRow);
                    var NTSelRow = oBatchInspectionPoint.byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NTSelectedRow = oBatchInspectionPoint.getView().getModel("PhasesNextTime").getProperty(NTSelRow);
                    var InsDateTime = IpSelectedRow.InsDateTime;
                    if (InsDateTime != "" && InsDateTime != null) {
                        var currentDT = CommonUtility.getCurrentDateTime(new Date());
                        var js_date = IpSelectedRow.InsDate;
                        var js_time = IpSelectedRow.InsTime;
                        var js_currenttime = IpSelectedRow.InsDateTime;
                        var js_phs = NTSelectedRow.Phase;
                        var js_phstxt = NTSelectedRow.PhaseText;
                        var js_stdkey = NTSelectedRow.StdKey;
                        // var js_currenttime = NTSelectedRow.Time;
                        // Default CCP Change by Praveen 16.02.2022
                        var js_stdkey = NTSelectedRow.StdKey;
                        var js_mat = txt_Mat;
                        var js_ord = txt_Ord;
                        var js_matdesc = txt_mattext;
                        var js_insplot = txt_insplot;
                        var js_matstrip = txt_matstrip;
                        var js_ordstrip = txt_ordstrip;
                        if (js_stdkey.indexOf("CCP") != "0") {
                            js_stdkey = "---";
                        }
                        var incResSubmitModel = new sap.ui.model.json.JSONModel();
                        let sID = {
                            plant: plant,
                            resource: resource,
                            qs_insplot: js_insplot,
                            qs_mat: js_mat,
                            qs_matdesc: js_matdesc,
                            qs_ord: js_ord,
                            qs_phs: js_phs,
                            qs_date: js_date,
                            qs_time: js_time,
                            qs_currenttime: js_currenttime,
                            qs_matstrip: js_matstrip,
                            qs_ordstrip: js_ordstrip,
                            qs_phstxt: js_phstxt,
                            qs_ccpsign: js_stdkey,

                            // isQualityInspectionView: false



                        }
                        incResSubmitModel.setData(sID)
                        sap.ui.getCore().setModel(incResSubmitModel, "IncResSubmitModel")
                         
                        // ID is Mandatory parameter in the routing, to find

                      /*  this._oRouter.navTo("BatchInspectResultSubmitHACCP", {
                            ID: incResSubmitModel
                        });*/

                sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectionSubmitPage", true)
                sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectionPage", false)
   sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectResultSubmit").routerPatternMatched();
            sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", false);
            
                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0015"));
                    }
                } else {
                    MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0016"));
                }
            },
            getTodayDate: function() {
                var that = oBatchInspectionPoint;
                var SelRow = oBatchInspectionPoint.byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths().length;
                if (SelRow != 0) {
                    var QnSelRow = that.getView().byId("APLT_CMD_GetPhasesNextTime").getSelectedContextPaths()[0];
                    var NtSelectedRow = that.getView().getModel("PhasesNextTime").getProperty(QnSelRow);
                    var phase = NtSelectedRow.Phase;
                    if (phase != "") {
                        var currentDT = CommonUtility.getCurrentDateTime(new Date());
                        var js_insplot = txt_insplot;
                        var AddInspPoint = models
                            .createNewJSONModel(
                                "com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectionPoint-->getTodayDate-->SQLQ_InsInspectPoint");
                        var params = "Param.2=" + "NA" + "&Param.3=" + js_insplot + "&Param.4=" + phase + "&Param.6=" + currentDT +
                            "&Param.10=0&Param.11=" + plant + "&Param.12=" + resource + "&Param.13=" + "0";
                        AddInspPoint.attcheReques
                        AddInspPoint.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_InsInspectPoint&" +
                            params + "&Content-Type=text/json", "", false);
                        // getOrder Details count
                        var InspectPointList = models.createNewJSONModel(
                            "com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectionPoint-->getTodayDate-->XACQ_GetInspectionPoints");
                        var insplot = txt_insplot;
                        var params = "Param.1=" + insplot + "&Param.2=" + phase + "&Param.3=" + plant + "&Param.4=" + resource+"&d=" +new Date();
                        InspectPointList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +
                            "/QueryTemplate/XACQ_GetInspectionPoints&" + params + "&Content-Type=text/json", "", false);
                        sap.ui.getCore().setModel(InspectPointList, "InspectPointList");
                        // document.APLT_GRI_InspectPoint.getGridObject().setSelectedRow(1);
                        oBatchInspectionPoint.byId("APLT_GRI_InspectPoint").setSelectedItem(
                            oBatchInspectionPoint.byId("APLT_GRI_InspectPoint").getItems()[0])
                        this.openSPCCharts();
                    } else {
                        MessageBox.error(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0014"));
                    }
                }
            },



            skipphase: function() {
             /*   function moved to parent controller
		this.start();
                //this.getView().byId("txt_complete").checked=true;
                this.NextPhase();*/
 	sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder").skipphase()
            },


           
            selectSessionPhase : function() {
              var qs_phs = sap.ui.getCore().getModel("InspPointRoute").getProperty("/qs_phs");
              if (qs_phs != "") {

                var ChkCount =CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("PhasesNextTime").getData());
                if (ChkCount > 0) {  
                  for (var i = 0; i < ChkCount; i++) {
                    var oPhaseNetTime = sap.ui.getCore().getModel("PhasesNextTime").getData().Rowsets.Rowset[0].Row;

                    if (oPhaseNetTime[i].Phase == qs_phs) {
                      oBatchInspectionPoint.getView().byId("APLT_CMD_GetPhasesNextTime").setSelectedItem(
                        oBatchInspectionPoint.getView().byId("APLT_CMD_GetPhasesNextTime").getItems()[i]);
                      oBatchInspectionPoint.GetInspectPoints();
                      break;
                    }
                  }

                  var insCount =CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("InspectPointList").getData());
                  if (insCount>0) {

                    var currenttime = sap.ui.getCore().getModel("InspPointRoute").getProperty("/qs_currenttime"); 
                    for (var i = 0; i < insCount; i++) {
                      var insList = sap.ui.getCore().getModel("InspectPointList").getData().Rowsets.Rowset[0].Row;
                      if (insList[i].InsDateTime == currenttime) {
                        var OInsTable = oBatchInspectionPoint.getView().byId("APLT_GRI_InspectPoint");
                        OInsTable.setSelectedItem(OInsTable.getItems()[i]);
                        break;
                      }
                    }
                  }

                }
              }

            }, 

            release: function() {
                this._oRouter.navTo("BatchProdDispatch");
            },


        });
    });