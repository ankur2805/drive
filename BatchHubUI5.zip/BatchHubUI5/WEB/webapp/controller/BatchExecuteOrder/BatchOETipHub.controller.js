sap.ui.define(["sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
   "sap/m/MessageBox",
   "com/khc/batchhub/utils/UI_utilities",
   "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models", "com/khc/batchhub/model/formatter"
],
function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter) {
   var plant;
   var resource;
   var projectName;
   var userName;
   var crdest;
   var crid;
   var orderID;
   var oBatchOETipHub;
   
   return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder.BatchOETipHub", {
      formatter: formatter,
      onInit: function() {
         oBatchOETipHub = this;
         
      },
      
      onLoadBatchOETipHub: function() {
   
            oBatchOETipHub.getView().byId("id_tbl_main_view").setVisible(true); 
            oBatchOETipHub.getView().byId("hideAllValue").setVisible(true)
            oBatchOETipHub.getView().byId("id_div_kit_details").setVisible(false);
            oBatchOETipHub.getView().byId("id_btn_OETipHubBack").setVisible(false);

         plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
         resource = sap.ui.getCore().getModel("session").oData.CA_Resource;
         crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
         projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
         userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
         this.clear();
         this.GetKitTipList();
         
      },
      
      GetKitTipList: function() {
         var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
         var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
         
         var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order"); //this.getView().byId("txt_Order").getValue();
         var splitOrdBatch = OrdBatch.split("/");
         var Batch = splitOrdBatch[0];
         
         var APLT_GRI_KitTipList = models.createNewJSONModel(
         "com.khc.batchhub.controller.BatchExecuteOrder-->GetKitTipList-->XACQ_TH_GetKitMatTipListByPhase");
         var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + orderid + "&Param.4=" + Batch + "&Param.5=" + phase +"&d="+new Date();
         APLT_GRI_KitTipList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_TH_GetKitMatTipListByPhase&" +
         params + "&Content-Type=text/json", "", false);
         sap.ui.getCore().setModel(APLT_GRI_KitTipList, "KitTipListModel");
         
         oBatchOETipHub.getView().byId("id_div_kit_details").setVisible(false);
         this.buttonDisable();
         
      },
      
      buttonDisable: function() {
         var hid_phasestatus= sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phasestatus");
         if (hid_phasestatus == "1") {
            oBatchOETipHub.getView().byId("id_btn_ScanBlendBarCode").setEnabled(true)
            oBatchOETipHub.getView().byId("id_btn_get_kit_detail").setEnabled(true)
            //document.getElementById("id_btn_ScanBlendBarCode").style.color = "black";
            //document.getElementById("id_btn_get_kit_detail").style.color = "black";
            
            /////////////////////////// Added Submit Event for id txt_BlendBarCode in the View  //////////////////////////////////////////////////////////
            
            /* var input = this.getView().byId("txt_BlendBarCode");
               
               // Execute a function when the user releases a key on the keyboard
               input.attachEvent("onkeydown", function(event) {
               // Number 13 is the "Enter" key on the keyboard
               
               if (event.keyCode === 13) {
               // Trigger the button element with a click
               this.ScanBlendBarCode();
               }
               
            }); */
            } else {
            oBatchOETipHub.getView().byId("id_btn_ScanBlendBarCode").setEnabled(false)
            oBatchOETipHub.getView().byId("id_btn_get_kit_detail").setEnabled(false)
            //document.getElementById("id_btn_ScanBlendBarCode").style.color = "grey";
            //document.getElementById("id_btn_get_kit_detail").style.color = "grey";
         }
         
         //if(document.APLT_GRI_KitTipList.getGridObject().getCellValueByName(1, 'KITTIPPED')=='1'){
         if (CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("KitTipListModel").getData()) > 0) {
         var objgridObj = sap.ui.getCore().getModel("KitTipListModel").getData().Rowsets.Rowset[0].Row[0];
         var KitTipFlag= objgridObj.KITTIPPED;
            if (KitTipFlag == '1') {
               oBatchOETipHub.getView().byId("id_btn_ScanBlendBarCode").setEnabled(false)
               oBatchOETipHub.getView().byId("id_btn_get_kit_detail").setEnabled(false)
               //document.getElementById("id_btn_ScanBlendBarCode").style.color = "grey";
               //document.getElementById("id_btn_get_kit_detail").style.color = "grey";
            }
         }
      },
      
      ShowKitDetails: function() {
         var blendBarCode = this.getView().byId("txt_BlendBarCode").getValue();
         if (blendBarCode == "") {
            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0124"));
            } else {
            oBatchOETipHub.getView().byId("id_div_kit_details").setVisible(true);
            oBatchOETipHub.getView().byId("id_tbl_main_view").setVisible(false); 
            //ajaxFunction("/XMII/Runner?Transaction=GBL_BatchHub/BLS/BLS_GetKitMaterialComponentDetails&BlendBarCode="+blendBarCode+"&OutputParameter=O_Return&Con//tent-Type=text/html","id_div_kit_details");
            
            var KitMaterialComponentDetails = models.createNewXMLModel(
            "com.khc.batchhub.controller.BatchExecuteOrder-->ShowKitDetails-->BLS_GetKitMaterialComponentDetails");
            KitMaterialComponentDetails.loadData("/XMII/Runner?Transaction=BatchHubUI5/BLS/BLS_GetKitMaterialComponentDetails&BlendBarCode="+blendBarCode+"&OutputParameter=O_Return&Content-Type=text/xml", "",false);
            sap.ui.getCore().setModel(KitMaterialComponentDetails, "KitTipDetailsModel");
            
            oBatchOETipHub.getView().byId("id_tbl_main_view").setVisible(false); 
            oBatchOETipHub.getView().byId("hideAllValue").setVisible(false)
            oBatchOETipHub.getView().byId("id_div_kit_details").setVisible(true);
            oBatchOETipHub.getView().byId("id_btn_OETipHubBack").setVisible(true);
         }
      },
      
      ScanBlendBarCode: function() {
         //var KitTipFlag = document.APLT_GRI_KitTipList.getGridObject().getCellValueByName(1, 'KITTIPPED');
         if (CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("KitTipListModel").getData()) > 0) {
         var objgridObj = sap.ui.getCore().getModel("KitTipListModel").getData().Rowsets.Rowset[0].Row[0];
         var KitTipFlag= objgridObj.KITTIPPED;
         if(KitTipFlag != 1)
         {
            //var ItemCount = document.APLT_GRI_KitTipList.getGridObject().getRowCount();
            var ItemCount = CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("KitTipListModel").getData());
            if (ItemCount > 0) {
               var rowcount = ItemCount - 1;
            }
            var orderid = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid"); //hid_ordid;
            var phase = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_phase"); //hid_phase;
            var blendbarcode = this.getView().byId("txt_BlendBarCode").getValue();
            var blend = blendbarcode.substr(blendbarcode.indexOf("(93)") + 4, 1);
            var OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/txt_Order"); //this.getView().byId("txt_Order").getValue();
            var splitOrdBatch = OrdBatch.split("/");
            var batch = splitOrdBatch[0];
            
            //var textkey = parent.document.APLT_GRI_BatchPhaseList.getGridObject().getSelectedCellValueByName('TEXTKEY'); 
            var textkey = sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/currentTextKey")

            var js_tippedBlendCheck = 1;
            var js_blendfromBarCodeBLEND = blendbarcode.substr(parseInt(blendbarcode.lastIndexOf(")")) + 1)
            var js_blendfromBarCodeSINGLE = "0" + blendbarcode.substr(parseInt(blendbarcode.lastIndexOf(")")) + 1)
            
            /* var gObj = document.APLT_GRI_KitTipList.getGridObject();
               for(var i=1;i<=gObj.getRowCount();i++)
               {
               if(gObj.getCellValueByName(i,'BLENDID')!="SINGLE"){
               //alert("BLEND"+gObj.getCellValueByName(i,'BLENDID'));
               if(gObj.getCellValueByName(i,'BLENDID')==js_blendfromBarCodeBLEND && gObj.getCellValueByName(i,'BLENDTIPPED')=="1"){
               js_tippedBlendCheck = 0;
               //alert("blend tipblendcheck"+js_tippedBlendCheck);
               }
               }  
               else{
               //alert("SINGLE"+gObj.getCellValueByName(i,'BLENDID'));
               if(gObj.getCellValueByName(i,'ITEMNO')==js_blendfromBarCodeSINGLE && gObj.getCellValueByName(i,'BLENDTIPPED')=="1"){
               js_tippedBlendCheck = 0;
               //alert("single tipblendcheck"+js_tippedBlendCheck);
               }
               
               }
            }*/
            
            var gObj = CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("KitTipListModel").getData());
            if (gObj > 0) {
               for(var i = 1; i < gObj; i++)
               {
                  if (CommonUtility.getJsonModelRowCount(sap.ui.getCore().getModel("KitTipListModel").getData()) > i) {
                  var objgridObj = sap.ui.getCore().getModel("KitTipListModel").getData().Rowsets.Rowset[0].Row[i];
                  if(objgridObj.BLENDID != "SINGLE"){
                     //alert("BLEND"+gObj.getCellValueByName(i,'BLENDID'));
                     
                     if(objgridObj.BLENDID == js_blendfromBarCodeBLEND && objgridObj.BLENDTIPPED == "1"){
                        js_tippedBlendCheck = 0;
                        //alert("blend tipblendcheck"+js_tippedBlendCheck);
                     }
                  }
                  else{
                     //alert("SINGLE"+gObj.getCellValueByName(i,'BLENDID'));
                     if(objgridObj.ITEMNO ==js_blendfromBarCodeSINGLE && objgridObj.BLENDTIPPED == "1"){
                        js_tippedBlendCheck = 0;
                        //alert("single tipblendcheck"+js_tippedBlendCheck);
                     }
                     
                  }
                  }
               }
            }
            if (blendbarcode == "") {
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0124"));
               } else if (js_tippedBlendCheck == "0") {
               MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0130"));
               } else {
               var APLT_CMD_InsertKitTip = models.createNewJSONModel(
               "com.khc.batchhub.controller.BatchExecuteOrder-->ScanBlendBarCode-->XACQ_TH_InsertKitTip");
               var params = "Param.1=" + blendbarcode + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" + orderid + "&Param.5=" +
               phase + "&Param.6=" + userName + "&Param.7=" + batch + "&Param.8=" + rowcount + "&Param.9=" + textkey + "&Param.10=" + blend +"&d="+new Date();
               APLT_CMD_InsertKitTip.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/XACQ_TH_InsertKitTip&" +
               params + "&Content-Type=text/json", "", false);
               
               if (CommonUtility.getJsonModelRowCount(APLT_CMD_InsertKitTip.getData()) > 0) {
                  var oData = APLT_CMD_InsertKitTip.getData().Rowsets.Rowset[0].Row[0];
                  var Type = oData.TYPE;
                  var Message = oData.MESSAGE;
                  
                  if (Type == "S") {
                     //document.getElementById("id_msg_goodsissue_success").innerHTML = Message;
                     //document.getElementById("id_msg_goodsissue_success").style.display = 'block';
                     
                       // MessageBox.success(Message);    ---to be checked later---
                         
                     this.GetKitTipList();
                      KitTipFlag= objgridObj.KITTIPPED;
                     
                     if (KitTipFlag == 1) {
                        oBatchOETipHub.getView().byId("id_btn_ScanBlendBarCode").setEnabled(false)
                        //document.getElementById("id_btn_ScanBlendBarCode").style.color = "grey";
                     }
                  }
                  else {
                  MessageBox.error(Message);
               }
               oBatchOETipHub.getView().byId("txt_BlendBarCode").setValue("");
               }
            }
            } else {
            MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0134"));
         }
      }

this.getView().byId("txt_BlendBarCode").focus();
      },
      
   closeBatchOETipHubPopUp: function() {
            oBatchOETipHub.getView().byId("id_tbl_main_view").setVisible(true); 
            oBatchOETipHub.getView().byId("hideAllValue").setVisible(true)
            oBatchOETipHub.getView().byId("id_div_kit_details").setVisible(false);
            oBatchOETipHub.getView().byId("id_btn_OETipHubBack").setVisible(false);
            },

   clear: function() {

                        sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage",false);
            oBatchOETipHub.getView().byId("txt_BlendBarCode").setValue("");
            oBatchOETipHub.getView().setModel(null, "KitTipListModel");
            
         },
      
   });
});      