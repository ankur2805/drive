var plant;
var resr;
var OrdBatch;
var orderid;
var phase;
var projectName;
var weightype;
var oModelGetMatPrepList;
var oModelGetOrderBatchList;
var SelRow;
var batchListSelRow
var Itemno;
var itemnoFinal;
var oBatchMaterialWeighing;
var ScaleDecimal;
var crdest ;
var dp;
var setBatchRow;
var setMatRow;
var SelMatRow;
var SelBatchRow;	
var continueFlag;

//hidden variables
var hid_PartialFlag;
var hid_PartialDisplayFlag;
var hid_lastcontainer;
var txt_crdest;
var hid_curMatRow;
var hid_firstMatLoad;
var hid_WeighedMat=0;
var hid_curMatRow;
var hid_phase;
var hid_textkey;
var txt_Component;

sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/Button",
	"com/khc/batchhub/utils/UI_utilities",
	"com/khc/common/Script/CommonUtility",
	"com/khc/batchhub/model/formatter",
	"sap/m/MessageBox",
	"com/khc/batchhub/model/models"
	],
	function(Controller,Button,UI_utilities,CommonUtility,formatter,MessageBox,models) {

	"use strict";

	return Controller.extend("com.khc.batchhub.BatchExecuteOrder.BatchMaterialWeighing", {
		formatter:formatter,
		onInit: function() {
			oBatchMaterialWeighing =this;
			//oBatchMaterialWeighing._oRouter = sap.ui.core.UIComponent.getRouterFor(oBatchMaterialWeighing);
			//oBatchMaterialWeighing._oRouter.getRoute("BatchMaterialWeighing").attachPatternMatched(oBatchMaterialWeighing._oRoutePatternMatched, oBatchMaterialWeighing);
		},

		_oRoutePatternMatched: function(oEvent) {
			console.log("pattern match funtion");


			//onloadfunctions
			//oBatchMaterialWeighing.initiate();
			//oBatchMaterialWeighing.setFirstRow();
		},

		onLoadBatchMaterialWeighing: function() {

			//UI_utilities.setContainerBusyState(oBatchMaterialWeighing, false);

			oBatchMaterialWeighing.clearValues();
			plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
			resr = sap.ui.getCore().getModel("session").oData.CA_Resource;
			orderid =  sap.ui.getCore().getModel("BatchExecOrderFragment").getProperty("/hid_ordid");
			phase = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.hid_phase;			
			OrdBatch = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_Order;			
			projectName = sap.ui.getCore().getModel("session").oData.CA_BatchProjectName;
			hid_PartialDisplayFlag = sap.ui.getCore().getModel("session").oData.CA_BHPartialWeigh;
			ScaleDecimal = sap.ui.getCore().getModel("session").oData.CA_ScaleDecimal;
			txt_crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
			crdest = txt_crdest;	
			dp = parseInt(ScaleDecimal);
			SelRow = 0;
			hid_firstMatLoad =0;
			/***
  var oData = {
qs_OrdBatch:"2/2",
qs_Phase:"0210",
qs_TextKey:"WEIGH",
qs_campaign:"000009566548",
qs_material:"000000000051068100",
qs_mattext:"Chevre Et Miel"
}; 
                var oDestModel = new sap.ui.model.json.JSONModel(oData);
                sap.ui.getCore().setModel(oDestModel, "BatchIdentParams"); ***/
			oBatchMaterialWeighing.initiate();
			oBatchMaterialWeighing.GetMatPrepList();
			oBatchMaterialWeighing.GetBatchList();
			oBatchMaterialWeighing.ScaleNameList();
			oBatchMaterialWeighing.ContainerValue();

		},

		//************** get the List of Material to be Wieghed for the Order ********//


		GetMatPrepList: function() {

			OrdBatch= OrdBatch.toString();
			var splitOrdBatch = OrdBatch.split("/");			
			var Batch = splitOrdBatch[0];

			oModelGetMatPrepList = models.createNewXMLModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->GetMatPrepList-->XACQ_GetMatPrepListByPhase");
			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + phase + "&Param.4=" + orderid + "&Param.5=" + Batch+"&d=" +new Date();
			oModelGetMatPrepList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetMatPrepListByPhase&" + params + "&Content-Type=text/xml", "", false);
			sap.ui.getCore().setModel(oModelGetMatPrepList, "GetMatPrepListData");

			oBatchMaterialWeighing.setFirstRow(); // Update event called
			oBatchMaterialWeighing.generatescalebutton();

		},

		GetBatchList: function() {

			var crid = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.hid_crid;	
			hid_phase = sap.ui.getCore().getModel("BatchMaterialWeighingDataModel").oData.qs_Phase;	
			hid_textkey = sap.ui.getCore().getModel("BatchMaterialWeighingDataModel").oData.qs_TextKey;	
			weightype =  hid_textkey;	
			var splitOrdBatch = OrdBatch.split("/");			
			var Batch = splitOrdBatch[0];

			if(weightype=="CWEIGH"){

				oModelGetOrderBatchList = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->GetBatchList-->SQLQ_GetOrderBatchListWeigh");
				var params = "Param.1=" + crid + "&Param.2=" + plant + "&Param.3=" + resr + "&Param.4=" + crdest + "&Param.5=" + orderid + "&Param.6=%"+"&d=" +new Date();
				var url = "/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/SQLQ_GetOrderBatchListWeigh&" + params + "&Content-Type=text/json";
				oModelGetOrderBatchList.loadData(encodeURI(url), "", false);
				sap.ui.getCore().setModel(oModelGetOrderBatchList, "GetOrderBatchListData");

			}
			else if(weightype=="WEIGH"){

				oModelGetOrderBatchList = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->GetBatchList-->SQLQ_GetOrderBatchListWeigh");
				var params = "Param.1=" + crid + "&Param.2=" + plant + "&Param.3=" + resr + "&Param.4=" + crdest + "&Param.5=" + orderid + "&Param.6=" + Batch+"&d=" +new Date();
				oModelGetOrderBatchList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/SQLQ_GetOrderBatchListWeigh&" + params + "&Content-Type=text/json", "", false);
				sap.ui.getCore().setModel(oModelGetOrderBatchList, "GetOrderBatchListData");
			}

			oBatchMaterialWeighing.setFirstBatchRow(); // Update event called
		},

		generatescalebutton: function() {

			var produnit;
			var oModelGenerateScaleButton = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->generatescalebutton-->XACQ_GenerateScaleButton");
			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + produnit+"&d=" +new Date();
			oModelGenerateScaleButton.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GenerateScaleButton&" + params + "&Content-Type=text/json", "", false);

			//Assign button result to a div
		},

		//********** Get the List of Material by Batch for the Order **************//

		GetMatPrepListByBatch: function(batch) {

			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + phase + "&Param.4=" + orderid + "&Param.5=" + batch+"&d=" +new Date();
			oModelGetMatPrepList.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetMatPrepListByPhase&" + params + "&Content-Type=text/xml", "", false);
			sap.ui.getCore().setModel(oModelGetMatPrepList, "GetMatPrepListData");

			//oBatchMaterialWeighing.setFirstRow(); // Update event called
		},

		//************** Get the Conatiner Details for the Materials ******************//

		getContDetails: function() {

			//SelRow = 0;

			if (CommonUtility.getXmlModelRowCount(oModelGetMatPrepList.getData()) > 0) {
				var oData = oModelGetMatPrepList.getObject("/Rowset/Row/"+SelRow);

				if(SelRow!=0){
					var oDataprev = oModelGetMatPrepList.getObject("/Rowset/Row/"+(SelRow-1));


					oBatchMaterialWeighing.getView().byId("txt_Container").setValue($(oDataprev).find("CONTAINER").text() );
				}
				else {
					oBatchMaterialWeighing.getView().byId("txt_Container").setValue($(oData).find("CONTAINER").text() );
				}
				if($(oData).find("ActQty").text() == 0){
					oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setValue("");
				}
				else {
					oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setValue(parseFloat($(oData).find("ActQty").text()).toFixed(dp));
				}

				oBatchMaterialWeighing.getView().byId("txt_Seq").setValue(SelRow+1);
				txt_Component= $(oData).find("BOM").text();
				oBatchMaterialWeighing.getView().byId("txt_CompDesc").setValue($(oData).find("BOMTEXT").text());
				oBatchMaterialWeighing.getView().byId("txt_TargetWeight").setValue(parseFloat($(oData).find("BOMQTY").text()).toFixed(dp));
				oBatchMaterialWeighing.getView().byId("txt_GridUOM").setValue($(oData).find("BOMUOM").text());
				oBatchMaterialWeighing.getView().byId("txt_Batch").setValue($(oData).find("BATCHID").text());
				oBatchMaterialWeighing.getView().byId("txt_Componentstrip").setValue($(oData).find("ModBOM").text());
				hid_WeighedMat= $(oData).find("STATUS").text();

			}
			if(oBatchMaterialWeighing.getView().byId("txt_Container").getValue() == ""){

				var prdunit = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_punit;	

				var oModelGetConfigContainer = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->getContDetails-->XACQ_GetConfigContainer");
				var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + prdunit+"&d=" +new Date();
				oModelGetConfigContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetConfigContainer&" + params + "&Content-Type=text/json", "", false);

				oBatchMaterialWeighing.getView().byId("txt_Container").setValue(oModelGetConfigContainer.getData().Rowsets.Rowset[0].Row[0].CONNUM);	

			}

			oBatchMaterialWeighing.setUpperandLowerLimit();
		},

		/********************************** Set Upper and Lower limit Code Added by Vaibhav for Seclin Plant***************/

		setUpperandLowerLimit: function() {

			var TrgtWeight = oBatchMaterialWeighing.getView().byId("txt_TargetWeight").getValue();
			var TarWeight = TrgtWeight.replace("," , ".");
			var FormatTrgrtWgt = parseFloat(TarWeight);

			var LowTolerance = parseFloat(FormatTrgrtWgt) - parseFloat(FormatTrgrtWgt)*0.01;
			var UpTolerance = parseFloat(FormatTrgrtWgt) + parseFloat(FormatTrgrtWgt)*0.01;

			oBatchMaterialWeighing.getView().byId("id_display_UpTrgtWgt").setValue(UpTolerance.toFixed(dp));
			oBatchMaterialWeighing.getView().byId("id_display_LowTrgtWgt").setValue(LowTolerance.toFixed(dp));

		},

		//****************** Insert the Qty of the Material Weighed alongiwht the conatiner entered ****************//

		CheckandInsCont: function(){

			return new Promise(function(myResolve, myReject) {
				var containNum = oBatchMaterialWeighing.getView().byId("txt_Container").getValue();
				var Batch = oModelGetOrderBatchList.getData().Rowsets.Rowset[0].Row[batchListSelRow].BATCH; //batchrow
				var BOM = $(oModelGetMatPrepList.getObject("/Rowset/Row/"+SelRow)).find("BOM").text();
				var ItemCount = $(oModelGetMatPrepList.getData()).find("Row").length;

				var QtyIssued = oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getValue();
				var TargetWeigh = oBatchMaterialWeighing.getView().byId("txt_TargetWeight").getValue();
				//	 let myPromise = new Promise(function(myResolve, myReject) {
				if(SelRow != null) {

					var QtyIssuedUL = parseFloat(TargetWeigh) + 0.5*parseFloat(TargetWeigh);
					var QtyIssuedLL = parseFloat(TargetWeigh) - 0.5*parseFloat(TargetWeigh);
					var ToleranceFlag=0;

					if(hid_PartialFlag == 1) {

						if(QtyIssued < parseFloat(TargetWeigh))
						{
							ToleranceFlag=1;
						}
						else{
							ToleranceFlag=0;
						}	

					}
					else {

						var UpperTrgtWeight= oBatchMaterialWeighing.getView().byId("id_display_UpTrgtWgt").getValue();
						var LowerTrgtWeight= oBatchMaterialWeighing.getView().byId("id_display_LowTrgtWgt").getValue();

						if(QtyIssued >= LowerTrgtWeight && QtyIssued <= UpperTrgtWeight)
						{
							ToleranceFlag=1;
						}
						else{
							ToleranceFlag=0;
						}
					}

					var BatchIDFlag=0;
					var BOMBatch = $(oModelGetMatPrepList.getObject("/Rowset/Row/"+SelRow)).find("BATCHID").text();

					if(BOMBatch==""){
						BatchIDFlag=0;
					}
					else if(BOMBatch=="---"){
						BatchIDFlag=0;
					}
					else{
						BatchIDFlag=1;
					}

					if(BatchIDFlag==1)
					{
						if(ToleranceFlag==1)
						{
							if(containNum != "" && QtyIssued !="" && containNum != "---")
							{
								var oModelCheckContainer = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->CheckandInsCont-->XACQ_CheckContainer");
								var params = "Param.1=" + plant + "&Param.2=" + containNum + "&Param.3=" + orderid + "&Param.4=" + Batch + "&Param.5=" + BOM+"&d=" +new Date();
								oModelCheckContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_CheckContainer&" + params + "&Content-Type=text/json", "", false);

								if (CommonUtility.getJsonModelRowCount(oModelCheckContainer.getData()) > 0) {

									var contFlag = oModelCheckContainer.getData().Rowsets.Rowset[0].Row[0].O_ContainerData;

									if(contFlag == 1)
									{

										var msg = "Container not empty. You want to Clear the Container and Confirm?";
										var that = oBatchMaterialWeighing;
										MessageBox.confirm(
												msg, {
													icon: MessageBox.Icon.INFORMATION,
													title: "Message from webpage",
													actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
													onClose: function(oAction) { 
														if(oAction==="OK"){
															that.ConfirmMatPrep('1');
															myResolve("1");
														}
														else {
															myResolve("0");
														}
													}
												});	

									}
									else {

										oBatchMaterialWeighing.ConfirmMatPrep('0');
										myResolve("1");

									}
								}
							}
							else
							{
								MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0062"));							
								myResolve("0");
							}
						}
						else
						{
							MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0074"));	
							myResolve("0");
						}
					}
					else
					{
						MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0108"));	
						myResolve("0");
					} 
				}
				else
				{
					MessageBox.alert(sap.ui.getCore().getModel("i18n").getProperty("BATCH_MSG_0063"));	
					myResolve("0");
				}
			});
		},

		ConfirmMatPrep: function(ContFlag) {

			var hdrmat = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_MatNo;

			if (CommonUtility.getXmlModelRowCount(oModelGetMatPrepList.getData()) > 0) {
				var oData = oModelGetMatPrepList.getObject("/Rowset/Row/"+SelRow);

				var Opr = $(oData).find("OPR").text();
				var BOM = $(oData).find("BOM").text();
				var BOMBatch = $(oData).find("BATCHID").text();
				var BOMQty = $(oData).find("BOMQTY").text();
				Itemno = $(oData).find("ITEMNO").text();
				var stgloc = $(oData).find("STGELOC").text();
				var UOM = $(oData).find("BOMUOM").text();
			}

			var Batch = oModelGetOrderBatchList.getData().Rowsets.Rowset[0].Row[batchListSelRow].BATCH; //batchrow
			var QtyIssued = oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getValue();
			var TargetWeigh = oBatchMaterialWeighing.getView().byId("txt_TargetWeight").getValue();
			var containNum = oBatchMaterialWeighing.getView().byId("txt_Container").getValue();
			hid_lastcontainer = containNum;
			var Flag = ContFlag;
			var ContText = "";	


			var oModelConfirmMaterialPreparation = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->ConfirmMatPrep-->XACQ_ConfirmMaterialPreparation");
			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + orderid + "&Param.4=" + hdrmat + "&Param.5=" + phase
			+ "&Param.6=" + Opr+ "&Param.7=" + BOM+ "&Param.8=" + BOMBatch+ "&Param.9=" + BOMQty+ "&Param.10=" + Batch+ "&Param.11=" + QtyIssued
			+ "&Param.12=" + containNum+ "&Param.13=" + Flag+ "&Param.14=" + ContText+ "&Param.15=" + crdest+ "&Param.16=" + UOM
			+ "&Param.17=" + Itemno+"&d=" +new Date();
			oModelConfirmMaterialPreparation.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_ConfirmMaterialPreparation&" + params + "&Content-Type=text/json", "", false);

			//if(oModelConfirmMaterialPreparation.getData().Rowsets.Rowset[0].Row[0].O_Output == 1)

			if(hid_PartialFlag == 1){

				itemnoFinal="";
				var indexofP = Itemno.indexOf("P");
				var indexofE = Itemno.indexOf("E");
				var itemnolength = Itemno.length;

				if(indexofP!="-1"){
					itemnoFinal=Itemno.substr(0,parseInt(itemnolength)-2);
				}
				else if(indexofE!="-1"){
					itemnoFinal=Itemno.substr(0,parseInt(itemnolength)-2);
				}
				else{
					itemnoFinal=Itemno;
				}

				var oModelConfirmMaterialPartial = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->ConfirmMatPrep-->XACQ_ConfirmMaterialPartial");
				var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + orderid + "&Param.4=" + hdrmat + "&Param.5=" + phase
				+ "&Param.6=" + Opr+ "&Param.7=" + BOM+ "&Param.8=" + BOMBatch+ "&Param.9=" + BOMQty+ "&Param.10=" + Batch+ "&Param.11=" + stgloc
				+ "&Param.12=" + UOM+ "&Param.13=" + txt_crdest+ "&Param.14=" + itemnoFinal+ "&Param.15=" + QtyIssued+"&d=" +new Date();
				oModelConfirmMaterialPartial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_ConfirmMaterialPartial&" + params + "&Content-Type=text/json", "", false);

			}
			oBatchMaterialWeighing.getView().byId("id_chk_partial").setSelected(false);
		},

		setFirstRow: function(){

			var selectedRow = 0;
			var currRow  = 0;

			if(hid_firstMatLoad == 0){
				var count =$(oModelGetMatPrepList.getData()).find("Row").length;
				for(var i=0;i<count;i++)
				{
					if($(oModelGetMatPrepList.getObject("/Rowset/Row/"+i)).find("STATUS").text() =="0")
					{
						selectedRow = i;
						SelRow = selectedRow;
						//oBatchMaterialWeighing.getContDetails();   //Selection event called
						break;		
					}
				}
				if(selectedRow ==0)
				{
					for(var j=0;j<count;j++)
					{
						if($(oModelGetMatPrepList.getObject("/Rowset/Row/"+j)).find("STATUS").text() =="1")
						{
							selectedRow = j;
							SelRow = selectedRow;
							//oBatchMaterialWeighing.getContDetails();   //Selection event called
							// weighing complete for all mat
							oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setEnabled(false);
							oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setEnabled(true);
							oBatchMaterialWeighing.getView().byId("id_btn_ReadScale").setEnabled(false);
							break;		
						}
					}
				}
			}
			oBatchMaterialWeighing.getContDetails();
		},

		//NextOrder(), setnextorder(), NextRow() and setnextrow() not used anywhere


		//****************** Redirects to the Material Preparation Page ****************//

		GetBack: function()
		{
			//window.history.back(-1);
			sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchMaterialWeighing", false);
			sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchOEMatPreparation").GetMatPrepList();
			sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/BatchOEMatPreparation", true);

		},

		setFirstBatchRow: function()
		{
			//var gridObj = document.APLT_GRI_BatchList.getGridObject();
			//gridObj.setSelectedRow(1);
			batchListSelRow = 0;
			oBatchMaterialWeighing.BatchSelection();   //Selection event called
		},

		NextComponent: function(){

			continueFlag="1";

			if (oBatchMaterialWeighing.getView().byId("id_chk_partial").getSelected()) {

				hid_PartialFlag = 1;

				var msg = "Partial Weigh is selected which will activate Batch spliting mode. Continue?";
				var that = oBatchMaterialWeighing;
				MessageBox.confirm(
						msg, {
							icon: MessageBox.Icon.INFORMATION,
							title: "Message from webpage",
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							onClose: function(oAction) { 
								if(oAction==="OK"){
									continueFlag = "1";
									oBatchMaterialWeighing.ConfirmPartial();
								}
								else {
									continueFlag = "0";
									//that.getView().byId("id_btn_NextIngr").setType("Default")
									//that.getView().byId("id_btn_ReadScale").setType("Emphasized")
									//that.getView().byId("id_btn_NextIngr").setEnabled(false)
								}
							}
						});	
			}
			else {

				hid_PartialFlag = 0;

			}

			if(continueFlag=="1" &  hid_PartialFlag=="0"){

				var totalBatchRow= oModelGetOrderBatchList.getData().Rowsets.Rowset[0].Row.length;
				var totalMatRow= $(oModelGetMatPrepList.getData()).find("Row").length;

				SelMatRow = SelRow;
				SelBatchRow = batchListSelRow;
				hid_firstMatLoad = 1;
				hid_curMatRow = SelMatRow;
				setBatchRow=0;
				setMatRow=0;
				var weighedMat = hid_WeighedMat;

				if(SelMatRow<(totalMatRow-1))
				{
					if(SelBatchRow<(totalBatchRow-1))
					{
						if(weighedMat=="0")
						{
							var retChk;
							oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

								retChk=sResult;
								oBatchMaterialWeighing.method2(retChk);
							});
						}
						else
						{
							var retChk =  1;
						}

						if(retChk==1)
						{	
							setBatchRow = parseInt(SelBatchRow)+1;
							batchListSelRow = setBatchRow;
							oBatchMaterialWeighing.BatchSelection();
						}				
					}
					else
					{	//alert(weighedMat);
						if(weighedMat=="0")
						{
							var retChk;
							oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

								retChk=sResult;
								oBatchMaterialWeighing.method3(retChk);
							});
						}
						else
						{
							var retChk =  1;
						}
						//alert(retChk);
						if(retChk==1)
						{				
							setBatchRow = 0;	
							oBatchMaterialWeighing.PrintLabel();			
							setMatRow = parseInt(SelMatRow)+1;
							hid_curMatRow=setMatRow;
							batchListSelRow=setBatchRow;	
							oBatchMaterialWeighing.BatchSelection();
							SelRow=setMatRow;
							//oBatchMaterialWeighing.getContDetails();   //Selection event called
						}
					}
				}
				else if(SelMatRow==(totalMatRow-1))
				{
					if(SelBatchRow<(totalBatchRow-1))
					{
						if(weighedMat=="0")
						{
							var retChk;
							oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

								retChk=sResult;
								oBatchMaterialWeighing.method2(retChk);
							});
						}
						else
						{
							var retChk =  1;
						}

						if(retChk==1)
						{
							setBatchRow = parseInt(SelBatchRow)+1;
							batchListSelRow=setBatchRow;	
							oBatchMaterialWeighing.BatchSelection();
						}
					}
					else
					{
						if(weighedMat=="0")
						{	var retChk;
						oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

							retChk=sResult;
							oBatchMaterialWeighing.method1(retChk);
						});
						}
						else
						{
							var retChk =  1;
						}

						if(retChk==1)
						{
							oBatchMaterialWeighing.PrintLabel();
							oBatchMaterialWeighing.GetBack();
						}
					}
				}
				else
				{
					oBatchMaterialWeighing.GetBack();
				}

			}
			//hid_PartialFlag ="";

		},

		BatchSelection: function() {


			var selBatch = oModelGetOrderBatchList.getData().Rowsets.Rowset[0].Row[batchListSelRow].BATCH;
			oBatchMaterialWeighing.getView().byId("txt_Order").setValue(selBatch);

			if(hid_firstMatLoad =="1") {

				oBatchMaterialWeighing.GetMatPrepListByBatch(selBatch);
				var selrow = hid_curMatRow;
				SelRow = parseInt(hid_curMatRow);
				//oBatchMaterialWeighing.getContDetails();   //Selection event called

				if($(oModelGetMatPrepList.getObject("/Rowset/Row/"+SelRow)).find("STATUS").text()  =="0") {

					hid_WeighedMat="0";
					oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setEnabled(true); 
					oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").focus(); 
					oBatchMaterialWeighing.getView().byId("txt_Container").setValue(oBatchMaterialWeighing.getPrevConnNum());
					oBatchMaterialWeighing.getView().byId("txt_Container").setEnabled(true); 	
					oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setEnabled(false);
					//document.getElementById('id_btn_ReadScale').style.backgroundColor = "";
					//document.getElementById('txt_ScaleWgt').style.backgroundColor = "";
					//document.getElementById('id_btn_NextIngr').style.backgroundColor = "";	

				}
				else {

					hid_WeighedMat="1";
					oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setEnabled(false); 
					oBatchMaterialWeighing.getView().byId("txt_Container").setEnabled(false);
					oBatchMaterialWeighing.getContDetails(); // to traverse through weighed components
				}

			}
		},

		getPrevConnNum: function() {

			var blankreturn;

			if (CommonUtility.getJsonModelRowCount(oModelGetOrderBatchList.getData()) > 0) {
				var orderid = oModelGetOrderBatchList.getData().Rowsets.Rowset[0].Row[batchListSelRow].ORDERID;
				var batch = oModelGetOrderBatchList.getData().Rowsets.Rowset[0].Row[batchListSelRow].BATCH;
			}

			var oModelGetContainerByBatchWeigh = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->getPrevConnNum-->SQLQ_GetContainerByBatchWeigh");
			var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + orderid + "&Param.4=" + batch+"&d=" +new Date();
			oModelGetContainerByBatchWeigh.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/SQLQ_GetContainerByBatchWeigh&" + params + "&Content-Type=text/json", "", false);

			if (CommonUtility.getJsonModelRowCount(oModelGetContainerByBatchWeigh.getData()) != 0) {
				blankreturn= oModelGetContainerByBatchWeigh.getData().Rowsets.Rowset[0].Row[0].CONNUM;
			}
			else{
				blankreturn = "";
			}
			return blankreturn;

		},

		initiate: function()
		{
			oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").focus();

			oBatchMaterialWeighing.CheckPartialWeigh();
		},

		searchKeyPress: function() {

			if(oBatchMaterialWeighing.getVieW().byId("id_btn_NextIngr").getEnabled()) {

				oBatchMaterialWeighing.NextComponent();
			}

		},

		CheckPartialWeigh: function() {

			if(hid_PartialDisplayFlag == 1){

				oBatchMaterialWeighing.getView().byId("id_div_CheckBox").setVisible(true);
			}
		},

		ReadWeight: function() {

			var Scale = oBatchMaterialWeighing.getView().byId("id_ScaleList").getSelectedKey();
			var O_Weight;

			var UpperTrgtWeight= oBatchMaterialWeighing.getView().byId("id_display_UpTrgtWgt").getValue();
			var LowerTrgtWeight= oBatchMaterialWeighing.getView().byId("id_display_LowTrgtWgt").getValue();
			var partialFlag ;

			if(oBatchMaterialWeighing.getView().byId("id_chk_partial").getSelected()){
				partialFlag = 1;
			}
			else {
				partialFlag = 0;
			}

			/***** 			---NOT BEING USED---
			var DestID = "";

			if (plant == "3278")
			{
				DestID = "MT_SCALES_ELST";
			}
			else if (plant == "3005")
			{
				DestID = "SCALES_KG";
			}
			else if (plant == "3414")
			{
				DestID = "SCALES_LL";
			}
			else if (plant == "3309")
			{
				DestID = "SCALES_PU";
			}
			 *****/
			if(oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getValue() == ""){

				var oModelCheckWeighingWebSocket = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->ReadWeight-->XACQ_CheckWeighingWebSocketConnectin");
				//var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + orderid + "&Param.4=" + batch+"&d=" +new Date();
				oModelCheckWeighingWebSocket.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_CheckWeighingWebSocketConnectin&Content-Type=text/json", "", false);
if (CommonUtility.getJsonModelRowCount(oModelCheckWeighingWebSocket.getData()) > 0) {
				var PCoConnectionFlag = parseInt(oModelCheckWeighingWebSocket.getData().Rowsets.Rowset[0].Row[0].WebSocketFlag);
				if(PCoConnectionFlag == 1)
				{
					var oModelGetWeighScaleReadingFromPCo = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->ReadWeight-->XACQ_GetWeighScaleReadingFromPCo");
					var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + Scale+"&d=" +new Date();
					oModelGetWeighScaleReadingFromPCo.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetWeighScaleReadingFromPCo&"+ params +"&Content-Type=text/json", "", false);

					O_Weight = oModelGetWeighScaleReadingFromPCo.getData().Rowsets.Rowset[0].Row[0].Value;

					oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setValue(parseFloat(O_Weight).toFixed(dp));

				}
				else {

					var oModelReadWeight = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->ReadWeight-->XACQ_ReadWeight");
					var params = "Param.1=" + plant + "&Param.2=" + Scale+"&d=" +new Date();
					oModelReadWeight.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_ReadWeight&"+ params +"&Content-Type=text/json", "", false);

					O_Weight = oModelReadWeight.getData().Rowsets.Rowset[0].Row[0].O_Weight;
					oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setValue(parseFloat(O_Weight).toFixed(dp));

				}
				}
			}

			var TrgtWeight = oBatchMaterialWeighing.getView().byId("txt_TargetWeight").getValue();
			var FormatTrgrtWgt = parseFloat(TrgtWeight);
			var SclWeight = oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getValue();

			if (Number(SclWeight )>=Number( LowerTrgtWeight )&&Number(SclWeight) <= Number(UpperTrgtWeight) && !partialFlag)
			{
				oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
				oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setType("Emphasized");	
				oBatchMaterialWeighing.getView().byId("id_btn_ReadScale").setType("Default");
				oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setEnabled(true);

			}
			else if (partialFlag && SclWeight < FormatTrgrtWgt && SclWeight > 0)
			{
				oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("positive");
				oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setType("Emphasized");	
				oBatchMaterialWeighing.getView().byId("id_btn_ReadScale").setType("Default");
				oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setEnabled(true);

			}
			else{

				oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("negative");
				oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setType("Default");	
				oBatchMaterialWeighing.getView().byId("id_btn_ReadScale").setType("Emphasized");
				oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setEnabled(false);

			}

		},

		PrintLabel: function() {

			var splitOrdBatch = OrdBatch.split("/");			
			var Batch = splitOrdBatch[0];

			var oModelGetBatchByOrderMaterial = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->PrintLabel-->SQLQ_GetBatchByOrderMaterial");
			var params = "Param.1=" + oBatchMaterialWeighing.getView().byId("txt_Batch").getValue() + "&Param.2=" + txt_Component + "&Param.3=" + orderid+"&d=" +new Date();
			oModelGetBatchByOrderMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/SQLQ_GetBatchByOrderMaterial&"+ params +"&Content-Type=text/json", "", false);

			if (CommonUtility.getJsonModelRowCount(oModelGetBatchByOrderMaterial.getData()) != 0) {
				var expiry = oModelGetBatchByOrderMaterial.getData().Rowsets.Rowset[0].Row[0].EXPIRYDATE;
				var expiry = expiry.split(" ");
				var expiry_final = expiry[0].split("/");

				var dt =  new Date();
				//var d_day = d.toDateString(); 
				//var d_date = d_day.split(" ");

				if(dt.getDate() < 10) {
					var day = "0"+dt.getDate();
				}
				else{
					var day=dt.getDate();
				}

				if(dt.getMonth()+1 < 10) {
					var month = "0"+eval(dt.getMonth()+1);
				}
				else{
					var month=eval(dt.getMonth()+1);
				}	

				var currentD = day + "." + month + "." + dt.getFullYear();	
				var currentT = dt.toTimeString();
				var currentTime_Final = currentT.split(" ");
				var cont = oBatchMaterialWeighing.getView().byId("txt_Container").getValue();
				var oModelPrintLabel = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->PrintLabel-->XACQ_CreateLabelPrint");

				var params = "Param.1=" + oBatchMaterialWeighing.getView().byId("txt_Batch").getValue() + "&Param.2=" + cont + "&Param.3=" 
				+ expiry_final[1] + "." + expiry_final[0] + "." + expiry_final[2] + "&Param.4=" + cont + "&Param.5=" + currentD
				+ "&Param.6=" + currentTime_Final[0] + "&Param.7=" + txt_Component+ "&Param.8=" + oBatchMaterialWeighing.getView().byId("txt_CompDesc").getValue()
				+ "&Param.9=" + orderid+ "&Param.10=" + plant+ "&Param.11=" + oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getValue()
				+ "&Param.12=" + resr+ "&Param.13=MATID&Param.14=" + splitOrdBatch[0]+ "&Param.15=" + splitOrdBatch[1]+ "&Param.17=" 
				+ oBatchMaterialWeighing.getView().byId("txt_GridUOM").getValue()+"&d=" +new Date();

				oModelPrintLabel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_CreateLabelPrint&" + params + "&Content-Type=text/json", "", false);
			}

		},

		ScaleNameList: function() {

			var oModelGetBatchByOrderMaterial = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->ScaleNameList-->XACQ_GetWeighScaleList");
			oModelGetBatchByOrderMaterial.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetWeighScaleList&Content-Type=text/json", "", false);
			sap.ui.getCore().setModel(oModelGetBatchByOrderMaterial, "GetWeighScaleListData");
			oBatchMaterialWeighing.getView().byId("id_ScaleList").setSelectedKey(oModelGetBatchByOrderMaterial.getData().Rowsets.Rowset[0].Row[0].ScaleName)

		},

		method1: function(retChk) {

			if(retChk==1)
			{
				oBatchMaterialWeighing.PrintLabel();
				oBatchMaterialWeighing.GetBack();
			}

		},

		method2 : function(retChk) {

			if(retChk==1)
			{
				setBatchRow = parseInt(SelBatchRow)+1;
				batchListSelRow=setBatchRow;	
				oBatchMaterialWeighing.BatchSelection();
				oBatchMaterialWeighing.getView().byId("id_btn_ReadScale").setType("Emphasized")
				oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
			}
		},

		method3 : function(retChk) {

			if(retChk==1)
			{				
				setBatchRow = 0;	
				oBatchMaterialWeighing.PrintLabel();			
				setMatRow = parseInt(SelMatRow)+1;
				hid_curMatRow=setMatRow;
				batchListSelRow=setBatchRow;	
				oBatchMaterialWeighing.BatchSelection();
				SelRow=setMatRow;
				oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
				oBatchMaterialWeighing.getContDetails();   //Selection event called
			}
		},

		clearValues : function() {

			oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").getCustomData()[0].setValue("nuetral");
			oBatchMaterialWeighing.getView().byId("txt_ScaleWgt").setEnabled(true);
			oBatchMaterialExtraWeigh.getView().byId("txt_Container").setValue("");
			oBatchMaterialWeighing.getView().byId("id_btn_ReadScale").setEnabled(true);
			oBatchMaterialWeighing.getView().byId("id_btn_ReadScale").setType("Emphasized");
			oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setEnabled(false);
			oBatchMaterialWeighing.getView().byId("id_btn_NextIngr").setType("Default");
			oBatchMaterialWeighing.getView().byId("id_chk_partial").setSelected(false);
			sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", false);
		},

		ConfirmPartial: function() {

			if(continueFlag=="1"){
				var totalBatchRow= oModelGetOrderBatchList.getData().Rowsets.Rowset[0].Row.length;
				var totalMatRow= $(oModelGetMatPrepList.getData()).find("Row").length;

				SelMatRow = SelRow;
				SelBatchRow = batchListSelRow;
				hid_firstMatLoad = 1;
				hid_curMatRow = SelMatRow;
				setBatchRow=0;
				setMatRow=0;
				var weighedMat = hid_WeighedMat;

				if(SelMatRow<(totalMatRow-1))
				{
					if(SelBatchRow<(totalBatchRow-1))
					{
						if(weighedMat=="0")
						{
							var retChk;
							oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

								retChk=sResult;
								oBatchMaterialWeighing.method2(retChk);
							});
						}
						else
						{
							var retChk =  1;
						}

						if(retChk==1)
						{	
							setBatchRow = parseInt(SelBatchRow)+1;
							batchListSelRow = setBatchRow;
							oBatchMaterialWeighing.BatchSelection();
						}				
					}
					else
					{	//alert(weighedMat);
						if(weighedMat=="0")
						{
							var retChk;
							oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

								retChk=sResult;
								oBatchMaterialWeighing.method3(retChk);
							});
						}
						else
						{
							var retChk =  1;
						}
						//alert(retChk);
						if(retChk==1)
						{				
							setBatchRow = 0;	
							oBatchMaterialWeighing.PrintLabel();			
							setMatRow = parseInt(SelMatRow)+1;
							hid_curMatRow=setMatRow;
							batchListSelRow=setBatchRow;	
							oBatchMaterialWeighing.BatchSelection();
							SelRow=setMatRow;
							//oBatchMaterialWeighing.getContDetails();   //Selection event called
						}
					}
				}
				else if(SelMatRow==(totalMatRow-1))
				{
					if(SelBatchRow<(totalBatchRow-1))
					{
						if(weighedMat=="0")
						{
							var retChk;
							oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

								retChk=sResult;
								oBatchMaterialWeighing.method2(retChk);
							});
						}
						else
						{
							var retChk =  1;
						}

						if(retChk==1)
						{
							setBatchRow = parseInt(SelBatchRow)+1;
							batchListSelRow=setBatchRow;	
							oBatchMaterialWeighing.BatchSelection();
						}
					}
					else
					{
						if(weighedMat=="0")
						{	var retChk;
						oBatchMaterialWeighing.CheckandInsCont().then(function (sResult){

							retChk=sResult;
							oBatchMaterialWeighing.method1(retChk);
						});
						}
						else
						{
							var retChk =  1;
						}

						if(retChk==1)
						{
							oBatchMaterialWeighing.PrintLabel();
							oBatchMaterialWeighing.GetBack();
						}
					}
				}
				else
				{
					oBatchMaterialWeighing.GetBack();
				}

			}
			//hid_PartialFlag ="";

		},

		ContainerValue: function() {
			// for weighing starting in between of components
			var oData = oModelGetMatPrepList.getObject("/Rowset/Row/"+SelRow);
			oBatchMaterialWeighing.getView().byId("txt_Container").setValue($(oData).find("CONTAINER").text() );

			if(oBatchMaterialWeighing.getView().byId("txt_Container").getValue() == ""){

				var prdunit = sap.ui.getCore().getModel("BatchExecOrderFragment").oData.txt_punit;	

				var oModelGetConfigContainer = models.createNewJSONModel("com.khc.batchhub.controller.batchexecuteorder.BatchMaterialWeighing-->getContDetails-->XACQ_GetConfigContainer");
				var params = "Param.1=" + plant + "&Param.2=" + resr + "&Param.3=" + prdunit+"&d=" +new Date();
				oModelGetConfigContainer.loadData("/XMII/Illuminator?QueryTemplate=" + projectName +  "/QueryTemplate/XACQ_GetConfigContainer&" + params + "&Content-Type=text/json", "", false);

				oBatchMaterialWeighing.getView().byId("txt_Container").setValue(oModelGetConfigContainer.getData().Rowsets.Rowset[0].Row[0].CONNUM);	

			}
		},

	});
});
//# sourceURL=https://sapmiigih.mykft.net/XMII/CM/BatchHubUI5/webapp/controller/BatchExecuteOrder/BatchMaterialWeighing.controller.js?eval