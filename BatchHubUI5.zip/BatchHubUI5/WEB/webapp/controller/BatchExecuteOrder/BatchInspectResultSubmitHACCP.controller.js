sap.ui.define(["sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/m/MessageBox",
        "com/khc/batchhub/utils/UI_utilities",
        "com/khc/common/Script/CommonUtility", "com/khc/batchhub/model/models",
        "com/khc/batchhub/model/formatter", "sap/m/Dialog", "sap/m/Button", "sap/m/DateTimeInput", "sap/ui/core/Fragment"
    ],
    function(Controller, Filter, MessageBox, UI_utilities, CommonUtility, models, formatter, Dialog, Button, DateTimeInput, Fragment) {

        "use strict";
        var plant;
        var resource;
        var projectName;
        var shiftname = '';
        var shiftId = '';
        var teamId = '';
        var shiftStartTime = '';
        var shiftEndTime = '';
        var oDownTimeData;
        var sDTStartDateFormatted;
        var userName;
        var crdest;


        var InspectPoint;
        var txt_Mat;
        var crid;
        var txt_Ord;

        var currenttime;
        var currentDate = "";
        var xmiiCommand;
        var TareWeightID;
        var js_resr;
        var js_resrtxt

        var oBatchHaccpSubmit;
        
        return Controller.extend("com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectResultSubmitHACCP", {
            formatter: formatter,
            onInit: function() {
              oBatchHaccpSubmit = this;  
            }, 
            goBack: function() { 
                sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectHACCPPage", false);
                sap.ui.getCore().getModel("BatchInspectionScreenView").setProperty("/InspectionSubmitPage", true);
		  
	sap.ui.controller("com.khc.batchhub.controller.BatchExecuteOrder.BatchInspectResultSubmit").getInspCharac();
            sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", false);
   
                return; 
            },
            onLoadHaccpSubmit: function(oEvent) {
   //this.clearValue();
              plant = sap.ui.getCore().getModel("session").oData.CA_Plant;
              resource = sap.ui.getCore().getModel("session").oData.CA_Resource; 
              projectName = sap.ui.getCore().getModel("session").oData.CA_ProjectName;
              userName = sap.ui.getCore().getModel("session").oData.CA_IllumLoginName;
              crdest = sap.ui.getCore().getModel("session").oData.CA_CRDest;
             oBatchHaccpSubmit.getView().byId("id_btn_Save").setEnabled(true); 
              this.getInspChar();
  
          },
          clearValue: function() {
             oBatchHaccpSubmit.getView().byId("txt_ResourceText").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_ordstrip").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_phstxt").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_matstrip").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_desc").setValue("");

             oBatchHaccpSubmit.getView().byId("id_txt_inslot").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_insdate").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_inschar").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_inslower").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_insupper").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_insresult").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_inseval").setValue(""); 
               
             oBatchHaccpSubmit.getView().byId("id_ta_corract").setValue(""); 
             oBatchHaccpSubmit.getView().byId("textURL").setContent("")
             oBatchHaccpSubmit.getView().byId("id_ta_longtext").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_acknow").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_verified").setValue(""); 
             oBatchHaccpSubmit.getView().byId("id_txt_datetime").setValue(""); 
          }, 
             
   getInspChar: function() {
                          // APLT_CMD_GetInspChar
            // Clear Input
              oBatchHaccpSubmit.getView().byId("id_ta_longtext").setValue("");
              oBatchHaccpSubmit.getView().byId("id_txt_acknow").setValue("");
              oBatchHaccpSubmit.getView().byId("id_txt_verified").setValue("");
              oBatchHaccpSubmit.getView().byId("id_txt_datetime").setValue("");

              var inslot = oBatchHaccpSubmit.getView().byId("id_txt_inslot").getValue();
              var txt_phs = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_phs");             
              var oGetInspCharModel =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit-->getInspChar-->SQLQ_GetInspChar");
              var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + inslot + "&Param.4=" + txt_phs+"&d=" +new Date();
              oGetInspCharModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetInspChar&" + params + "&Content-Type=text/json", "", false);
              if (CommonUtility.getJsonModelRowCount(oGetInspCharModel.getData()) > 0 ) {
                  var getInspCharData = oGetInspCharModel.getData().Rowsets.Rowset[0].Row[0];
                  

                      var corract = getInspCharData.CORRACTION;
                      var urls = getInspCharData.URLLINKS;
                      var ccpind = getInspCharData.CCPIND;
                      var urls1 = urls.split("\r\n");

                      var urllinks = "";
                      for (var i = 0; i < urls1.length; i++) {
                          if (urls1[i].indexOf("www.") == "0") {
                              urls1[i] = "http://" + urls1[i];
                          }
                          //if no  url then main menu is opening, to fix that added about:blank
                          if(!urls1[i]){
                             urls1[i] = "about:blank";
                          }
                          var docno = i + 1;
                          urllinks = urllinks + "\n" + "<a target=\"_blank\" href=\"" + urls1[i].replace("\n", "\"") + "\">" + "Document-" + docno + "<\/a>";

                      }
                      oBatchHaccpSubmit.getView().byId("id_ta_corract").setValue(corract);
                    
                      oBatchHaccpSubmit.getView().byId("textURL").setContent(urllinks)
                      /*
                       * document.getElementById("textURL").innerHTML =
                       * urllinks;
                       */
                  
              }

              var inslot = oBatchHaccpSubmit.getView().byId("id_txt_inslot").getValue();
              var txt_phs = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_phs");
              var char = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_inspChar");
              var insdate = oBatchHaccpSubmit.getView().byId("id_txt_insdate").getValue();
              var inspcount = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_inspcount");
              var ccpsign =   sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_ccpsign");   

              // APLT_CMD_GetInspPoint
             
              var oGetInspCharModel =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit-->getInspChar-->SQLQ_GetInspectionPointListHACCP");

              var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + inslot + "&Param.4=" +
                  txt_phs + "&Param.5=" + char + "&Param.6=" + insdate + "&Param.7=" + inspcount+"&d=" +new Date();
              oGetInspCharModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetInspectionPointListHACCP&" + params + "&Content-Type=text/json", "", false);

              if (CommonUtility.getJsonModelRowCount(oGetInspCharModel.getData()) > 0 ) {
                  var getGetInspPointData = oGetInspCharModel.getData().Rowsets.Rowset[0].Row[0];
                  

                      var signstatus = getGetInspPointData.SIGNSTATUS;
                      if (signstatus == "1") {
                          oBatchHaccpSubmit.getView().byId("id_ta_longtext").setValue(getGetInspPointData.LONGTEXT);
                          oBatchHaccpSubmit.getView().byId("id_txt_acknow").setValue(getGetInspPointData.CORRSIGN1USER);
                          if (ccpsign == "CCP1")
                              oBatchHaccpSubmit.getView().byId("id_txt_verified").setValue(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0166"));
                          else
                              oBatchHaccpSubmit.getView().byId("id_txt_verified").setValue(getGetInspPointData.CORRSIGN2USER);

                          oBatchHaccpSubmit.getView().byId("id_txt_datetime").setValue(getGetInspPointData.CORRSIGN1DATE);
                          oBatchHaccpSubmit.getView().byId("id_btn_Save").setEnabled(false)
                      }
                   
              }
          },

          Save: function() {
              // new ccheck command
              var ccpsign =  sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_ccpsign");   

              xmiiCommand = new com.sap.xmii.chart.hchart.i5Command("GBL_BatchHub/QueryTemplate/SQLQ_GetPlant", projectName + "/DisplayTemplate/CMD_VerifyDigitalSignature");

              if (ccpsign.indexOf("CCP") == "0")
                  xmiiCommand.setCommandAudit(true)
              else
                  xmiiCommand.setCommandAudit(false)

              if (ccpsign == "CCP2") {
                  var role = sap.ui.getCore().getModel("session").getProperty("/HACCPSign2Role");
                  xmiiCommand.getCommandObject().setCommandRole2(role)
              }

              xmiiCommand.executeCommand();
              xmiiCommand.registerCommandCompletionEventHandler(oBatchHaccpSubmit.UpdInspPointDataStatus);


          },

          UpdInspPointDataStatus: function() {
             var that = oBatchHaccpSubmit;

              var longtext = that.getView().byId("id_ta_longtext").getValue();
              var inslot = that.getView().byId("id_txt_inslot").getValue();
              var txt_phs = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_phs");
              var char = sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_inspChar");
              var insdate = that.getView().byId("id_txt_insdate").getValue();
              var ccpsign =  sap.ui.getCore().getModel("oViewHACCPParam").getProperty("/qs_ccpsign");   


              var currentDT = CommonUtility.getCurrentDateTime(new Date()).replace(" ","T");
              // APLT_CMD_UpdInspPointData
            
              var oUpdInspPointData =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit-->UpdInspPointDataStatus-->XACQ_UpdInspectPointLongTextandSignV1HACCP");

              var params = "Param.1=" + longtext + "&Param.2=" + plant + "&Param.3=" + resource + "&Param.4=" +
                  inslot + "&Param.5=" + txt_phs + "&Param.6=" + char + "&Param.7=" + insdate +
                  "&Param.9=" + currentDT + "&Param.10=" + xmiiCommand.commandUserID1 + "&Param.11=" + xmiiCommand.commandUserID2+"&d=" +new Date();
              oUpdInspPointData.loadData("/XMII/Illuminator?QueryTemplate=RepHubUI5/Query/XACQ_UpdInspectPointLongTextandSignV1HACCP&" + params + "&Content-Type=text/json", "", false);

              if (CommonUtility.getJsonModelRowCount(oUpdInspPointData.getData()) > 0 ) { 
                      // APLT_CMD_GetInspPoint
                    
                      var oGetInspPointModel =  models.createNewJSONModel("com.khc.rephub.controller.quality.InspectResultHaccpSubmit-->UpdInspPointDataStatus-->SQLQ_GetInspectionPointListHACCP");

                      var params = "Param.1=" + plant + "&Param.2=" + resource + "&Param.3=" + inslot + "&Param.4=" +
                          txt_phs + "&Param.5=" + char + "&Param.6=" + insdate+"&d=" +new Date();
                      oGetInspPointModel.loadData("/XMII/Illuminator?QueryTemplate=" + projectName + "/QueryTemplate/SQLQ_GetInspectionPointListHACCP&" + params + "&Content-Type=text/json", "", false);
                      if (CommonUtility.getJsonModelRowCount(oGetInspPointModel.getData()) > 0 ) {
                          var getInspData = oGetInspPointModel.getData().Rowsets.Rowset[0].Row[0];
                         

                              var signstatus = getInspData.SIGNSTATUS;
                              if (signstatus == "1") { 
                                 var sNoShiftMsg = "Updated Successfully.";
                                  sap.ui.getCore().getModel("oPageMessage").setProperty("/message", sNoShiftMsg);
                                  sap.ui.getCore().getModel("oPageMessage").setProperty("/showMessage", true);
                                  sap.ui.getCore().getModel("oPageMessage").setProperty("/type", "Success");
 
                                  that.getView().byId("id_ta_longtext").setValue(getInspData.LONGTEXT);
                                  that.getView().byId("id_txt_acknow").setValue(getInspData.CORRSIGN1USER);
                                  if (ccpsign == "CCP1")
                                      that.getView().byId("id_txt_verified").setValue(sap.ui.getCore().getModel("i18n").getProperty("HUB_MSG_0166"));
                                  else
                                      that.getView().byId("id_txt_verified").setValue(getInspData.CORRSIGN2USER);

                                  that.getView().byId("id_txt_datetime").setValue(getInspData.CORRSIGN1DATE);
                                  that.getView().byId("id_btn_Save").setEnabled(false)

                              }
                          
                      } 
              }

          },


      });
  });