
function ShowType(tdid){
document.getElementById("id_dttype").innerHTML=document.getElementById(tdid+"s").innerHTML;
}

function HideType(){
document.getElementById("id_dttype").innerHTML="";
}

function ajaxFunction(url,obj){

	
	
	jQuery.ajax({
			url: url,
		            type : 'GET',
			async:false,
		      	success : function (htmlData) {
				//console.log("Sucess");
				document.getElementById(obj).innerHTML = htmlData;
            }
});
	
			 
  
}

function getCurrentDateTime(dt)
{
		if(dt.getHours() < 10) {
			var hour = "0"+dt.getHours();
	            }
		else{
			var hour=dt.getHours();
		}

		if(dt.getMinutes() < 10) {
			var min = "0"+dt.getMinutes();
	            }
		else{
			var min=dt.getMinutes();
		}

		if(dt.getSeconds() < 10) {
			var sec = "0"+dt.getSeconds();
	            }
		else{
			var sec=dt.getSeconds();
		}

return formatDate(dt)+" "+hour+":"+min+":"+sec;
}

function formatDate(dt)
{
		if(dt.getDate() < 10) {
			var day = "0"+dt.getDate();
	            }
		else{
			var day=dt.getDate();
		}

		if(dt.getMonth()+1 < 10) {
			var month = "0"+eval(dt.getMonth()+1);
	            }
		else{
			var month=eval(dt.getMonth()+1);
		}		
		//return dt.getYear() + "-" +month +"-"+day;
		return dt.getFullYear() + "-" +month +"-"+day;

}
