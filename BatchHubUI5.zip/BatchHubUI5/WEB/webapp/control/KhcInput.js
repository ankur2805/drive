sap.ui.define([
	"sap/m/Input"
], function (Input) {
	"use strict";

	return Input.extend("com.khc.batchhub.control.KhcInput", {

		metadata: {
			events: {
                focus: {}
            }
		  },
		 
		  renderer: {},
		  
		 
				  
	  onfocusin : function(evt) {
					   
					  console.log("onfocus 1");
					  this.fireFocus();
					  },
					  

	});
});